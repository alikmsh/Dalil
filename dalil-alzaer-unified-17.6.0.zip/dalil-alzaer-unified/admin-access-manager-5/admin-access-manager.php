<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // جلوگیری از دسترسی مستقیم
}

class AAM_Admin_Access_Manager {

    const OPTION_KEY = 'aam_admin_permissions';
    const CAP_MANAGE = 'manage_options';

    // مشخصات مدیر اصلی - فقط همین کاربر اجازه دارد این افزونه را ببیند و تنظیم کند.
    const MASTER_USERNAME = 'alikmsh';
    const MASTER_EMAIL    = 'alikmsh1381@gmail.com';

    // منوهایی که همیشه برای همه باز است (نیازی به تیک ندارد)
    private $always_allowed_slugs = array( 'index.php', 'profile.php' );

    // منوهایی که همیشه برای ادمین‌های محدودشده کاملاً بسته است، صرف نظر از هر تنظیمی
    private $always_blocked_slugs = array( 'plugins.php', 'plugin-install.php', 'plugin-editor.php', 'aam-settings' );

    public function __construct() {
        add_action( 'admin_menu', array( $this, 'register_settings_page' ), 999 );
        add_action( 'admin_menu', array( $this, 'restrict_menus' ), 100000 );
        add_action( 'admin_init', array( $this, 'restrict_direct_access' ) );
        add_filter( 'all_plugins', array( $this, 'filter_plugins_list' ) );
    }

    private function is_master_admin( $user_id = null ) {
        $user = $user_id ? get_userdata( $user_id ) : wp_get_current_user();
        if ( ! $user || ! $user->exists() ) {
            return false;
        }
        return ( $user->user_login === self::MASTER_USERNAME && strtolower( $user->user_email ) === strtolower( self::MASTER_EMAIL ) );
    }

    private function should_restrict_current_user() {
        if ( $this->is_master_admin() ) {
            return false;
        }
        if ( ! current_user_can( 'administrator' ) ) {
            return false; // این پلاگین فقط برای ادمین‌ها اعمال می‌شود
        }
        return true;
    }

    /**
     * لیست منوهای سطح بالای پیشخوان (شامل منوهای افزونه‌ها) که می‌توان دسترسی به آن‌ها را کنترل کرد.
     */
    private function get_top_level_menu_items() {
        global $menu;
        $items = array();
        if ( empty( $menu ) ) {
            return $items;
        }
        foreach ( $menu as $item ) {
            if ( empty( $item[2] ) || strpos( $item[2], 'separator' ) !== false ) {
                continue;
            }
            $slug = $item[2];
            if ( in_array( $slug, $this->always_allowed_slugs, true ) || in_array( $slug, $this->always_blocked_slugs, true ) ) {
                continue; // این‌ها نیازی به چک‌باکس ندارند
            }
            $title = wp_strip_all_tags( $item[0] );
            if ( empty( $title ) ) {
                continue;
            }
            $items[ $slug ] = $title;
        }
        return $items;
    }

    /**
     * برای یک slug مشخص (چه منوی اصلی، چه زیرمنو) نام منوی سطح بالای والدش را برمی‌گرداند.
     * اگر خودش منوی سطح بالا باشد، همان slug را برمی‌گرداند.
     */
    private function get_top_parent_slug( $slug ) {
        global $submenu;
        if ( ! empty( $submenu ) ) {
            foreach ( $submenu as $parent_slug => $subs ) {
                foreach ( $subs as $sub ) {
                    if ( isset( $sub[2] ) && $sub[2] === $slug ) {
                        return $parent_slug;
                    }
                }
            }
        }
        return $slug; // خودش سطح بالاست یا زیرمنوی شناخته‌شده‌ای برایش پیدا نشد
    }

    public function register_settings_page() {
        if ( ! current_user_can( self::CAP_MANAGE ) || ! $this->is_master_admin() ) {
            return; // فقط مدیر اصلی این صفحه تنظیمات را می‌بیند
        }
        add_menu_page(
            'دسترسی ادمین‌ها',
            'دسترسی ادمین‌ها',
            self::CAP_MANAGE,
            'aam-settings',
            array( $this, 'render_settings_page' ),
            'dashicons-lock',
            100
        );

        if ( isset( $_POST['aam_save_permissions'] ) && check_admin_referer( 'aam_save_permissions_action', 'aam_nonce' ) ) {
            $this->save_permissions();
        }
    }

    private function save_permissions() {
        $settings = get_option( self::OPTION_KEY, array() );

        $posted_perms = isset( $_POST['aam_perms'] ) && is_array( $_POST['aam_perms'] ) ? $_POST['aam_perms'] : array();
        $settings['users'] = array();
        foreach ( $posted_perms as $user_id => $slugs ) {
            $user_id = (int) $user_id;
            $settings['users'][ $user_id ] = array_map( 'sanitize_text_field', (array) $slugs );
        }

        update_option( self::OPTION_KEY, $settings );
        add_action( 'admin_notices', function () {
            echo '<div class="notice notice-success is-dismissible"><p>تنظیمات دسترسی با موفقیت ذخیره شد.</p></div>';
        } );
    }

    public function render_settings_page() {
        $menu_items = $this->get_top_level_menu_items();

        $settings    = get_option( self::OPTION_KEY, array() );
        $saved_users = isset( $settings['users'] ) ? $settings['users'] : array();

        $admins = get_users( array( 'role' => 'administrator', 'orderby' => 'ID', 'order' => 'ASC' ) );
        $admins = array_filter( $admins, function ( $u ) {
            return ! $this->is_master_admin( $u->ID );
        } );
        ?>
        <div class="wrap" dir="rtl" style="font-family: Tahoma, sans-serif;">
            <h1>مدیریت دسترسی ادمین‌ها</h1>
            <p>این صفحه فقط برای کاربر <strong><?php echo esc_html( self::MASTER_USERNAME ); ?></strong> قابل مشاهده است.</p>
            <p>
                هر منویی که برای یک ادمین تیک بزنی (شامل منوهایی که خودِ افزونه‌ها می‌سازند، مثل «استوری»)،
                هم در نوار کناری پیشخوانش نمایش داده می‌شود و هم به تمام زیرصفحات و امکانات داخلی همان بخش دسترسی پیدا می‌کند.<br>
                صفحه‌ی «افزونه‌ها» (نصب/فعال/غیرفعال‌سازی) در هر حالت فقط برای تو باز است.
            </p>

            <form method="post">
                <?php wp_nonce_field( 'aam_save_permissions_action', 'aam_nonce' ); ?>

                <?php if ( empty( $admins ) ) : ?>
                    <p><em>هیچ ادمین دیگری (به‌جز خودت) پیدا نشد.</em></p>
                <?php endif; ?>

                <?php foreach ( $admins as $admin ) :
                    $user_slugs = isset( $saved_users[ $admin->ID ] ) ? $saved_users[ $admin->ID ] : array();
                    ?>
                    <div style="border:1px solid #ccd0d4; background:#fff; padding:16px 20px; margin:20px 0; max-width:1000px;">
                        <h2 style="margin-top:0;"><?php echo esc_html( $admin->user_login ); ?>
                            <span style="font-weight:normal; color:#777; font-size:14px;"> (<?php echo esc_html( $admin->user_email ); ?>)</span>
                        </h2>
                        <div>
                            <?php if ( empty( $menu_items ) ) : ?>
                                <p><em>موردی یافت نشد.</em></p>
                            <?php endif; ?>
                            <?php foreach ( $menu_items as $slug => $title ) : ?>
                                <label style="display:inline-block; width:240px; margin-bottom:6px;">
                                    <input type="checkbox"
                                           name="aam_perms[<?php echo esc_attr( $admin->ID ); ?>][]"
                                           value="<?php echo esc_attr( $slug ); ?>"
                                           <?php checked( in_array( $slug, $user_slugs, true ) ); ?>>
                                    <?php echo esc_html( $title ); ?>
                                </label>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endforeach; ?>

                <p class="submit">
                    <button type="submit" name="aam_save_permissions" class="button button-primary">ذخیره تنظیمات</button>
                </p>
            </form>
        </div>
        <?php
    }

    /**
     * حذف منوها/زیرمنوهایی که کاربر اجازه دسترسی به منوی والدشان را ندارد.
     */
    public function restrict_menus() {
        global $menu;

        if ( ! $this->should_restrict_current_user() ) {
            return;
        }

        $settings = get_option( self::OPTION_KEY, array() );
        $user_id  = get_current_user_id();
        $allowed  = isset( $settings['users'][ $user_id ] ) ? $settings['users'][ $user_id ] : array();

        if ( empty( $menu ) ) {
            return;
        }

        foreach ( $menu as $item ) {
            if ( empty( $item[2] ) ) {
                continue;
            }
            $slug = $item[2];
            if ( in_array( $slug, $this->always_allowed_slugs, true ) ) {
                continue;
            }
            if ( in_array( $slug, $this->always_blocked_slugs, true ) || ! in_array( $slug, $allowed, true ) ) {
                remove_menu_page( $slug );
            }
        }
    }

    /**
     * جلوگیری از دسترسی مستقیم به صفحه‌ای که خارج از منوهای مجاز است (با وارد کردن آدرس).
     * زیرمنوی هر بخش هم مجاز شمرده می‌شود اگر منوی سطح بالای همان بخش مجاز باشد.
     */
    public function restrict_direct_access() {
        if ( ! $this->should_restrict_current_user() || wp_doing_ajax() ) {
            return;
        }

        global $pagenow;
        $always_allowed_pages = array( 'profile.php', 'index.php', 'admin-ajax.php', 'async-upload.php' );
        if ( in_array( $pagenow, $always_allowed_pages, true ) ) {
            return;
        }

        // ساخت slug فعلی، مطابق همان قالبی که وردپرس در $menu/$submenu استفاده می‌کند
        $current_slug = $pagenow;
        if ( $pagenow === 'admin.php' && isset( $_GET['page'] ) ) {
            $current_slug = sanitize_text_field( wp_unslash( $_GET['page'] ) );
        } elseif ( in_array( $pagenow, array( 'edit.php', 'post-new.php', 'edit-tags.php', 'term.php' ), true )
                   && isset( $_GET['post_type'] ) && sanitize_text_field( wp_unslash( $_GET['post_type'] ) ) !== 'post' ) {
            $current_slug = $pagenow . '?post_type=' . sanitize_text_field( wp_unslash( $_GET['post_type'] ) );
        }

        if ( in_array( $current_slug, $this->always_blocked_slugs, true ) ) {
            wp_die( 'شما اجازه دسترسی به این بخش را ندارید.', 'دسترسی غیرمجاز', array( 'response' => 403, 'back_link' => true ) );
        }

        $settings = get_option( self::OPTION_KEY, array() );
        $user_id  = get_current_user_id();
        $allowed  = isset( $settings['users'][ $user_id ] ) ? $settings['users'][ $user_id ] : array();

        $top_parent = $this->get_top_parent_slug( $current_slug );

        if ( ! in_array( $top_parent, $allowed, true ) && ! in_array( $current_slug, $allowed, true ) ) {
            wp_die( 'شما اجازه دسترسی به این بخش را ندارید.', 'دسترسی غیرمجاز', array( 'response' => 403, 'back_link' => true ) );
        }
    }

    /**
     * صفحه‌ی «افزونه‌ها» را به‌کل از دید ادمین‌های محدودشده مخفی می‌کند (لایه‌ی دفاعی اضافه).
     */
    public function filter_plugins_list( $all_plugins ) {
        if ( ! is_admin() || ! $this->should_restrict_current_user() ) {
            return $all_plugins;
        }
        return array();
    }
}

new AAM_Admin_Access_Manager();
