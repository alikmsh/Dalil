<?php
if (!defined('ABSPATH')) exit;

define('DBD_VERSION', '3.0.0');
define('DBD_PATH', plugin_dir_path(__FILE__));
define('DBD_URL', plugin_dir_url(__FILE__));

require_once DBD_PATH . 'includes/class-dbd-post-type.php';
require_once DBD_PATH . 'includes/class-dbd-room.php';
require_once DBD_PATH . 'includes/class-dbd-meta.php';
require_once DBD_PATH . 'includes/class-dbd-icons.php';
require_once DBD_PATH . 'includes/class-dbd-look.php';
require_once DBD_PATH . 'includes/class-dbd-cards.php';
require_once DBD_PATH . 'includes/class-dbd-ui.php';
require_once DBD_PATH . 'includes/class-dbd-admin.php';
require_once DBD_PATH . 'includes/class-dbd-expiration.php';
require_once DBD_PATH . 'includes/class-dbd-frontend.php';
require_once DBD_PATH . 'includes/class-dbd-elementor.php';
require_once DBD_PATH . 'includes/class-dbd-reviews.php';
require_once DBD_PATH . 'includes/class-dbd-detail.php';
require_once DBD_PATH . 'includes/class-dbd-register.php';
require_once DBD_PATH . 'includes/class-dbd-settings.php';
require_once DBD_PATH . 'includes/class-dbd-owner.php';
require_once DBD_PATH . 'includes/class-dbd-showcase.php'; // 17.5: «قاعات الأفراح وباغ تالار» + «صالونات التجميل»

function dbd_activate() {
    DBD_Post_Type::register();
    DBD_Room::register();
    flush_rewrite_rules();
    if (!wp_next_scheduled('dbd_check_expirations')) {
        wp_schedule_event(time() + 300, 'hourly', 'dbd_check_expirations');
    }
}
register_activation_hook(__FILE__, 'dbd_activate');

function dbd_deactivate() {
    wp_clear_scheduled_hook('dbd_check_expirations');
    flush_rewrite_rules();
}
register_deactivation_hook(__FILE__, 'dbd_deactivate');

DBD_Post_Type::init();
DBD_Room::init();
DBD_Meta::init();
DBD_Admin::init();
DBD_Expiration::init();
DBD_Frontend::init();
DBD_Elementor::init();
DBD_Reviews::init();
DBD_Register::init();
DBD_Settings::init();
DBD_Owner::init();
// [dalil_sections preset="food|shop|med|cos|sal|leg" title=""] — the ready section grids without Elementor
add_shortcode('dalil_sections', function ($a) {
    $a = shortcode_atts(['preset' => 'food', 'title' => '', 'columns' => ''], $a);
    $all = DBD_UI::presets();
    $p = $all[$a['preset']] ?? $all['food'];
    $items = [];
    foreach ($p[3] as $x) $items[] = ['image' => DBD_UI::img($x[1]), 'title' => $x[0], 'link' => ''];
    return DBD_UI::sections(['title' => $a['title'] !== '' ? $a['title'] : $p[0], 'style' => $p[1], 'columns' => $a['columns'] !== '' ? $a['columns'] : (string) $p[2], 'items' => $items]);
});
