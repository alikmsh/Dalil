<?php
/**
 * «تنظیمات نقشه» — which map tiles the listings use.
 * Default: OpenStreetMap (free, street names in the local language).
 * With a MapTiler key (free plan) or any tile URL, labels can be Arabic.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DBD_Settings {

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 30 );
		add_action( 'admin_init', array( __CLASS__, 'register' ) );
	}

	public static function menu() {
		add_submenu_page( 'edit.php?post_type=dbd_business', 'تنظیمات نقشه و تماس', 'تنظیمات نقشه و تماس', 'manage_options', 'dbd-map-settings', array( __CLASS__, 'page' ) );
	}

	public static function register() {
		register_setting( 'dbd_map', 'dbd_contact', array(
			'type'              => 'array',
			'sanitize_callback' => function ( $v ) {
				$v = is_array( $v ) ? $v : array();
				return array(
					'on'    => empty( $v['on'] ) ? 0 : 1,
					'phone' => trim( preg_replace( '/[^\d+\s]/', '', DBD_Meta::digits( $v['phone'] ?? '' ) ) ),
					'wa'    => trim( preg_replace( '/[^\d+]/', '', DBD_Meta::digits( $v['wa'] ?? '' ) ) ),
					'label' => sanitize_text_field( $v['label'] ?? '' ),
				);
			},
		) );
		register_setting( 'dbd_map', 'dbd_map', array(
			'type'              => 'array',
			'sanitize_callback' => function ( $v ) {
				$v = is_array( $v ) ? $v : array();
				$t = trim( (string) ( $v['tiles'] ?? '' ) );
				return array(
					'maptiler' => preg_replace( '/[^A-Za-z0-9_\-]/', '', (string) ( $v['maptiler'] ?? '' ) ),
					'tiles'    => ( $t && preg_match( '#^https://#', $t ) && false !== strpos( $t, '{z}' ) ) ? esc_url_raw( $t ) : '',
					'attr'     => sanitize_text_field( $v['attr'] ?? '' ),
				);
			},
		) );
	}

	public static function page() {
		$o = wp_parse_args( get_option( 'dbd_map', array() ), array( 'maptiler' => '', 'tiles' => '', 'attr' => '' ) );
		?>
		<div class="wrap" dir="rtl">
			<h1>تنظیمات نقشه و تماس</h1>
			<p>نقشه‌ی پیش‌فرض OpenStreetMap است؛ رایگان است ولی اسم خیابان‌های ایران را فارسی نشان می‌دهد. برای برچسب‌های عربی، یک کلید رایگان <a href="https://cloud.maptiler.com/account/keys/" target="_blank" rel="noopener">MapTiler</a> بسازید و این‌جا وارد کنید.</p>
			<form method="post" action="options.php">
				<?php settings_fields( 'dbd_map' ); ?>
				<table class="form-table" role="presentation">
					<tr><th scope="row"><label for="dbd-mt">کلید MapTiler</label></th><td><input id="dbd-mt" class="regular-text" dir="ltr" name="dbd_map[maptiler]" value="<?php echo esc_attr( $o['maptiler'] ); ?>"><p class="description">خالی = OpenStreetMap.</p></td></tr>
					<tr><th scope="row"><label for="dbd-tu">آدرس دلخواه کاشی‌ها (پیشرفته)</label></th><td><input id="dbd-tu" class="large-text" dir="ltr" name="dbd_map[tiles]" value="<?php echo esc_attr( $o['tiles'] ); ?>" placeholder="https://…/{z}/{x}/{y}.png"><p class="description">اگر پر شود به جای MapTiler استفاده می‌شود. باید با https شروع شود و {z} {x} {y} داشته باشد.</p></td></tr>
					<tr><th scope="row"><label for="dbd-at">متن حق نشر نقشه</label></th><td><input id="dbd-at" class="regular-text" name="dbd_map[attr]" value="<?php echo esc_attr( $o['attr'] ); ?>" placeholder="© OpenStreetMap"></td></tr>
				</table>
				<?php $fb = DBD_Look::fallback(); ?>
				<h2>تماس آگهی‌هایی که شماره ندارند</h2>
				<p style="max-width:760px;line-height:2">تا همه‌ی آگهی‌ها مثل هتل‌ها دکمه‌ی «اتصال» و «واتساب» داشته باشند: اگر آگهی‌ای شماره و واتساپ خودش را نداشته باشد، این شماره‌ها (دلیل الزائر) نمایش داده می‌شود و پیام واتساپ با نام همان مکان آماده است. هر آگهی که شماره‌ی خودش را داشته باشد، شماره‌ی خودش نمایش داده می‌شود.</p>
				<table class="form-table" role="presentation">
					<tr><th scope="row">فعال</th><td><label><input type="checkbox" name="dbd_contact[on]" value="1" <?php checked( $fb['on'] ); ?>> برای آگهی‌های بدون شماره، شماره‌ی دلیل الزائر نمایش داده شود</label></td></tr>
					<tr><th scope="row"><label for="dbd-fp">شماره تماس</label></th><td><input id="dbd-fp" class="regular-text" dir="ltr" name="dbd_contact[phone]" value="<?php echo esc_attr( $fb['phone'] ); ?>"></td></tr>
					<tr><th scope="row"><label for="dbd-fw">واتساپ</label></th><td><input id="dbd-fw" class="regular-text" dir="ltr" name="dbd_contact[wa]" value="<?php echo esc_attr( $fb['wa'] ); ?>"><p class="description">با کد کشور، مثلاً 9647822719796</p></td></tr>
					<tr><th scope="row"><label for="dbd-fl">عنوان شماره</label></th><td><input id="dbd-fl" class="regular-text" name="dbd_contact[label]" value="<?php echo esc_attr( $fb['label'] ); ?>"></td></tr>
				</table>
				<?php submit_button( 'ذخیره' ); ?>
			</form>
			<h2>شورت‌کدها</h2>
			<p><code>[dalil_shop_register]</code> فرم «سجّل متجرك» برای صاحبان مغازه — مغازه بعد از تأیید شما نمایش داده می‌شود.<br><code>[dalil_map_banner kind="shopping"]</code> بنر «الخريطة» به‌تنهایی.</p>
		</div>
		<?php
	}
}
