<?php
if (!defined('ABSPATH')) exit;

class DBD_Expiration {
    public static function init() {
        add_action('dbd_check_expirations', [__CLASS__, 'check']);
    }

    public static function check() {
        $posts = get_posts([
            'post_type'=>'dbd_business',
            'post_status'=>'publish',
            'posts_per_page'=>-1,
            'fields'=>'ids',
        ]);
        $today = current_time('Y-m-d');
        foreach ($posts as $id) {
            $end = DBD_Meta::get($id,'end_date');
            if ($end && $today >= $end) {
                update_post_meta($id, '_dbd_manual_active', '0');
            }
        }
    }
}
