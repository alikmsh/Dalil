<?php
/**
 * One icon catalogue for the whole directory: feature chips, guarantees, admin icon picker.
 * Line icons, 24×24, drawn with currentColor.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DBD_Icons {

	/** key => [Persian label for the admin picker, SVG paths] */
	public static function all() {
		static $all = null;
		if ( null !== $all ) {
			return $all;
		}
		$all = array(
			'star'      => array( 'ستاره', '<path d="m12 3.6 2.6 5.3 5.8.8-4.2 4.1 1 5.8-5.2-2.7-5.2 2.7 1-5.8-4.2-4.1 5.8-.8z"/>' ),
			'crown'     => array( 'تاج / VIP', '<path d="M4 18h16M5 15 3.5 7l5 3.5L12 5l3.5 5.5 5-3.5L19 15z"/>' ),
			'shield'    => array( 'موثق / امن', '<path d="M12 3.5 5 6.2v5.3c0 4.4 3 7.7 7 9 4-1.3 7-4.6 7-9V6.2z"/><path d="m9 12 2.2 2.2L15.2 10"/>' ),
			'medal'     => array( 'کیفیت', '<circle cx="12" cy="14.5" r="5.5"/><path d="M9 9.6 6.5 3.5h3.5L12 8M15 9.6l2.5-6.1H14L12 8"/><path d="m12 12 .9 1.8 2 .3-1.4 1.4.3 2-1.8-.9-1.8.9.3-2-1.4-1.4 2-.3z"/>' ),
			'truck'     => array( 'ارسال / توصیل', '<path d="M3 7h11v9H3zM14 10h4l3 3v3h-7"/><circle cx="7" cy="18" r="1.8"/><circle cx="17" cy="18" r="1.8"/>' ),
			'gift'      => array( 'هدیه / بسته‌بندی', '<rect x="4" y="9" width="16" height="11" rx="1.5"/><path d="M3 9h18M12 9v11M12 9c-1.5-3.5-5-4-5-1.5S10 9 12 9zM12 9c1.5-3.5 5-4 5-1.5S14 9 12 9z"/>' ),
			'box'       => array( 'جعبه', '<path d="M4 8 12 4l8 4v8l-8 4-8-4z"/><path d="m4 8 8 4 8-4M12 12v8"/>' ),
			'percent'   => array( 'تخفیف', '<path d="M18 6 6 18"/><circle cx="7.5" cy="7.5" r="2.3"/><circle cx="16.5" cy="16.5" r="2.3"/>' ),
			'tag'       => array( 'قیمت', '<path d="M3.5 12.5V4.5h8l9 9-8 8z"/><circle cx="8" cy="9" r="1.5"/>' ),
			'card'      => array( 'کارت بانکی', '<rect x="3" y="6" width="18" height="12.5" rx="2"/><path d="M3 10h18M6.5 15h4"/>' ),
			'cash'      => array( 'پول نقد', '<rect x="3" y="6.5" width="18" height="11" rx="2"/><circle cx="12" cy="12" r="2.6"/><path d="M6 9.5v5M18 9.5v5"/>' ),
			'arabic'    => array( 'عربی صحبت می‌کنیم', '<path d="M4 5.5h16v10H9l-5 4z"/><path d="M9 9.5h6M9 12h4"/>' ),
			'mosque'    => array( 'نزدیک حرم', '<path d="M12 3v2M12 5c-3.5 1.6-5.5 4-5.5 7h11c0-3-2-5.4-5.5-7zM5 12h14v8H5zM10 20v-4a2 2 0 0 1 4 0v4M3 20h18"/>' ),
			'pin'       => array( 'موقعیت', '<path d="M12 21.2s-6.6-6.1-6.6-11.2a6.6 6.6 0 0 1 13.2 0c0 5.1-6.6 11.2-6.6 11.2z"/><circle cx="12" cy="10" r="2.5"/>' ),
			'clock'     => array( 'ساعت', '<circle cx="12" cy="12" r="8.2"/><path d="M12 7.6V12l3 1.9"/>' ),
			'open24'    => array( '۲۴ ساعته', '<circle cx="12" cy="12" r="8.5"/><path d="M12 7v5l3.5 2"/>' ),
			'phone'     => array( 'تلفن', '<path d="M6.6 3.8h2.6l1.4 4-2 1.3a11 11 0 0 0 6.3 6.3l1.3-2 4 1.4v2.6a2 2 0 0 1-2.1 2A16.5 16.5 0 0 1 4.6 5.9a2 2 0 0 1 2-2.1z"/>' ),
			'support'   => array( 'پشتیبانی', '<path d="M4 14v-2a8 8 0 0 1 16 0v2"/><path d="M4 14a2 2 0 0 1 2-2h1v6H6a2 2 0 0 1-2-2zM20 14a2 2 0 0 0-2-2h-1v6h1a2 2 0 0 0 2-2zM18 18v.5a2.5 2.5 0 0 1-2.5 2.5H12"/>' ),
			'wifi'      => array( 'وای‌فای', '<path d="M3 9.5a13 13 0 0 1 18 0M6 12.8a8.5 8.5 0 0 1 12 0M9 16a4 4 0 0 1 6 0"/><circle cx="12" cy="19" r="1.2" fill="currentColor"/>' ),
			'ac'        => array( 'کولر', '<path d="M12 3v18M4.2 7.5l15.6 9M19.8 7.5l-15.6 9M9.5 4.5 12 6l2.5-1.5M9.5 19.5 12 18l2.5 1.5"/>' ),
			'parking'   => array( 'پارکینگ', '<rect x="4" y="4" width="16" height="16" rx="3"/><path d="M10 16.5v-9h3a2.6 2.6 0 0 1 0 5.2h-3"/>' ),
			'elevator'  => array( 'آسانسور', '<rect x="5" y="3.5" width="14" height="17" rx="2"/><path d="M12 3.5v17M8.5 9l1.5-2 1.5 2M12.5 15l1.5 2 1.5-2"/>' ),
			'family'    => array( 'خانوادگی', '<circle cx="8" cy="7.5" r="2.5"/><circle cx="16" cy="7.5" r="2.5"/><path d="M3.5 18c.4-3.3 2.2-5.3 4.5-5.3S12 14.7 12.5 18M11.5 18c.4-3.3 2.2-5.3 4.5-5.3s4.1 2 4.5 5.3"/>' ),
			'bed'       => array( 'اتاق / تخت', '<path d="M3 18V7M3 14h18v4M21 14v-2.5A2.5 2.5 0 0 0 18.5 9H11v5"/><circle cx="7" cy="11" r="1.8"/>' ),
			'breakfast' => array( 'صبحانه / قهوه', '<path d="M4 10h12v4a5 5 0 0 1-5 5H9a5 5 0 0 1-5-5zM16 11h1.5a2.5 2.5 0 0 1 0 5H16M7 3.5c-.8 1 .8 2 0 3M11 3.5c-.8 1 .8 2 0 3"/>' ),
			'food'      => array( 'غذا', '<path d="M7 3v8M5 3v5a2 2 0 0 0 4 0V3M7 11v10M17 21V3c-2.5 1-4 3.5-4 7h4"/>' ),
			'grill'     => array( 'کباب', '<path d="M4 20 18 6M7 17l-2-2M10 14 8 12M13 11l-2-2M16 8l-2-2"/><circle cx="19" cy="5" r="1.4"/>' ),
			'fish'      => array( 'ماهی', '<path d="M3 12c3-4 7-5.5 11-4.5 2 .5 3.5 2 4.5 4.5-1 2.5-2.5 4-4.5 4.5-4 1-8-.5-11-4.5zM18.5 12l2.5-3v6z"/><circle cx="14.5" cy="11" r=".9" fill="currentColor"/>' ),
			'tea'       => array( 'چای', '<path d="M5 9h11v5a5 5 0 0 1-5 5h-1a5 5 0 0 1-5-5zM16 10h1.5a2.3 2.3 0 0 1 0 4.6H16M4 21h14"/>' ),
			'delivery'  => array( 'پیک', '<circle cx="6" cy="17" r="2.5"/><circle cx="18" cy="17" r="2.5"/><path d="M6 17h4l3-6h3l2 6M12 7h3l1 4"/>' ),
			'takeaway'  => array( 'بیرون‌بر', '<path d="M6 8h12l-1.2 12H7.2zM9 8V6a3 3 0 0 1 6 0v2"/>' ),
			'bag'       => array( 'خرید', '<path d="M5 8h14l-1 13H6zM9 8V6a3 3 0 0 1 6 0v2"/>' ),
			'saffron'   => array( 'زعفران', '<path d="M12 20v-7M12 13c-3.5 0-6-2.5-6-7 3.5 0 6 2.5 6 7zM12 13c3.5 0 6-2.5 6-7-3.5 0-6 2.5-6 7z"/>' ),
			'honey'     => array( 'عسل', '<path d="M7 7h10M8 7V5h8v2M6.5 7h11l-.8 12.5a1.6 1.6 0 0 1-1.6 1.5H8.9a1.6 1.6 0 0 1-1.6-1.5z"/><path d="M9 12.5h6l-1 2h-4z"/>' ),
			'nuts'      => array( 'آجیل', '<ellipse cx="12" cy="12" rx="5" ry="7.5"/><path d="M12 4.5v15M8.5 8c2 1 5 1 7 0M8.5 16c2-1 5-1 7 0"/>' ),
			'perfume'   => array( 'عطر', '<path d="M9.5 3.5h5v3h-5zM8 6.5h8l1.5 3V19a1.5 1.5 0 0 1-1.5 1.5H8A1.5 1.5 0 0 1 6.5 19V9.5z"/><circle cx="12" cy="14" r="2.6"/>' ),
			'gem'       => array( 'سنگ / جواهر', '<path d="M7 4h10l4 5-9 11L3 9z"/><path d="M3 9h18M9.5 4 8 9l4 11 4-11-1.5-5"/>' ),
			'carpet'    => array( 'سجاده / فرش', '<rect x="5" y="3.5" width="14" height="17" rx="1.5"/><path d="M8 7h8v10H8zM12 9.5l1.5 2.5-1.5 2.5-1.5-2.5zM5 6H3.5M5 18H3.5M19 6h1.5M19 18h1.5"/>' ),
			'rosary'    => array( 'تسبیح', '<circle cx="12" cy="9" r="5.5" stroke-dasharray="1.5 2"/><path d="M12 14.5V18M10.5 21h3l-1.5-3z"/>' ),
			'dress'     => array( 'عبا / پوشاک', '<path d="M9 3.5h6l1 3-2 2 4 12H6l4-12-2-2z"/>' ),
			'shirt'     => array( 'لباس', '<path d="M8 4 4 6.5l1.8 4L8 9.5V20h8V9.5l2.2 1 1.8-4L16 4c-.8 1.5-2.2 2.3-4 2.3S8.8 5.5 8 4z"/>' ),
			'sim'       => array( 'سیم‌کارت', '<path d="M7 3h7l4 4v14H7z"/><rect x="9.5" y="11" width="6" height="6" rx="1"/>' ),
			'packages'  => array( 'بسته اینترنت', '<rect x="7" y="2.5" width="10" height="19" rx="2.5"/><path d="M10 18.5h4M9.5 9.5a4 4 0 0 1 5 0M11 11.5a1.6 1.6 0 0 1 2 0"/>' ),
			'fast'      => array( 'سریع', '<path d="M13 2.5 5 13.5h6l-1 8 8-11h-6z"/>' ),
			'passport'  => array( 'پاسپورت', '<rect x="5" y="2.8" width="14" height="18.4" rx="2.2"/><circle cx="12" cy="10.4" r="3.4"/><path d="M8.6 10.4h6.8M9 17.4h6"/>' ),
			'scissors'  => array( 'آرایشگاه', '<circle cx="6" cy="6.5" r="2.5"/><circle cx="6" cy="17.5" r="2.5"/><path d="M8 8l12 10M8 16 20 6"/>' ),
			'women'     => array( 'بانوان', '<circle cx="12" cy="8" r="4.5"/><path d="M12 12.5V21M8.5 17.5h7"/>' ),
			'men'       => array( 'آقایان', '<circle cx="10" cy="14" r="5"/><path d="M13.6 10.4 20 4M15 4h5v5"/>' ),
			'bridal'    => array( 'عروس', '<path d="M12 3l1.8 3.6 4 .6-2.9 2.8.7 4L12 12.2 8.4 14l.7-4-2.9-2.8 4-.6z"/><path d="M7 21c1-3 2.8-4.5 5-4.5S16 18 17 21"/>' ),
			'sparkle'   => array( 'زیبایی', '<path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8z"/><path d="M18.5 15.5l.7 2 2 .7-2 .7-.7 2-.7-2-2-.7 2-.7z"/>' ),
			'heart'     => array( 'قلب', '<path d="M12 20s-7.5-4.6-7.5-10A4.3 4.3 0 0 1 12 7.4 4.3 4.3 0 0 1 19.5 10c0 5.4-7.5 10-7.5 10z"/>' ),
			'leaf'      => array( 'طبیعی', '<path d="M5 19c0-8 5-13 14-14 0 9-5 14-13 14z"/><path d="M5 19 13 11"/>' ),
			'car'       => array( 'ماشین', '<path d="M5 16V11l2-5h10l2 5v5M3.5 16h17M5 11h14"/><circle cx="7.5" cy="16.5" r="1.7"/><circle cx="16.5" cy="16.5" r="1.7"/>' ),
			'child'     => array( 'کودک', '<circle cx="12" cy="6" r="2.6"/><path d="M8 21v-5l-2-4 4-2.5h4l4 2.5-2 4v5M10 21v-3M14 21v-3"/>' ),
			'wheelchair'=> array( 'دسترسی معلولین', '<circle cx="11" cy="4.5" r="1.8"/><path d="M11 7v6h5l2 5M11 10h5"/><path d="M8.5 11.5a5 5 0 1 0 6.5 6.3"/>' ),
			'camera'    => array( 'عکاسی', '<path d="M4 8h3.5L9 5.5h6L16.5 8H20v11H4z"/><circle cx="12" cy="13.5" r="3.5"/>' ),
			'calendar'  => array( 'رزرو', '<rect x="4" y="5.5" width="16" height="14.5" rx="2.5"/><path d="M4 10h16M8.5 3.5v4M15.5 3.5v4"/>' ),
			'tv'        => array( 'تلویزیون', '<rect x="3" y="5" width="18" height="12" rx="2"/><path d="M8 21h8M12 17v4"/>' ),
			'laundry'   => array( 'لباسشویی', '<rect x="5" y="3" width="14" height="18" rx="2"/><circle cx="12" cy="13" r="4"/><path d="M8 6.5h2"/>' ),
			'key'       => array( 'کلید', '<circle cx="8" cy="15" r="4"/><path d="M11 12l8-8M16 7l2 2M14 9l2 2"/>' ),
			'rings'     => array( 'عروسی / حلقه', '<circle cx="9" cy="14" r="5"/><circle cx="15" cy="14" r="5"/><path d="M10.5 6.5 12 4l1.5 2.5"/>' ),
			'hall'      => array( 'تالار', '<path d="M3 20h18M4.5 20V9.5L12 4l7.5 5.5V20"/><path d="M8 20v-6M12 20v-6M16 20v-6M7 11h10"/>' ),
			'garden'    => array( 'باغ', '<path d="M12 21v-7M12 14c-4 0-6.5-3-6.5-7.5C9.5 6.5 12 9 12 14zM12 14c4 0 6.5-3 6.5-7.5-4 0-6.5 2.5-6.5 7.5zM5 21h14"/>' ),
			'catering'  => array( 'پذیرایی', '<path d="M3.5 17h17M5 17a7 7 0 0 1 14 0M12 7.5V6M10.5 6h3"/><path d="M4 20h16"/>' ),
			'people'    => array( 'ظرفیت / نفرات', '<circle cx="9" cy="8.4" r="3.4"/><path d="M2.9 19.6c.5-3.6 2.9-5.6 6.1-5.6s5.6 2 6.1 5.6"/><circle cx="16.8" cy="7.6" r="2.7"/><path d="M15.6 12.8c2.9-.4 5.1 1.4 5.6 4.6"/>' ),
			'stage'     => array( 'جایگاه عروس و داماد', '<path d="M4 20V10a8 8 0 0 1 16 0v10M4 20h16"/><path d="M9 20v-4.5a3 3 0 0 1 6 0V20M12 4v-1.5"/>' ),
			'music'     => array( 'سیستم صوتی', '<path d="M9 18V6l10-2v12"/><circle cx="6.5" cy="18" r="2.5"/><circle cx="16.5" cy="16" r="2.5"/>' ),
			'lights'    => array( 'نورپردازی', '<path d="M9 18h6M10 21h4M12 3a6 6 0 0 0-3.5 10.9V16h7v-2.1A6 6 0 0 0 12 3z"/>' ),
			'check'     => array( 'تیک', '<circle cx="12" cy="12" r="8.5"/><path d="m8.5 12.2 2.4 2.4 4.6-4.8"/>' ),
		);
		return $all;
	}

	/** Interface icons (not offered in the admin picker). */
	public static function ui() {
		return array(
			'search' => '<circle cx="11" cy="11" r="6.5"/><path d="m16 16 4.5 4.5"/>',
			'wa'     => '<path d="M12 3.1a8.9 8.9 0 0 0-7.7 13.3L3.1 20.9l4.6-1.2A8.9 8.9 0 1 0 12 3.1z"/><path d="M9 8.3c.3-.5.7-.5 1-.2l1 1.1c.3.3.3.6 0 .9l-.5.6c.7 1.3 1.7 2.3 3 3l.6-.5c.3-.3.6-.3.9 0l1.1 1c.3.3.3.7-.2 1-.7.5-1.5.8-2.3.5-2.3-.8-4.1-2.6-4.9-4.9-.3-.8 0-1.6.3-2.3z" fill="currentColor" stroke="none"/>',
			'nav'    => '<path d="M20.5 3.5 3.8 10.4l7 2.8 2.8 7z"/>',
			'share'  => '<circle cx="17.5" cy="5.5" r="2.5"/><circle cx="6.5" cy="12" r="2.5"/><circle cx="17.5" cy="18.5" r="2.5"/><path d="m8.7 10.8 6.6-4M8.7 13.2l6.6 4"/>',
			'chev'   => '<path d="m14.5 6-6 6 6 6"/>',
			'back'   => '<path d="m9.5 6 6 6-6 6"/>',
			'close'  => '<path d="M6.5 6.5l11 11M17.5 6.5l-11 11"/>',
			'filter' => '<path d="M4 6h16M7 12h10M10 18h4"/>',
			'grid'   => '<rect x="4" y="4" width="7" height="7" rx="1.5"/><rect x="13" y="4" width="7" height="7" rx="1.5"/><rect x="4" y="13" width="7" height="7" rx="1.5"/><rect x="13" y="13" width="7" height="7" rx="1.5"/>',
			'walk'   => '<circle cx="13" cy="4.5" r="1.8"/><path d="m9.5 21 2.2-6.2 2.8 2.7V21M8 11.5l2-3.3 3.2-.8 2.2 3 2.6 1.1M11.7 14.8l.6-4"/>',
			'locate' => '<circle cx="12" cy="12" r="3.2"/><circle cx="12" cy="12" r="7.5"/><path d="M12 2v2.5M12 19.5V22M2 12h2.5M19.5 12H22"/>',
			'map'    => '<path d="m9 4-5 2v14l5-2 6 2 5-2V4l-5 2z"/><path d="M9 4v14M15 6v14"/>',
			'store'  => '<path d="M4 9.5 5.5 4h13L20 9.5M4 9.5a2.7 2.7 0 0 0 5.3 0 2.7 2.7 0 0 0 5.4 0 2.7 2.7 0 0 0 5.3 0M5 11.5V20h14v-8.5M10 20v-5h4v5"/>',
			'list'   => '<path d="M8 6h12M8 12h12M8 18h12"/><circle cx="4" cy="6" r="1" fill="currentColor"/><circle cx="4" cy="12" r="1" fill="currentColor"/><circle cx="4" cy="18" r="1" fill="currentColor"/>',
			'info'   => '<circle cx="12" cy="12" r="8.2"/><path d="M12 11v5.2M12 7.8v.4"/>',
			'copy'   => '<rect x="8.5" y="8.5" width="11" height="11" rx="2.2"/><path d="M15.5 8.5V6.2a1.7 1.7 0 0 0-1.7-1.7H6.2a1.7 1.7 0 0 0-1.7 1.7v7.6a1.7 1.7 0 0 0 1.7 1.7h2.3"/>',
			'ig'     => '<rect x="4" y="4" width="16" height="16" rx="4.5"/><circle cx="12" cy="12" r="3.6"/><circle cx="16.8" cy="7.2" r=".9" fill="currentColor"/>',
			'tg'     => '<path d="M20.6 4.4 3.4 11.2c-.8.3-.8 1.4 0 1.7l4.2 1.4 1.6 5.1c.2.7 1.1.9 1.6.4l2.4-2.3 4.4 3.2c.6.4 1.4.1 1.6-.6l2.9-14.3c.2-.8-.6-1.5-1.5-1.1z"/><path d="m7.6 14.3 9.8-6.5-7.2 7.7"/>',
			'pen'    => '<path d="M4 20h4L19 9a2.8 2.8 0 0 0-4-4L4 16z"/><path d="m13.5 6.5 4 4"/>',
			'plus'   => '<path d="M12 5v14M5 12h14"/>',
			'img'    => '<rect x="3.5" y="5.5" width="17" height="13" rx="2.5"/><circle cx="9" cy="10.5" r="1.8"/><path d="m4 17 5-4.5 3.5 3 3-2.5L20 17"/>',
		);
	}

	public static function svg( $key, $cls = 'dbd-fi' ) {
		$a = self::all();
		$u = self::ui();
		$p = isset( $u[ $key ] ) ? $u[ $key ] : ( isset( $a[ $key ] ) ? $a[ $key ][1] : $a['check'][1] );
		return '<svg class="' . esc_attr( $cls ) . '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . $p . '</svg>';
	}

	/** Old feature keys (2.0 catalogue) → icon keys. */
	public static function from_feature( $k ) {
		$map = array( 'capacity' => 'people', 'valet' => 'car', 'bride_room' => 'bridal', 'photo' => 'camera', 'hair' => 'scissors', 'family_hall' => 'family', 'shuttle' => 'car', 'near' => 'mosque', 'iraqi' => 'food', 'gifts' => 'gift', 'makeup' => 'sparkle', 'booking' => 'calendar' );
		if ( isset( $map[ $k ] ) ) {
			return $map[ $k ];
		}
		return isset( self::all()[ $k ] ) ? $k : 'check';
	}
}
