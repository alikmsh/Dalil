<?php
if (!defined('ABSPATH')) exit;

class DBD_Admin {
    public static function init() {
        add_action('admin_enqueue_scripts', [__CLASS__, 'assets']);
        add_action('admin_menu', [__CLASS__, 'menu']);
        add_action('wp_ajax_dbd_reorder', [__CLASS__, 'reorder']);
    }

    public static function menu() {
        add_submenu_page(
            'edit.php?post_type=dbd_room',
            'مرتب‌سازی کسب‌وکارها',
            'مرتب‌سازی / اولویت',
            'edit_posts',
            'dbd-sort',
            [__CLASS__, 'sort_page']
        );
    }

    public static function assets($hook) {
        global $post_type;
        if ($post_type !== 'dbd_business' && strpos($hook,'dbd-sort')===false) return;
        wp_enqueue_media();
        wp_enqueue_script('dbd-admin', DBD_URL . 'assets/js/admin.js', ['jquery','jquery-ui-sortable'], DBD_VERSION, true);
        wp_enqueue_style('dbd-admin', DBD_URL . 'assets/css/admin.css', [], DBD_VERSION);
        wp_localize_script('dbd-admin', 'DBDAdmin', [
            'nonce' => wp_create_nonce('dbd_admin'),
            'ajax' => admin_url('admin-ajax.php')
        ]);
    }

    public static function sort_page() {
        $room_id = isset($_GET['room']) ? absint($_GET['room']) : 0;
        $rooms = get_posts([
            'post_type'=>'dbd_room',
            'post_status'=>'publish',
            'posts_per_page'=>-1,
            'orderby'=>'title',
            'order'=>'ASC',
        ]);
        $ids = $room_id && class_exists('DBD_Room') ? DBD_Room::business_ids($room_id) : [];
        $posts = [];
        if ($room_id && $ids) {
            $posts = get_posts([
                'post_type'=>'dbd_business',
                'post_status'=>['publish','draft','pending','private'],
                'posts_per_page'=>-1,
                'post__in'=>$ids,
                'orderby'=>'post__in',
            ]);
        }
        ?>
        <div class="wrap" dir="rtl">
            <h1>مرتب‌سازی و اولویت کسب‌وکارها بر اساس Room</h1>
            <p>ابتدا Room را انتخاب کنید؛ سپس فقط کسب‌وکارهای همان Room را با کشیدن و رها کردن مرتب کنید.</p>

            <form method="get" style="margin:15px 0 20px">
                <input type="hidden" name="post_type" value="dbd_room">
                <input type="hidden" name="page" value="dbd-sort">
                <select name="room" style="min-width:280px;padding:7px" onchange="this.form.submit()">
                    <option value="0">انتخاب Room...</option>
                    <?php foreach($rooms as $room): ?>
                        <option value="<?php echo (int)$room->ID; ?>" <?php selected($room_id,$room->ID); ?>>
                            <?php echo esc_html($room->post_title); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </form>

            <?php if(!$room_id): ?>
                <div class="notice notice-info"><p>یک Room انتخاب کنید تا اولویت کسب‌وکارهای همان Room را تنظیم کنید.</p></div>
            <?php elseif(!$posts): ?>
                <div class="notice notice-warning"><p>این Room هنوز کسب‌وکاری ندارد.</p></div>
            <?php else: ?>
                <ul id="dbd-sortable">
                <?php foreach($posts as $index=>$post): ?>
                    <li data-id="<?php echo intval($post->ID); ?>">
                        <span class="dbd-drag">☰</span>
                        <strong><?php echo esc_html($post->post_title ?: 'بدون عنوان'); ?></strong>
                        <span class="dbd-priority">اولویت <?php echo $index+1; ?></span>
                    </li>
                <?php endforeach; ?>
                </ul>
                <button type="button" class="button button-primary" id="dbd-save-order" data-room="<?php echo (int)$room_id; ?>">ذخیره اولویت این Room</button>
                <span id="dbd-sort-message"></span>
            <?php endif; ?>
        </div>
        <?php
    }

    public static function reorder() {
        check_ajax_referer('dbd_admin','nonce');
        if (!current_user_can('edit_posts')) wp_send_json_error(['message'=>'دسترسی کافی نیست.']);

        $room_id = isset($_POST['room_id']) ? absint($_POST['room_id']) : 0;
        $ids = isset($_POST['ids']) ? array_values(array_unique(array_filter(array_map('intval',(array)$_POST['ids'])))) : [];

        if (!$room_id || get_post_type($room_id) !== 'dbd_room') {
            wp_send_json_error(['message'=>'Room معتبر نیست.']);
        }

        $existing = class_exists('DBD_Room') ? DBD_Room::business_ids($room_id) : [];
        $allowed = array_map('intval',$existing);

        // فقط کسب‌وکارهایی که واقعاً عضو همین Room هستند اجازه مرتب‌سازی دارند.
        $ordered = [];
        foreach ($ids as $id) {
            if (in_array($id,$allowed,true) && get_post_type($id)==='dbd_business') {
                $ordered[] = $id;
            }
        }

        // اگر موردی از لیست ارسال نشده بود، موارد باقی‌مانده را هم در انتها حفظ کن.
        foreach ($allowed as $id) {
            if (!in_array($id,$ordered,true)) $ordered[] = $id;
        }

        update_post_meta($room_id, DBD_Room::META, $ordered);

        wp_send_json_success(['message'=>'اولویت‌های همین Room با موفقیت ذخیره شد.']);
    }
}
