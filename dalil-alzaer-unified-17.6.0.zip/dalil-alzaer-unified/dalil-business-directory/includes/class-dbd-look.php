<?php
/**
 * Dalil Al Zaer — listing cards (hotels, restaurants, SIM & internet, shopping, salons):
 * kinds, feature icons, price units, distance to the holy shrine and map data.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DBD_Look {

	/** kind => [Arabic name, Persian name, default unit, default 4 features, map pin icon] */
	public static function kinds() {
		return array(
			'hotel'      => array( 'الفنادق والشقق', 'هتل و آپارتمان', 'د.ع / ليلة', array( 'elevator', 'family', 'ac', 'wifi' ), 'bed' ),
			'restaurant' => array( 'المطاعم والمقاهي', 'رستوران و کافه', 'د.ع / شخص', array( 'family_hall', 'delivery', 'ac', 'wifi' ), 'food' ),
			'sim'        => array( 'شحن الرصيد والإنترنت', 'سیم‌کارت و اینترنت', 'د.ع / خدمة', array( 'support', 'passport', 'fast', 'wifi' ), 'sim' ),
			'shopping'   => array( 'التسوق والهدايا', 'خرید و سوغات', 'د.ع', array( 'gifts', 'saffron', 'card', 'arabic' ), 'bag' ),
			'salon'      => array( 'الصالونات', 'سالن آرایش', 'د.ع / خدمة', array( 'women', 'bridal', 'booking', 'makeup' ), 'scissors' ),
			'venue'      => array( 'قاعات الأفراح وباغ تالار', 'تالار و باغ‌تالار', 'د.ع', array( 'parking', 'catering', 'valet', 'stage' ), 'rings' ),
			'other'      => array( 'خدمات أخرى', 'سایر', 'د.ع', array( 'arabic', 'card', 'ac', 'wifi' ), 'pin' ),
		);
	}

	/** feature => [Arabic label, icon path] */
	public static function features() {
		return array(
			'elevator'    => array( 'مصعد', '<rect x="5" y="3.5" width="14" height="17" rx="2"/><path d="M12 3.5v17M8.5 9l1.5-2 1.5 2M12.5 15l1.5 2 1.5-2"/>' ),
			'family'      => array( 'غرف عائلية', '<circle cx="8" cy="7.5" r="2.5"/><circle cx="16" cy="7.5" r="2.5"/><path d="M3.5 18c.4-3.3 2.2-5.3 4.5-5.3S12 14.7 12.5 18M11.5 18c.4-3.3 2.2-5.3 4.5-5.3s4.1 2 4.5 5.3"/>' ),
			'ac'          => array( 'مكيف', '<path d="M12 3v18M4.2 7.5l15.6 9M19.8 7.5l-15.6 9M9.5 4.5 12 6l2.5-1.5M9.5 19.5 12 18l2.5 1.5M4 10.4l2.6.6-.8 2.7M20 10.4l-2.6.6.8 2.7"/>' ),
			'wifi'        => array( 'واي فاي', '<path d="M3 9.5a13 13 0 0 1 18 0M6 12.8a8.5 8.5 0 0 1 12 0M9 16a4 4 0 0 1 6 0"/><circle cx="12" cy="19" r="1.2" fill="currentColor"/>' ),
			'parking'     => array( 'موقف سيارات', '<rect x="4" y="4" width="16" height="16" rx="3"/><path d="M10 16.5v-9h3a2.6 2.6 0 0 1 0 5.2h-3"/>' ),
			'breakfast'   => array( 'إفطار', '<path d="M4 10h12v4a5 5 0 0 1-5 5H9a5 5 0 0 1-5-5zM16 11h1.5a2.5 2.5 0 0 1 0 5H16M7 3.5c-.8 1 .8 2 0 3M11 3.5c-.8 1 .8 2 0 3"/>' ),
			'shuttle'     => array( 'خدمة نقل', '<rect x="4" y="4" width="16" height="12" rx="2"/><path d="M4 10h16M7 19v-3M17 19v-3"/><circle cx="8" cy="13" r=".9" fill="currentColor"/><circle cx="16" cy="13" r=".9" fill="currentColor"/>' ),
			'near'        => array( 'قريب من الحرم', '<path d="M12 21.2s-6.6-6.1-6.6-11.2a6.6 6.6 0 0 1 13.2 0c0 5.1-6.6 11.2-6.6 11.2z"/><path d="M9.3 11.5c.3-2 1.4-2.8 2.7-3.6 1.3.8 2.4 1.6 2.7 3.6z"/>' ),
			'family_hall' => array( 'صالة عائلية', '<path d="M4 20V9l8-5 8 5v11M4 20h16"/><circle cx="10" cy="13" r="1.6"/><circle cx="14.5" cy="13.5" r="1.3"/><path d="M8 18c.3-1.6 1-2.4 2-2.4s1.7.8 2 2.4M13 18c.2-1.3.8-2 1.5-2s1.3.7 1.5 2"/>' ),
			'delivery'    => array( 'توصيل', '<path d="M3 7h11v9H3zM14 10h4l3 3v3h-7"/><circle cx="7" cy="18" r="1.8"/><circle cx="17" cy="18" r="1.8"/>' ),
			'takeaway'    => array( 'سفري', '<path d="M6 8h12l-1.2 12H7.2zM9 8V6a3 3 0 0 1 6 0v2"/>' ),
			'open24'      => array( 'مفتوح 24 ساعة', '<circle cx="12" cy="12" r="8.5"/><path d="M12 7v5l3.5 2"/>' ),
			'iraqi'       => array( 'أكلات عربية', '<path d="M4 13h16a8 8 0 0 1-16 0zM12 5v4M8.5 6.5l1 2.5M15.5 6.5l-1 2.5"/>' ),
			'support'     => array( 'دعم فني', '<path d="M4 14v-2a8 8 0 0 1 16 0v2"/><path d="M4 14a2 2 0 0 1 2-2h1v6H6a2 2 0 0 1-2-2zM20 14a2 2 0 0 0-2-2h-1v6h1a2 2 0 0 0 2-2zM18 18v.5a2.5 2.5 0 0 1-2.5 2.5H12"/>' ),
			'passport'    => array( 'تفعيل بالجواز', '<rect x="5" y="2.8" width="14" height="18.4" rx="2.2"/><circle cx="12" cy="10.4" r="3.4"/><path d="M8.6 10.4h6.8M12 7c1 .9 1.5 2.1 1.5 3.4S13 12.9 12 13.8M12 7c-1 .9-1.5 2.1-1.5 3.4s.5 2.5 1.5 3.4M9 17.4h6"/>' ),
			'fast'        => array( 'تفعيل سريع', '<path d="M13 2.5 5 13.5h6l-1 8 8-11h-6z"/>' ),
			'packages'    => array( 'باقات إنترنت', '<rect x="7" y="2.5" width="10" height="19" rx="2.5"/><path d="M10 18.5h4M9.5 9.5a4 4 0 0 1 5 0M11 11.5a1.6 1.6 0 0 1 2 0"/>' ),
			'arabic'      => array( 'نتكلم العربية', '<path d="M4 5.5h16v10H9l-5 4z"/><path d="M9 9.5h6M9 12h4"/>' ),
			'gifts'       => array( 'هدايا', '<rect x="4" y="9" width="16" height="11" rx="1.5"/><path d="M3 9h18M12 9v11M12 9c-1.5-3.5-5-4-5-1.5S10 9 12 9zM12 9c1.5-3.5 5-4 5-1.5S14 9 12 9z"/>' ),
			'saffron'     => array( 'زعفران وتذكارات', '<path d="M12 20v-7M12 13c-3.5 0-6-2.5-6-7 3.5 0 6 2.5 6 7zM12 13c3.5 0 6-2.5 6-7-3.5 0-6 2.5-6 7z"/>' ),
			'card'        => array( 'دفع بالبطاقة', '<rect x="3" y="6" width="18" height="12.5" rx="2"/><path d="M3 10h18M6.5 15h4"/>' ),
			'women'       => array( 'قسم نسائي', '<circle cx="12" cy="8" r="4.5"/><path d="M12 12.5V21M8.5 17.5h7"/>' ),
			'men'         => array( 'قسم رجالي', '<circle cx="10" cy="14" r="5"/><path d="M13.6 10.4 20 4M15 4h5v5"/>' ),
			'bridal'      => array( 'تجهيز العرائس', '<path d="M12 3l1.8 3.6 4 .6-2.9 2.8.7 4L12 12.2 8.4 14l.7-4-2.9-2.8 4-.6z"/><path d="M7 21c1-3 2.8-4.5 5-4.5S16 18 17 21"/>' ),
			'booking'     => array( 'حجز موعد', '<rect x="4" y="5.5" width="16" height="14.5" rx="2.5"/><path d="M4 10h16M8.5 3.5v4M15.5 3.5v4M9 14.5l2 2 4-4"/>' ),
			'makeup'      => array( 'مكياج', '<path d="M9 21v-8h6v8zM10 13V8l4-4v9"/>' ),
			'catering'    => array( 'خدمات ضيافة', '<path d="M3.5 17h17M5 17a7 7 0 0 1 14 0M12 7.5V6M10.5 6h3"/><path d="M4 20h16"/>' ),
			'valet'       => array( 'موقف صبارات', '<path d="M5 16.5V12l2-5h10l2 5v4.5"/><path d="M4 12.5h16M7.5 16.5v2M16.5 16.5v2"/><circle cx="8" cy="14.3" r=".9" fill="currentColor"/><circle cx="16" cy="14.3" r=".9" fill="currentColor"/>' ),
			'stage'       => array( 'كوشة العروسين', '<path d="M4 20V10a8 8 0 0 1 16 0v10M4 20h16"/><path d="M9 20v-4.5a3 3 0 0 1 6 0V20M12 4v-1.5"/>' ),
			'garden'      => array( 'حديقة', '<path d="M12 21v-7M12 14c-4 0-6.5-3-6.5-7.5C9.5 6.5 12 9 12 14zM12 14c4 0 6.5-3 6.5-7.5-4 0-6.5 2.5-6.5 7.5zM5 21h14"/>' ),
			'capacity'    => array( 'سعة كبيرة', '<circle cx="9" cy="8.4" r="3.4"/><path d="M2.9 19.6c.5-3.6 2.9-5.6 6.1-5.6s5.6 2 6.1 5.6"/><circle cx="16.8" cy="7.6" r="2.7"/><path d="M15.6 12.8c2.9-.4 5.1 1.4 5.6 4.6"/>' ),
			'music'       => array( 'نظام صوتي', '<path d="M9 18V6l10-2v12"/><circle cx="6.5" cy="18" r="2.5"/><circle cx="16.5" cy="16" r="2.5"/>' ),
			'photo'       => array( 'تصوير', '<path d="M4 8.2a2 2 0 0 1 2-2h1.8l1.4-2h5.6l1.4 2H18a2 2 0 0 1 2 2V17a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2z"/><circle cx="12" cy="12.4" r="3.4"/>' ),
			'bride_room'  => array( 'غرفة العروس', '<path d="M12 3l1.8 3.6 4 .6-2.9 2.8.7 4L12 12.2 8.4 14l.7-4-2.9-2.8 4-.6z"/><path d="M7 21c1-3 2.8-4.5 5-4.5S16 18 17 21"/>' ),
			'hair'        => array( 'صبغ وهايلايت', '<path d="M6 21c0-8 2-15 6-17 4 2 6 9 6 17M9.5 21c0-6 1-11 2.5-13M14.5 21c0-6-1-11-2.5-13"/>' ),
		);
	}

	public static function icon( $path, $cls = 'dbd-fi' ) {
		return '<svg class="' . esc_attr( $cls ) . '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . $path . '</svg>';
	}

	public static function pin_icon( $kind ) {
		$p = array(
			'bed'      => '<path d="M3 18V7M3 14h18v4M21 14v-2.5A2.5 2.5 0 0 0 18.5 9H11v5"/><circle cx="7" cy="11" r="1.8"/>',
			'food'     => '<path d="M7 3v8M5 3v5a2 2 0 0 0 4 0V3M7 11v10M17 21V3c-2.5 1-4 3.5-4 7h4"/>',
			'sim'      => '<path d="M7 3h7l4 4v14H7z"/><rect x="9.5" y="11" width="6" height="6" rx="1"/>',
			'bag'      => '<path d="M5 8h14l-1 13H6zM9 8V6a3 3 0 0 1 6 0v2"/>',
			'scissors' => '<circle cx="6" cy="6.5" r="2.5"/><circle cx="6" cy="17.5" r="2.5"/><path d="M8 8l12 10M8 16 20 6"/>',
			'pin'      => '<circle cx="12" cy="10" r="3"/>',
			'rings'    => '<circle cx="9" cy="14" r="4.5"/><circle cx="15" cy="14" r="4.5"/><path d="M10.5 7 12 4.5 13.5 7"/>',
		);
		$k = self::kinds();
		$n = isset( $k[ $kind ] ) ? $k[ $kind ][4] : 'pin';
		return isset( $p[ $n ] ) ? $p[ $n ] : $p['pin'];
	}

	/** The holy shrine of each city (map centre and distance reference). */
	public static function haram( $city ) {
		$h = array(
			'mashhad' => array( 36.2880, 59.6158, 'العتبة الرضوية المقدسة' ),
			'qom'     => array( 34.6416, 50.8790, 'حرم السيدة المعصومة (ع)' ),
			'shiraz'  => array( 29.6094, 52.5432, 'حرم شاه چراغ (ع)' ),
			'tehran'  => array( 35.5869, 51.4346, 'حرم السيد عبد العظيم الحسني (ع)' ),
		);
		return isset( $h[ $city ] ) ? $h[ $city ] : $h['mashhad'];
	}

	/** «…@36.28,59.61,17z», «?q=36.28,59.61», «!3d36.28!4d59.61», «ll=…» → [lat, lng] */
	public static function parse_latlng( $url ) {
		$u = rawurldecode( (string) $url );
		$re = array( '/!3d(-?\d+\.\d+)!4d(-?\d+\.\d+)/', '/@(-?\d+\.\d+),(-?\d+\.\d+)/', '/[?&](?:q|ll|query|center|destination)=(-?\d+\.\d+),\s*(-?\d+\.\d+)/', '/^\s*(-?\d+\.\d+)\s*,\s*(-?\d+\.\d+)\s*$/' );
		foreach ( $re as $r ) {
			if ( preg_match( $r, $u, $m ) ) {
				$lat = (float) $m[1];
				$lng = (float) $m[2];
				if ( abs( $lat ) <= 90 && abs( $lng ) <= 180 ) {
					return array( $lat, $lng );
				}
			}
		}
		return null;
	}

	public static function meters( $a, $b ) {
		$r  = 6371000;
		$p1 = deg2rad( $a[0] );
		$p2 = deg2rad( $b[0] );
		$dp = $p2 - $p1;
		$dl = deg2rad( $b[1] - $a[1] );
		$h  = sin( $dp / 2 ) ** 2 + cos( $p1 ) * cos( $p2 ) * sin( $dl / 2 ) ** 2;
		return 2 * $r * asin( min( 1, sqrt( $h ) ) );
	}

	public static function distance_label( $m ) {
		if ( $m <= 0 ) {
			return '';
		}
		if ( $m < 1000 ) {
			return ( round( $m / 50 ) * 50 ?: 50 ) . ' م من الحرم';
		}
		return rtrim( rtrim( number_format( $m / 1000, 1 ), '0' ), '.' ) . ' كم من الحرم';
	}

	/** WhatsApp number / link → https://wa.me/… (Iranian local 09… → 989…, 00… → international). */
	/** «دليل الزائر» contact used by listings that have no phone / WhatsApp of their own. */
	public static function fallback() {
		$o = get_option( 'dbd_contact', array() );
		$o = is_array( $o ) ? $o : array();
		return array(
			'on'    => ! isset( $o['on'] ) || ! empty( $o['on'] ),
			'phone' => isset( $o['phone'] ) ? (string) $o['phone'] : '09152082983',
			'wa'    => isset( $o['wa'] ) ? (string) $o['wa'] : '9647822719796',
			'label' => ! empty( $o['label'] ) ? (string) $o['label'] : 'هاتف «دليل الزائر» للحجز والاستفسار',
		);
	}

	/** Two buttons: open the place in Google Maps / in Waze (turn-by-turn from the phone's own location). */
	public static function nav_links( $lat, $lng, $mode = 'driving' ) {
		if ( ! $lat || ! $lng ) {
			return '';
		}
		$ll = round( (float) $lat, 6 ) . ',' . round( (float) $lng, 6 );
		$g  = 'https://www.google.com/maps/dir/?api=1&destination=' . $ll . '&travelmode=' . ( 'walking' === $mode ? 'walking' : 'driving' );
		$w  = 'https://waze.com/ul?ll=' . $ll . '&navigate=yes&zoom=17';
		$sv = function ( $p ) { return '<svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . $p . '</svg>'; };
		// the styles travel with the buttons: a page cache can still hold an older stylesheet
		static $css = false;
		$st = '';
		if ( ! $css ) {
			$css = true;
			$st  = '<style>.dbd-nav2{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin:10px 0 0}.dbd-n2{display:flex;align-items:center;gap:9px;min-width:0;height:52px;padding:0 10px;border-radius:15px;text-decoration:none!important;background:#fff;box-shadow:inset 0 0 0 1.2px #EADFC4,0 6px 14px -12px rgba(8,47,28,.55)}.dbd-n2-i{display:flex;flex:0 0 34px;width:34px;height:34px;align-items:center;justify-content:center;border-radius:11px;color:#fff}.dbd-n2-i svg{display:block;width:19px!important;height:19px!important}.dbd-n2.is-g .dbd-n2-i{background:linear-gradient(160deg,#4A8AF4,#1F5FD1)}.dbd-n2.is-w .dbd-n2-i{background:linear-gradient(160deg,#3BD1F5,#119ECB)}.dbd-n2-t{display:flex;flex-direction:column;min-width:0;line-height:1.25}.dbd-n2-t small{font-size:10.5px;font-weight:700;color:#7C8580}.dbd-n2-t b{font-size:13.5px;font-weight:800;color:#1D2A22;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}</style>';
		}
		return $st . '<div class="dbd-nav2">'
			. '<a class="dbd-n2 is-g" href="' . esc_url( $g ) . '" target="_blank" rel="noopener"><span class="dbd-n2-i">' . $sv( '<path d="M12 21.5s-6.5-6.2-6.5-11.6a6.5 6.5 0 0 1 13 0c0 5.4-6.5 11.6-6.5 11.6z"/><circle cx="12" cy="9.8" r="2.4"/>' ) . '</span><span class="dbd-n2-t"><small>افتح في</small><b>Google Maps</b></span></a>'
			. '<a class="dbd-n2 is-w" href="' . esc_url( $w ) . '" target="_blank" rel="noopener"><span class="dbd-n2-i">' . $sv( '<path d="M20.5 3.5 3.5 10.6l7 2.9 2.9 7z"/>' ) . '</span><span class="dbd-n2-t"><small>افتح في</small><b>Waze</b></span></a>'
			. '</div>';
	}

	public static function wa_url( $wa ) {
		$wa = trim( (string) $wa );
		if ( '' === $wa ) {
			return '';
		}
		if ( 0 === strpos( $wa, 'http' ) ) {
			return $wa;
		}
		$n = preg_replace( '/\D+/', '', DBD_Meta::digits( $wa ) );
		if ( 0 === strpos( $n, '00' ) ) {
			$n = substr( $n, 2 );
		} elseif ( 0 === strpos( $n, '0' ) ) {
			$n = '98' . substr( $n, 1 );
		}
		return $n ? 'https://wa.me/' . $n : '';
	}

	/** Everything a card, the map and the details page need (cached per request). */
	public static function card( $id, $default_kind = '' ) {
		static $memo = array();
		$mk = $id . '|' . $default_kind;
		if ( isset( $memo[ $mk ] ) ) {
			return $memo[ $mk ];
		}
		$kinds = self::kinds();
		$kind  = (string) DBD_Meta::get( $id, 'kind' );
		if ( '' === $kind && class_exists( 'DBD_Frontend' ) ) {
			$kind = DBD_Frontend::guess_own( $id ); // no «نوع»: its own name decides the icon / unit (not the page)
		}
		if ( ! isset( $kinds[ $kind ] ) || ( 'other' === $kind && $default_kind ) ) {
			$kind = isset( $kinds[ $default_kind ] ) ? $default_kind : 'other';
		}
		$city = (string) DBD_Meta::get( $id, 'city' );
		$h    = self::haram( $city );
		$lat  = (float) DBD_Meta::get( $id, 'lat' );
		$lng  = (float) DBD_Meta::get( $id, 'lng' );
		$m    = (float) DBD_Meta::get( $id, 'distance' );
		if ( ! $m && $lat && $lng ) {
			$m = self::meters( array( $h[0], $h[1] ), array( $lat, $lng ) );
		}
		$price  = (float) preg_replace( '/[^\d.]/', '', (string) DBD_Meta::get( $id, 'price_from' ) );
		$unit   = trim( (string) DBD_Meta::get( $id, 'price_unit' ) );
		$wa     = trim( (string) DBD_Meta::get( $id, 'whatsapp' ) );
		$phones = DBD_Meta::phones( $id );
		$logo   = (string) DBD_Meta::get( $id, 'profile_image' );
		$gal    = array();
		for ( $i = 1; $i <= 7; $i++ ) {
			$u = (string) DBD_Meta::get( $id, 'image_' . $i );
			if ( $u ) {
				$gal[] = $u;
			}
		}
		$img = $gal ? $gal[0] : $logo;
		if ( ! $img ) {
			$img = (string) get_the_post_thumbnail_url( $id, 'medium_large' );
		}
		$badges = DBD_Meta::badge_keys( $id );
		if ( $m > 0 && $m <= 1000 && ! in_array( 'near', $badges, true ) ) {
			$badges[] = 'near';
		}
		$st   = class_exists( 'DBD_Reviews' ) ? DBD_Reviews::stats( $id ) : array( 'average' => 0, 'count' => 0 );
		$tags = array_values( array_filter( array_map( 'trim', preg_split( '/[,،]/u', (string) DBD_Meta::get( $id, 'tags' ) ) ) ) );
		// a listing without its own phone (or WhatsApp) is reached through «دليل الزائر» (setting), so every page has both buttons
		$via = false;
		$fb  = self::fallback();
		if ( $fb['on'] ) {
			if ( ! $phones && $fb['phone'] ) {
				$phones = array( array( $fb['label'], $fb['phone'] ) );
				$via    = true;
			}
			if ( '' === $wa && $fb['wa'] ) {
				$wa  = $fb['wa'];
				$via = true;
				$wtx = true;
			}
		}
		$wa_url = self::wa_url( $wa );
		if ( ! empty( $wtx ) && $wa_url ) {
			$wa_url = add_query_arg( 'text', rawurlencode( 'مرحباً، أريد الاستفسار عن: ' . get_the_title( $id ) . ' — عبر «دليل الزائر»' ), $wa_url );
		}
		// «ابتداءً من» in the visitor's currency (DLZ_Money); the unit keeps its «/ ليلة» part
		$unit = $unit ? $unit : $kinds[ $kind ][2];
		$pp   = class_exists( 'DLZ_Money' ) ? DLZ_Money::pair( $price, $unit ) : array( number_format( $price ), $unit );
		$tel = $phones ? preg_replace( '/[^\d+]/', '', DBD_Meta::digits( $phones[0][1] ) ) : '';
		return $memo[ $mk ] = array(
			'id'      => $id,
			'kind'    => $kind,
			'title'   => get_the_title( $id ),
			'slogan'  => (string) DBD_Meta::get( $id, 'slogan' ),
			'img'     => $img,
			'logo'    => $logo,
			'gallery' => $gal,
			'feats'   => DBD_Meta::feats( $id ),
			'badges'  => $badges,
			'tags'    => $tags,
			'level'   => (int) DBD_Meta::get( $id, 'price_level' ),
			'offer'   => (string) DBD_Meta::get( $id, 'offer' ),
			'meters'  => $m,
			'dist'    => self::distance_label( $m ),
			'walk'    => $m > 0 ? max( 1, (int) round( $m / 75 ) ) : 0,
			'price'   => $price,
			'pnum'    => $pp[0],
			'unit'    => $pp[1],
			'wa'      => $wa_url,
			'tel'     => $tel ? 'tel:' . $tel : '',
			'phones'  => $phones,
			'via'     => $via,
			'map'     => (string) DBD_Meta::get( $id, 'map_url' ),
			'lat'     => $lat,
			'lng'     => $lng,
			'city'    => $city,
			'address' => (string) DBD_Meta::get( $id, 'address' ),
			'vtype'   => (string) DBD_Meta::get( $id, 'venue_type' ),
			'cap'     => (int) DBD_Meta::get( $id, 'capacity' ),
			'h24'     => '1' === (string) DBD_Meta::get( $id, 'open_24' ),
			'hfrom'   => (string) DBD_Meta::get( $id, 'hours_from' ),
			'hto'     => (string) DBD_Meta::get( $id, 'hours_to' ),
			'rating'  => (float) $st['average'],
			'count'   => (int) $st['count'],
			'route'   => $lat && $lng ? 'https://www.google.com/maps/dir/?api=1&destination=' . rawurlencode( $lat . ',' . $lng ) : (string) DBD_Meta::get( $id, 'map_url' ),
		);
	}

	public static function stars( $avg ) {
		$pct = max( 0, min( 100, $avg / 5 * 100 ) );
		return '<span class="dbd-st" aria-label="' . esc_attr( number_format( $avg, 1 ) . ' / 5' ) . '"><span class="dbd-st-b">★★★★★</span><span class="dbd-st-f" style="width:' . esc_attr( round( $pct, 1 ) ) . '%">★★★★★</span></span>';
	}
}
