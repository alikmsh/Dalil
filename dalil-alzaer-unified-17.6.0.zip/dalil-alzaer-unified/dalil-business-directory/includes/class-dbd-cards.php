<?php
/**
 * Listing building blocks (3.0): page header, «الخريطة» banner, filter chips, featured card,
 * and the store card in five looks — compact (default, ~4–5 per phone screen), honey, salon, grid, large.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DBD_Cards {

	private static function i( $k, $cls = 'dbd-fi' ) {
		return DBD_Icons::svg( $k, $cls );
	}

	/** Small ornament (diamond flourish) used in headers and section titles. */
	public static function orn() {
		return '<svg class="dbd-orn-s" viewBox="0 0 60 12" aria-hidden="true"><path d="M0 6h22M38 6h22" stroke="currentColor" stroke-width="1"/><path d="M30 1.5 34.5 6 30 10.5 25.5 6z" fill="none" stroke="currentColor" stroke-width="1.1"/><circle cx="30" cy="6" r="1.4" fill="currentColor"/></svg>';
	}

	public static function flourish() {
		return '<svg class="dbd-flr" viewBox="0 0 28 28" aria-hidden="true"><g fill="none" stroke="currentColor" stroke-width="1.2"><path d="M14 3c2.5 3 2.5 6 0 9-2.5-3-2.5-6 0-9zM14 25c2.5-3 2.5-6 0-9-2.5 3-2.5 6 0 9zM3 14c3-2.5 6-2.5 9 0-3 2.5-6 2.5-9 0zM25 14c-3-2.5-6-2.5-9 0 3 2.5 6 2.5 9 0z"/><circle cx="14" cy="14" r="2"/></g></svg>';
	}

	public static function header( $title, $sub = '', $img1 = '', $img2 = '' ) {
		if ( class_exists( 'DLZ_Labels' ) ) {
			$title = DLZ_Labels::heading( $title ); // the text of the home icon that opens this page
		}
		$h  = '<header class="dbd-hd' . ( $img1 || $img2 ? ' has-art' : '' ) . '">';
		if ( $img2 ) {
			$h .= '<img class="dbd-hd-art is-r" src="' . esc_url( $img2 ) . '" alt="" loading="lazy" decoding="async">';
		}
		if ( $img1 ) {
			$h .= '<img class="dbd-hd-art is-l" src="' . esc_url( $img1 ) . '" alt="" loading="lazy" decoding="async">';
		}
		$h .= '<div class="dbd-hd-t"><h2>' . self::flourish() . '<span>' . esc_html( $title ) . '</span>' . self::flourish() . '</h2>';
		if ( '' !== $sub ) {
			$h .= '<p>' . esc_html( $sub ) . '</p>';
		}
		return $h . self::orn() . '</div></header>';
	}

	/** «الخريطة» banner: opens the full-screen map with GPS, nearest places and directions. */
	public static function map_banner( $title = '', $text = '', $img = '', $kind = 'other', $count = 0 ) {
		$title = '' !== $title ? $title : 'الخريطة';
		$text  = '' !== $text ? $text : 'اعثر على أقرب الأماكن إليك واحصل على الاتجاهات';
		$art   = $img ? '<img class="dbd-mb-img" src="' . esc_url( $img ) . '" alt="" loading="lazy" decoding="async">' : self::map_art();
		return '<button type="button" class="dbd-mb" data-dbd-explore aria-label="' . esc_attr( $title ) . '">' . $art
			. '<span class="dbd-mb-sh"></span><span class="dbd-mb-t"><b>' . self::i( 'map', 'dbd-mb-i' ) . esc_html( $title ) . '</b><small>' . esc_html( $text ) . '</small></span>'
			. '<span class="dbd-mb-go">' . self::i( 'locate', 'dbd-mb-gi' ) . '<span>افتح الخريطة</span>' . ( $count ? '<em>' . (int) $count . '</em>' : '' ) . '</span></button>';
	}

	/** Built-in illustration (no download): streets, the shrine dome and golden pins. */
	public static function map_art() {
		return '<svg class="dbd-mb-img" viewBox="0 0 400 160" preserveAspectRatio="xMinYMid slice" aria-hidden="true">'
			. '<rect width="400" height="160" fill="#EDE6D3"/>'
			. '<path d="M-10 118 260 48M40 -10 110 170M170 -10 150 170M-10 74 260 104M230 -10 270 170" stroke="#fff" stroke-width="10" fill="none"/>'
			. '<path d="M-10 118 260 48M40 -10 110 170M170 -10 150 170M-10 74 260 104M230 -10 270 170" stroke="#E2D7BC" stroke-width="1" fill="none" stroke-dasharray="6 6"/>'
			. '<path d="M14 20h22v16H14zM196 120h26v18h-26zM120 18h20v14h-20z" fill="#DCE8D6"/>'
			. '<g transform="translate(62 58) scale(.9)"><path d="M24 4v4M24 8c-6 3-10 7-10 13h20c0-6-4-10-10-13z" fill="#E2B954" stroke="#7A5410" stroke-width=".8"/><rect x="12" y="21" width="24" height="5" fill="#C8922E"/><path d="M10 26h28v14H10z" fill="#E9C46A" stroke="#7A5410" stroke-width=".8"/><path d="M5 40V16l2-3 2 3v24M39 40V16l2-3 2 3v24" fill="#E2B954" stroke="#7A5410" stroke-width=".8"/></g>'
			. '<g fill="#D9AE4A" stroke="#7A5410" stroke-width="1"><path d="M30 60s-9-9.5-9-16a9 9 0 0 1 18 0c0 6.5-9 16-9 16z"/><path d="M168 74s-10-10.5-10-18a10 10 0 0 1 20 0c0 7.5-10 18-10 18z"/><path d="M118 140s-8-8.5-8-14.5a8 8 0 0 1 16 0c0 6-8 14.5-8 14.5z"/><path d="M200 34s-8-8.5-8-14.5a8 8 0 0 1 16 0c0 6-8 14.5-8 14.5z"/></g>'
			. '<g fill="#fff"><circle cx="30" cy="44" r="3.6"/><circle cx="168" cy="56" r="4"/><circle cx="118" cy="125.5" r="3.2"/><circle cx="200" cy="19.5" r="3.2"/></g>'
			. '<path d="M70 128C96 128 140 100 168 74" fill="none" stroke="#0F4D2E" stroke-width="3" stroke-linecap="round" stroke-dasharray="1 6"/>'
			. '<circle cx="66" cy="128" r="15" fill="#3B82F6" opacity=".18"/><circle cx="66" cy="128" r="6.5" fill="#3B82F6" stroke="#fff" stroke-width="2.5"/></svg>';
	}

	public static function filters( $keys, $cards ) {
		$all = array(
			'near'        => array( 'الأقرب', 'locate' ),
			'haram'       => array( 'الأقرب للحرم', 'pin' ),
			'top'         => array( 'الأعلى تقييماً', 'star' ),
			'vip'         => array( 'VIP', 'crown' ),
			'arabic'      => array( 'يتكلم العربية', 'arabic' ),
			'nearharam'   => array( 'قريب من الحرم', 'mosque' ),
			'delivery'    => array( 'توصيل للفندق', 'truck' ),
			'verified'    => array( 'موثوق', 'shield' ),
			'recommended' => array( 'موصى به', 'star' ),
			'cheap'       => array( 'الأرخص', 'tag' ),
		);
		$h = '<div class="dbd-chips" role="toolbar" aria-label="تصفية">';
		foreach ( $keys as $k ) {
			if ( 'cats' === $k ) {
				$tags = array();
				foreach ( $cards as $c ) {
					foreach ( $c['tags'] as $t ) {
						$tags[ $t ] = 1;
					}
				}
				if ( $tags ) {
					$h .= '<span class="dbd-chip-sel">' . self::i( 'grid', 'dbd-ci' ) . '<select aria-label="التصنيفات" data-f="cat"><option value="">التصنيفات</option>';
					foreach ( array_keys( $tags ) as $t ) {
						$h .= '<option value="' . esc_attr( $t ) . '">' . esc_html( $t ) . '</option>';
					}
					$h .= '</select></span>';
				}
				continue;
			}
			if ( ! isset( $all[ $k ] ) ) {
				continue;
			}
			$h .= '<button type="button" class="dbd-chip" data-f="' . esc_attr( $k ) . '" aria-pressed="false">' . self::i( $all[ $k ][1], 'dbd-ci' ) . '<span>' . esc_html( $all[ $k ][0] ) . '</span></button>';
		}
		return $h . '</div>';
	}

	/* ------------------------------------------------------------ pieces */

	private static function attrs( $c ) {
		return ' data-id="' . (int) $c['id'] . '" data-name="' . esc_attr( mb_strtolower( $c['title'] . ' ' . $c['slogan'] . ' ' . implode( ' ', $c['tags'] ) ) ) . '" data-tags="' . esc_attr( implode( '|', $c['tags'] ) ) . '" data-badges="' . esc_attr( implode( ' ', $c['badges'] ) ) . '" data-r="' . esc_attr( $c['rating'] ) . '" data-m="' . esc_attr( round( $c['meters'] ) ) . '" data-p="' . esc_attr( $c['price'] ) . '"' . ( $c['lat'] ? ' data-lat="' . esc_attr( $c['lat'] ) . '" data-lng="' . esc_attr( $c['lng'] ) . '"' : '' );
	}

	private static function photo( $c, $extra = '' ) {
		$img = $c['img'] ? '<img src="' . esc_url( $c['img'] ) . '" alt="" loading="lazy" decoding="async">' : '<span class="dbd-c-ini">' . esc_html( mb_substr( $c['title'], 0, 1 ) ) . '</span>';
		$fav = function_exists( 'dlz_favorite_button' ) ? dlz_favorite_button( 'dbd_business', $c['id'] ) : '';
		return '<div class="dbd-c-ph"><button type="button" class="dbd-c-phb" data-open-business="' . (int) $c['id'] . '" aria-label="' . esc_attr( $c['title'] ) . '" tabindex="-1">' . $img . '</button>' . $extra . $fav . '</div>';
	}

	private static function rate( $c, $count = true ) {
		if ( ! $c['count'] ) {
			return '<span class="dbd-c-rate is-new"><em>جديد</em>' . DBD_Look::stars( 0 ) . '</span>';
		}
		return '<span class="dbd-c-rate">' . ( $count ? '<small>(' . (int) $c['count'] . ')</small>' : '' ) . DBD_Look::stars( $c['rating'] ) . '<b dir="ltr">' . esc_html( number_format( $c['rating'], 1 ) ) . '</b></span>';
	}

	private static function wa( $c, $cls = '' ) {
		return $c['wa'] ? '<a class="dbd-b is-wa ' . esc_attr( $cls ) . '" href="' . esc_url( $c['wa'] ) . '" target="_blank" rel="noopener">' . self::i( 'wa', 'dbd-bi' ) . '<span>واتساب</span></a>' : '';
	}

	private static function route( $c, $label = 'الطريق', $cls = '' ) {
		if ( ! $c['lat'] && ! $c['route'] ) {
			return '';
		}
		return '<a class="dbd-b is-nav ' . esc_attr( $cls ) . '" href="' . esc_url( $c['route'] ) . '" target="_blank" rel="noopener" data-dbd-route="' . (int) $c['id'] . '">' . self::i( 'nav', 'dbd-bi' ) . '<span>' . esc_html( $label ) . '</span></a>';
	}

	/** «التفاصيل ‹» — a quiet hint that the card opens (the whole card is the link). */
	private static function more( $c ) {
		return '<button type="button" class="dbd-c-more" data-open-business="' . (int) $c['id'] . '" tabindex="-1"><span>التفاصيل</span>' . self::i( 'chev', 'dbd-bi' ) . '</button>';
	}

	private static function badge_ico( $c ) {
		$by = array( 'hotel' => 'bed', 'restaurant' => 'food', 'sim' => 'sim', 'shopping' => 'bag', 'salon' => 'scissors', 'venue' => 'rings', 'other' => 'store' );
		$ic = $c['feats'] ? $c['feats'][0][0] : ( isset( $by[ $c['kind'] ] ) ? $by[ $c['kind'] ] : 'store' );
		return '<span class="dbd-c-badge" aria-hidden="true">' . self::i( $ic ) . '</span>';
	}

	private static function dist( $c, $mins = false ) {
		if ( ! $c['dist'] ) {
			return $c['slogan'] ? '<p class="dbd-c-dist is-slogan">' . esc_html( $c['slogan'] ) . '</p>' : '';
		}
		$t = $mins && $c['walk'] ? $c['walk'] . ' ' . ( $c['walk'] <= 10 ? 'دقائق' : 'دقيقة' ) . ' من الحرم' : $c['dist'];
		return '<p class="dbd-c-dist">' . self::i( 'pin', 'dbd-di' ) . '<span>' . esc_html( $t ) . '</span></p>';
	}

	private static function price( $c ) {
		if ( $c['price'] <= 0 ) {
			return '';
		}
		return '<p class="dbd-c-price">' . self::i( 'tag', 'dbd-di' ) . '<span>ابتداءً من <b dir="ltr">' . esc_html( $c['pnum'] ) . '</b> ' . esc_html( $c['unit'] ) . '</span></p>';
	}

	private static function chips( $c, $max = 2 ) {
		$b = DBD_Meta::badges();
		$h = '';
		$n = 0;
		foreach ( $c['badges'] as $k ) {
			if ( 'vip' === $k || ! isset( $b[ $k ] ) || $n >= $max ) {
				continue;
			}
			$h .= '<i class="is-' . esc_attr( $k ) . '">' . self::i( $b[ $k ][1], 'dbd-chi' ) . esc_html( $b[ $k ][0] ) . '</i>';
			$n++;
		}
		return $h ? '<p class="dbd-c-chips">' . $h . '</p>' : '';
	}

	/* ------------------------------------------------------------ cards */

	public static function card( $c, $style = 'compact' ) {
		$a = self::attrs( $c );
		$t = '<h3 class="dbd-c-t"><button type="button" data-open-business="' . (int) $c['id'] . '">' . esc_html( $c['title'] ) . '</button></h3>';
		$vip = in_array( 'vip', $c['badges'], true ) ? '<em class="dbd-c-vip">' . self::i( 'crown', 'dbd-chi' ) . 'VIP</em>' : '';
		switch ( $style ) {
			case 'honey':
				$lvl = $c['level'] ? str_repeat( '$', $c['level'] ) : '';
				$stats = '<div class="dbd-c-stats">'
					. ( $c['dist'] ? '<span>' . self::i( 'pin', 'dbd-di' ) . '<small>قريب من</small><b>' . esc_html( trim( str_replace( array( 'من الحرم' ), '', $c['dist'] ) ) ) . '</b></span>' : '' )
					. '<span>' . self::i( 'star', 'dbd-di' ) . '<small>' . ( $c['count'] ? 'التقييم' : 'جديد' ) . '</small><b dir="ltr">' . ( $c['count'] ? esc_html( number_format( $c['rating'], 1 ) ) : '—' ) . '</b></span>'
					. ( $lvl ? '<span><small>مستوى الأسعار</small><b dir="ltr">' . esc_html( $lvl ) . '</b></span>' : ( $c['price'] > 0 ? '<span><small>ابتداءً من</small><b dir="ltr">' . esc_html( $c['pnum'] . ' ' . trim( preg_replace( '#/.*#u', '', $c['unit'] ) ) ) . '</b></span>' : '' ) )
					. '</div>';
				// 17.4 (Divar-style): no WhatsApp / route on the list — the whole card opens the place (call, WhatsApp, map inside)
				$acts = '<div class="dbd-c-acts">' . ( in_array( 'delivery', $c['badges'], true ) ? '<span class="dbd-b is-soft">' . self::i( 'truck', 'dbd-bi' ) . '<span>توصيل للفندق</span></span>' : '' ) . self::more( $c ) . '</div>';
				return '<article class="dbd-c is-honey"' . $a . '>' . self::photo( $c, $vip ) . '<div class="dbd-c-b">' . $t . ( $c['slogan'] ? '<p class="dbd-c-sl">' . esc_html( $c['slogan'] ) . '</p>' : '' ) . $stats . '</div>' . $acts . '</article>';

			case 'salon':
				$rec = in_array( 'recommended', $c['badges'], true ) ? '<em class="dbd-c-rib">' . self::i( 'star', 'dbd-chi' ) . 'موصى به</em>' : $vip;
				$side = '<div class="dbd-c-side">' . self::rate( $c, false ) . '<button type="button" class="dbd-b is-gold" data-open-business="' . (int) $c['id'] . '"><span>التفاصيل</span>' . self::i( 'chev', 'dbd-bi' ) . '</button></div>';
				return '<article class="dbd-c is-salon"' . $a . '>' . $side . '<div class="dbd-c-b">' . $t . self::chips( $c, 2 ) . self::price( $c ) . self::dist( $c, true ) . '</div>' . self::photo( $c, $rec ) . '</article>';

			case 'grid':
				return '<article class="dbd-c is-grid"' . $a . '>' . self::photo( $c, $vip . self::badge_ico( $c ) ) . '<div class="dbd-c-b">' . $t . self::rate( $c ) . self::dist( $c ) . self::price( $c ) . '</div></article>';

			case 'large':
				$feat = '';
				foreach ( array_slice( $c['feats'], 0, 4 ) as $f ) {
					$feat .= '<li><span class="dbd-c-fic">' . self::i( $f[0] ) . '</span><small>' . esc_html( $f[1] ) . '</small></li>';
				}
				return '<article class="dbd-c is-large"' . $a . '>' . self::photo( $c, $vip ) . '<div class="dbd-c-b">' . $t . self::dist( $c ) . self::rate( $c ) . ( $feat ? '<ul class="dbd-c-feats">' . $feat . '</ul>' : '' ) . self::price( $c ) . '<div class="dbd-c-acts">' . self::more( $c ) . '</div></div></article>';

			default: // compact
				return '<article class="dbd-c is-compact"' . $a . '><div class="dbd-c-b">' . $t . self::rate( $c ) . self::dist( $c ) . '<div class="dbd-c-foot">' . ( $c['price'] > 0 ? '<span class="dbd-c-pr"><b dir="ltr">' . esc_html( $c['pnum'] ) . '</b> ' . esc_html( trim( preg_replace( '#/.*#u', '', $c['unit'] ) ) ) . '</span>' : '' ) . self::more( $c ) . '</div></div>' . self::photo( $c, $vip . self::badge_ico( $c ) ) . '</article>';
		}
	}

	/** The dark «العرض المميز» card (VIP). */
	public static function featured( $c, $label = 'العرض المميز' ) {
		$img = $c['img'] ? '<img src="' . esc_url( $c['img'] ) . '" alt="" loading="lazy" decoding="async">' : '';
		$meta = '';
		if ( $c['count'] ) {
			$meta .= '<span>' . self::i( 'star', 'dbd-di' ) . '<b dir="ltr">' . esc_html( number_format( $c['rating'], 1 ) ) . '</b></span>';
		}
		if ( $c['walk'] ) {
			$meta .= '<span>' . self::i( 'pin', 'dbd-di' ) . esc_html( $c['walk'] . ' ' . ( $c['walk'] <= 10 ? 'دقائق' : 'دقيقة' ) . ' من الحرم' ) . '</span>';
		}
		$acts = ( $c['tel'] ? '<a class="dbd-b is-gold" href="' . esc_attr( $c['tel'] ) . '">' . self::i( 'phone', 'dbd-bi' ) . '<span>اتصال</span></a>' : '' ) . self::wa( $c, 'is-gold' );
		return '<article class="dbd-ft"' . self::attrs( $c ) . '><div class="dbd-ft-ph">' . $img . '</div><em class="dbd-ft-rib">' . esc_html( $label ) . '</em>'
			. '<div class="dbd-ft-b">' . self::i( 'crown', 'dbd-ft-crown' ) . '<h3><button type="button" data-open-business="' . (int) $c['id'] . '">' . esc_html( $c['title'] ) . '</button></h3>'
			. ( $c['offer'] || $c['slogan'] ? '<p>' . esc_html( $c['offer'] ? $c['offer'] : $c['slogan'] ) . '</p>' : '' )
			. ( $meta ? '<div class="dbd-ft-m">' . $meta . '</div>' : '' ) . ( $acts ? '<div class="dbd-ft-acts">' . $acts . '</div>' : '' ) . '</div></article>';
	}
}
