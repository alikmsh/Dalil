<?php
/**
 * Listings front end (3.0).
 *
 * [dalil_businesses] — the store list: header, «الخريطة» banner, tabs, search, filter chips,
 * featured card and cards in five looks (compact · honey · salon · grid · large).
 * Details sheets load on demand (admin-ajax «dbd_detail») so a long list stays light.
 */
if (!defined('ABSPATH')) exit;

class DBD_Frontend {
    public static $kind = '';
    public static $cards = [];
    private static $css_done = false;

    public static function init() {
        add_action('wp_enqueue_scripts', [__CLASS__, 'register']);
        add_shortcode('dalil_businesses', [__CLASS__, 'shortcode']);
        add_shortcode('dalil_business', [__CLASS__, 'single_shortcode']);
        add_shortcode('dalil_map_banner', [__CLASS__, 'banner_shortcode']);
        add_action('wp_ajax_dbd_detail', [__CLASS__, 'ajax_detail']);
        add_action('wp_ajax_nopriv_dbd_detail', [__CLASS__, 'ajax_detail']);
    }

    /* ------------------------------------------------------------ assets */

    /** Map tiles: OpenStreetMap by default, or the service set in «تنظیمات نقشه» (e.g. MapTiler with Arabic labels). */
    public static function tiles() {
        $o = get_option('dbd_map', []);
        $url = !empty($o['tiles']) ? (string) $o['tiles'] : '';
        if ($url === '' && !empty($o['maptiler'])) $url = 'https://api.maptiler.com/maps/streets-v2/256/{z}/{x}/{y}{r}.png?key=' . rawurlencode($o['maptiler']);
        if ($url === '') return ['url' => 'https://tile.openstreetmap.org/{z}/{x}/{y}.png', 'attr' => '© OpenStreetMap'];
        $attr = !empty($o['attr']) ? (string) $o['attr'] : (false !== strpos($url, 'maptiler') ? '© MapTiler © OpenStreetMap' : '© OpenStreetMap');
        return ['url' => esc_url_raw($url), 'attr' => wp_strip_all_tags($attr)];
    }

    public static function register() {
        wp_register_style('dbd-frontend', DBD_URL . 'assets/css/frontend.css', [], DBD_VERSION);
        wp_register_script('dbd-tilemap', DBD_URL . 'assets/js/tilemap.js', [], DBD_VERSION, true);
        wp_register_script('dbd-frontend', DBD_URL . 'assets/js/frontend.js', ['dbd-tilemap'], DBD_VERSION, true);
        $t = self::tiles();
        wp_localize_script('dbd-frontend', 'DBDMap', [
            'tiles'  => $t['url'],
            'attr'   => $t['attr'],
            'ajax'   => admin_url('admin-ajax.php'),
            'route'  => apply_filters('dbd_route_url', 'https://routing.openstreetmap.de/routed-{p}/route/v1/driving/{a};{b}?overview=full&geometries=geojson'),
            'login'  => function_exists('dlz_profile_url') ? dlz_profile_url() : wp_login_url(),
            'logged' => is_user_logged_in() ? 1 : 0,
        ]);
        // in <head> when the page holds the listing (no flash of unstyled cards)
        if (is_singular()) {
            $p = get_queried_object();
            $c = $p && isset($p->post_content) ? (string) $p->post_content : '';
            $hit = false !== strpos($c, 'dalil_business') || false !== strpos($c, 'dalil_map_banner') || false !== strpos($c, 'dalil_shop_register') || false !== strpos($c, 'dalil_venues') || false !== strpos($c, 'dalil_salons');
            if (!$hit) { $d = get_post_meta(get_queried_object_id(), '_elementor_data', true); $hit = is_string($d) && (false !== strpos($d, 'dalil_businesses') || false !== strpos($d, 'dlz_store') || false !== strpos($d, 'dlz_map_banner') || false !== strpos($d, 'dlz_featured') || false !== strpos($d, 'dlz_shop_register') || false !== strpos($d, '"dlz_venues"') || false !== strpos($d, '"dlz_salons"')); }
            if ($hit) { wp_enqueue_style('dbd-frontend'); wp_enqueue_script('dbd-frontend'); self::$css_done = true; }
        }
    }

    /** CSS + JS for a block rendered in the page body (page builders render after <head>). */
    public static function assets() {
        wp_enqueue_script('dbd-frontend');
        if (self::$css_done || wp_style_is('dbd-frontend', 'done')) return '';
        self::$css_done = true;
        if (!did_action('wp_head')) { wp_enqueue_style('dbd-frontend'); return ''; }
        if (function_exists('dlz_inline_css')) return dlz_inline_css('dbd-frontend', DBD_PATH . 'assets/css/frontend.css');
        return '<link rel="stylesheet" id="dbd-frontend-late-css" href="' . esc_url(DBD_URL . 'assets/css/frontend.css?ver=' . DBD_VERSION) . '">';
    }

    public static function flush() { wp_cache_delete('dbd_ids', 'dbd'); }

    /* ------------------------------------------------------------ data */

    public static function guess_kind($room) {
        $t = ($room ? get_the_title($room) . ' ' : '') . (is_singular() ? get_the_title(get_queried_object_id()) : '');
        $map = ['venue' => '/تالار|قاعات الأفراح|أفراح|افراح|زفاف/u', 'hotel' => '/فندق|فنادق|الشقق|شقق|هتل|آپارتمان|اقامت|سكن/u', 'restaurant' => '/مطعم|مطاعم|مقهى|مقاهي|رستوران|کافه|كافيه|غذا|طعام|مشويات|كباب/u', 'sim' => '/شحن|رصيد|إنترنت|انترنت|اینترنت|سیم|شريحة|شرائح|اتصال/u', 'shopping' => '/تسوق|هدايا|هدیه|سوغات|خرید|بازار|متجر|زعفران|عسل|مكسرات|عطور|عبايات|ملابس|سجاد/u', 'salon' => '/صالون|سالن|آرایش|حلاقة|صبغ|هايلايت|كوافير|تجميل/u'];
        foreach ($map as $k => $re) if (preg_match($re, $t)) return $k;
        return '';
    }

    /** Kind of a listing without «نوع», guessed from its own name, slogan and tags ('' = unknown). */
    public static function guess_own($id) {
        $t = get_the_title($id) . ' ' . DBD_Meta::get($id, 'slogan') . ' ' . DBD_Meta::get($id, 'tags');
        $map = ['venue' => '/تالار|قاعة الأفراح|قاعات|قاعة|باغ ?تالار|أفراح|افراح|عرس|زفاف/u', 'restaurant' => '/مطعم|مطاعم|مقهى|مقاهي|رستوران|کافه|كافيه|غذا|طعام|مشويات|كباب|کباب|کوبیده|كوبيده|چلو|برياني|پیتزا|بيتزا|ساندويش|فلافل|حلويات|شیرینی/u', 'hotel' => '/فندق|فنادق|الشقق|شقق|هتل|آپارتمان|اقامتگاه|مسافرخانه|سكن|نزل/u', 'sim' => '/شحن|رصيد|إنترنت|انترنت|اینترنت|سیم‌?کارت|شريحة|شرائح/u', 'salon' => '/صالون|سالن|آرایش|حلاقة|كوافير|تجميل/u', 'shopping' => '/هدايا|هدیه|سوغات|زعفران|عسل|مكسرات|عطور|عبايات|ملابس|سجاد|متجر|فروشگاه/u'];
        foreach ($map as $k => $re) if (preg_match($re, $t)) return $k;
        return '';
    }

    /** Active listings for the current city (or a Room), in admin order. */
    public static function ids($room_id = 0, $city = '', $limit = -1) {
        $city = $city ?: (function_exists('dlz_current_city') ? dlz_current_city() : 'mashhad');
        $args = [
            'post_type' => 'dbd_business', 'post_status' => 'publish', 'posts_per_page' => (int) $limit, 'fields' => 'ids', 'no_found_rows' => true,
            'orderby' => ['menu_order' => 'ASC', 'date' => 'DESC'],
            'meta_query' => [
                'relation' => 'AND',
                ['relation' => 'OR', ['key' => '_dbd_manual_active', 'value' => '1'], ['key' => '_dbd_manual_active', 'compare' => 'NOT EXISTS']],
                ['relation' => 'OR', ['key' => '_dbd_city', 'value' => $city], ['key' => '_dbd_city', 'compare' => 'NOT EXISTS'], ['key' => '_dbd_city', 'value' => '']],
            ],
        ];
        if ($room_id > 0) {
            $in = class_exists('DBD_Room') ? DBD_Room::business_ids($room_id) : [];
            $args['post__in'] = $in ?: [0]; $args['orderby'] = 'post__in'; $args['posts_per_page'] = -1;
        }
        $q = new WP_Query($args);
        if ($q->posts) update_meta_cache('post', $q->posts); // one query for every card's meta
        return array_values(array_filter($q->posts, ['DBD_Meta', 'is_active']));
    }

    /** Map payload for the «الخريطة» explorer. */
    public static function pins($cards) {
        $pins = [];
        foreach ($cards as $c) {
            if (!$c['lat'] || !$c['lng']) continue;
            $pins[] = ['id' => $c['id'], 'lat' => $c['lat'], 'lng' => $c['lng'], 't' => $c['title'], 'd' => $c['dist'], 'k' => $c['kind'], 'wa' => $c['wa'], 'tel' => $c['tel'], 'img' => $c['img'], 'r' => $c['rating']];
        }
        return $pins;
    }

    public static function icons() {
        $out = [];
        foreach (array_keys(DBD_Look::kinds()) as $k) $out[$k] = DBD_Look::pin_icon($k);
        return $out;
    }

    /* ------------------------------------------------------------ shortcodes */

    /**
     * [dalil_businesses style="compact|honey|salon|grid|large" room="" kind="" tags="" title="" subtitle="" side_image="" side_image2=""
     *   map="1" map_title="" map_text="" map_image="" tabs="المحلات|محل\nالمولات|مول" search="1" search_ph="" filters="near,top,vip,arabic"
     *   featured="0|auto|ID" featured_label="" section="" limit=""]
     */
    public static function shortcode($atts = []) {
        $a = shortcode_atts([
            'template' => '', 'style' => '', 'limit' => -1, 'room' => 0, 'kind' => '', 'tags' => '', 'title' => '', 'subtitle' => '',
            'side_image' => '', 'side_image2' => '', 'map' => '0', 'map_title' => '', 'map_text' => '', 'map_image' => '',
            'tabs' => '', 'search' => '0', 'search_ph' => '', 'filters' => '', 'featured' => '0', 'featured_label' => 'العرض المميز', 'section' => '',
        ], $atts);
        $style = $a['style'] ?: $a['template'];
        $style = in_array($style, ['compact', 'honey', 'salon', 'grid', 'large'], true) ? $style : 'compact'; // 2.x «card» → compact (smaller cards)
        self::$kind = isset(DBD_Look::kinds()[$a['kind']]) ? $a['kind'] : self::guess_kind((int) $a['room']);
        $room_id = (int) $a['room'];
        $city = function_exists('dlz_current_city') ? dlz_current_city() : 'mashhad';
        $h = DBD_Look::haram($city);
        $ids = self::ids($room_id, $city, (int) $a['limit'] ?: -1);
        $cards = [];
        foreach ($ids as $id) $cards[] = DBD_Look::card($id, self::$kind);
        if (!$room_id && $a['kind'] !== '' && isset(DBD_Look::kinds()[$a['kind']])) {
            // a page for one kind (e.g. salons) shows only that kind (17.4: listings without a kind no longer
            // appear on every kind page — a kebab shop showed up among the hotels; the edit screen warns about it)
            $k = $a['kind'];
            $cards = array_values(array_filter($cards, function ($c) use ($k) {
                $own = (string) DBD_Meta::get($c['id'], 'kind');
                if ($own === '') $own = self::guess_own($c['id']); // no kind set: read it from the name / tags
                return $own === '' || $own === $k;
            }));
        }
        if ($a['tags'] !== '') {
            $want = array_filter(array_map('trim', preg_split('/[,،]/u', $a['tags'])));
            $cards = array_values(array_filter($cards, function ($c) use ($want) { return (bool) array_intersect($want, $c['tags']); }));
        }
        self::$cards = $cards;
        $kind = self::$kind ?: ($cards ? $cards[0]['kind'] : 'other');

        ob_start();
        echo self::assets(); // phpcs:ignore
        $explore = ['haram' => [$h[0], $h[1], $h[2]], 'pins' => self::pins($cards), 'icons' => self::icons(), 'title' => $a['title'] ?: DBD_Look::kinds()[$kind][0]];
        echo '<div class="dbd-directory dbd-v3 is-' . esc_attr($style) . '" dir="rtl" data-room="' . esc_attr($room_id) . '" data-city="' . esc_attr($city) . '" data-explore="' . esc_attr(wp_json_encode($explore)) . '">';

        if ($a['title'] !== '') echo DBD_Cards::header($a['title'], $a['subtitle'], $a['side_image'], $a['side_image2']); // phpcs:ignore
        // «الخريطة» banner is no longer drawn above the lists (17.2); the map still opens from each card's «الطريق»

        // tabs: one per line «label|tag»
        $tabs = [];
        foreach (preg_split('/\r\n|\r|\n|;/', (string) $a['tabs']) as $line) {
            $p = array_map('trim', explode('|', $line));
            if ($p[0] !== '') $tabs[] = [$p[0], $p[1] ?? '', $p[2] ?? ''];
        }
        // 17.4: search + tabs + chips stay on top while the list scrolls (Divar-style)
        $sticky = ($a['search'] === '1' || $tabs || $a['filters'] !== '') && $cards;
        if ($sticky) echo '<div class="dbd-sticky">';
        if ($tabs) {
            echo '<div class="dbd-tabs" role="tablist">';
            foreach ($tabs as $i => $t) echo '<button type="button" role="tab" class="dbd-tab' . ($i ? '' : ' is-on') . '" aria-selected="' . ($i ? 'false' : 'true') . '" data-tag="' . esc_attr($t[1]) . '">' . DBD_Icons::svg($t[2] ?: ($i ? 'bag' : 'mosque'), 'dbd-ti') . '<span>' . esc_html($t[0]) . '</span></button>'; // phpcs:ignore
            echo '</div>';
        }
        if ($a['search'] === '1' && $cards) {
            echo '<label class="dbd-search"><input type="search" placeholder="' . esc_attr($a['search_ph'] ?: 'ابحث عن ' . DBD_Look::kinds()[$kind][0] . '…') . '" aria-label="بحث">' . DBD_Icons::svg('search', 'dbd-si') . '</label>'; // phpcs:ignore
        }
        $filters = array_filter(array_map('trim', explode(',', (string) $a['filters'])));
        if ($filters && $cards) echo DBD_Cards::filters($filters, $cards); // phpcs:ignore
        if ($sticky) echo '</div>';

        // featured
        if ($a['featured'] !== '0' && $a['featured'] !== '' && $cards) {
            $f = null;
            if (ctype_digit((string) $a['featured'])) { foreach ($cards as $c) if ((int) $c['id'] === (int) $a['featured']) $f = $c; if (!$f && DBD_Meta::is_active((int) $a['featured'])) $f = DBD_Look::card((int) $a['featured'], self::$kind); }
            else { foreach ($cards as $c) if (in_array('vip', $c['badges'], true)) { $f = $c; break; } }
            if ($f) echo DBD_Cards::featured($f, $a['featured_label']); // phpcs:ignore
        }
        if ($a['section'] !== '') echo '<h2 class="dbd-sec-t"><i></i><span>' . esc_html($a['section']) . '</span><i></i></h2>';

        echo '<div class="dbd-list">';
        foreach ($cards as $c) echo DBD_Cards::card($c, $style); // phpcs:ignore
        echo '</div>';
        echo '<div class="dbd-nores" hidden><span>' . DBD_Icons::svg('pin', 'dbd-fi') . '</span><p>لا توجد نتائج مطابقة.</p></div>'; // phpcs:ignore
        if (!$cards) {
            echo '<div class="dbd-empty"><span class="dbd-empty-icon">' . DBD_Icons::svg('bag', 'dbd-fi') . '</span><p>لا توجد إعلانات في هذه المدينة حالياً.</p></div>'; // phpcs:ignore
            if (current_user_can('edit_posts')) echo self::diagnostics($room_id, $city); // phpcs:ignore
        }
        echo '</div>';
        return ob_get_clean();
    }

    /** [dalil_business id=""] — one store page, inline (the «صفحة متجر» widget). */
    public static function single_shortcode($atts = []) {
        $a = shortcode_atts(['id' => 0], $atts);
        $id = (int) $a['id'];
        if (!$id || get_post_type($id) !== 'dbd_business') return current_user_can('edit_posts') ? '<p dir="rtl">یک کسب‌وکار در تنظیمات ویجت انتخاب کنید.</p>' : '';
        ob_start();
        echo self::assets(); // phpcs:ignore
        DBD_Detail::render($id, true);
        return ob_get_clean();
    }

    /** [dalil_map_banner kind="" room="" title="" text="" image=""] — the «الخريطة» banner on its own. */
    public static function banner_shortcode($atts = []) {
        $a = shortcode_atts(['kind' => '', 'room' => 0, 'tags' => '', 'title' => '', 'text' => '', 'image' => ''], $atts);
        $city = function_exists('dlz_current_city') ? dlz_current_city() : 'mashhad';
        $h = DBD_Look::haram($city);
        $cards = [];
        foreach (self::ids((int) $a['room'], $city) as $id) {
            $c = DBD_Look::card($id, $a['kind']);
            if ($a['kind'] && $c['kind'] !== $a['kind'] && !(int) $a['room']) continue;
            $cards[] = $c;
        }
        if ($a['tags'] !== '') {
            $want = array_filter(array_map('trim', preg_split('/[,،]/u', $a['tags'])));
            $cards = array_values(array_filter($cards, function ($c) use ($want) { return (bool) array_intersect($want, $c['tags']); }));
        }
        $kind = $a['kind'] ?: 'other';
        $explore = ['haram' => [$h[0], $h[1], $h[2]], 'pins' => self::pins($cards), 'icons' => self::icons(), 'title' => $a['title'] ?: 'الخريطة'];
        ob_start();
        echo self::assets(); // phpcs:ignore
        echo '<div class="dbd-directory dbd-v3 dbd-banner-only" dir="rtl" data-explore="' . esc_attr(wp_json_encode($explore)) . '">' . DBD_Cards::map_banner($a['title'], $a['text'], $a['image'], $kind, count($explore['pins'])) . '</div>'; // phpcs:ignore
        return ob_get_clean();
    }

    /** Details sheet HTML, on demand. */
    public static function ajax_detail() {
        $id = isset($_GET['id']) ? absint($_GET['id']) : 0; // phpcs:ignore
        if (!$id || get_post_type($id) !== 'dbd_business' || !DBD_Meta::is_active($id)) wp_send_json_error(['message' => 'غير متاح'], 404);
        ob_start();
        DBD_Detail::render($id);
        wp_send_json_success(['html' => ob_get_clean()]);
    }

    /** Shown only to editors when the list is empty: explains exactly why nothing appears. */
    public static function diagnostics($room_id, $city) {
        $labels = ['mashhad' => 'مشهد', 'qom' => 'قم', 'shiraz' => 'شیراز', 'tehran' => 'تهران'];
        $ids = $room_id > 0 ? (class_exists('DBD_Room') ? DBD_Room::business_ids($room_id) : []) : get_posts(['post_type' => 'dbd_business', 'post_status' => 'any', 'posts_per_page' => -1, 'fields' => 'ids']);
        $out = '<div class="dbd-diag" dir="rtl"><strong>راهنمای مدیر (فقط برای شما نمایش داده می‌شود):</strong><ul>';
        if ($room_id > 0 && get_post_type($room_id) !== 'dbd_room') $out .= '<li>Room انتخاب‌شده در ویجت دیگر وجود ندارد. ویجت را ویرایش و Room را دوباره انتخاب کنید.</li>';
        elseif (!$ids) $out .= '<li>' . ($room_id > 0 ? 'این Room هیچ کسب‌وکاری ندارد. از «Room ها» کسب‌وکارها را به آن اضافه کنید.' : 'هنوز هیچ کسب‌وکاری ثبت نشده است.') . '</li>';
        else {
            $count = ['city' => 0, 'active' => 0, 'other' => []];
            foreach ($ids as $id) {
                $st = DBD_Meta::status($id); $c = DBD_Meta::get($id, 'city');
                if ($st === 'active' && $c !== $city) { $count['city']++; continue; }
                if ($st === 'active') { $count['active']++; continue; }
                $count['other'][$st] = ($count['other'][$st] ?? 0) + 1;
            }
            $out .= '<li>شهر فعلی بازدیدکننده: <b>' . esc_html($labels[$city] ?? $city) . '</b></li>';
            if ($count['city']) $out .= '<li>' . (int) $count['city'] . ' کسب‌وکار فعال هست ولی مربوط به شهر دیگری است. شهر را از هدر سایت عوض کنید تا ببینید.</li>';
            foreach ($count['other'] as $st => $n) $out .= '<li>' . (int) $n . ' کسب‌وکار در وضعیت «' . esc_html(DBD_Meta::status_label($st)) . '» است.</li>';
            if (!empty($count['other']['expired'])) $out .= '<li>برای نمایش دوباره‌ی آگهی‌های منقضی: کسب‌وکار را ویرایش کنید، «تمدید از امروز» را تیک بزنید و ذخیره کنید.</li>';
        }
        return $out . '</ul></div>';
    }

    /* 2.x API kept for the favourites page and old templates */
    public static function render_business($id) { echo DBD_Cards::card(DBD_Look::card($id, self::$kind), 'compact'); } // phpcs:ignore
    public static function popup($id) { DBD_Detail::render($id); }
}
