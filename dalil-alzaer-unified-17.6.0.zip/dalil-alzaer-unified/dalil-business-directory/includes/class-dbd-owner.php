<?php
/**
 * «متجري» — the shop owner's own panel: [dalil_my_shop]
 * The account linked to a listing (_dbd_owner) adds products with photo, price and description,
 * edits the shop's description, contact details, opening hours, logo and photos. Changes go live at once.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DBD_Owner {

	const NONCE = 'dbd_owner';

	public static function init() {
		add_shortcode( 'dalil_my_shop', array( __CLASS__, 'shortcode' ) );
		foreach ( array( 'item', 'info', 'photo', 'upload' ) as $a ) {
			add_action( 'wp_ajax_dbd_owner_' . $a, array( __CLASS__, 'ajax_' . $a ) );
		}
		add_action( 'admin_init', array( __CLASS__, 'ensure_page' ) );
		add_action( 'admin_notices', array( __CLASS__, 'admin_notice' ) );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'register_assets' ) );
	}

	public static function register_assets() {
		wp_register_script( 'dbd-owner', DBD_URL . 'assets/js/owner.js', array(), DBD_VERSION, true );
	}

	/* ------------------------------------------------------------ who owns what */

	public static function shops( $uid = 0 ) {
		$uid = $uid ? (int) $uid : get_current_user_id();
		if ( ! $uid ) {
			return array();
		}
		return get_posts( array(
			'post_type'      => 'dbd_business',
			'post_status'    => array( 'publish', 'pending', 'draft', 'private', 'future' ),
			'meta_key'       => '_dbd_owner', // phpcs:ignore
			'meta_value'     => $uid, // phpcs:ignore
			'fields'         => 'ids',
			'posts_per_page' => 20,
			'orderby'        => 'title',
			'order'          => 'ASC',
			'no_found_rows'  => true,
		) );
	}

	public static function can( $pid, $uid = 0 ) {
		$uid = $uid ? (int) $uid : get_current_user_id();
		if ( ! $uid || 'dbd_business' !== get_post_type( $pid ) || 'trash' === get_post_status( $pid ) ) {
			return false;
		}
		return (int) get_post_meta( $pid, '_dbd_owner', true ) === $uid || user_can( $uid, 'edit_post', $pid );
	}

	/** The page that shows the panel (created once, «متجري»). */
	public static function url() {
		$id = (int) get_option( 'dbd_owner_page' );
		if ( $id && 'publish' === get_post_status( $id ) ) {
			return get_permalink( $id );
		}
		return '';
	}

	public static function ensure_page() {
		if ( ! current_user_can( 'manage_options' ) || get_option( 'dbd_owner_page_done' ) ) {
			return;
		}
		$id = (int) get_option( 'dbd_owner_page' );
		if ( ! $id || ! get_post( $id ) ) {
			$id = wp_insert_post( array(
				'post_type'    => 'page',
				'post_status'  => 'publish',
				'post_title'   => 'متجري',
				'post_name'    => 'my-shop',
				'post_content' => '[dalil_my_shop]',
			) );
			if ( $id && ! is_wp_error( $id ) ) {
				update_option( 'dbd_owner_page', (int) $id );
			}
		}
		update_option( 'dbd_owner_page_done', 1 );
	}

	public static function admin_notice() {
		$miss = get_transient( 'dbd_owner_miss_' . get_current_user_id() );
		if ( ! $miss ) {
			return;
		}
		delete_transient( 'dbd_owner_miss_' . get_current_user_id() );
		echo '<div class="notice notice-warning is-dismissible"><p><strong>دلیل الزائر:</strong> کاربری با شماره‌ی <span dir="ltr">' . esc_html( $miss ) . '</span> پیدا نشد. صاحب مغازه باید یک بار با همین شماره وارد سایت شود، بعد دوباره ذخیره کنید.</p></div>';
	}

	/* ------------------------------------------------------------ data for the panel */

	private static function photos( $pid ) {
		$o = array( 'logo' => (string) DBD_Meta::get( $pid, 'profile_image' ) );
		for ( $i = 1; $i <= 7; $i++ ) {
			$o[ 'image_' . $i ] = (string) DBD_Meta::get( $pid, 'image_' . $i );
		}
		return $o;
	}

	private static function info( $pid ) {
		$f = array();
		foreach ( array( 'slogan', 'description', 'items_title', 'whatsapp', 'address', 'hours_from', 'hours_to', 'open_24', 'hours_note', 'instagram', 'telegram' ) as $k ) {
			$f[ $k ] = (string) DBD_Meta::get( $pid, $k );
		}
		$f['phones'] = array_map( function ( $p ) { return array( 'l' => $p[0], 'n' => $p[1] ); }, DBD_Meta::phones( $pid ) );
		return $f;
	}

	private static function status( $pid ) {
		$st = get_post_status( $pid );
		if ( 'publish' !== $st ) {
			return array( 'wait', 'بانتظار المراجعة' );
		}
		return DBD_Meta::is_active( $pid ) ? array( 'on', 'منشور على الموقع' ) : array( 'off', 'متوقف حالياً' );
	}

	private static function ic( $p ) {
		return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . $p . '</svg>';
	}

	/* ------------------------------------------------------------ page */

	public static function shortcode( $atts = array() ) {
		$a = shortcode_atts( array( 'register' => '' ), $atts );
		ob_start();
		echo DBD_Frontend::assets(); // phpcs:ignore
		echo function_exists( 'dlz_inline_css' ) ? dlz_inline_css( 'dbd-owner', DBD_PATH . 'assets/css/owner.css' ) : ''; // phpcs:ignore
		wp_enqueue_script( 'dbd-owner' );
		$login = function_exists( 'dlz_profile_url' ) ? dlz_profile_url() : wp_login_url( get_permalink() );

		if ( ! is_user_logged_in() ) {
			self::gate( 'لوحة متجري', 'سجّل الدخول برقم الهاتف الذي سجّلت به متجرك لتضيف منتجاتك وأسعارك.', 'تسجيل الدخول', $login );
			return ob_get_clean();
		}
		$shops = self::shops();
		if ( ! $shops ) {
			$reg = $a['register'] ? $a['register'] : self::register_url();
			self::gate( 'لا يوجد متجر مرتبط بحسابك', 'إذا كان لديك متجر في «دليل الزائر» اطلب من فريق الدعم ربطه برقم هاتفك، أو سجّل متجرك الآن.', $reg ? 'سجّل متجرك' : '', $reg );
			return ob_get_clean();
		}
		$pid = isset( $_GET['shop'] ) ? absint( $_GET['shop'] ) : 0; // phpcs:ignore
		if ( ! in_array( $pid, $shops, true ) ) {
			$pid = (int) $shops[0];
		}
		$c     = DBD_Look::card( $pid );
		$st    = self::status( $pid );
		$kind  = $c['kind'] ? $c['kind'] : 'other';
		$kinds = DBD_Look::kinds();
		$unit  = isset( $kinds[ $kind ] ) ? trim( preg_replace( '#/.*#', '', $kinds[ $kind ][2] ) ) : 'د.ع';
		$cover = DBD_Meta::get( $pid, 'image_1' );
		$cfg   = array(
			'ajax'   => admin_url( 'admin-ajax.php' ),
			'nonce'  => wp_create_nonce( self::NONCE ),
			'id'     => $pid,
			'items'  => DBD_Meta::items( $pid ),
			'info'   => self::info( $pid ),
			'photos' => self::photos( $pid ),
			'unit'   => $unit ? $unit : 'د.ع',
			'units'  => array_values( array_unique( array( $unit ? $unit : 'د.ع', 'د.ع', 'تومان', '$', 'ريال' ) ) ),
			'grid'   => in_array( $kind, array( 'shopping', 'restaurant' ), true ),
		);
		?>
<div class="dbo" dir="rtl" data-cfg="<?php echo esc_attr( wp_json_encode( $cfg ) ); ?>">
	<header class="dbo-hero"<?php echo $cover ? ' style="--cover:url(\'' . esc_url( $cover ) . '\')"' : ''; ?>>
		<div class="dbo-hero-in">
			<span class="dbo-logo" data-photo-slot="logo"><?php echo $c['logo'] ? '<img src="' . esc_url( $c['logo'] ) . '" alt="">' : '<b>' . esc_html( mb_substr( $c['title'], 0, 1 ) ) . '</b>'; ?></span>
			<div class="dbo-who">
				<small>لوحة متجري</small>
				<h2><?php echo esc_html( $c['title'] ); ?></h2>
				<span class="dbo-st is-<?php echo esc_attr( $st[0] ); ?>"><i></i><?php echo esc_html( $st[1] ); ?></span>
			</div>
		</div>
		<?php if ( 'publish' === get_post_status( $pid ) ) : ?>
		<button type="button" class="dbo-view" data-open-business="<?php echo (int) $pid; ?>"><?php echo self::ic( '<path d="M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12z"/><circle cx="12" cy="12" r="3"/>' ); // phpcs:ignore ?><span>عرض صفحة متجري</span></button>
		<?php endif; ?>
	</header>

	<?php if ( count( $shops ) > 1 ) : ?>
	<nav class="dbo-shops" aria-label="متاجري"><?php foreach ( $shops as $s ) : ?><a href="<?php echo esc_url( add_query_arg( 'shop', $s ) ); ?>" class="<?php echo (int) $s === $pid ? 'is-on' : ''; ?>"><?php echo esc_html( get_the_title( $s ) ); ?></a><?php endforeach; ?></nav>
	<?php endif; ?>

	<div class="dbo-stats">
		<div><b class="dbo-n-items"><?php echo count( $cfg['items'] ); ?></b><small>منتج / خدمة</small></div>
		<div><b><?php echo $c['count'] ? esc_html( number_format( (float) $c['rating'], 1 ) ) : '—'; ?></b><small>التقييم</small></div>
		<div><b><?php echo (int) $c['count']; ?></b><small>مراجعة</small></div>
	</div>

	<nav class="dbo-tabs" role="tablist">
		<button type="button" role="tab" class="is-on" data-tab="items" aria-selected="true"><?php echo self::ic( '<path d="M4 7.5 12 3l8 4.5v9L12 21l-8-4.5z"/><path d="m4 7.5 8 4.5 8-4.5M12 12v9"/>' ); // phpcs:ignore ?><span>المنتجات</span></button>
		<button type="button" role="tab" data-tab="info" aria-selected="false"><?php echo self::ic( '<circle cx="12" cy="12" r="8.5"/><path d="M12 11v5.5M12 7.6v.1"/>' ); // phpcs:ignore ?><span>المعلومات</span></button>
		<button type="button" role="tab" data-tab="photos" aria-selected="false"><?php echo self::ic( '<rect x="3" y="5" width="18" height="14" rx="2.5"/><circle cx="9" cy="10" r="1.8"/><path d="m21 16-5-5-8 8"/>' ); // phpcs:ignore ?><span>الصور</span></button>
	</nav>

	<section class="dbo-pane" data-pane="items">
		<div class="dbo-pane-h">
			<div><h3>منتجاتك وخدماتك</h3><p>أضف الصورة والسعر والوصف، وتظهر فوراً في صفحة متجرك.</p></div>
			<button type="button" class="dbo-add"><?php echo self::ic( '<path d="M12 5v14M5 12h14"/>' ); // phpcs:ignore ?><span>إضافة</span></button>
		</div>
		<div class="dbo-items" aria-live="polite"></div>
		<div class="dbo-empty" hidden>
			<span class="dbo-empty-art"><?php echo self::ic( '<path d="M4 7.5 12 3l8 4.5v9L12 21l-8-4.5z"/><path d="m4 7.5 8 4.5 8-4.5M12 12v9"/>' ); // phpcs:ignore ?></span>
			<b>لم تضف أي منتج بعد</b>
			<p>ابدأ بأول منتج: صورة جميلة، اسم واضح، وسعر.</p>
			<button type="button" class="dbo-btn is-gold dbo-add"><?php echo self::ic( '<path d="M12 5v14M5 12h14"/>' ); // phpcs:ignore ?><span>أضف أول منتج</span></button>
		</div>
	</section>

	<section class="dbo-pane" data-pane="info" hidden>
		<form class="dbo-form dbo-info" novalidate>
			<div class="dbo-card">
				<h4>عن المتجر</h4>
				<label class="dbo-l"><span>جملة قصيرة تحت اسم المتجر</span><input name="slogan" maxlength="90" placeholder="مثلاً: أجود أنواع الزعفران الإيراني"></label>
				<label class="dbo-l"><span>الوصف</span><textarea name="description" rows="5" maxlength="1500" placeholder="عرّف الزوار بمتجرك وما يميّزه…"></textarea><em class="dbo-cnt"></em></label>
				<label class="dbo-l"><span>عنوان قسم المنتجات</span><input name="items_title" maxlength="40" placeholder="مثلاً: منتجاتنا / قائمة الطعام / خدماتنا"></label>
			</div>
			<div class="dbo-card">
				<h4>التواصل</h4>
				<div class="dbo-phones"></div>
				<button type="button" class="dbo-mini dbo-phone-add"><?php echo self::ic( '<path d="M12 5v14M5 12h14"/>' ); // phpcs:ignore ?>إضافة رقم</button>
				<label class="dbo-l"><span>واتساب</span><input name="whatsapp" dir="ltr" inputmode="tel" maxlength="40" placeholder="+964 770 123 4567"></label>
				<label class="dbo-l"><span>العنوان</span><input name="address" maxlength="200" placeholder="مشهد، شارع الإمام الرضا…"></label>
				<div class="dbo-2">
					<label class="dbo-l"><span>إنستغرام</span><input name="instagram" dir="ltr" maxlength="60" placeholder="@shop"></label>
					<label class="dbo-l"><span>تيليغرام</span><input name="telegram" dir="ltr" maxlength="60" placeholder="@shop"></label>
				</div>
			</div>
			<div class="dbo-card">
				<h4>أوقات العمل</h4>
				<label class="dbo-sw"><input type="checkbox" name="open_24" value="1"><i></i><span>مفتوح 24 ساعة</span></label>
				<div class="dbo-2 dbo-hours">
					<label class="dbo-l"><span>من</span><input type="time" name="hours_from" dir="ltr"></label>
					<label class="dbo-l"><span>إلى</span><input type="time" name="hours_to" dir="ltr"></label>
				</div>
				<label class="dbo-l"><span>ملاحظة</span><input name="hours_note" maxlength="80" placeholder="مثلاً: يومياً عدا الجمعة"></label>
			</div>
			<div class="dbo-savebar"><button type="submit" class="dbo-btn is-gold"><?php echo self::ic( '<path d="m5 12.5 4.5 4.5L19 7.5"/>' ); // phpcs:ignore ?><span>حفظ المعلومات</span></button></div>
		</form>
	</section>

	<section class="dbo-pane" data-pane="photos" hidden>
		<div class="dbo-card">
			<h4>الشعار</h4>
			<div class="dbo-logo-row"><div class="dbo-ph is-round" data-slot="logo"></div><p>يظهر بجانب اسم متجرك. يفضّل صورة مربّعة.</p></div>
		</div>
		<div class="dbo-card">
			<h4>صور المتجر</h4>
			<p class="dbo-hint">الصورة الأولى هي الغلاف وصورة البطاقة، والباقي في معرض الصور.</p>
			<div class="dbo-gal"><?php for ( $i = 1; $i <= 7; $i++ ) : ?><div class="dbo-ph" data-slot="image_<?php echo (int) $i; ?>"><?php echo 1 === $i ? '<em>الغلاف</em>' : ''; ?></div><?php endfor; ?></div>
		</div>
	</section>

	<div class="dbo-sheet" hidden>
		<div class="dbo-sheet-bd" data-close></div>
		<form class="dbo-sheet-box dbo-ed" role="dialog" aria-modal="true" aria-labelledby="dbo-ed-t" novalidate>
			<span class="dbo-grip" aria-hidden="true"></span>
			<header class="dbo-ed-h"><h3 id="dbo-ed-t">منتج جديد</h3><button type="button" class="dbo-x" data-close aria-label="إغلاق"><?php echo self::ic( '<path d="M6 6l12 12M18 6 6 18"/>' ); // phpcs:ignore ?></button></header>
			<div class="dbo-ed-b">
				<label class="dbo-drop">
					<input type="file" accept="image/jpeg,image/png,image/webp" class="dbo-file">
					<span class="dbo-drop-in"><?php echo self::ic( '<rect x="3" y="5" width="18" height="14" rx="2.5"/><circle cx="9" cy="10" r="1.8"/><path d="m21 16-5-5-8 8"/>' ); // phpcs:ignore ?><b>أضف صورة المنتج</b><small>اضغط لاختيار صورة من الهاتف</small></span>
					<img alt="" hidden><i class="dbo-prog" hidden></i>
				</label>
				<button type="button" class="dbo-mini dbo-img-x" hidden><?php echo self::ic( '<path d="M6 6l12 12M18 6 6 18"/>' ); // phpcs:ignore ?>إزالة الصورة</button>
				<label class="dbo-l"><span>اسم المنتج *</span><input name="t" maxlength="90" required placeholder="مثلاً: زعفران سرگل ممتاز — مثقال"></label>
				<div class="dbo-price">
					<label class="dbo-l"><span>السعر</span><input name="p" inputmode="decimal" dir="ltr" maxlength="20" placeholder="25,000"></label>
					<label class="dbo-l dbo-unit"><span>العملة</span><select name="u"></select></label>
				</div>
				<label class="dbo-l"><span>السعر قبل الخصم <small>(اختياري)</small></span><input name="o" inputmode="decimal" dir="ltr" maxlength="20" placeholder="30,000"></label>
				<label class="dbo-l"><span>الوصف</span><textarea name="d" rows="3" maxlength="700" placeholder="الوزن، الحجم، المكوّنات، مدة الخدمة…"></textarea><em class="dbo-cnt"></em></label>
				<div class="dbo-pv" aria-hidden="true"><small>معاينة</small><div class="dbo-pv-c"></div></div>
			</div>
			<footer class="dbo-ed-f">
				<button type="button" class="dbo-btn is-del" hidden><?php echo self::ic( '<path d="M4.5 7h15M9.5 7V4.8h5V7M6.5 7l.9 12.2a1.6 1.6 0 0 0 1.6 1.5h6a1.6 1.6 0 0 0 1.6-1.5L17.5 7"/>' ); // phpcs:ignore ?><span>حذف</span></button>
				<button type="submit" class="dbo-btn is-gold"><?php echo self::ic( '<path d="m5 12.5 4.5 4.5L19 7.5"/>' ); // phpcs:ignore ?><span>حفظ المنتج</span></button>
			</footer>
		</form>
	</div>
	<div class="dbo-toast" role="status" aria-live="polite" hidden></div>
</div>
		<?php
		return ob_get_clean();
	}

	private static function gate( $title, $text, $btn, $url ) {
		?>
<div class="dbo dbo-gate" dir="rtl">
	<span class="dbo-gate-art"><?php echo self::ic( '<path d="M3.5 9.5 5 4.5h14l1.5 5"/><path d="M3.5 9.5a2.8 2.8 0 0 0 5.6 0 2.9 2.9 0 0 0 5.8 0 2.8 2.8 0 0 0 5.6 0"/><path d="M5 12.2V20h14v-7.8M10 20v-4.5h4V20"/>' ); // phpcs:ignore ?></span>
	<h2><?php echo esc_html( $title ); ?></h2>
	<p><?php echo esc_html( $text ); ?></p>
	<?php if ( $btn && $url ) : ?><a class="dbo-btn is-gold" href="<?php echo esc_url( $url ); ?>"><span><?php echo esc_html( $btn ); ?></span></a><?php endif; ?>
</div>
		<?php
	}

	private static function register_url() {
		$p = get_posts( array( 'post_type' => 'page', 'post_status' => 'publish', 's' => 'dalil_shop_register', 'posts_per_page' => 1, 'fields' => 'ids', 'no_found_rows' => true ) );
		return $p ? get_permalink( $p[0] ) : '';
	}

	/* ------------------------------------------------------------ ajax */

	private static function guard() {
		if ( ! check_ajax_referer( self::NONCE, 'nonce', false ) ) {
			wp_send_json_error( array( 'message' => 'انتهت صلاحية الصفحة، يرجى تحديثها.' ), 403 );
		}
		$pid = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
		if ( ! is_user_logged_in() || ! self::can( $pid ) ) {
			wp_send_json_error( array( 'message' => 'لا تملك صلاحية تعديل هذا المتجر.' ), 403 );
		}
		$rk = 'dbd_own_rl_' . get_current_user_id();
		$n  = (int) get_transient( $rk );
		if ( $n >= 300 ) {
			wp_send_json_error( array( 'message' => 'تعديلات كثيرة خلال وقت قصير، حاول بعد قليل.' ), 429 );
		}
		set_transient( $rk, $n + 1, HOUR_IN_SECONDS );
		return $pid;
	}

	private static function touched( $pid ) {
		update_post_meta( $pid, '_dbd_owner_edit', time() );
		DBD_Frontend::flush();
		clean_post_cache( $pid );
	}

	/** Only pictures stored on this site (or the value the field already has). */
	private static function own_url( $url, $old = '' ) {
		$url = esc_url_raw( (string) $url );
		if ( '' === $url || $url === $old ) {
			return $url;
		}
		$up = wp_upload_dir();
		return 0 === strpos( set_url_scheme( $url, 'https' ), set_url_scheme( $up['baseurl'], 'https' ) ) ? $url : $old;
	}

	public static function ajax_item() {
		$pid   = self::guard();
		$items = DBD_Meta::items( $pid );
		$op    = sanitize_key( wp_unslash( $_POST['op'] ?? 'save' ) );
		$i     = isset( $_POST['index'] ) ? (int) $_POST['index'] : -1;
		if ( 'delete' === $op ) {
			if ( isset( $items[ $i ] ) ) {
				array_splice( $items, $i, 1 );
			}
		} elseif ( 'move' === $op ) {
			$to = $i + ( 'up' === sanitize_key( wp_unslash( $_POST['dir'] ?? '' ) ) ? -1 : 1 );
			if ( isset( $items[ $i ], $items[ $to ] ) ) {
				$t = $items[ $i ]; $items[ $i ] = $items[ $to ]; $items[ $to ] = $t;
			}
		} else {
			$raw = wp_unslash( $_POST ); // phpcs:ignore — sanitised by DBD_Meta::store()
			$t   = trim( sanitize_text_field( $raw['t'] ?? '' ) );
			if ( mb_strlen( $t ) < 2 ) {
				wp_send_json_error( array( 'message' => 'اكتب اسم المنتج.' ), 400 );
			}
			if ( $i < 0 && count( $items ) >= 80 ) {
				wp_send_json_error( array( 'message' => 'وصلت إلى الحد الأقصى (80 منتجاً).' ), 400 );
			}
			$old = isset( $items[ $i ] ) ? $items[ $i ]['img'] : '';
			$row = array(
				'img' => self::own_url( $raw['img'] ?? '', $old ),
				't'   => $t,
				'p'   => (string) ( $raw['p'] ?? '' ),
				'o'   => (string) ( $raw['o'] ?? '' ),
				'd'   => (string) ( $raw['d'] ?? '' ),
			);
			if ( isset( $items[ $i ] ) ) {
				$items[ $i ] = $row;
			} else {
				array_unshift( $items, $row ); // newest first
			}
		}
		DBD_Meta::store( $pid, array( 'items' => $items ), true );
		self::touched( $pid );
		wp_send_json_success( array( 'items' => DBD_Meta::items( $pid ) ) );
	}

	public static function ajax_info() {
		$pid = self::guard();
		$raw = wp_unslash( $_POST ); // phpcs:ignore — sanitised by DBD_Meta::store()
		$in  = array();
		foreach ( array( 'slogan', 'description', 'items_title', 'whatsapp', 'address', 'hours_from', 'hours_to', 'hours_note', 'instagram', 'telegram' ) as $k ) {
			$in[ $k ] = (string) ( $raw[ $k ] ?? '' );
		}
		$in['description'] = mb_substr( $in['description'], 0, 1500 );
		$in['open_24']     = empty( $raw['open_24'] ) ? '' : '1';
		$in['phones']      = array();
		foreach ( (array) ( $raw['phones'] ?? array() ) as $p ) {
			if ( is_array( $p ) ) {
				$in['phones'][] = array( 'l' => (string) ( $p['l'] ?? '' ), 'n' => (string) ( $p['n'] ?? '' ) );
			}
		}
		$in['phones'] = array_slice( $in['phones'], 0, 5 );
		DBD_Meta::store( $pid, $in, true );
		self::touched( $pid );
		wp_send_json_success( array( 'info' => self::info( $pid ), 'message' => 'تم حفظ المعلومات' ) );
	}

	public static function ajax_photo() {
		$pid  = self::guard();
		$slot = sanitize_key( wp_unslash( $_POST['slot'] ?? '' ) );
		$map  = array( 'logo' => 'profile_image' );
		for ( $i = 1; $i <= 7; $i++ ) {
			$map[ 'image_' . $i ] = 'image_' . $i;
		}
		if ( ! isset( $map[ $slot ] ) ) {
			wp_send_json_error( array( 'message' => 'خطأ في البيانات.' ), 400 );
		}
		$key = $map[ $slot ];
		$url = self::own_url( wp_unslash( $_POST['url'] ?? '' ), (string) DBD_Meta::get( $pid, $key ) );
		DBD_Meta::store( $pid, array( $key => $url ), true );
		self::touched( $pid );
		wp_send_json_success( array( 'photos' => self::photos( $pid ) ) );
	}

	public static function ajax_upload() {
		$pid = self::guard();
		$uk  = 'dbd_own_up_' . get_current_user_id();
		if ( (int) get_transient( $uk ) >= 60 ) {
			wp_send_json_error( array( 'message' => 'رفعت صوراً كثيرة، حاول بعد ساعة.' ), 429 );
		}
		if ( empty( $_FILES['file']['name'] ) ) {
			wp_send_json_error( array( 'message' => 'لم يتم اختيار صورة.' ), 400 );
		}
		$f = $_FILES['file']; // phpcs:ignore
		if ( ! empty( $f['error'] ) || (int) $f['size'] > 5 * MB_IN_BYTES ) {
			wp_send_json_error( array( 'message' => 'حجم الصورة كبير، الحد الأقصى 5 ميغابايت.' ), 400 );
		}
		$mimes = array( 'jpg|jpeg|jpe' => 'image/jpeg', 'png' => 'image/png', 'webp' => 'image/webp' );
		$chk   = wp_check_filetype_and_ext( $f['tmp_name'], $f['name'], $mimes );
		if ( empty( $chk['ext'] ) || empty( $chk['type'] ) || ! @getimagesize( $f['tmp_name'] ) ) { // phpcs:ignore
			wp_send_json_error( array( 'message' => 'يرجى اختيار صورة بصيغة JPG أو PNG أو WEBP.' ), 400 );
		}
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		$f['name']      = 'shop-' . $pid . '-' . wp_generate_password( 8, false, false ) . '.' . $chk['ext'];
		$_FILES['file'] = $f;
		$att            = media_handle_upload( 'file', $pid, array( 'post_title' => get_the_title( $pid ) ), array( 'test_form' => false, 'mimes' => $mimes ) );
		if ( is_wp_error( $att ) ) {
			wp_send_json_error( array( 'message' => 'تعذّر رفع الصورة، حاول بصورة أخرى.' ), 500 );
		}
		set_transient( $uk, (int) get_transient( $uk ) + 1, HOUR_IN_SECONDS );
		$url = wp_get_attachment_image_url( $att, 'large' );
		wp_send_json_success( array( 'url' => $url ? $url : wp_get_attachment_url( $att ) ) );
	}
}
