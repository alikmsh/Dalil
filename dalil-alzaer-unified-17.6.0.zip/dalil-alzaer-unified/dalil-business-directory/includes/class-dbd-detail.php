<?php
/**
 * Store page (3.0) — full-screen sheet (or inline with the «صفحة متجر» widget):
 * photo gallery, logo, name, rating, badges, distance, «عن المكان», services / products with prices,
 * guarantees, features, «معرض الصور», contact & address with hours and map, reviews,
 * and a fixed bar: اتصال · واتساب · الموقع على الخريطة.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DBD_Detail {

	public static function init() {
		add_filter( 'comment_post_redirect', array( __CLASS__, 'after_review' ), 10, 2 );
		add_action( 'pre_comment_on_post', array( __CLASS__, 'require_rating' ) );
	}

	public static function after_review( $location, $comment ) {
		if ( $comment && 'dbd_business' === get_post_type( $comment->comment_post_ID ) ) {
			$ref = wp_get_referer();
			if ( $ref && wp_validate_redirect( $ref, false ) ) {
				return strtok( $ref, '#' ) . '#dbd-business-' . (int) $comment->comment_post_ID;
			}
		}
		return $location;
	}

	public static function require_rating( $post_id ) {
		if ( 'dbd_business' !== get_post_type( $post_id ) ) {
			return;
		}
		if ( ! is_user_logged_in() ) {
			wp_die( 'يرجى تسجيل الدخول أولاً.', 'دليل الزائر', array( 'response' => 403, 'back_link' => true ) );
		}
		$r = isset( $_POST['dbd_rating'] ) ? (int) $_POST['dbd_rating'] : 0; // phpcs:ignore
		if ( $r < 1 || $r > 5 ) {
			wp_die( 'يرجى اختيار التقييم (من نجمة إلى خمس نجوم).', 'دليل الزائر', array( 'response' => 400, 'back_link' => true ) );
		}
		// one review per visitor and place, max 5 reviews an hour
		$uid = get_current_user_id();
		if ( get_comments( array( 'post_id' => $post_id, 'user_id' => $uid, 'count' => true, 'status' => 'all' ) ) ) {
			wp_die( 'لقد أضفت رأيك في هذا المكان من قبل، شكراً لك.', 'دليل الزائر', array( 'response' => 409, 'back_link' => true ) );
		}
		$k = 'dbd_rv_' . $uid;
		if ( (int) get_transient( $k ) >= 5 ) {
			wp_die( 'حاول بعد قليل.', 'دليل الزائر', array( 'response' => 429, 'back_link' => true ) );
		}
		set_transient( $k, (int) get_transient( $k ) + 1, HOUR_IN_SECONDS );
	}

	/* ---------------------------------------------------------- helpers */

	private static function i( $k, $cls = 'dbd-di' ) {
		return DBD_Icons::svg( $k, $cls );
	}

	public static function num( $v, $dec = 1 ) {
		return number_format( (float) $v, $dec, '.', ',' );
	}

	public static function reviewer( $c ) {
		$name = '';
		if ( ! empty( $c->user_id ) ) {
			$uid  = (int) $c->user_id;
			$name = trim( (string) get_user_meta( $uid, 'mp_full_name', true ) );
			if ( '' === $name ) {
				$name = trim( get_user_meta( $uid, 'first_name', true ) . ' ' . get_user_meta( $uid, 'last_name', true ) );
			}
			if ( '' === $name ) {
				$u    = get_userdata( $uid );
				$name = $u ? (string) $u->display_name : '';
			}
		}
		if ( '' === $name ) {
			$name = (string) $c->comment_author;
		}
		if ( '' === $name || preg_match( '/^mp_[0-9a-f]{6,}$/i', $name ) || preg_match( '/^\+?\d[\d\s]{6,}$/', $name ) || is_email( $name ) ) {
			$name = 'زائر';
		}
		return $name;
	}

	public static function date( $ts ) {
		$m = array( 'يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر' );
		return $ts ? (int) gmdate( 'j', $ts ) . ' ' . $m[ (int) gmdate( 'n', $ts ) - 1 ] . ' ' . gmdate( 'Y', $ts ) : '';
	}

	public static function avatar( $c, $name ) {
		$url = ! empty( $c->user_id ) ? (string) get_user_meta( (int) $c->user_id, 'mp_avatar', true ) : '';
		if ( $url ) {
			return '<img class="dbd-d-av" src="' . esc_url( $url ) . '" alt="" loading="lazy" decoding="async">';
		}
		return '<span class="dbd-d-av is-ini" aria-hidden="true">' . esc_html( mb_substr( $name, 0, 1 ) ) . '</span>';
	}

	private static function social( $v, $base ) {
		$v = trim( (string) $v );
		if ( '' === $v ) {
			return '';
		}
		return 0 === strpos( $v, 'http' ) ? $v : $base . ltrim( $v, '@/' );
	}

	private static function mins( $t ) {
		return preg_match( '/^(\d{1,2}):(\d{2})$/', trim( (string) $t ), $m ) ? ( (int) $m[1] * 60 + (int) $m[2] ) : -1;
	}

	private static function items_title( $id, $kind ) {
		$t = trim( (string) DBD_Meta::get( $id, 'items_title' ) );
		if ( '' !== $t ) {
			return $t;
		}
		$d = array( 'shopping' => 'منتجاتنا', 'restaurant' => 'قائمة الطعام', 'hotel' => 'الغرف والأسعار', 'sim' => 'الباقات والخدمات' );
		return isset( $d[ $kind ] ) ? $d[ $kind ] : 'الخدمات';
	}

	private static function sec_t( $t, $id = '' ) {
		return '<h3 class="dbd-s-h"' . ( $id ? ' id="' . esc_attr( $id ) . '"' : '' ) . '><span>' . esc_html( $t ) . '</span><i aria-hidden="true">' . DBD_Cards::orn() . '</i></h3>';
	}

	/* ---------------------------------------------------------- render */

	public static function render( $id, $inline = false ) {
		$c      = DBD_Look::card( $id );
		$title  = $c['title'];
		$desc   = trim( (string) DBD_Meta::get( $id, 'description' ) );
		$wa     = trim( (string) DBD_Meta::get( $id, 'whatsapp' ) );
		$addr   = trim( (string) DBD_Meta::get( $id, 'address' ) );
		$addr_i = (string) DBD_Meta::get( $id, 'address_image' );
		$map_i  = (string) DBD_Meta::get( $id, 'map_image' );
		$from   = (string) DBD_Meta::get( $id, 'hours_from' );
		$to     = (string) DBD_Meta::get( $id, 'hours_to' );
		$h24    = '1' === (string) DBD_Meta::get( $id, 'open_24' );
		$hnote  = trim( (string) DBD_Meta::get( $id, 'hours_note' ) );
		$ig     = self::social( DBD_Meta::get( $id, 'instagram' ), 'https://instagram.com/' );
		$tg     = self::social( DBD_Meta::get( $id, 'telegram' ), 'https://t.me/' );
		$items  = DBD_Meta::items( $id );
		if ( class_exists( 'DLZ_Money' ) ) {
			// product / service prices in the visitor's currency (the listing's unit is the default)
			$pu = (string) DBD_Meta::get( $id, 'price_unit' );
			foreach ( $items as &$it0 ) {
				$raw      = trim( (string) $it0['p'] );
				$it0['p'] = DLZ_Money::text( $it0['p'], $pu );
				if ( '' !== $raw && $raw !== $it0['p'] ) {
					$it0['p0'] = preg_match( '/\p{L}|\$/u', $raw ) ? $raw : $raw . ' ' . ( DLZ_Money::detect( $pu ) ? trim( preg_replace( '#/.*#u', '', $pu ) ) : 'د.ع' ); // the shop's own price, for the WhatsApp message to the shop
				}
				$it0['o'] = DLZ_Money::text( $it0['o'], $pu );
			}
			unset( $it0 );
		}
		$trust  = DBD_Meta::trust( $id );
		$feats  = $c['feats'];
		if ( 'venue' === $c['kind'] ) {
			// halls: the type and the capacity first
			$pre = array();
			if ( in_array( $c['vtype'], array( 'hall', 'garden' ), true ) ) {
				$pre[] = array( 'garden' === $c['vtype'] ? 'garden' : 'hall', 'garden' === $c['vtype'] ? 'باغ تالار' : 'قاعة' );
			}
			if ( $c['cap'] > 0 ) {
				$pre[] = array( 'people', 'ظرفية ' . number_format( $c['cap'] ) . ' شخص' );
			}
			$feats = array_merge( $pre, $feats );
		} elseif ( 'salon' === $c['kind'] && $c['tags'] ) {
			$feats = array_merge( array_map( function ( $t ) { return array( 'sparkle', $t ); }, $c['tags'] ), $feats ); // the services
		}
		$imgs   = $c['gallery'] ? $c['gallery'] : ( $c['img'] ? array( $c['img'] ) : array() );
		$h      = DBD_Look::haram( $c['city'] );
		$fm     = self::mins( $from );
		$tm     = self::mins( $to );
		$hours  = $h24 ? 'مفتوح على مدار الساعة' : ( $fm >= 0 && $tm >= 0 ? $from . ' – ' . $to : '' );
		$uid    = 'dbd-m' . (int) $id;
		$go     = $c['lat'] ? wp_json_encode( array( 'id' => $id, 'lat' => $c['lat'], 'lng' => $c['lng'], 't' => $title, 'img' => $c['img'], 'k' => $c['kind'], 'wa' => $c['wa'], 'tel' => $c['tel'], 'h' => $h ) ) : '';
		$grid   = 'shopping' === $c['kind'];
		$bmap   = DBD_Meta::badges();

		if ( $inline ) {
			echo '<div class="dbd-store-inline" dir="rtl" id="dbd-business-' . (int) $id . '">';
		} else {
			echo '<div class="dbd-modal" id="dbd-modal-' . (int) $id . '" aria-hidden="true" dir="rtl"><div class="dbd-modal-backdrop" data-close-modal></div><div class="dbd-modal-dialog" role="dialog" aria-modal="true" aria-labelledby="' . esc_attr( $uid ) . '-t"><div class="dbd-modal-scroll">';
		}
		?>
<div class="dbd-s">
	<div class="dbd-s-hero<?php echo $imgs ? '' : ' is-empty'; ?>">
		<div class="dbd-s-track">
			<?php foreach ( $imgs as $k => $u ) : ?><figure><img src="<?php echo esc_url( $u ); ?>" alt="" <?php echo $k ? 'loading="lazy"' : ''; ?> decoding="async" data-lightbox-image="<?php echo esc_url( $u ); ?>"></figure><?php endforeach; ?>
		</div>
		<?php if ( count( $imgs ) > 1 ) : ?><div class="dbd-s-dots"><?php foreach ( $imgs as $k => $u ) echo '<i' . ( $k ? '' : ' class="is-on"' ) . '></i>'; ?></div><?php endif; ?>
		<div class="dbd-s-top">
			<?php if ( ! $inline ) : ?><button type="button" class="dbd-s-tb" data-close-modal aria-label="رجوع"><?php echo self::i( 'chev', 'dbd-tbi' ); // phpcs:ignore ?></button><?php endif; ?>
			<span class="dbd-s-tsp"></span>
			<?php if ( function_exists( 'dlz_favorite_button' ) ) echo dlz_favorite_button( 'dbd_business', $id ); // phpcs:ignore ?>
			<button type="button" class="dbd-s-tb" data-dbd-share data-title="<?php echo esc_attr( $title ); ?>" data-id="<?php echo (int) $id; ?>" aria-label="مشاركة"><?php echo self::i( 'share', 'dbd-tbi' ); // phpcs:ignore ?></button>
		</div>
		<svg class="dbd-s-wave" viewBox="0 0 400 34" preserveAspectRatio="none" aria-hidden="true"><path d="M0 34V18C70 2 140 -2 210 10s130 22 190 6v18z"/></svg>
	</div>

	<header class="dbd-s-head">
		<span class="dbd-s-logo"><?php echo $c['logo'] ? '<img src="' . esc_url( $c['logo'] ) . '" alt="" loading="lazy" decoding="async">' : '<b>' . esc_html( mb_substr( $title, 0, 1 ) ) . '</b>'; // phpcs:ignore ?></span>
		<div class="dbd-s-ht">
			<h2 id="<?php echo esc_attr( $uid ); ?>-t"><?php echo esc_html( $title ); ?></h2>
			<div class="dbd-s-rate">
				<?php if ( $c['count'] ) : ?><b dir="ltr"><?php echo esc_html( self::num( $c['rating'] ) ); ?></b><?php echo DBD_Look::stars( $c['rating'] ); // phpcs:ignore ?><small>(<?php echo (int) $c['count']; ?> تقييم)</small>
				<?php else : ?><em class="dbd-s-new">جديد</em><?php echo DBD_Look::stars( 0 ); // phpcs:ignore ?><?php endif; ?>
			</div>
		</div>
	</header>
	<?php if ( $c['badges'] ) : ?>
	<div class="dbd-s-badges"><?php foreach ( $c['badges'] as $b ) : if ( ! isset( $bmap[ $b ] ) ) continue; ?><span class="is-<?php echo esc_attr( $b ); ?>"><?php echo self::i( $bmap[ $b ][1], 'dbd-chi' ); // phpcs:ignore ?><?php echo esc_html( $bmap[ $b ][0] ); ?></span><?php endforeach; ?></div>
	<?php endif; ?>
	<?php if ( $c['dist'] ) : ?><p class="dbd-s-dist"><?php echo self::i( 'pin' ); // phpcs:ignore ?><span><?php echo esc_html( str_replace( 'من الحرم', 'من ' . $h[2], $c['dist'] ) ); ?></span></p><?php endif; ?>
	<?php if ( $c['slogan'] && ! $desc ) : ?><p class="dbd-s-desc"><?php echo esc_html( $c['slogan'] ); ?></p><?php endif; ?>
	<?php if ( $desc ) : ?><div class="dbd-s-desc is-clamp"><?php echo wpautop( esc_html( $desc ) ); // phpcs:ignore ?><button type="button" class="dbd-s-more" hidden>المزيد</button></div><?php endif; ?>

	<?php if ( $items ) : ?>
	<section class="dbd-s-sec">
		<?php echo self::sec_t( self::items_title( $id, $c['kind'] ) ); // phpcs:ignore ?>
		<div class="dbd-s-items<?php echo $grid ? ' is-grid' : ''; ?>" data-shop="<?php echo esc_attr( $title ); ?>" data-wa="<?php echo esc_url( $c['wa'] ); ?>" data-tel="<?php echo esc_attr( $c['tel'] ); ?>">
		<?php foreach ( $items as $k => $it ) : $more = $k >= ( $grid ? 6 : 4 ); ?>
			<?php if ( $grid ) : ?>
			<article class="dbd-s-pr" role="button" tabindex="0" data-item="<?php echo esc_attr( wp_json_encode( $it ) ); ?>"<?php echo $more ? ' hidden data-more' : ''; ?>><span class="dbd-s-pi"><?php echo $it['img'] ? '<img src="' . esc_url( $it['img'] ) . '" alt="" loading="lazy" decoding="async">' : self::i( 'gift', 'dbd-s-pii' ); // phpcs:ignore ?><?php if ( $it['o'] && $it['p'] ) : ?><em class="dbd-s-off">خصم</em><?php endif; ?></span><b><?php echo esc_html( $it['t'] ); ?></b><?php if ( $it['p'] ) : ?><small dir="auto" class="dbd-s-prp"><?php echo esc_html( $it['p'] ); ?><?php if ( $it['o'] ) : ?> <s><?php echo esc_html( $it['o'] ); ?></s><?php endif; ?></small><?php endif; ?></article>
			<?php else : ?>
			<article class="dbd-s-sv" role="button" tabindex="0" data-item="<?php echo esc_attr( wp_json_encode( $it ) ); ?>"<?php echo $more ? ' hidden data-more' : ''; ?>><div class="dbd-s-svt"><b><?php echo esc_html( $it['t'] ); ?></b><?php if ( $it['d'] ) : ?><small><?php echo esc_html( $it['d'] ); ?></small><?php endif; ?></div><?php if ( $it['p'] ) : ?><strong class="dbd-s-svp" dir="auto"><?php echo esc_html( $it['p'] ); ?><?php if ( $it['o'] ) : ?><s><?php echo esc_html( $it['o'] ); ?></s><?php endif; ?></strong><?php endif; ?><?php if ( $it['img'] ) : ?><img src="<?php echo esc_url( $it['img'] ); ?>" alt="" loading="lazy" decoding="async"><?php endif; ?></article>
			<?php endif; ?>
		<?php endforeach; ?>
		</div>
		<?php if ( count( $items ) > ( $grid ? 6 : 4 ) ) : ?><button type="button" class="dbd-s-all" data-dbd-more><span><?php echo esc_html( $grid ? 'عرض جميع المنتجات' : 'عرض جميع الخدمات' ); ?></span><?php echo self::i( 'chev', 'dbd-bi' ); // phpcs:ignore ?></button><?php endif; ?>
	</section>
	<?php endif; ?>

	<?php if ( $trust ) : ?>
	<ul class="dbd-s-trust"><?php foreach ( $trust as $t ) : ?><li><span><?php echo self::i( $t[0], 'dbd-fi' ); // phpcs:ignore ?></span><div><b><?php echo esc_html( $t[1] ); ?></b><?php if ( $t[2] ) : ?><small><?php echo esc_html( $t[2] ); ?></small><?php endif; ?></div></li><?php endforeach; ?></ul>
	<?php endif; ?>

	<?php if ( $feats ) : ?>
	<section class="dbd-s-sec">
		<?php echo self::sec_t( 'المميزات' ); // phpcs:ignore ?>
		<ul class="dbd-s-feats"><?php foreach ( $feats as $f ) : ?><li><?php echo self::i( $f[0], 'dbd-fi' ); // phpcs:ignore ?><span><?php echo esc_html( $f[1] ); ?></span></li><?php endforeach; ?></ul>
	</section>
	<?php endif; ?>

	<?php if ( count( $imgs ) > 1 ) : ?>
	<section class="dbd-s-sec">
		<?php echo self::sec_t( 'معرض الصور' ); // phpcs:ignore ?>
		<div class="dbd-s-gal"><?php foreach ( $imgs as $k => $u ) : ?><button type="button" data-lightbox-image="<?php echo esc_url( $u ); ?>" aria-label="<?php echo esc_attr( 'الصورة ' . ( $k + 1 ) ); ?>"><img src="<?php echo esc_url( $u ); ?>" alt="" loading="lazy" decoding="async"></button><?php endforeach; ?></div>
	</section>
	<?php endif; ?>

	<?php if ( $addr || $c['phones'] || $c['wa'] || $hours || $hnote || $ig || $tg || $c['lat'] || $map_i || $addr_i ) : ?>
	<section class="dbd-s-sec dbd-s-box">
		<?php echo self::sec_t( 'التواصل والعنوان' ); // phpcs:ignore ?>
		<ul class="dbd-d-rows">
			<?php if ( $addr ) : ?><li><span class="dbd-d-ic"><?php echo self::i( 'pin' ); // phpcs:ignore ?></span><div><small>العنوان</small><b><?php echo esc_html( $addr ); ?></b></div><button type="button" class="dbd-d-act" data-dbd-copy="<?php echo esc_attr( $addr ); ?>"><?php echo self::i( 'copy' ); // phpcs:ignore ?><span>نسخ</span></button></li>
			<?php elseif ( $c['dist'] ) : $cl = array( 'mashhad' => 'مشهد', 'qom' => 'قم', 'shiraz' => 'شيراز', 'tehran' => 'طهران' ); ?><li><span class="dbd-d-ic"><?php echo self::i( 'pin' ); // phpcs:ignore ?></span><div><small>الموقع</small><b><?php echo esc_html( ( $cl[ $c['city'] ] ?? 'مشهد' ) . ' — ' . str_replace( 'من الحرم', 'من ' . $h[2], $c['dist'] ) ); ?></b></div></li><?php endif; ?>
			<?php if ( $hours || $hnote ) : ?><li class="dbd-d-hours" <?php echo $h24 ? 'data-h24="1"' : ( $fm >= 0 && $tm >= 0 ? 'data-from="' . (int) $fm . '" data-to="' . (int) $tm . '"' : '' ); // phpcs:ignore ?>><span class="dbd-d-ic"><?php echo self::i( 'clock' ); // phpcs:ignore ?></span><div><small>ساعات العمل</small><b dir="auto"><?php echo esc_html( trim( $hours . ( $hours && $hnote ? ' · ' : '' ) . $hnote ) ); ?></b></div><em class="dbd-d-open" hidden></em></li><?php endif; ?>
			<?php foreach ( $c['phones'] as $p ) : $t = preg_replace( '/[^\d+]/', '', DBD_Meta::digits( $p[1] ) ); ?><li><span class="dbd-d-ic"><?php echo self::i( 'phone' ); // phpcs:ignore ?></span><div><small><?php echo esc_html( $p[0] ? $p[0] : 'الهاتف' ); ?></small><b dir="ltr"><?php echo esc_html( $p[1] ); ?></b></div><a class="dbd-d-act" href="tel:<?php echo esc_attr( $t ); ?>"><?php echo self::i( 'phone' ); // phpcs:ignore ?><span>اتصال</span></a></li><?php endforeach; ?>
			<?php if ( $c['wa'] ) : ?><li><span class="dbd-d-ic is-wa"><?php echo self::i( 'wa' ); // phpcs:ignore ?></span><div><small>واتساب</small><b dir="ltr"><?php echo esc_html( 0 === strpos( $wa, 'http' ) ? 'WhatsApp' : $wa ); ?></b></div><a class="dbd-d-act is-wa" href="<?php echo esc_url( $c['wa'] ); ?>" target="_blank" rel="noopener"><?php echo self::i( 'wa' ); // phpcs:ignore ?><span>محادثة</span></a></li><?php endif; ?>
			<?php if ( ! empty( $c['via'] ) ) : ?><li class="dbd-d-via"><span class="dbd-d-ic"><?php echo self::i( 'info' ); // phpcs:ignore ?></span><div><small>التواصل</small><b>بعض أرقام التواصل المعروضة تابعة لفريق «دليل الزائر»، ويسعدنا خدمتكم وإيصالكم بهذا المكان</b></div></li><?php endif; ?>
			<?php if ( $ig ) : ?><li><span class="dbd-d-ic"><?php echo self::i( 'ig' ); // phpcs:ignore ?></span><div><small>إنستغرام</small><b dir="ltr"><?php echo esc_html( '@' . trim( (string) wp_parse_url( $ig, PHP_URL_PATH ), '/' ) ); ?></b></div><a class="dbd-d-act" href="<?php echo esc_url( $ig ); ?>" target="_blank" rel="noopener"><span>فتح</span></a></li><?php endif; ?>
			<?php if ( $tg ) : ?><li><span class="dbd-d-ic"><?php echo self::i( 'tg' ); // phpcs:ignore ?></span><div><small>تيليغرام</small><b dir="ltr"><?php echo esc_html( '@' . trim( (string) wp_parse_url( $tg, PHP_URL_PATH ), '/' ) ); ?></b></div><a class="dbd-d-act" href="<?php echo esc_url( $tg ); ?>" target="_blank" rel="noopener"><span>فتح</span></a></li><?php endif; ?>
		</ul>
		<?php if ( $c['lat'] ) : ?>
			<div class="dbd-d-map" data-lat="<?php echo esc_attr( $c['lat'] ); ?>" data-lng="<?php echo esc_attr( $c['lng'] ); ?>" data-kind="<?php echo esc_attr( $c['kind'] ); ?>" data-icon="<?php echo esc_attr( DBD_Look::pin_icon( $c['kind'] ) ); ?>" data-dbd-go="<?php echo esc_attr( $go ); ?>" role="button" tabindex="0" aria-label="الاتجاهات إلى المكان"></div>
			<?php echo DBD_Look::nav_links( $c['lat'], $c['lng'] ); // phpcs:ignore ?>
		<?php elseif ( $map_i || $addr_i ) : ?>
			<button type="button" class="dbd-d-mapimg" data-lightbox-image="<?php echo esc_url( $map_i ? $map_i : $addr_i ); ?>"><img src="<?php echo esc_url( $map_i ? $map_i : $addr_i ); ?>" alt="خريطة الموقع" loading="lazy" decoding="async"></button>
		<?php endif; ?>
		<?php if ( $addr_i && ( $map_i || $c['lat'] ) ) : ?><button type="button" class="dbd-d-mapimg is-addr" data-lightbox-image="<?php echo esc_url( $addr_i ); ?>"><img src="<?php echo esc_url( $addr_i ); ?>" alt="صورة العنوان" loading="lazy" decoding="async"></button><?php endif; ?>
	</section>
	<?php endif; ?>

	<?php self::reviews( $id, $c ); ?>
</div>
		<?php
		// fixed action bar
		$bar = '';
		if ( $c['tel'] ) {
			$bar .= '<a class="dbd-sb is-call" href="' . esc_attr( $c['tel'] ) . '">' . self::i( 'phone', 'dbd-sbi' ) . '<span>اتصال</span></a>';
		}
		if ( $c['wa'] ) {
			$bar .= '<a class="dbd-sb is-wa" href="' . esc_url( $c['wa'] ) . '" target="_blank" rel="noopener">' . self::i( 'wa', 'dbd-sbi' ) . '<span>واتساب</span></a>';
		}
		if ( $go ) {
			$bar .= '<button type="button" class="dbd-sb is-map" data-dbd-go="' . esc_attr( $go ) . '">' . self::i( 'pin', 'dbd-sbi' ) . '<span>الموقع على الخريطة</span></button>';
		} elseif ( $c['route'] ) {
			$bar .= '<a class="dbd-sb is-map" href="' . esc_url( $c['route'] ) . '" target="_blank" rel="noopener">' . self::i( 'pin', 'dbd-sbi' ) . '<span>الموقع على الخريطة</span></a>';
		}
		if ( $inline ) {
			echo $bar ? '<nav class="dbd-s-bar is-inline">' . $bar . '</nav>' : ''; // phpcs:ignore
			echo '</div>';
		} else {
			echo '</div>' . ( $bar ? '<nav class="dbd-s-bar" aria-label="تواصل">' . $bar . '</nav>' : '' ) . '</div></div>'; // phpcs:ignore
		}
	}

	/* ---------------------------------------------------------- reviews */

	private static function reviews( $id, $card ) {
		$cs   = get_comments( array( 'post_id' => $id, 'status' => 'approve', 'type' => 'comment', 'number' => 20, 'orderby' => 'comment_date_gmt', 'order' => 'DESC' ) );
		$dist = array( 5 => 0, 4 => 0, 3 => 0, 2 => 0, 1 => 0 );
		foreach ( $cs as $c ) {
			$r = (int) get_comment_meta( $c->comment_ID, '_dbd_rating', true );
			if ( isset( $dist[ $r ] ) ) {
				$dist[ $r ]++;
			}
		}
		$n   = max( 1, array_sum( $dist ) );
		$rid = 'dbd-rv' . (int) $id;
		?>
	<section class="dbd-s-sec dbd-s-box dbd-d-reviews" aria-labelledby="<?php echo esc_attr( $rid ); ?>">
		<?php echo self::sec_t( 'آراء الزوار', $rid ); // phpcs:ignore ?>
		<div class="dbd-d-sum">
			<div class="dbd-d-avg"><b dir="ltr"><?php echo esc_html( $card['count'] ? self::num( $card['rating'] ) : '—' ); ?></b><?php echo DBD_Look::stars( $card['rating'] ); // phpcs:ignore ?><small><?php echo (int) $card['count']; ?> تقييم</small></div>
			<ul class="dbd-d-bars"><?php foreach ( $dist as $k => $v ) : ?><li><span dir="ltr"><?php echo (int) $k; ?></span><i><em style="width:<?php echo esc_attr( round( $v / $n * 100 ) ); ?>%"></em></i></li><?php endforeach; ?></ul>
		</div>
		<div class="dbd-d-rlist">
		<?php if ( $cs ) : foreach ( $cs as $c ) : $r = (int) get_comment_meta( $c->comment_ID, '_dbd_rating', true ); $name = self::reviewer( $c ); ?>
			<article class="dbd-d-rv"><header><?php echo self::avatar( $c, $name ); // phpcs:ignore ?><div><b><?php echo esc_html( $name ); ?></b><time datetime="<?php echo esc_attr( get_comment_date( 'c', $c ) ); ?>"><?php echo esc_html( self::date( strtotime( $c->comment_date ) ) ); ?></time></div><?php if ( $r ) echo DBD_Look::stars( $r ); // phpcs:ignore ?></header><p><?php echo esc_html( $c->comment_content ); ?></p></article>
		<?php endforeach; else : ?>
			<p class="dbd-d-none">لا توجد آراء بعد. كن أول من يكتب رأيه.</p>
		<?php endif; ?>
		</div>
		<div class="dbd-review-cta">
		<?php if ( is_user_logged_in() ) : ?>
			<button type="button" class="dbd-review-button" data-open-review="<?php echo (int) $id; ?>"><?php echo self::i( 'pen', 'dbd-bi' ); // phpcs:ignore ?>أضف رأيك</button>
		<?php else : ?>
			<a class="dbd-review-button" href="<?php echo esc_url( function_exists( 'dlz_profile_url' ) ? dlz_profile_url() : wp_login_url() ); ?>"><?php echo self::i( 'pen', 'dbd-bi' ); // phpcs:ignore ?>سجّل الدخول لإضافة رأيك</a>
		<?php endif; ?>
		</div>
		<?php if ( is_user_logged_in() && comments_open( $id ) ) : ?>
		<div class="dbd-review-form-wrap" id="dbd-review-form-<?php echo (int) $id; ?>" hidden>
			<form class="dbd-d-form" novalidate action="<?php echo esc_url( site_url( '/wp-comments-post.php' ) ); ?>" method="post">
				<p class="dbd-d-flab">تقييمك</p>
				<div class="dbd-d-pick" role="radiogroup" aria-label="تقييمك">
					<?php for ( $k = 5; $k >= 1; $k-- ) : ?><input type="radio" id="<?php echo esc_attr( $rid . '-' . $k ); ?>" name="dbd_rating" value="<?php echo (int) $k; ?>"><label for="<?php echo esc_attr( $rid . '-' . $k ); ?>" aria-label="<?php echo esc_attr( $k . ' / 5' ); ?>"><?php echo self::i( 'star', 'dbd-di' ); // phpcs:ignore ?></label><?php endfor; ?>
				</div>
				<label class="dbd-d-flab" for="<?php echo esc_attr( $rid ); ?>-txt">رأيك</label>
				<textarea id="<?php echo esc_attr( $rid ); ?>-txt" name="comment" rows="4" maxlength="1200" placeholder="اكتب تجربتك مع هذا المكان…"></textarea>
				<input type="hidden" name="comment_post_ID" value="<?php echo (int) $id; ?>">
				<input type="hidden" name="comment_parent" value="0">
				<?php wp_comment_form_unfiltered_html_nonce(); ?>
				<?php do_action( 'comment_form', $id ); ?>
				<button type="submit" class="dbd-d-send">إرسال الرأي</button>
			</form>
		</div>
		<?php endif; ?>
	</section>
		<?php
	}
}
DBD_Detail::init();
