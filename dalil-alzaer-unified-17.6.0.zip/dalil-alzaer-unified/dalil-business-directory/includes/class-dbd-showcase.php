<?php
/**
 * Dalil Al Zaer — two showcase lists built on the listings (dbd_business):
 *
 *  «قاعات الأفراح وباغ تالار»  [dalil_venues]  — two-column photo cards: type (قاعة / باغ), rating, city and address,
 *                                                feature chips (capacity, parking …), «من …» price; search, type chips, city.
 *  «صالونات التجميل»           [dalil_salons]  — horizontal cards: open now / closed (working hours), rating, address,
 *                                                distance, the services, «يبدأ من …», «عرض التفاصيل»; search, «الأقرب», «تصفية».
 *
 * The whole card opens the place (photos, description, features, hours, map + directions, call / WhatsApp,
 * reviews and stars — the listing details sheet). Hearts use the app favourites. Prices in the visitor's currency.
 * Dashboard: «تالارها و باغ‌تالارها» and «سالن‌های زیبایی» menus (list + add, the listing form with every field).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DBD_Showcase {

	public static function init() {
		add_shortcode( 'dalil_venues', array( __CLASS__, 'venues_sc' ) );
		add_shortcode( 'dalil_salons', array( __CLASS__, 'salons_sc' ) );
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 9 );
		add_action( 'pre_get_posts', array( __CLASS__, 'admin_filter' ) );
		add_filter( 'parent_file', array( __CLASS__, 'parent_file' ) );
		add_filter( 'submenu_file', array( __CLASS__, 'submenu_file' ) );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'register' ), 20 );
	}

	/* ------------------------------------------------------------ dashboard */

	public static function menus() {
		return array(
			'venue' => array( 'تالارها و باغ‌تالارها', 'همه‌ی تالارها', 'افزودن تالار / باغ', 'dashicons-heart', 26 ),
			'salon' => array( 'سالن‌های زیبایی', 'همه‌ی سالن‌ها', 'افزودن سالن', 'dashicons-art', 26.1 ),
		);
	}

	public static function menu() {
		foreach ( self::menus() as $k => $m ) {
			$list = 'edit.php?post_type=dbd_business&dbd_kind=' . $k;
			add_menu_page( $m[0], $m[0], 'edit_posts', $list, '', $m[3], $m[4] );
			add_submenu_page( $list, $m[1], $m[1], 'edit_posts', $list );
			add_submenu_page( $list, $m[2], $m[2], 'edit_posts', 'post-new.php?post_type=dbd_business&dbd_kind=' . $k );
		}
	}

	private static function admin_kind() {
		if ( ! is_admin() || empty( $_GET['dbd_kind'] ) ) { // phpcs:ignore
			return '';
		}
		$k = sanitize_key( wp_unslash( $_GET['dbd_kind'] ) ); // phpcs:ignore
		return isset( self::menus()[ $k ] ) ? $k : '';
	}

	/** «همه‌ی تالارها» lists only the halls (kind = venue), «همه‌ی سالن‌ها» only the salons. */
	public static function admin_filter( $q ) {
		if ( ! is_admin() || ! $q->is_main_query() || 'dbd_business' !== $q->get( 'post_type' ) ) {
			return;
		}
		$k = self::admin_kind();
		if ( '' === $k ) {
			return;
		}
		$mq   = (array) $q->get( 'meta_query' );
		$mq[] = array( 'key' => '_dbd_kind', 'value' => $k );
		$q->set( 'meta_query', $mq );
	}

	public static function parent_file( $f ) {
		global $pagenow;
		$k = self::admin_kind();
		if ( $k && in_array( $pagenow, array( 'edit.php', 'post-new.php' ), true ) ) {
			return 'edit.php?post_type=dbd_business&dbd_kind=' . $k;
		}
		return $f;
	}

	public static function submenu_file( $f ) {
		global $pagenow;
		$k = self::admin_kind();
		if ( $k ) {
			return 'post-new.php' === $pagenow ? 'post-new.php?post_type=dbd_business&dbd_kind=' . $k : 'edit.php?post_type=dbd_business&dbd_kind=' . $k;
		}
		return $f;
	}

	/* ------------------------------------------------------------ assets */

	public static function register() {
		wp_register_script( 'dbd-showcase', DBD_URL . 'assets/js/showcase.js', array( 'dbd-frontend' ), DBD_VERSION, true );
	}

	private static function assets() {
		$out = class_exists( 'DBD_Frontend' ) ? DBD_Frontend::assets() : ''; // the details sheet (map, reviews, call)
		wp_enqueue_script( 'dbd-showcase' );
		static $css = false;
		if ( ! $css ) {
			$css  = true;
			$out .= function_exists( 'dlz_inline_css' ) ? dlz_inline_css( 'dbd-showcase', DBD_PATH . 'assets/css/showcase.css' ) : '<link rel="stylesheet" href="' . esc_url( DBD_URL . 'assets/css/showcase.css?ver=' . DBD_VERSION ) . '">';
		}
		return $out;
	}

	/* ------------------------------------------------------------ data */

	private static function cards( $kind, $room = 0, $tags = '' ) {
		$city  = function_exists( 'dlz_current_city' ) ? dlz_current_city() : 'mashhad';
		$cards = array();
		foreach ( DBD_Frontend::ids( (int) $room, $city ) as $id ) {
			$own = (string) DBD_Meta::get( $id, 'kind' );
			if ( '' === $own ) {
				$own = DBD_Frontend::guess_own( $id );
			}
			if ( ! $room && $own !== $kind ) {
				continue;
			}
			$cards[] = DBD_Look::card( $id, $kind );
		}
		if ( '' !== trim( (string) $tags ) ) {
			$want  = array_filter( array_map( 'trim', preg_split( '/[,،]/u', $tags ) ) );
			$cards = array_values( array_filter( $cards, function ( $c ) use ( $want ) { return (bool) array_intersect( $want, $c['tags'] ); } ) );
		}
		return array( $city, $cards );
	}

	private static function i( $k, $cls = 'dsc-i' ) {
		$p = array(
			'pin'    => '<path d="M12 21.2s-6.6-6.1-6.6-11.2a6.6 6.6 0 0 1 13.2 0c0 5.1-6.6 11.2-6.6 11.2z"/><circle cx="12" cy="10" r="2.4"/>',
			'star'   => '<path d="m12 3.6 2.6 5.3 5.8.8-4.2 4.1 1 5.8-5.2-2.7-5.2 2.7 1-5.8-4.2-4.1 5.8-.8z" fill="currentColor" stroke="none"/>',
			'search' => '<circle cx="11" cy="11" r="6.5"/><path d="m20 20-4.2-4.2"/>',
			'chev'   => '<path d="m14.5 6-6 6 6 6"/>',
			'down'   => '<path d="m6.5 9.5 5.5 5.5 5.5-5.5"/>',
			'sort'   => '<path d="M7 4v16M3.5 16.5 7 20l3.5-3.5M17 20V4M13.5 7.5 17 4l3.5 3.5"/>',
			'filter' => '<path d="M4 7h10M18 7h2M4 17h4M12 17h8"/><circle cx="16" cy="7" r="2"/><circle cx="10" cy="17" r="2"/>',
			'nav'    => '<path d="M20.5 3.5 3.5 10.6l7 2.9 2.9 7z"/>',
			'coins'  => '<ellipse cx="9" cy="7.5" rx="5.5" ry="2.6"/><path d="M3.5 7.5v4c0 1.4 2.5 2.6 5.5 2.6s5.5-1.2 5.5-2.6v-4"/><path d="M9.5 16.6c.9 1.2 3 2 5.5 2 3 0 5.5-1.2 5.5-2.6v-4c0-1.4-2.5-2.6-5.5-2.6"/>',
			'hall'   => '<path d="M3 20h18M4.5 20V9.5L12 4l7.5 5.5V20"/><path d="M8 20v-6M12 20v-6M16 20v-6M7 11h10"/>',
			'garden' => '<path d="M12 21v-7M12 14c-4 0-6.5-3-6.5-7.5C9.5 6.5 12 9 12 14zM12 14c4 0 6.5-3 6.5-7.5-4 0-6.5 2.5-6.5 7.5zM5 21h14"/>',
			'empty'  => '<circle cx="9" cy="14" r="4.5"/><circle cx="15" cy="14" r="4.5"/><path d="M10.5 7 12 4.5 13.5 7"/>',
			'scis'   => '<circle cx="6" cy="6.5" r="2.5"/><circle cx="6" cy="17.5" r="2.5"/><path d="M8 8l12 10M8 16 20 6"/>',
			'close'  => '<path d="M6 6l12 12M18 6 6 18"/>',
		);
		return '<svg class="' . esc_attr( $cls ) . '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . ( isset( $p[ $k ] ) ? $p[ $k ] : '' ) . '</svg>';
	}

	private static function rate( $c ) {
		if ( ! $c['count'] ) {
			return '<span class="dsc-rate is-new">' . self::i( 'star' ) . '<small>جديد</small></span>';
		}
		return '<span class="dsc-rate">' . self::i( 'star' ) . '<b dir="ltr">' . esc_html( number_format( (float) $c['rating'], 1 ) ) . '</b><small>(' . (int) $c['count'] . ') تقييم</small></span>';
	}

	private static function heading( $title, $sub ) {
		if ( class_exists( 'DLZ_Labels' ) ) {
			$title = DLZ_Labels::heading( $title ); // the text of the home icon that opens this page
		}
		return '<header class="dsc-hd"><div class="dsc-hd-t"><span class="dsc-orn" aria-hidden="true"><i></i><b></b></span><h2>' . esc_html( $title ) . '</h2><span class="dsc-orn is-r" aria-hidden="true"><b></b><i></i></span></div>' . ( '' !== $sub ? '<p>' . esc_html( $sub ) . '</p>' : '' ) . '</header>';
	}

	private static function attrs( $c, $extra = '' ) {
		$m = (int) round( $c['meters'] );
		return ' data-id="' . (int) $c['id'] . '" data-name="' . esc_attr( mb_strtolower( $c['title'] . ' ' . $c['slogan'] . ' ' . $c['address'] . ' ' . implode( ' ', $c['tags'] ) ) ) . '" data-r="' . esc_attr( $c['rating'] ) . '" data-c="' . (int) $c['count'] . '" data-p="' . esc_attr( $c['price'] ) . '" data-m="' . $m . '"'
			. ( $c['lat'] ? ' data-lat="' . esc_attr( $c['lat'] ) . '" data-lng="' . esc_attr( $c['lng'] ) . '"' : '' ) . $extra . ' tabindex="0" role="link" aria-label="' . esc_attr( $c['title'] ) . '"';
	}

	private static function photo( $c, $cls, $first = false ) {
		$img = $c['img'] ? '<img src="' . esc_url( $c['img'] ) . '" alt="" ' . ( $first ? 'fetchpriority="high"' : 'loading="lazy"' ) . ' decoding="async">' : '<span class="dsc-noimg">' . self::i( 'empty' ) . '</span>';
		$fav = function_exists( 'dlz_favorite_button' ) ? dlz_favorite_button( 'dbd_business', $c['id'] ) : '';
		return '<div class="' . $cls . '">' . $img . $fav . '</div>';
	}

	private static function city_name( $city ) {
		$l = function_exists( 'dlz_city_labels' ) ? dlz_city_labels() : array();
		return isset( $l[ $city ] ) ? $l[ $city ] : '';
	}

	private static function empty_box( $txt ) {
		return '<div class="dsc-empty"><span>' . self::i( 'empty' ) . '</span><p>' . esc_html( $txt ) . '</p></div>';
	}

	/* ------------------------------------------------------------ «قاعات الأفراح وباغ تالار» */

	public static function venues_sc( $a = array() ) {
		$a = shortcode_atts( array( 'title' => 'قاعات الأفراح وباغ تالار', 'subtitle' => 'اختر قاعة أو باغ تالار لمناسبتك السعيدة', 'search' => '1', 'room' => 0, 'tags' => '', 'mobile' => '2' ), $a, 'dalil_venues' );
		return self::venues( $a );
	}

	public static function venues( $a ) {
		list( $city, $cards ) = self::cards( 'venue', (int) $a['room'], $a['tags'] );
		$out  = self::assets();
		$out .= '<div class="dsc dsc-venues" dir="rtl" data-kind="venue">';
		$out .= self::heading( $a['title'], (string) $a['subtitle'] );
		$out .= '<div class="dsc-bar">';
		if ( '1' === (string) $a['search'] ) {
			$out .= '<label class="dsc-search">' . self::i( 'search' ) . '<input type="search" placeholder="ابحث عن قاعة أو باغ تالار…" aria-label="بحث"></label>';
		}
		$out .= '<div class="dsc-chips-bar" role="toolbar" aria-label="تصفية">'
			. '<button type="button" class="dsc-chip is-on" data-t="" aria-pressed="true">الكل</button>'
			. '<button type="button" class="dsc-chip" data-t="hall" aria-pressed="false">' . self::i( 'hall' ) . 'قاعات</button>'
			. '<button type="button" class="dsc-chip" data-t="garden" aria-pressed="false">' . self::i( 'garden' ) . 'باغ تالار</button>';
		$labels = function_exists( 'dlz_city_labels' ) ? dlz_city_labels() : array();
		if ( count( $labels ) > 1 ) {
			$out .= '<span class="dsc-city">' . self::i( 'pin' ) . '<select aria-label="المدينة" data-city>';
			foreach ( $labels as $k => $l ) {
				$out .= '<option value="' . esc_attr( $k ) . '"' . selected( $city, $k, false ) . '>' . esc_html( $l ) . '</option>';
			}
			$out .= '</select>' . self::i( 'down', 'dsc-i dsc-dd' ) . '</span>';
		}
		$out .= '</div></div>';
		$out .= '<div class="dsc-grid' . ( '1' === (string) $a['mobile'] ? ' is-m1' : '' ) . '">';
		foreach ( $cards as $k => $c ) {
			$vt    = in_array( $c['vtype'], array( 'hall', 'garden' ), true ) ? $c['vtype'] : 'hall';
			$chips = array();
			if ( $c['cap'] > 0 ) {
				$chips[] = 'ظرفية ' . number_format( $c['cap'] ) . ' شخص';
			}
			foreach ( $c['feats'] as $f ) {
				$chips[] = $f[1];
			}
			$chips = array_slice( $chips, 0, 3 );
			$loc   = trim( self::city_name( $c['city'] ) . ( $c['address'] ? '، ' . $c['address'] : '' ), '، ' );
			$out  .= '<article class="dsc-v" style="--d:' . (int) min( $k, 10 ) * 40 . 'ms"' . self::attrs( $c, ' data-type="' . $vt . '"' ) . '>';
			$out  .= self::photo( $c, 'dsc-v-ph', $k < 2 );
			$out  .= '<div class="dsc-v-b"><div class="dsc-v-row"><span class="dsc-type">' . self::i( 'garden' === $vt ? 'garden' : 'hall' ) . ( 'garden' === $vt ? 'باغ' : 'قاعة' ) . '</span>' . self::rate( $c ) . '</div>';
			$out  .= '<h3>' . esc_html( $c['title'] ) . '</h3>';
			if ( $loc ) {
				$out .= '<p class="dsc-loc">' . self::i( 'pin' ) . '<span>' . esc_html( $loc ) . '</span></p>';
			}
			if ( $chips ) {
				$out .= '<ul class="dsc-tags">';
				foreach ( $chips as $t ) {
					$out .= '<li>' . esc_html( $t ) . '</li>';
				}
				$out .= '</ul>';
			}
			$out .= '<div class="dsc-v-ft">' . ( $c['price'] > 0 ? '<span class="dsc-pr">من <b dir="ltr">' . esc_html( $c['pnum'] ) . '</b> ' . esc_html( trim( preg_replace( '#/.*#u', '', $c['unit'] ) ) ) . '</span>' : '<span class="dsc-pr is-ask">اتصل للسعر</span>' ) . '<span class="dsc-go">' . self::i( 'chev' ) . '</span></div>';
			$out .= '</div><span class="dsc-o" data-open-business="' . (int) $c['id'] . '" aria-hidden="true"></span></article>';
		}
		$out .= '</div>';
		$out .= '<div class="dsc-none" hidden>' . self::empty_box( 'لا توجد نتائج مطابقة.' ) . '</div>';
		if ( ! $cards ) {
			$out .= self::empty_box( 'لا توجد قاعات في ' . ( self::city_name( $city ) ? self::city_name( $city ) : 'هذه المدينة' ) . ' حالياً.' );
		}
		return $out . '</div>';
	}

	/* ------------------------------------------------------------ «صالونات التجميل» */

	public static function salons_sc( $a = array() ) {
		$a = shortcode_atts( array( 'title' => 'صالونات التجميل', 'subtitle' => '', 'search' => '1', 'room' => 0, 'tags' => '' ), $a, 'dalil_salons' );
		return self::salons( $a );
	}

	public static function salons( $a ) {
		list( $city, $cards ) = self::cards( 'salon', (int) $a['room'], $a['tags'] );
		$cn   = self::city_name( $city );
		$sub  = '' !== trim( (string) $a['subtitle'] ) ? (string) $a['subtitle'] : 'اكتشف أفضل الصالونات' . ( $cn ? ' في ' . $cn : '' );
		$out  = self::assets();
		$out .= '<div class="dsc dsc-salons" dir="rtl" data-kind="salon">';
		if ( '1' === (string) $a['search'] ) {
			$out .= '<label class="dsc-search is-big">' . self::i( 'search' ) . '<input type="search" placeholder="ابحث عن صالون أو خدمة…" aria-label="بحث"></label>';
		}
		$out .= '<div class="dsc-tools"><button type="button" class="dsc-tool" data-sort>' . self::i( 'sort' ) . '<span>الأقرب</span></button><button type="button" class="dsc-tool" data-filter>' . self::i( 'filter' ) . '<span>تصفية</span><em hidden></em></button></div>';
		$out .= self::heading( $a['title'], $sub );
		$out .= '<div class="dsc-list">';
		$svc  = array();
		foreach ( $cards as $k => $c ) {
			$tags = $c['tags'] ? $c['tags'] : array_map( function ( $f ) { return $f[1]; }, $c['feats'] );
			foreach ( $tags as $t ) {
				$svc[ $t ] = 1;
			}
			$hrs = $c['h24'] ? ' data-h24="1"' : ( $c['hfrom'] && $c['hto'] ? ' data-from="' . esc_attr( $c['hfrom'] ) . '" data-to="' . esc_attr( $c['hto'] ) . '"' : '' );
			$loc = $c['address'] ? $c['address'] : self::city_name( $c['city'] );
			$out .= '<article class="dsc-s" style="--d:' . (int) min( $k, 10 ) * 40 . 'ms"' . self::attrs( $c, $hrs . ' data-tags="' . esc_attr( implode( '|', $tags ) ) . '"' ) . '>';
			$out .= '<div class="dsc-s-b"><div class="dsc-s-top"><h3>' . esc_html( $c['title'] ) . '</h3>' . ( $hrs ? '<em class="dsc-open" hidden></em>' : '' ) . '</div>';
			$out .= self::rate( $c );
			if ( $loc ) {
				$out .= '<p class="dsc-loc">' . self::i( 'pin' ) . '<span>' . esc_html( $loc ) . '</span></p>';
			}
			if ( $c['dist'] ) {
				$out .= '<p class="dsc-dist">' . self::i( 'nav' ) . '<span data-dist>' . esc_html( $c['dist'] ) . '</span></p>';
			}
			if ( $tags ) {
				$out .= '<ul class="dsc-tags">';
				foreach ( array_slice( $tags, 0, 4 ) as $t ) {
					$out .= '<li>' . esc_html( $t ) . '</li>';
				}
				$out .= '</ul>';
			}
			$out .= '</div>' . self::photo( $c, 'dsc-s-ph', $k < 1 );
			$out .= '<div class="dsc-s-ft"><span class="dsc-btn">عرض التفاصيل' . self::i( 'chev' ) . '</span>' . ( $c['price'] > 0 ? '<span class="dsc-pr is-soft">' . self::i( 'coins' ) . '<span>يبدأ من <b dir="ltr">' . esc_html( $c['pnum'] ) . '</b> ' . esc_html( trim( preg_replace( '#/.*#u', '', $c['unit'] ) ) ) . '</span></span>' : '' ) . '</div>';
			$out .= '<span class="dsc-o" data-open-business="' . (int) $c['id'] . '" aria-hidden="true"></span></article>';
		}
		$out .= '</div>';
		$out .= '<div class="dsc-none" hidden>' . self::empty_box( 'لا توجد نتائج مطابقة.' ) . '</div>';
		if ( ! $cards ) {
			$out .= self::empty_box( 'لا توجد صالونات في ' . ( $cn ? $cn : 'هذه المدينة' ) . ' حالياً.' );
		}
		// «تصفية» sheet: open now + services
		$out .= '<div class="dsc-sheet" hidden><div class="dsc-sheet-bd" data-close></div><div class="dsc-sheet-box" role="dialog" aria-modal="true" aria-label="تصفية"><span class="dsc-grip"></span><div class="dsc-sheet-hd"><b>تصفية</b><button type="button" class="dsc-x" data-close aria-label="إغلاق">' . self::i( 'close' ) . '</button></div>'
			. '<label class="dsc-sw"><input type="checkbox" data-open-now><span></span>مفتوح الآن فقط</label>';
		if ( $svc ) {
			$out .= '<p class="dsc-sheet-t">الخدمات</p><div class="dsc-svc">';
			foreach ( array_keys( $svc ) as $t ) {
				$out .= '<button type="button" class="dsc-chip" data-svc="' . esc_attr( $t ) . '" aria-pressed="false">' . esc_html( $t ) . '</button>';
			}
			$out .= '</div>';
		}
		$out .= '<div class="dsc-sheet-ft"><button type="button" class="dsc-apply">عرض النتائج</button><button type="button" class="dsc-reset">مسح</button></div></div></div>';
		// «الأقرب» menu
		$out .= '<div class="dsc-menu" hidden role="menu"><button type="button" data-s="near" role="menuitemradio" aria-checked="true">الأقرب</button><button type="button" data-s="top" role="menuitemradio" aria-checked="false">الأعلى تقييماً</button><button type="button" data-s="cheap" role="menuitemradio" aria-checked="false">الأقل سعراً</button></div>';
		return $out . '</div>';
	}
}
DBD_Showcase::init();
