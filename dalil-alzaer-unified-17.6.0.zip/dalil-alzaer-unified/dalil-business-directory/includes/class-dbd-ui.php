<?php
/**
 * Page blocks drawn from the design mockups (used by the Elementor widgets):
 *  • «شبكة الأقسام» — category grid (restaurants / shopping pages)
 *  • «خدمات دائرية» — round service pictures (salons page)
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DBD_UI {

	private static $css = false;

	public static function css() {
		if ( self::$css ) {
			return '';
		}
		self::$css = true;
		wp_enqueue_script( 'dbd-ui', DBD_URL . 'assets/js/ui.js', array(), DBD_VERSION, true );
		if ( function_exists( 'dlz_inline_css' ) ) {
			return dlz_inline_css( 'dbd-ui', DBD_PATH . 'assets/css/ui.css' );
		}
		wp_enqueue_style( 'dbd-ui', DBD_URL . 'assets/css/ui.css', array(), DBD_VERSION );
		return '';
	}

	public static function img( $file ) {
		return DBD_URL . 'assets/ui/' . $file;
	}

	/** Our own section pictures get the file time as version, so a replaced picture is never served from an old cache. */
	private static function bust( $u ) {
		static $base = null;
		if ( null === $base ) {
			$base = DBD_URL . 'assets/ui/';
		}
		if ( '' === $u || 0 !== strpos( $u, $base ) || false !== strpos( $u, '?' ) ) {
			return $u;
		}
		$f = DBD_PATH . 'assets/ui/' . substr( $u, strlen( $base ) );
		return is_file( $f ) ? $u . '?v=' . filemtime( $f ) : $u;
	}

	private static function url( $v ) {
		if ( is_array( $v ) ) {
			return ! empty( $v['url'] ) ? (string) $v['url'] : '';
		}
		return (string) $v;
	}

	private static function link_attrs( $l ) {
		$u = is_array( $l ) ? ( $l['url'] ?? '' ) : (string) $l;
		if ( '' === $u ) {
			return '';
		}
		$ext = is_array( $l ) && ! empty( $l['is_external'] );
		return ' href="' . esc_url( $u ) . '"' . ( $ext ? ' target="_blank" rel="noopener"' : '' );
	}

	public static function lantern() {
		return '<svg viewBox="0 0 40 90" aria-hidden="true"><g fill="none" stroke="currentColor" stroke-width="1.4"><path d="M20 0v18"/><path d="M14 18h12l3 6H11z"/><path d="M11 24c-4 6-4 30 0 36h18c4-6 4-30 0-36z"/><path d="M20 24v36M14 26c-2 6-2 26 0 32M26 26c2 6 2 26 0 32"/><path d="M11 60h18l-3 6H14z"/><path d="M20 66v8"/><circle cx="20" cy="78" r="3"/></g><circle cx="20" cy="42" r="4" fill="currentColor" opacity=".35"/></svg>';
	}

	private static function corner() {
		return '<svg viewBox="0 0 120 120" aria-hidden="true"><g fill="none" stroke="currentColor" stroke-width="1"><path d="M0 40C30 40 40 30 40 0M0 70C50 70 70 50 70 0M0 100C70 100 100 70 100 0"/><path d="M40 0c0 18 12 30 30 30M70 0c0 12 8 20 20 20"/><circle cx="40" cy="40" r="5"/><path d="M14 14l8 8M22 14l-8 8"/></g></svg>';
	}

	/** The minimal page title (same look as the title bar under the app header). */
	public static function mtitle( $t ) {
		$t = trim( (string) $t );
		if ( '' === $t ) {
			return '';
		}
		if ( class_exists( 'DLZ_Labels' ) ) {
			$t = DLZ_Labels::heading( $t ); // the text of the home icon that opens this page
		}
		return '<header class="dui-mt"><h2>' . esc_html( $t ) . '</h2><span class="dui-mt-o" aria-hidden="true"><i></i><b></b><i></i></span></header>';
	}

	/** Arabic / Persian spelling differences out: «المقاهی» = «المقاهي», «و الشاي» = «والشاي» … */
	public static function norm( $s ) {
		$s = (string) $s;
		$s = preg_replace( '/[\x{064B}-\x{065F}\x{0670}\x{0640}]/u', '', $s );
		$s = strtr( $s, array( 'ی' => 'ي', 'ى' => 'ي', 'ک' => 'ك', 'ة' => 'ه', 'أ' => 'ا', 'إ' => 'ا', 'آ' => 'ا', 'ؤ' => 'و', 'ئ' => 'ي', '‌' => '' ) );
		$s = preg_replace( '/[^\p{L}\p{N}]+/u', '', $s );
		return mb_strtolower( $s );
	}

	/** Link of the site page whose title (or address) matches the label — so the ready widgets are linked without typing URLs. */
	public static function auto_link( $label ) {
		static $map = null;
		if ( null === $map ) {
			$map = array();
			$ids = get_posts( array( 'post_type' => 'page', 'post_status' => 'publish', 'posts_per_page' => 400, 'fields' => 'ids', 'no_found_rows' => true, 'orderby' => 'ID', 'order' => 'ASC' ) );
			foreach ( $ids as $id ) {
				foreach ( array( get_the_title( $id ), rawurldecode( (string) get_post_field( 'post_name', $id ) ) ) as $t ) {
					$k = self::norm( $t );
					if ( $k && ! isset( $map[ $k ] ) ) {
						$map[ $k ] = $id;
					}
				}
			}
		}
		$k = self::norm( $label );
		if ( '' === $k ) {
			return '';
		}
		$self = is_singular() ? (int) get_queried_object_id() : 0; // never link an icon back to the page it sits on
		if ( isset( $map[ $k ] ) && $map[ $k ] !== $self ) {
			return get_permalink( $map[ $k ] );
		}
		// «الكباب والمشويات» ↔ page «الكباب» / «المشويات والكباب»: the closest title that contains the other
		$best = 0; $bl = PHP_INT_MAX;
		foreach ( $map as $t => $id ) {
			if ( mb_strlen( $t ) < 4 || $id === $self ) {
				continue;
			}
			if ( false !== mb_strpos( $t, $k ) || false !== mb_strpos( $k, $t ) ) {
				$l = abs( mb_strlen( $t ) - mb_strlen( $k ) );
				if ( $l < $bl ) {
					$bl = $l; $best = $id;
				}
			}
		}
		return $best ? get_permalink( $best ) : '';
	}

	/** The six ready section grids (icons cut from the site's own pages, redrawn sharper). */
	public static function presets() {
		$c = function ( $k, $labels ) {
			$o = array();
			foreach ( $labels as $i => $l ) {
				$o[] = array( $l, 'sec/' . $k . '-' . ( $i + 1 ) . '.jpg' );
			}
			return $o;
		};
		return array(
			'food'  => array( 'المطاعم والمقاهي', 'photo', 2, $c( 'food', array( 'المطاعم', 'الوجبات السريعة', 'الكراعين والباجة', 'المقاهي والشاي العراقي', 'الأسماك والمسكوف', 'الكباب والمشويات' ) ) ),
			'shop'  => array( 'التسوق والهدايا', 'photo', 2, $c( 'shop', array( 'الزعفران والمكسرات', 'العطور والأحجار', 'السجاد والمسابيح', 'العبايات والحجاب', 'الملابس', 'العسل' ) ) ),
			'med'   => array( 'العلاج', 'circle', 3, $c( 'med', array( 'علاج العقم', 'طب العيون', 'طب الأسنان', 'أمراض القلب والشرايين', 'العظام والمفاصل', 'أمراض الدماغ والأعصاب', 'أمراض الجهاز الهضمي', 'أمراض الصدر والتنفس', 'أمراض السرطان', 'أمراض الكلى والمجاري البولية', 'أمراض النساء والولادة', 'أمراض الذكورة والتناسل' ) ) ),
			'cos'   => array( 'التجميل', 'arrow', 3, $c( 'cos', array( 'تجميل الأنف', 'زراعة الشعر', 'نحت الجسم', 'تجميل الجفون', 'تجميل الأسنان', 'شد الوجه', 'تكبير الشفاه', 'شد الرقبة', 'عمليات أخرى' ) ) ),
			'sal'   => array( 'الصالونات', 'circle', 3, $c( 'sal', array( 'إزالة الشامات', 'حقن الفيلر والجل', 'كيراتين وعلاج الشعر', 'المساج والاسترخاء', 'صبغ وهايلايت الشعر', 'تركيب الرموش', 'تاتو وتجميل الحواجب' ) ) ),
			'leg'   => array( 'المساعدة القانونية', 'list', 1, $c( 'leg', array( 'حادث سير أو إصابة', 'احتيال أو مشكلة مالية', 'الزواج والأسرة', 'مشاكل الإقامة والتأشيرة', 'مشكلة مع الفندق', 'مشكلة مع المستشفى', 'مشكلة مع الشرطة', 'فقدان الجواز أو الوثائق', 'مشكلات متفرقة', 'ترجمة ووثائق قانونية' ) ) ),
		);
	}

	/* ------------------------------------------------------------ section grid (ready widgets) */

	public static function sections( $s ) {
		$items = isset( $s['items'] ) && is_array( $s['items'] ) ? $s['items'] : array();
		$style = in_array( $s['style'] ?? 'circle', array( 'photo', 'circle', 'list', 'arrow' ), true ) ? $s['style'] : 'circle';
		$cols  = in_array( (string) ( $s['columns'] ?? '3' ), array( '1', '2', '3' ), true ) ? (string) $s['columns'] : '3';
		if ( 'list' === $style ) {
			$cols = '1'; // one row per item (17.4: «الخدمات القانونية»)
		} elseif ( '1' === $cols ) {
			$cols = '2';
		}
		$chev = 'list' === $style ? '<i class="dui-sx-ch" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="m14.5 6-6 6 6 6"/></svg></i>' : ( 'arrow' === $style ? '<i class="dui-sx-go" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="m9.5 6 6 6-6 6"/></svg></i>' : '' );
		$edit  = class_exists( '\Elementor\Plugin' ) && isset( \Elementor\Plugin::$instance->editor ) && \Elementor\Plugin::$instance->editor->is_edit_mode();
		ob_start();
		echo self::css(); // phpcs:ignore
		echo '<div class="dui dui-sx is-' . esc_attr( $style ) . '" dir="rtl">';
		echo self::mtitle( ! empty( $s['title'] ) ? $s['title'] : ( is_singular() ? get_the_title( get_queried_object_id() ) : '' ) ); // phpcs:ignore
		echo '<div class="dui-sx-g is-c' . esc_attr( $cols ) . '">';
		foreach ( $items as $i => $it ) {
			$img = self::bust( self::url( $it['image'] ?? '' ) );
			$t   = (string) ( $it['title'] ?? '' );
			$l   = $it['link'] ?? '';
			$u   = is_array( $l ) ? ( $l['url'] ?? '' ) : (string) $l;
			if ( '' === $u ) {
				$l = self::auto_link( $t );
			}
			$a = self::link_attrs( $l );
			echo '<a class="dui-sx-c" style="--d:' . (int) min( $i, 12 ) * 35 . 'ms"' . ( $a ? $a : ' role="presentation"' ) . '><span class="dui-sx-p">' . ( $img ? '<img src="' . esc_url( $img ) . '" alt="" loading="' . ( $i < 6 ? 'eager' : 'lazy' ) . '" decoding="async">' : '' ) . '</span><b>' . esc_html( $t ) . '</b>' . $chev . ( $edit && ! $a ? '<em class="dui-sx-nl">بدون لینک</em>' : '' ) . '</a>'; // phpcs:ignore
		}
		echo '</div></div>';
		return ob_get_clean();
	}

	/* ------------------------------------------------------------ category grid */

	public static function catgrid( $s ) {
		$items = isset( $s['items'] ) && is_array( $s['items'] ) ? $s['items'] : array();
		$hs    = $s['header'] ?? 'logo';
		$cols  = in_array( (string) ( $s['columns'] ?? '2' ), array( '2', '3' ), true ) ? (string) $s['columns'] : '2';
		$tone  = in_array( $s['tone'] ?? 'green', array( 'green', 'brown' ), true ) ? $s['tone'] : 'green';
		ob_start();
		echo self::css(); // phpcs:ignore
		echo '<div class="dui dui-cg is-' . esc_attr( $hs ) . ' is-' . esc_attr( $tone ) . '" dir="rtl">';
		// 17.3: no shrine / logo pictures above the icons any more — only the page name, minimal
		if ( 'none' !== $hs ) {
			$t = 'logo' === $hs ? ( ( $s['brand'] ?? '' ) !== 'دليل الزائر' ? ( $s['brand'] ?? '' ) : '' ) : (string) ( $s['title'] ?? '' );
			if ( '' === trim( $t ) && is_singular() ) {
				$t = get_the_title( get_queried_object_id() ); // the page's own name
			}
			echo self::mtitle( $t ); // phpcs:ignore
		}
		if ( ! empty( $s['search'] ) && 'yes' === $s['search'] ) {
			wp_enqueue_script( 'dbd-ui', DBD_URL . 'assets/js/ui.js', array(), DBD_VERSION, true );
			echo '<div class="dui-sr"><label class="dui-sr-in"><input type="search" placeholder="' . esc_attr( $s['search_ph'] ?? 'ابحث…' ) . '" aria-label="بحث">' . DBD_Icons::svg( 'search', 'dui-sr-i' ) . '</label>'; // phpcs:ignore
			if ( ! empty( $s['fav'] ) && 'yes' === $s['fav'] ) {
				$fav = class_exists( 'DLZ_App_Shell' ) ? DLZ_App_Shell::links()['favorites'] : home_url( '/' );
				echo '<a class="dui-fav" href="' . esc_url( $fav ) . '" aria-label="المفضلة">' . DBD_Icons::svg( 'heart', 'dui-fav-i' ) . '</a>'; // phpcs:ignore
			}
			echo '</div>';
		}
		echo '<div class="dui-cg-g is-c' . esc_attr( $cols ) . '">';
		foreach ( $items as $i => $it ) {
			$img = self::url( $it['image'] ?? '' );
			$t   = (string) ( $it['title'] ?? '' );
			$a   = self::link_attrs( $it['link'] ?? '' );
			echo '<a class="dui-cg-c" style="--d:' . (int) min( $i, 8 ) * 45 . 'ms"' . ( $a ? $a : ' role="presentation"' ) . ' data-t="' . esc_attr( mb_strtolower( $t ) ) . '"><span class="dui-cg-p">' . ( $img ? '<img src="' . esc_url( $img ) . '" alt="" loading="' . ( $i < 4 ? 'eager' : 'lazy' ) . '" decoding="async">' : '' ) . '</span><b>' . esc_html( $t ) . '</b>' . DBD_Cards::orn() . '</a>'; // phpcs:ignore
		}
		echo '</div><p class="dui-none" hidden>لا توجد نتائج.</p></div>';
		return ob_get_clean();
	}

	/* ------------------------------------------------------------ round services */

	public static function circles( $s ) {
		$items = isset( $s['items'] ) && is_array( $s['items'] ) ? $s['items'] : array();
		$hero  = self::url( $s['hero'] ?? '' );
		ob_start();
		echo self::css(); // phpcs:ignore
		echo '<div class="dui dui-ci" dir="rtl">';
		echo self::mtitle( $s['title'] ?? '' ); // phpcs:ignore — 17.3: no picture above the icons
		echo '<div class="dui-ci-g">';
		foreach ( $items as $i => $it ) {
			$img = self::url( $it['image'] ?? '' );
			$a   = self::link_attrs( $it['link'] ?? '' );
			echo '<a class="dui-ci-it" style="--d:' . (int) min( $i, 10 ) * 40 . 'ms"' . ( $a ? $a : ' role="presentation"' ) . '><span class="dui-ci-p">' . ( $img ? '<img src="' . esc_url( $img ) . '" alt="" loading="lazy" decoding="async">' : '' ) . '</span><b>' . esc_html( $it['title'] ?? '' ) . '</b></a>';
		}
		echo '</div>';
		if ( ! empty( $s['button'] ) ) {
			$a = self::link_attrs( $s['button_link'] ?? '' );
			echo '<div class="dui-ci-cta"><i></i><a class="dui-ci-btn"' . ( $a ? $a : '' ) . '><span>' . esc_html( $s['button'] ) . '</span>' . DBD_Icons::svg( 'chev', 'dui-ci-bi' ) . '</a><i></i></div>'; // phpcs:ignore
		}
		echo '</div>';
		return ob_get_clean();
	}
}
