<?php
if (!defined('ABSPATH')) exit;

class DBD_Post_Type {
    public static function init() {
        add_action('init', [__CLASS__, 'register']);
        add_filter('manage_dbd_business_posts_columns', [__CLASS__, 'columns']);
        add_action('manage_dbd_business_posts_custom_column', [__CLASS__, 'column_content'], 10, 2);
        add_filter('post_row_actions', [__CLASS__, 'remove_view'], 10, 2);
    }

    public static function register() {
        register_post_type('dbd_business', [
            'labels' => [
                'name' => 'کسب‌وکارها',
                'singular_name' => 'کسب‌وکار',
                'add_new' => 'افزودن کسب‌وکار',
                'add_new_item' => 'افزودن کسب‌وکار جدید',
                'edit_item' => 'ویرایش کسب‌وکار',
                'new_item' => 'کسب‌وکار جدید',
                'view_item' => 'مشاهده کسب‌وکار',
                'search_items' => 'جستجوی کسب‌وکار',
                'not_found' => 'کسب‌وکاری پیدا نشد',
                'menu_name' => 'کسب‌وکارها',
            ],
            'public' => false,
            'show_ui' => true,
            'show_in_menu' => true,
            'menu_icon' => 'dashicons-store',
            'supports' => ['title', 'thumbnail', 'comments', 'page-attributes'],
            'capability_type' => 'post',
            'map_meta_cap' => true,
            'has_archive' => false,
            'rewrite' => false,
            'show_in_rest' => false,
        ]);
    }

    public static function columns($columns) {
        return [
            'cb' => $columns['cb'],
            'title' => 'کسب‌وکار',
            'dbd_status' => 'وضعیت',
            'dbd_full' => 'کامل بودن',
            'dbd_city' => 'شهر',
            'dbd_start' => 'شروع نمایش',
            'dbd_end' => 'پایان نمایش',
            'dbd_priority' => 'اولویت',
            'date' => 'تاریخ ایجاد',
        ];
    }

    public static function column_content($column, $post_id) {
        if ($column === 'dbd_status') {
            $st = DBD_Meta::status($post_id);
            $color = $st === 'active' ? '#1a7f37' : ($st === 'expired' ? '#b32d2e' : '#996800');
            echo '<span class="dbd-badge" style="display:inline-block;padding:2px 8px;border-radius:10px;color:#fff;background:'.$color.'">'.esc_html(DBD_Meta::status_label($st)).'</span>';
        } elseif ($column === 'dbd_full') {
            list($pc, $miss) = DBD_Meta::completeness($post_id);
            $col = $pc >= 90 ? '#1a7f37' : ($pc >= 60 ? '#996800' : '#b32d2e');
            echo '<span title="' . esc_attr($miss ? 'ندارد: ' . implode('، ', $miss) : 'کامل') . '" style="display:inline-flex;align-items:center;gap:6px"><span style="width:54px;height:6px;border-radius:6px;background:#eee;overflow:hidden;display:inline-block"><span style="display:block;height:100%;width:' . (int) $pc . '%;background:' . $col . '"></span></span><b style="color:' . $col . '">' . (int) $pc . '٪</b></span>';
            if ($miss) echo '<div style="font-size:11px;color:#777;margin-top:3px">ندارد: ' . esc_html(implode('، ', array_slice($miss, 0, 4))) . (count($miss) > 4 ? '…' : '') . '</div>';
        } elseif ($column === 'dbd_city') {
            $c = DBD_Meta::get($post_id, 'city');
            $labels = ['mashhad'=>'مشهد','qom'=>'قم','shiraz'=>'شیراز','tehran'=>'تهران'];
            echo esc_html($labels[$c] ?? $c);
        } elseif ($column === 'dbd_start') {
            echo esc_html(DBD_Meta::get($post_id, 'start_date') ?: '—');
        } elseif ($column === 'dbd_end') {
            echo esc_html(DBD_Meta::get($post_id, 'end_date') ?: '—');
        } elseif ($column === 'dbd_priority') {
            echo '<strong>' . intval(get_post_field('menu_order', $post_id)) . '</strong>';
        }
    }

    public static function remove_view($actions, $post) {
        if ($post->post_type === 'dbd_business') unset($actions['view']);
        return $actions;
    }
}
