<?php
/**
 * Listing data + the admin edit form (3.0).
 *
 * Form sections: اطلاعات اصلی · تماس و آدرس · موقعیت روی نقشه · امکانات · خدمات / محصولات ·
 * ضمانت‌ها · تصاویر · قیمت و فاصله · نمایش و انقضا. Every repeater (phones, features, products,
 * guarantees) is free: add, remove, drag to reorder.
 */
if (!defined('ABSPATH')) exit;

class DBD_Meta {
    const NONCE = 'dbd_business_nonce';

    public static function init() {
        add_action('add_meta_boxes', [__CLASS__, 'metabox']);
        add_action('save_post_dbd_business', [__CLASS__, 'save'], 10, 2);
        add_action('admin_enqueue_scripts', [__CLASS__, 'assets']);
        add_filter('manage_dbd_business_posts_sortable_columns', function($cols) {
            $cols['dbd_priority'] = 'menu_order';
            return $cols;
        });
    }

    /** Scalar fields (stored as _dbd_<key>). */
    public static function fields() {
        return [
            'slogan' => '', 'description' => '', 'profile_image' => '',
            'phone' => '', 'whatsapp' => '', 'address' => '',
            'hours_from' => '', 'hours_to' => '', 'open_24' => '', 'hours_note' => '',
            'instagram' => '', 'telegram' => '',
            'address_image' => '', 'map_image' => '', 'map_url' => '',
            'image_1' => '', 'image_2' => '', 'image_3' => '', 'image_4' => '', 'image_5' => '', 'image_6' => '', 'image_7' => '',
            'duration' => '1_month', 'start_date' => '', 'end_date' => '', 'manual_active' => '1',
            'city' => 'mashhad', 'kind' => '', 'features' => '',
            'price_from' => '', 'price_unit' => '', 'distance' => '', 'lat' => '', 'lng' => '',
            'tags' => '', 'offer' => '', 'price_level' => '', 'items_title' => '',
            'venue_type' => '', 'capacity' => '',
        ];
    }

    /** Badges the admin can switch on. key => [Arabic label, icon] */
    public static function badges() {
        return [
            'verified'    => ['موثوق', 'shield'],
            'recommended' => ['موصى به', 'star'],
            'vip'         => ['VIP', 'crown'],
            'arabic'      => ['يتكلم العربية', 'arabic'],
            'delivery'    => ['توصيل للفندق', 'truck'],
            'near'        => ['قريب من الحرم', 'mosque'],
        ];
    }

    public static function get($post_id, $key) {
        $value = get_post_meta($post_id, '_dbd_' . $key, true);
        return $value !== '' ? $value : (self::fields()[$key] ?? '');
    }

    /** Structured lists (arrays of rows). */
    public static function rows($post_id, $key) {
        $v = get_post_meta($post_id, '_dbd_' . $key, true);
        return is_array($v) ? array_values($v) : [];
    }

    /** Features chosen for this listing: [[icon, text], …]. 2.x checkboxes are converted once; there are no defaults any more. */
    public static function feats($post_id) {
        if (metadata_exists('post', $post_id, '_dbd_feats')) {
            $out = [];
            foreach (self::rows($post_id, 'feats') as $r) if (!empty($r['t'])) $out[] = [(string) ($r['i'] ?? 'check'), (string) $r['t']];
            return $out;
        }
        $old = array_filter(array_map('trim', explode(',', (string) get_post_meta($post_id, '_dbd_features', true))));
        $cat = class_exists('DBD_Look') ? DBD_Look::features() : [];
        $out = [];
        foreach ($old as $k) if (isset($cat[$k])) $out[] = [DBD_Icons::from_feature($k), $cat[$k][0]];
        return $out;
    }

    /** Phone numbers: [[label, number], …] — the 2.x single «phone» counts as the first one. */
    public static function phones($post_id) {
        $out = [];
        foreach (self::rows($post_id, 'phones') as $r) if (!empty($r['n'])) $out[] = [(string) ($r['l'] ?? ''), (string) $r['n']];
        if (!$out && ($p = trim((string) get_post_meta($post_id, '_dbd_phone', true)))) $out[] = ['', $p];
        return $out;
    }

    public static function items($post_id) {
        $out = [];
        foreach (self::rows($post_id, 'items') as $r) if (!empty($r['t'])) $out[] = ['img' => (string) ($r['img'] ?? ''), 't' => (string) $r['t'], 'd' => (string) ($r['d'] ?? ''), 'p' => (string) ($r['p'] ?? ''), 'o' => (string) ($r['o'] ?? '')];
        return $out;
    }

    public static function trust($post_id) {
        $out = [];
        foreach (self::rows($post_id, 'trust') as $r) if (!empty($r['t'])) $out[] = [(string) ($r['i'] ?? 'check'), (string) $r['t'], (string) ($r['s'] ?? '')];
        return $out;
    }

    public static function badge_keys($post_id) {
        $v = get_post_meta($post_id, '_dbd_badges', true);
        return is_array($v) ? array_values(array_intersect($v, array_keys(self::badges()))) : [];
    }

    public static function metabox() {
        add_meta_box('dbd_business_details', 'اطلاعات کسب‌وکار', [__CLASS__, 'render'], 'dbd_business', 'normal', 'high');
    }

    public static function assets($hook) {
        $s = function_exists('get_current_screen') ? get_current_screen() : null;
        if (!$s || $s->post_type !== 'dbd_business' || !in_array($hook, ['post.php', 'post-new.php'], true)) return;
        wp_enqueue_media();
        wp_enqueue_style('dbd-admin-edit', DBD_URL . 'assets/css/admin-edit.css', [], DBD_VERSION);
        wp_enqueue_script('dbd-tilemap', DBD_URL . 'assets/js/tilemap.js', [], DBD_VERSION, true);
        wp_enqueue_script('dbd-admin-edit', DBD_URL . 'assets/js/admin-edit.js', ['dbd-tilemap'], DBD_VERSION, true);
        $icons = [];
        foreach (DBD_Icons::all() as $k => $v) $icons[$k] = [$v[0], $v[1]];
        wp_localize_script('dbd-admin-edit', 'DBDEdit', [
            'icons' => $icons,
            'tiles' => DBD_Frontend::tiles(),
            'haram' => [
                'mashhad' => DBD_Look::haram('mashhad'), 'qom' => DBD_Look::haram('qom'),
                'shiraz' => DBD_Look::haram('shiraz'), 'tehran' => DBD_Look::haram('tehran'),
            ],
        ]);
    }

    /* ------------------------------------------------------------ form */

    private static function media($name, $value, $label, $round = false) {
        $id = 'dbdm-' . md5($name . wp_rand());
        echo '<div class="dbde-media' . ($round ? ' is-round' : '') . '"><span class="dbde-media-ph"' . ($value ? ' style="background-image:url(' . esc_url($value) . ')"' : '') . '></span>';
        echo '<input type="hidden" name="' . esc_attr($name) . '" value="' . esc_attr($value) . '">';
        echo '<span class="dbde-media-b"><button type="button" class="button dbde-pick">' . esc_html($label) . '</button> <button type="button" class="button-link dbde-unpick">حذف</button></span></div>';
    }

    private static function icon_btn($name, $value) {
        $value = isset(DBD_Icons::all()[$value]) ? $value : 'check';
        return '<button type="button" class="dbde-ico" title="انتخاب آیکن">' . DBD_Icons::svg($value, 'dbde-ico-svg') . '<input type="hidden" name="' . esc_attr($name) . '" value="' . esc_attr($value) . '"></button>';
    }

    /** One repeater row; «__i__» in the template row is replaced by JS. */
    private static function row($type, $i, $r) {
        $n = 'dbd[' . $type . '][' . $i . ']';
        $h = '<div class="dbde-row" data-type="' . esc_attr($type) . '"><span class="dbde-drag" title="جابه‌جایی" draggable="true">⋮⋮</span>';
        if ($type === 'phones') {
            $h .= '<input type="text" class="dbde-sm" name="' . $n . '[l]" value="' . esc_attr($r['l'] ?? '') . '" placeholder="عنوان (اختیاری)، مثلاً: الاستقبال">';
            $h .= '<input type="text" name="' . $n . '[n]" value="' . esc_attr($r['n'] ?? '') . '" placeholder="شماره تلفن" dir="ltr">';
        } elseif ($type === 'feats') {
            $h .= self::icon_btn($n . '[i]', $r['i'] ?? 'check');
            $h .= '<input type="text" name="' . $n . '[t]" value="' . esc_attr($r['t'] ?? '') . '" placeholder="متن امکان به عربی، مثلاً: توصيل مجاني">';
        } elseif ($type === 'trust') {
            $h .= self::icon_btn($n . '[i]', $r['i'] ?? 'medal');
            $h .= '<input type="text" class="dbde-sm" name="' . $n . '[t]" value="' . esc_attr($r['t'] ?? '') . '" placeholder="عنوان، مثلاً: ضمان الجودة">';
            $h .= '<input type="text" name="' . $n . '[s]" value="' . esc_attr($r['s'] ?? '') . '" placeholder="توضیح کوتاه، مثلاً: 100% أصلي">';
        } else { // items
            ob_start(); self::media($n . '[img]', $r['img'] ?? '', 'عکس');
            $h .= '<span class="dbde-item">' . ob_get_clean();
            $h .= '<span class="dbde-item-f"><input type="text" name="' . $n . '[t]" value="' . esc_attr($r['t'] ?? '') . '" placeholder="نام خدمت / محصول، مثلاً: صبغ الشعر">';
            $h .= '<input type="text" name="' . $n . '[d]" value="' . esc_attr($r['d'] ?? '') . '" placeholder="توضیح کوتاه (اختیاری)">';
            $h .= '<span class="dbde-item-pp"><input type="text" class="dbde-sm" name="' . $n . '[p]" value="' . esc_attr($r['p'] ?? '') . '" placeholder="قیمت، مثلاً: 320,000 تومان"><input type="text" class="dbde-sm" name="' . $n . '[o]" value="' . esc_attr($r['o'] ?? '') . '" placeholder="قیمت قبل از تخفیف (اختیاری)"></span></span></span>';
        }
        return $h . '<button type="button" class="dbde-del" title="حذف">×</button></div>';
    }

    private static function repeater($type, $rows, $add, $help = '') {
        echo '<div class="dbde-rep" data-type="' . esc_attr($type) . '"><div class="dbde-rows">';
        foreach ($rows as $i => $r) echo self::row($type, $i, $r); // phpcs:ignore
        echo '</div><template>' . self::row($type, '__i__', []) . '</template>'; // phpcs:ignore
        echo '<button type="button" class="button dbde-add">+ ' . esc_html($add) . '</button>';
        if ($help) echo '<p class="dbde-help">' . esc_html($help) . '</p>';
        echo '</div>';
    }

    public static function render($post) {
        wp_nonce_field(self::NONCE, self::NONCE);
        $f = self::fields();
        foreach ($f as $k => $v) $f[$k] = self::get($post->ID, $k);
        // «افزودن تالار» / «افزودن سالن» from the dashboard menu: the kind is chosen already
        if ('auto-draft' === $post->post_status && isset($_GET['dbd_kind']) && isset(DBD_Look::kinds()[sanitize_key(wp_unslash($_GET['dbd_kind']))])) $f['kind'] = sanitize_key(wp_unslash($_GET['dbd_kind'])); // phpcs:ignore
        $phones = array_map(function ($p) { return ['l' => $p[0], 'n' => $p[1]]; }, self::phones($post->ID));
        $feats  = array_map(function ($p) { return ['i' => $p[0], 't' => $p[1]]; }, self::feats($post->ID));
        $trust  = array_map(function ($p) { return ['i' => $p[0], 't' => $p[1], 's' => $p[2]]; }, self::trust($post->ID));
        $items  = self::items($post->ID);
        $badges = self::badge_keys($post->ID);
        $kinds  = DBD_Look::kinds();
        $secs   = ['main' => 'اطلاعات اصلی', 'contact' => 'تماس و آدرس', 'map' => 'نقشه', 'feats' => 'امکانات', 'items' => 'خدمات / محصولات', 'trust' => 'ضمانت‌ها', 'imgs' => 'تصاویر', 'price' => 'قیمت و فاصله', 'pub' => 'نمایش'];
        ?>
        <div class="dbde" dir="rtl">
        <?php echo self::status_notice($post->ID); // phpcs:ignore ?>
        <nav class="dbde-nav"><?php foreach ($secs as $k => $l) echo '<a href="#dbde-' . esc_attr($k) . '">' . esc_html($l) . '</a>'; ?></nav>

        <section class="dbde-sec" id="dbde-main">
            <h3><span>۱</span>اطلاعات اصلی</h3>
            <div class="dbde-grid">
                <div class="full"><label>توضیحات (عن المكان) — به عربی</label><textarea name="dbd[description]" rows="5" placeholder="چند جمله درباره‌ی مغازه، خدمات و ویژگی‌هایش…"><?php echo esc_textarea($f['description']); ?></textarea></div>
                <div><label>شعار / توضیح کوتاه زیر اسم</label><input type="text" name="dbd[slogan]" value="<?php echo esc_attr($f['slogan']); ?>" placeholder="مثلاً: أجود أنواع العسل الطبيعي"></div>
                <div><label>متن پیشنهاد ویژه (کارت «العرض المميز»)</label><input type="text" name="dbd[offer]" value="<?php echo esc_attr($f['offer']); ?>" placeholder="مثلاً: خصم خاص للزائرات العراقيات"></div>
                <div><label>لوگو / تصویر پروفایل</label><?php self::media('dbd[profile_image]', $f['profile_image'], 'انتخاب لوگو', true); ?></div>
                <div>
                    <label>نوع کسب‌وکار</label>
                    <select name="dbd[kind]"><option value="" <?php selected($f['kind'], ''); ?>>مثل تنظیم ویجت صفحه</option><?php foreach ($kinds as $k => $kd) : ?><option value="<?php echo esc_attr($k); ?>" <?php selected($f['kind'], $k); ?>><?php echo esc_html($kd[1] . ' — ' . $kd[0]); ?></option><?php endforeach; ?></select>
                    <label class="dbde-mt">شهر</label>
                    <select name="dbd[city]" class="dbde-city"><?php foreach (['mashhad' => 'مشهد', 'qom' => 'قم', 'shiraz' => 'شیراز', 'tehran' => 'تهران'] as $k => $l) echo '<option value="' . esc_attr($k) . '"' . selected($f['city'], $k, false) . '>' . esc_html($l) . '</option>'; ?></select>
                </div>
                <div class="full"><label>نشان‌ها (روی کارت و صفحه نمایش داده می‌شوند)</label>
                    <div class="dbde-chips"><?php foreach (self::badges() as $k => $b) : ?><label class="dbde-chip"><input type="checkbox" name="dbd[badges][]" value="<?php echo esc_attr($k); ?>" <?php checked(in_array($k, $badges, true)); ?>><?php echo DBD_Icons::svg($b[1], 'dbde-chip-i'); // phpcs:ignore ?><span><?php echo esc_html($b[0]); ?></span></label><?php endforeach; ?></div>
                    <p class="dbde-help">«قريب من الحرم» اگر تیک نخورد ولی فاصله تا حرم کمتر از ۱ کیلومتر باشد، خودکار نمایش داده می‌شود.</p>
                </div>
                <div><label>دسته / برچسب‌ها / خدمات</label><input type="text" name="dbd[tags]" value="<?php echo esc_attr($f['tags']); ?>" placeholder="مثلاً: زعفران، مول — برای سالن: كيراتين، صبغ الشعر، تركيب الرموش"><p class="dbde-help">با ویرگول جدا کنید. برای سالن‌ها همین‌ها «خدماتی که انجام می‌دهند» هستند و روی کارت نمایش داده می‌شوند. در ویجت «قائمة المتاجر» با همین برچسب‌ها تب می‌سازید.</p></div>
                <div class="full dbde-venue"<?php echo 'venue' === $f['kind'] ? '' : ' hidden'; ?>>
                    <div class="dbde-grid">
                        <div><label>نوع تالار</label><select name="dbd[venue_type]"><option value="">—</option><option value="hall" <?php selected($f['venue_type'], 'hall'); ?>>تالار (قاعة)</option><option value="garden" <?php selected($f['venue_type'], 'garden'); ?>>باغ‌تالار (باغ)</option></select></div>
                        <div><label>ظرفیت (نفر)</label><input type="text" inputmode="numeric" name="dbd[capacity]" value="<?php echo esc_attr($f['capacity']); ?>" dir="ltr" placeholder="مثلاً 400"></div>
                    </div>
                    <p class="dbde-help">امکانات تالار (پارکینگ، خدمات پذیرایی، موقف صبارات، باغ مسترز…) را در بخش «امکانات» با آیکن اضافه کنید؛ سه‌تای اول روی کارت نمایش داده می‌شوند.</p>
                </div>
                <script>(function(){var k=document.querySelector('select[name="dbd[kind]"]'),v=document.querySelector('.dbde-venue');if(k&&v)k.addEventListener('change',function(){v.hidden=k.value!=='venue';});})();</script>
                <div><label>سطح قیمت</label><select name="dbd[price_level]"><option value="">—</option><?php for ($i = 1; $i <= 4; $i++) echo '<option value="' . $i . '"' . selected((string) $f['price_level'], (string) $i, false) . '>' . str_repeat('$', $i) . '</option>'; ?></select></div>
            </div>
        </section>

        <section class="dbde-sec" id="dbde-contact">
            <h3><span>۲</span>تماس و آدرس</h3>
            <label>شماره‌های تماس</label>
            <?php self::repeater('phones', $phones, 'افزودن شماره', 'اولین شماره روی دکمه‌ی «اتصال» قرار می‌گیرد. برای هر شماره می‌توانید عنوان بگذارید.'); ?>
            <div class="dbde-grid">
                <div><label>واتساپ</label><input type="text" name="dbd[whatsapp]" value="<?php echo esc_attr($f['whatsapp']); ?>" dir="ltr" placeholder="9647801234567 یا لینک wa.me"></div>
                <div><label>آدرس متنی (به عربی)</label><input type="text" name="dbd[address]" value="<?php echo esc_attr($f['address']); ?>" placeholder="مشهد، شارع الإمام الرضا، زقاق 12"></div>
                <div><label>ساعت کاری — از</label><input type="time" name="dbd[hours_from]" value="<?php echo esc_attr($f['hours_from']); ?>" dir="ltr"></div>
                <div><label>ساعت کاری — تا</label><input type="time" name="dbd[hours_to]" value="<?php echo esc_attr($f['hours_to']); ?>" dir="ltr"></div>
                <div><label class="dbde-check"><input type="checkbox" name="dbd[open_24]" value="1" <?php checked($f['open_24'], '1'); ?>> شبانه‌روزی (۲۴ ساعته)</label></div>
                <div><label>توضیح ساعت کاری (اختیاری)</label><input type="text" name="dbd[hours_note]" value="<?php echo esc_attr($f['hours_note']); ?>" placeholder="مثلاً: يومياً عدا الجمعة"></div>
                <div><label>اینستاگرام</label><input type="text" name="dbd[instagram]" value="<?php echo esc_attr($f['instagram']); ?>" dir="ltr" placeholder="@shop"></div>
                <div><label>تلگرام</label><input type="text" name="dbd[telegram]" value="<?php echo esc_attr($f['telegram']); ?>" dir="ltr" placeholder="@shop"></div>
                <div><label>تصویر آدرس (اختیاری)</label><?php self::media('dbd[address_image]', $f['address_image'], 'انتخاب تصویر'); ?></div>
                <div><label>تصویر نقشه (اختیاری، اگر پین ندارد)</label><?php self::media('dbd[map_image]', $f['map_image'], 'انتخاب تصویر'); ?></div>
            </div>
        </section>

        <section class="dbde-sec" id="dbde-map">
            <h3><span>۳</span>موقعیت روی نقشه</h3>
            <p class="dbde-help">آدرس را جستجو کنید یا روی نقشه بزنید تا پین ثبت شود؛ پین را می‌توانید بکشید. فاصله تا حرم خودکار حساب می‌شود.</p>
            <div class="dbde-mapbar"><input type="search" class="dbde-geo-q" placeholder="جستجوی آدرس یا نام مکان… (مثلاً: فندق درويشي مشهد)"><button type="button" class="button dbde-geo-go">جستجو</button><button type="button" class="button dbde-geo-me">موقعیت فعلی من</button><button type="button" class="button-link dbde-geo-clear">حذف پین</button></div>
            <div class="dbde-geo-res" hidden></div>
            <div class="dbde-map"></div>
            <div class="dbde-grid dbde-ll">
                <div><label>عرض جغرافیایی (Lat)</label><input type="text" name="dbd[lat]" class="dbde-lat" value="<?php echo esc_attr($f['lat']); ?>" dir="ltr"></div>
                <div><label>طول جغرافیایی (Lng)</label><input type="text" name="dbd[lng]" class="dbde-lng" value="<?php echo esc_attr($f['lng']); ?>" dir="ltr"></div>
                <div class="full"><label>لینک Google Maps (اختیاری)</label><input type="url" name="dbd[map_url]" value="<?php echo esc_attr($f['map_url']); ?>" dir="ltr"><p class="dbde-help">اگر پین نگذارید، مختصات از همین لینک خوانده می‌شود.</p></div>
            </div>
        </section>

        <section class="dbde-sec" id="dbde-feats">
            <h3><span>۴</span>امکانات (المميزات)</h3>
            <?php self::repeater('feats', $feats, 'افزودن امکان', 'فقط همین موارد نمایش داده می‌شوند؛ اگر خالی باشد بخش امکانات نمایش داده نمی‌شود. روی آیکن بزنید تا عوضش کنید.'); ?>
        </section>

        <section class="dbde-sec" id="dbde-items">
            <h3><span>۵</span>خدمات / محصولات</h3>
            <div class="dbde-grid"><div><label>عنوان این بخش</label><input type="text" name="dbd[items_title]" value="<?php echo esc_attr($f['items_title']); ?>" placeholder="خالی = خودکار (الخدمات / منتجاتنا / قائمة الطعام …)"></div></div>
            <?php self::repeater('items', $items, 'افزودن خدمت / محصول'); ?>
        </section>

        <section class="dbde-sec" id="dbde-trust">
            <h3><span>۶</span>ضمانت‌ها (ردیف زیر محصولات)</h3>
            <?php self::repeater('trust', $trust, 'افزودن ضمانت', 'مثلاً: ضمان الجودة · شحن سريع · تغليف فاخر'); ?>
        </section>

        <section class="dbde-sec" id="dbde-imgs">
            <h3><span>۷</span>تصاویر</h3>
            <p class="dbde-help">تصویر ۱ عکس بزرگ بالای صفحه و عکس کارت است؛ بقیه در گالری لغزنده و «معرض الصور» نمایش داده می‌شوند.</p>
            <div class="dbde-imgs"><?php for ($i = 1; $i <= 7; $i++) { echo '<div><small>تصویر ' . (int) $i . '</small>'; self::media('dbd[image_' . $i . ']', $f['image_' . $i], 'انتخاب'); echo '</div>'; } ?></div>
        </section>

        <section class="dbde-sec" id="dbde-price">
            <h3><span>۸</span>قیمت و فاصله</h3>
            <div class="dbde-grid">
                <div><label>قیمت «ابتداءً من»</label><input type="text" inputmode="numeric" name="dbd[price_from]" value="<?php echo esc_attr($f['price_from']); ?>" dir="ltr" placeholder="50000"></div>
                <div><label>واحد قیمت</label><input type="text" name="dbd[price_unit]" value="<?php echo esc_attr($f['price_unit']); ?>" placeholder="خالی = پیش‌فرض نوع (مثلاً د.ع / ليلة)"></div>
                <div><label>فاصله تا حرم (متر)</label><input type="text" inputmode="numeric" name="dbd[distance]" value="<?php echo esc_attr($f['distance']); ?>" dir="ltr" placeholder="خودکار از روی پین نقشه"></div>
            </div>
        </section>

        <section class="dbde-sec" id="dbde-pub">
            <h3><span>۹</span>نمایش و انقضا</h3>
            <div class="dbde-grid">
                <div><label>مدت نمایش</label>
                    <select name="dbd[duration]"><?php foreach (['15_days' => '۱۵ روز', '1_month' => '۱ ماه', '3_months' => '۳ ماه', '6_months' => '۶ ماه', '1_year' => '۱ سال', 'unlimited' => 'بدون محدودیت (دائمی)'] as $k => $l) echo '<option value="' . esc_attr($k) . '"' . selected($f['duration'], $k, false) . '>' . esc_html($l) . '</option>'; ?></select>
                    <label class="dbde-check"><input type="checkbox" name="dbd[renew]" value="1"> تمدید از امروز</label>
                </div>
                <div><label>تاریخ شروع</label><input type="date" name="dbd[start_date]" value="<?php echo esc_attr($f['start_date']); ?>"></div>
                <div><label>تاریخ پایان</label><input type="date" value="<?php echo esc_attr($f['end_date']); ?>" readonly></div>
                <div><label class="dbde-check"><input type="checkbox" name="dbd[manual_active]" value="1" <?php checked($f['manual_active'], '1'); ?>> نمایش فعال باشد</label></div>
            </div>
            <?php $ow = (int) get_post_meta($post->ID, '_dbd_owner', true); $ou = $ow ? get_userdata($ow) : null; $op = $ou ? (string) get_user_meta($ow, 'mp_sms_phone', true) : ''; $oe = (int) get_post_meta($post->ID, '_dbd_owner_edit', true); ?>
            <div class="dbde-owner">
                <label>صاحب مغازه (پنل «متجري»)</label>
                <?php if ($ou) : ?><p class="dbde-owner-now"><b><?php echo esc_html(trim($ou->display_name) && 0 !== strpos($ou->display_name, 'mp_') ? $ou->display_name : 'کاربر'); ?></b> <span dir="ltr"><?php echo esc_html($op); ?></span><?php if ($oe) echo ' · آخرین ویرایش صاحب مغازه: ' . esc_html(wp_date('Y/m/d H:i', $oe)); ?></p><?php endif; ?>
                <input type="text" name="dbd[owner_phone]" value="<?php echo esc_attr($op); ?>" dir="ltr" placeholder="شماره‌ای که صاحب مغازه با آن وارد سایت شده — مثلاً 09121234567 یا +9647701234567">
                <p class="dbde-help">صاحب مغازه با همین شماره وارد سایت می‌شود و در صفحه‌ی «متجري» محصولات، قیمت‌ها، توضیحات، ساعت کاری و عکس‌ها را خودش ویرایش می‌کند. خالی = بدون صاحب. (اگر هنوز وارد سایت نشده، اول یک بار وارد شود.)</p>
            </div>
        </section>
        <div class="dbde-pop" hidden><input type="search" class="dbde-pop-q" placeholder="جستجوی آیکن…"><div class="dbde-pop-g"></div></div>
        </div>
        <?php
    }

    /* ------------------------------------------------------------ save */

    public static function digits($s) {
        return strtr((string) $s, ['۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9','٠'=>'0','١'=>'1','٢'=>'2','٣'=>'3','٤'=>'4','٥'=>'5','٦'=>'6','٧'=>'7','٨'=>'8','٩'=>'9']);
    }

    public static function save($post_id, $post) {
        if (!isset($_POST[self::NONCE]) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST[self::NONCE])), self::NONCE)) return;
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
        if (!current_user_can('edit_post', $post_id)) return;
        if (!isset($_POST['dbd']) || !is_array($_POST['dbd'])) return;
        $raw = wp_unslash($_POST['dbd']); // phpcs:ignore — every key is sanitised in store()
        self::store($post_id, $raw);
        if (array_key_exists('owner_phone', $raw)) self::set_owner($post_id, (string) $raw['owner_phone']);
    }

    /** Admin: link the listing to the account that signed in with this phone number. */
    public static function set_owner($post_id, $phone) {
        $p = preg_replace('/[^\d+]/', '', self::digits(trim($phone)));
        if ($p === '') { delete_post_meta($post_id, '_dbd_owner'); return; }
        if (strpos($p, '00') === 0) $p = '+' . substr($p, 2);
        if (preg_match('/^(?:\+98|98)(9\d{9})$/', $p, $m)) $p = '0' . $m[1];
        elseif (preg_match('/^9\d{9}$/', $p)) $p = '0' . $p;
        $u = get_users(['meta_key' => 'mp_sms_phone', 'meta_value' => $p, 'number' => 1, 'fields' => 'ID']);
        if ($u) update_post_meta($post_id, '_dbd_owner', (int) $u[0]);
        else set_transient('dbd_owner_miss_' . get_current_user_id(), $p, 60);
    }

    /** Shared by the admin form and the public «سجّل متجرك» form ($partial = only the keys present are written). */
    public static function store($post_id, $raw, $partial = false) {
        $icons = DBD_Icons::all();
        $urls  = ['map_url', 'address_image', 'map_image', 'profile_image', 'image_1', 'image_2', 'image_3', 'image_4', 'image_5', 'image_6', 'image_7'];
        foreach (array_keys(self::fields()) as $key) {
            if ($partial && !array_key_exists($key, $raw)) continue;
            switch ($key) {
                case 'features': case 'lat': case 'lng': case 'end_date': case 'phone':
                    continue 2;
                case 'kind':
                    $v = sanitize_key($raw['kind'] ?? '');
                    update_post_meta($post_id, '_dbd_kind', isset(DBD_Look::kinds()[$v]) ? $v : '');
                    continue 2;
                case 'venue_type':
                    $v = sanitize_key($raw['venue_type'] ?? '');
                    update_post_meta($post_id, '_dbd_venue_type', in_array($v, ['hall', 'garden'], true) ? $v : '');
                    continue 2;
                case 'capacity':
                    $v = (int) preg_replace('/\D/', '', self::digits($raw['capacity'] ?? ''));
                    update_post_meta($post_id, '_dbd_capacity', $v > 0 ? (string) min($v, 100000) : '');
                    continue 2;
                case 'price_from': case 'distance':
                    update_post_meta($post_id, '_dbd_' . $key, preg_replace('/[^\d.]/', '', self::digits($raw[$key] ?? '')));
                    continue 2;
                case 'price_level':
                    $v = (int) ($raw['price_level'] ?? 0);
                    update_post_meta($post_id, '_dbd_price_level', $v >= 1 && $v <= 4 ? (string) $v : '');
                    continue 2;
                case 'open_24':
                    update_post_meta($post_id, '_dbd_open_24', !empty($raw['open_24']) ? '1' : '');
                    continue 2;
                case 'manual_active':
                    update_post_meta($post_id, '_dbd_manual_active', isset($raw['manual_active']) ? '1' : '0');
                    continue 2;
                case 'hours_from': case 'hours_to':
                    $t = trim(self::digits($raw[$key] ?? ''));
                    update_post_meta($post_id, '_dbd_' . $key, preg_match('/^([01]?\d|2[0-3]):[0-5]\d$/', $t) ? str_pad($t, 5, '0', STR_PAD_LEFT) : '');
                    continue 2;
                case 'description':
                    update_post_meta($post_id, '_dbd_description', sanitize_textarea_field($raw['description'] ?? ''));
                    continue 2;
                case 'city':
                    $v = sanitize_key($raw['city'] ?? '');
                    update_post_meta($post_id, '_dbd_city', in_array($v, ['mashhad', 'qom', 'shiraz', 'tehran'], true) ? $v : 'mashhad');
                    continue 2;
                case 'duration':
                    $v = sanitize_key($raw['duration'] ?? '1_month');
                    update_post_meta($post_id, '_dbd_duration', in_array($v, ['15_days', '1_month', '3_months', '6_months', '1_year', 'unlimited'], true) ? $v : '1_month');
                    continue 2;
            }
            $v = sanitize_text_field($raw[$key] ?? '');
            if (in_array($key, $urls, true)) $v = esc_url_raw($v);
            update_post_meta($post_id, '_dbd_' . $key, $v);
        }

        // repeaters
        if (!$partial || isset($raw['phones'])) {
            $rows = [];
            foreach ((array) ($raw['phones'] ?? []) as $r) {
                if (!is_array($r)) continue;
                $n = trim(preg_replace('/[^\d+\s\-()]/', '', self::digits($r['n'] ?? '')));
                if ($n !== '') $rows[] = ['l' => sanitize_text_field($r['l'] ?? ''), 'n' => $n];
            }
            update_post_meta($post_id, '_dbd_phones', array_slice($rows, 0, 10));
            update_post_meta($post_id, '_dbd_phone', $rows ? $rows[0]['n'] : '');
        }
        if (!$partial || isset($raw['feats'])) {
            $rows = [];
            foreach ((array) ($raw['feats'] ?? []) as $r) {
                if (!is_array($r)) continue;
                $t = sanitize_text_field($r['t'] ?? '');
                $i = sanitize_key($r['i'] ?? 'check');
                if ($t !== '') $rows[] = ['i' => isset($icons[$i]) ? $i : 'check', 't' => $t];
            }
            update_post_meta($post_id, '_dbd_feats', array_slice($rows, 0, 30));
            update_post_meta($post_id, '_dbd_features', '');
        }
        if (!$partial || isset($raw['trust'])) {
            $rows = [];
            foreach ((array) ($raw['trust'] ?? []) as $r) {
                if (!is_array($r)) continue;
                $t = sanitize_text_field($r['t'] ?? '');
                $i = sanitize_key($r['i'] ?? 'check');
                if ($t !== '') $rows[] = ['i' => isset($icons[$i]) ? $i : 'check', 't' => $t, 's' => sanitize_text_field($r['s'] ?? '')];
            }
            update_post_meta($post_id, '_dbd_trust', array_slice($rows, 0, 8));
        }
        if (!$partial || isset($raw['items'])) {
            $rows = [];
            foreach ((array) ($raw['items'] ?? []) as $r) {
                if (!is_array($r)) continue;
                $t = sanitize_text_field($r['t'] ?? '');
                if ($t !== '') $rows[] = ['img' => esc_url_raw($r['img'] ?? ''), 't' => mb_substr($t, 0, 90), 'd' => mb_substr(sanitize_textarea_field($r['d'] ?? ''), 0, 700), 'p' => mb_substr(sanitize_text_field(self::digits($r['p'] ?? '')), 0, 40), 'o' => mb_substr(sanitize_text_field(self::digits($r['o'] ?? '')), 0, 40)];
            }
            update_post_meta($post_id, '_dbd_items', array_slice($rows, 0, 80));
        }
        if (!$partial || isset($raw['badges'])) {
            $b = array_values(array_intersect(array_map('sanitize_key', (array) ($raw['badges'] ?? [])), array_keys(self::badges())));
            update_post_meta($post_id, '_dbd_badges', $b);
        }

        // map position: pin / typed / pasted, otherwise read from the Google Maps link
        if (!$partial || isset($raw['lat']) || isset($raw['map_url'])) {
            $pair = null;
            foreach (['lat', 'lng'] as $k) {
                if (!empty($raw[$k]) && ($p = DBD_Look::parse_latlng(self::digits($raw[$k])))) $pair = $p;
            }
            $la = trim(self::digits($raw['lat'] ?? '')); $ln = trim(self::digits($raw['lng'] ?? ''));
            if (!$pair && is_numeric($la) && is_numeric($ln)) $pair = [(float) $la, (float) $ln];
            if (!$pair && !empty($raw['map_url'])) $pair = DBD_Look::parse_latlng($raw['map_url']);
            if ($pair && abs($pair[0]) <= 90 && abs($pair[1]) <= 180 && ($pair[0] || $pair[1])) {
                update_post_meta($post_id, '_dbd_lat', round($pair[0], 6));
                update_post_meta($post_id, '_dbd_lng', round($pair[1], 6));
            } else {
                delete_post_meta($post_id, '_dbd_lat');
                delete_post_meta($post_id, '_dbd_lng');
            }
        }

        if (!$partial) {
            $start = sanitize_text_field($raw['start_date'] ?? '');
            if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $start)) $start = '';
            $duration = sanitize_key($raw['duration'] ?? '1_month');
            if (!$start || !empty($raw['renew'])) $start = current_time('Y-m-d');
            if (!empty($raw['renew'])) update_post_meta($post_id, '_dbd_manual_active', '1');
            update_post_meta($post_id, '_dbd_start_date', $start);
            update_post_meta($post_id, '_dbd_end_date', self::calculate_end($start, $duration));
        }
        if (class_exists('DBD_Frontend')) DBD_Frontend::flush();
    }

    public static function calculate_end($start, $duration) {
        try {
            $dt = new DateTime($start, wp_timezone());
        } catch (Exception $e) {
            $dt = new DateTime(current_time('Y-m-d'), wp_timezone());
        }
        if ($duration === 'unlimited') return '';
        switch ($duration) {
            case '15_days': $dt->modify('+15 days'); break;
            case '3_months': $dt->modify('+3 months'); break;
            case '6_months': $dt->modify('+6 months'); break;
            case '1_year': $dt->modify('+1 year'); break;
            default: $dt->modify('+1 month');
        }
        return $dt->format('Y-m-d');
    }

    /** Why a listing is (not) shown: active | inactive | expired | scheduled | unpublished | pending */
    public static function status($post_id) {
        $ps = get_post_status($post_id);
        if ($ps === 'pending') return 'pending';
        if ($ps !== 'publish') return 'unpublished';
        $manual = get_post_meta($post_id, '_dbd_manual_active', true);
        if ($manual !== '' && $manual !== '1') {
            $end = self::get($post_id, 'end_date');
            return ($end && current_time('Y-m-d') >= $end) ? 'expired' : 'inactive';
        }
        $start = self::get($post_id, 'start_date'); $end = self::get($post_id, 'end_date'); $today = current_time('Y-m-d');
        if ($start && $today < $start) return 'scheduled';
        if ($end && $today >= $end) return 'expired';
        return 'active';
    }

    public static function status_label($status) {
        $l = ['active'=>'فعال','inactive'=>'غیرفعال (تیک نمایش خاموش است)','expired'=>'منقضی شده','scheduled'=>'هنوز شروع نشده','unpublished'=>'منتشر نشده','pending'=>'در انتظار تأیید'];
        return $l[$status] ?? $status;
    }

    /** What a listing still misses to look complete (like the hotels): [percent, [missing labels]] */
    public static function completeness($post_id) {
        $has_img = (bool) self::get($post_id, 'image_1') || (bool) self::get($post_id, 'profile_image');
        $checks = [
            'نوع (هتل، رستوران، سیم‌کارت…)' => isset(DBD_Look::kinds()[(string) self::get($post_id, 'kind')]),
            'عکس' => $has_img,
            'توضیحات' => trim((string) self::get($post_id, 'description')) !== '',
            'شماره تماس' => (bool) self::phones($post_id),
            'واتساپ' => trim((string) self::get($post_id, 'whatsapp')) !== '',
            'آدرس' => trim((string) self::get($post_id, 'address')) !== '',
            'ساعت کاری' => self::get($post_id, 'open_24') === '1' || (self::get($post_id, 'hours_from') && self::get($post_id, 'hours_to')),
            'پین نقشه' => (bool) self::get($post_id, 'lat'),
            'امکانات' => (bool) self::feats($post_id),
            'چند عکس' => count(array_filter([self::get($post_id, 'image_2'), self::get($post_id, 'image_3')])) > 0,
        ];
        $miss = array_keys(array_filter($checks, function ($v) { return !$v; }));
        return [(int) round(100 * (count($checks) - count($miss)) / count($checks)), $miss];
    }

    public static function status_notice($post_id) {
        list($pc, $miss) = self::completeness($post_id);
        $done = $miss ? '<div class="notice notice-warning inline" style="margin:0 0 10px"><p><strong>کامل بودن آگهی: ' . (int) $pc . '٪</strong> — برای اینکه صفحه‌ی این آگهی مثل هتل‌ها کامل باشد، این‌ها را وارد کنید: ' . esc_html(implode('، ', $miss)) . '</p></div>' : '';
        if (!isset(DBD_Look::kinds()[(string) self::get($post_id, 'kind')])) {
            $done .= '<div class="notice notice-error inline" style="margin:0 0 10px"><p><strong>«نوع» این آگهی انتخاب نشده است.</strong> آگهی بدون نوع در صفحه‌های هتل، رستوران، سیم‌کارت و… نمایش داده نمی‌شود؛ نوع درست را انتخاب و ذخیره کنید.</p></div>';
        }
        if (!self::get($post_id, 'lat') && !trim((string) self::get($post_id, 'map_url'))) {
            $done .= '<div class="notice notice-info inline" style="margin:0 0 10px"><p><strong>پین نقشه ثبت نشده است</strong> — تا پین (یا لینک Google Maps) ثبت نشود، نقشه، «الطريق» و دکمه‌های Google Maps / Waze در صفحه‌ی این مکان نمایش داده نمی‌شوند.</p></div>';
        }
        return $done . self::status_notice_base($post_id);
    }

    private static function status_notice_base($post_id) {
        $st = self::status($post_id);
        if ($st === 'active') return '<div class="notice notice-success inline" style="margin:0 0 14px"><p>این آگهی هم‌اکنون در سایت نمایش داده می‌شود.</p></div>';
        if ($st === 'pending') return '<div class="notice notice-info inline" style="margin:0 0 14px"><p><strong>این مغازه از فرم «سجّل متجرك» در سایت ثبت شده و منتظر تأیید شماست.</strong> اطلاعات را بررسی و کامل کنید و «انتشار» را بزنید.</p></div>';
        if ($st === 'expired') return '<div class="notice notice-error inline" style="margin:0 0 14px"><p><strong>این آگهی منقضی شده و در سایت نمایش داده نمی‌شود.</strong> برای نمایش دوباره، گزینه‌ی «تمدید از امروز» را تیک بزنید (یا مدت را «بدون محدودیت» کنید) و ذخیره کنید.</p></div>';
        if ($st === 'inactive') return '<div class="notice notice-warning inline" style="margin:0 0 14px"><p>تیک «نمایش فعال باشد» خاموش است؛ این آگهی در سایت دیده نمی‌شود.</p></div>';
        if ($st === 'scheduled') return '<div class="notice notice-info inline" style="margin:0 0 14px"><p>تاریخ شروع نمایش هنوز نرسیده است.</p></div>';
        return '';
    }

    public static function is_active($post_id) {
        $manual = get_post_meta($post_id, '_dbd_manual_active', true);
        if ($manual !== '' && $manual !== '1') return false;
        $start = self::get($post_id, 'start_date');
        $end = self::get($post_id, 'end_date');
        $today = current_time('Y-m-d');
        if ($start && $today < $start) return false;
        if ($end && $today >= $end) return false;
        return get_post_status($post_id) === 'publish';
    }
}
