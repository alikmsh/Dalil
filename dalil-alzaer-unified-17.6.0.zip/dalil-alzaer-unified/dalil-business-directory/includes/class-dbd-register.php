<?php
/**
 * «سجّل متجرك على الخريطة» — [dalil_shop_register]
 * A logged-in shop owner sends name, type, phone, address, a photo and the shop's position on the map
 * (GPS or a tap on the map). It is saved as a pending listing; it appears on the site after the admin approves.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DBD_Register {

	public static function init() {
		add_shortcode( 'dalil_shop_register', array( __CLASS__, 'shortcode' ) );
		add_action( 'wp_ajax_dbd_shop_register', array( __CLASS__, 'submit' ) );
		add_action( 'wp_ajax_nopriv_dbd_shop_register', array( __CLASS__, 'submit' ) );
		add_action( 'admin_notices', array( __CLASS__, 'notice' ) );
	}

	public static function shortcode( $atts = array() ) {
		$a     = shortcode_atts( array( 'title' => 'سجّل متجرك على الخريطة', 'text' => 'أضف متجرك ليصل إليه آلاف الزوار. سيظهر بعد مراجعة فريق «دليل الزائر».' ), $atts );
		$city  = function_exists( 'dlz_current_city' ) ? dlz_current_city() : 'mashhad';
		$h     = DBD_Look::haram( $city );
		$kinds = DBD_Look::kinds();
		ob_start();
		echo DBD_Frontend::assets(); // phpcs:ignore
		?>
<div class="dbd-reg" dir="rtl" data-haram="<?php echo esc_attr( wp_json_encode( $h ) ); ?>">
	<header class="dbd-reg-h"><span><?php echo DBD_Icons::svg( 'store', 'dbd-reg-hi' ); // phpcs:ignore ?></span><div><h2><?php echo esc_html( $a['title'] ); ?></h2><p><?php echo esc_html( $a['text'] ); ?></p></div></header>
	<?php if ( ! is_user_logged_in() ) : ?>
		<div class="dbd-reg-login"><p>سجّل الدخول برقم هاتفك أولاً لتتمكن من تسجيل متجرك.</p><a class="dbd-b is-gold" href="<?php echo esc_url( function_exists( 'dlz_profile_url' ) ? dlz_profile_url() : wp_login_url() ); ?>"><span>تسجيل الدخول</span></a></div>
	<?php else : ?>
	<form class="dbd-reg-f" novalidate enctype="multipart/form-data">
		<input type="hidden" name="action" value="dbd_shop_register">
		<input type="hidden" name="nonce" value="<?php echo esc_attr( wp_create_nonce( 'dbd_shop_register' ) ); ?>">
		<input type="text" name="website" value="" class="dbd-hp" tabindex="-1" autocomplete="off" aria-hidden="true">
		<label class="dbd-reg-l"><span>اسم المتجر *</span><input name="name" required maxlength="80" autocomplete="organization"></label>
		<label class="dbd-reg-l"><span>نوع النشاط *</span><select name="kind" required><?php foreach ( $kinds as $k => $kd ) echo '<option value="' . esc_attr( $k ) . '">' . esc_html( $kd[0] ) . '</option>'; ?></select></label>
		<div class="dbd-reg-2">
			<label class="dbd-reg-l"><span>رقم الهاتف *</span><input name="phone" type="tel" inputmode="tel" dir="ltr" required maxlength="20" autocomplete="tel"></label>
			<label class="dbd-reg-l"><span>واتساب</span><input name="whatsapp" type="tel" inputmode="tel" dir="ltr" maxlength="20"></label>
		</div>
		<label class="dbd-reg-l"><span>العنوان</span><input name="address" maxlength="200" autocomplete="street-address"></label>
		<label class="dbd-reg-l"><span>نبذة عن المتجر</span><textarea name="description" rows="3" maxlength="800"></textarea></label>
		<div class="dbd-reg-l"><span>موقع المتجر على الخريطة *</span>
			<div class="dbd-reg-map"></div>
			<div class="dbd-reg-mb"><button type="button" class="dbd-b is-out dbd-reg-me"><?php echo DBD_Icons::svg( 'locate', 'dbd-bi' ); // phpcs:ignore ?><span>استخدم موقعي الحالي</span></button><small class="dbd-reg-ll">اضغط على الخريطة لتحديد مكان المتجر.</small></div>
			<input type="hidden" name="lat"><input type="hidden" name="lng">
		</div>
		<label class="dbd-reg-l dbd-reg-file"><span>صورة المتجر</span><input type="file" name="photo" accept="image/jpeg,image/png,image/webp"><em><?php echo DBD_Icons::svg( 'img', 'dbd-bi' ); // phpcs:ignore ?>اختر صورة (حتى 4 ميغابايت)</em></label>
		<p class="dbd-reg-msg" role="alert" hidden></p>
		<button type="submit" class="dbd-b is-gold dbd-reg-go"><span>إرسال للمراجعة</span></button>
	</form>
	<div class="dbd-reg-ok" hidden><span><?php echo DBD_Icons::svg( 'check', 'dbd-reg-oki' ); // phpcs:ignore ?></span><b>تم استلام طلبك</b><p>سيراجع فريق «دليل الزائر» بيانات متجرك ويظهر على الخريطة بعد الموافقة.</p><?php if ( class_exists( 'DBD_Owner' ) && DBD_Owner::url() ) : ?><a class="dbd-b is-gold" href="<?php echo esc_url( DBD_Owner::url() ); ?>"><span>أضف منتجاتك الآن من «متجري»</span></a><?php endif; ?></div>
	<?php endif; ?>
</div>
		<?php
		return ob_get_clean();
	}

	private static function fail( $m, $code = 400 ) {
		wp_send_json_error( array( 'message' => $m ), $code );
	}

	public static function submit() {
		if ( ! check_ajax_referer( 'dbd_shop_register', 'nonce', false ) ) {
			self::fail( 'انتهت صلاحية الصفحة، يرجى تحديثها.', 403 );
		}
		if ( ! is_user_logged_in() ) {
			self::fail( 'يرجى تسجيل الدخول أولاً.', 401 );
		}
		if ( ! empty( $_POST['website'] ) ) { // honeypot
			wp_send_json_success( array( 'message' => 'ok' ) );
		}
		$uid = get_current_user_id();
		$rk  = 'dbd_reg_' . $uid;
		if ( (int) get_transient( $rk ) >= 3 ) {
			self::fail( 'لقد أرسلت عدة طلبات اليوم، حاول غداً.', 429 );
		}
		$raw  = wp_unslash( $_POST ); // phpcs:ignore — each field is sanitised by DBD_Meta::store()
		$name = sanitize_text_field( $raw['name'] ?? '' );
		$phone = trim( preg_replace( '/[^\d+\s]/', '', DBD_Meta::digits( $raw['phone'] ?? '' ) ) );
		$lat  = (float) DBD_Meta::digits( $raw['lat'] ?? '' );
		$lng  = (float) DBD_Meta::digits( $raw['lng'] ?? '' );
		if ( mb_strlen( $name ) < 2 ) {
			self::fail( 'يرجى كتابة اسم المتجر.' );
		}
		if ( strlen( preg_replace( '/\D/', '', $phone ) ) < 7 ) {
			self::fail( 'يرجى كتابة رقم هاتف صحيح.' );
		}
		if ( ! $lat || ! $lng || abs( $lat ) > 90 || abs( $lng ) > 180 ) {
			self::fail( 'يرجى تحديد موقع المتجر على الخريطة.' );
		}
		$photo = '';
		if ( ! empty( $_FILES['photo']['name'] ) ) {
			$f = $_FILES['photo']; // phpcs:ignore
			if ( ! empty( $f['error'] ) || (int) $f['size'] > 4 * MB_IN_BYTES ) {
				self::fail( 'حجم الصورة كبير، الحد الأقصى 4 ميغابايت.' );
			}
			$mimes = array( 'jpg|jpeg|jpe' => 'image/jpeg', 'png' => 'image/png', 'webp' => 'image/webp' );
			$chk   = wp_check_filetype_and_ext( $f['tmp_name'], $f['name'], $mimes );
			if ( empty( $chk['ext'] ) || empty( $chk['type'] ) || ! @getimagesize( $f['tmp_name'] ) ) { // phpcs:ignore
				self::fail( 'يرجى اختيار صورة بصيغة JPG أو PNG أو WEBP.' );
			}
			require_once ABSPATH . 'wp-admin/includes/file.php';
			require_once ABSPATH . 'wp-admin/includes/image.php';
			require_once ABSPATH . 'wp-admin/includes/media.php';
			$f['name'] = 'shop-' . wp_generate_password( 10, false, false ) . '.' . $chk['ext'];
			$_FILES['photo'] = $f;
			$att = media_handle_upload( 'photo', 0, array(), array( 'test_form' => false, 'mimes' => $mimes ) );
			if ( is_wp_error( $att ) ) {
				self::fail( 'تعذّر رفع الصورة، حاول بصورة أخرى.' );
			}
			$photo = (string) wp_get_attachment_image_url( $att, 'large' );
		}
		$pid = wp_insert_post( array( 'post_type' => 'dbd_business', 'post_status' => 'pending', 'post_title' => $name, 'post_author' => $uid ), true );
		if ( is_wp_error( $pid ) ) {
			self::fail( 'تعذّر حفظ الطلب، حاول مرة أخرى.' );
		}
		$kind = sanitize_key( $raw['kind'] ?? '' );
		DBD_Meta::store( $pid, array(
			'kind'        => isset( DBD_Look::kinds()[ $kind ] ) ? $kind : 'other',
			'city'        => function_exists( 'dlz_current_city' ) ? dlz_current_city() : 'mashhad',
			'phones'      => array( array( 'l' => '', 'n' => $phone ) ),
			'whatsapp'    => sanitize_text_field( $raw['whatsapp'] ?? '' ),
			'address'     => sanitize_text_field( $raw['address'] ?? '' ),
			'description' => sanitize_textarea_field( $raw['description'] ?? '' ),
			'lat'         => (string) $lat,
			'lng'         => (string) $lng,
			'image_1'     => $photo,
		), true );
		update_post_meta( $pid, '_dbd_manual_active', '1' );
		update_post_meta( $pid, '_dbd_duration', 'unlimited' );
		update_post_meta( $pid, '_dbd_owner', $uid );
		set_transient( $rk, (int) get_transient( $rk ) + 1, DAY_IN_SECONDS );
		$mail = get_option( 'admin_email' );
		if ( $mail ) {
			wp_mail( $mail, 'متجر جديد بانتظار التأیید — ' . $name, "یک مغازه از فرم «سجّل متجرك» ثبت شد:\n\n" . $name . "\n" . $phone . "\n\n" . admin_url( 'post.php?post=' . (int) $pid . '&action=edit' ) );
		}
		wp_send_json_success( array( 'message' => 'تم استلام طلبك' ) );
	}

	public static function notice() {
		if ( ! current_user_can( 'edit_posts' ) ) {
			return;
		}
		$n = (int) wp_count_posts( 'dbd_business' )->pending;
		if ( ! $n ) {
			return;
		}
		$s = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( $s && 'dbd_business' === $s->post_type && 'post' === $s->base ) {
			return;
		}
		echo '<div class="notice notice-info"><p><strong>دلیل الزائر:</strong> ' . (int) $n . ' مغازه از فرم «سجّل متجرك» منتظر تأیید شماست. <a href="' . esc_url( admin_url( 'edit.php?post_type=dbd_business&post_status=pending' ) ) . '">بررسی و تأیید</a></p></div>';
	}
}
