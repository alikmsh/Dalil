<?php
if (!defined('ABSPATH')) exit;

class DBD_Elementor {
    public static function init() {
        add_action('elementor/widgets/register', [__CLASS__, 'register']);
    }

    public static function register($widgets_manager) {
        if (!did_action('elementor/loaded') || !class_exists('\Elementor\Widget_Base')) return;
        require_once DBD_PATH . 'includes/widgets/class-dbd-elementor-widget.php';
        foreach (['DBD_Elementor_Widget', 'DBD_W_Featured', 'DBD_W_Store', 'DBD_W_Map', 'DBD_W_Register', 'DBD_W_Owner', 'DBD_W_CatGrid', 'DBD_W_Circles', 'DBD_W_Sec_Food', 'DBD_W_Sec_Shop', 'DBD_W_Sec_Med', 'DBD_W_Sec_Cos', 'DBD_W_Sec_Sal', 'DBD_W_Sec_Leg', 'DBD_W_Venues', 'DBD_W_Salons'] as $c) {
            $widgets_manager->register(new $c());
        }
    }
}
