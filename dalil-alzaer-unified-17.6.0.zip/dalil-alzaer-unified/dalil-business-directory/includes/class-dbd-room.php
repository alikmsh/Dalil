<?php
if (!defined('ABSPATH')) exit;

class DBD_Room {
    const META = '_dbd_room_businesses';
    const NONCE = 'dbd_room_nonce';

    public static function init() {
        add_action('init', [__CLASS__, 'register']);
        add_action('add_meta_boxes', [__CLASS__, 'metabox']);
        add_action('save_post_dbd_room', [__CLASS__, 'save'], 10, 2);
        add_filter('manage_dbd_room_posts_columns', [__CLASS__, 'columns']);
        add_action('manage_dbd_room_posts_custom_column', [__CLASS__, 'column_content'], 10, 2);
    }

    public static function register() {
        register_post_type('dbd_room', [
            'labels' => [
                'name'=>'Room ها','singular_name'=>'Room','add_new'=>'افزودن Room','add_new_item'=>'افزودن Room جدید',
                'edit_item'=>'ویرایش Room','new_item'=>'Room جدید','view_item'=>'مشاهده Room','search_items'=>'جستجوی Room',
                'not_found'=>'Room ای پیدا نشد','menu_name'=>'Room ها'
            ],
            'public'=>false,'show_ui'=>true,'show_in_menu'=>true,'menu_icon'=>'dashicons-screenoptions',
            'supports'=>['title'],'capability_type'=>'post','map_meta_cap'=>true,'has_archive'=>false,'rewrite'=>false,'show_in_rest'=>false,
        ]);
    }

    public static function columns($cols) {
        return ['cb'=>$cols['cb'],'title'=>'Room','dbd_count'=>'تعداد کسب‌وکار','date'=>'تاریخ ایجاد'];
    }
    public static function column_content($column,$id) {
        if($column==='dbd_count') echo '<strong>'.count(self::business_ids($id)).'</strong>';
    }
    public static function business_ids($room_id) {
        $ids=get_post_meta($room_id,self::META,true);
        if(!is_array($ids)) return [];
        return array_values(array_unique(array_filter(array_map('intval',$ids))));
    }
    public static function metabox() {
        add_meta_box('dbd_room_businesses','کسب‌وکارهای داخل این Room',[__CLASS__,'render'],'dbd_room','normal','high');
    }
    public static function render($post) {
        wp_nonce_field(self::NONCE,self::NONCE);
        $selected=self::business_ids($post->ID);
        $businesses=get_posts(['post_type'=>'dbd_business','post_status'=>['publish','draft','pending','private'],'posts_per_page'=>-1,'orderby'=>'menu_order','order'=>'ASC']);
        ?>
        <div dir="rtl" class="dbd-room-box">
            <p><strong>کسب‌وکارهای این Room را انتخاب کنید.</strong> هر کسب‌وکار می‌تواند هم‌زمان داخل چند Room قرار بگیرد.</p>
            <input type="search" id="dbd-room-search" placeholder="جستجوی کسب‌وکار..." style="width:100%;max-width:500px;padding:9px;margin-bottom:12px">
            <div id="dbd-room-business-list" style="max-height:520px;overflow:auto;border:1px solid #ddd;background:#fff;padding:10px">
            <?php if(!$businesses): ?><p>هنوز کسب‌وکاری ساخته نشده است.</p><?php endif; ?>
            <?php foreach($businesses as $b): ?>
                <label class="dbd-room-business" data-name="<?php echo esc_attr(mb_strtolower($b->post_title)); ?>" style="display:block;padding:9px;border-bottom:1px solid #eee">
                    <input type="checkbox" name="dbd_room_businesses[]" value="<?php echo (int)$b->ID; ?>" <?php checked(in_array($b->ID,$selected,true)); ?>>
                    <?php echo esc_html($b->post_title ?: 'بدون عنوان'); ?>
                </label>
            <?php endforeach; ?>
            </div>
        </div>
        <script>(function(){const i=document.getElementById('dbd-room-search');if(!i)return;i.addEventListener('input',function(){const q=this.value.toLowerCase().trim();document.querySelectorAll('.dbd-room-business').forEach(x=>x.style.display=!q||x.dataset.name.indexOf(q)>-1?'block':'none')})})();</script>
        <?php
    }
    public static function save($post_id,$post) {
        if(!isset($_POST[self::NONCE])||!wp_verify_nonce($_POST[self::NONCE],self::NONCE)) return;
        if(defined('DOING_AUTOSAVE')&&DOING_AUTOSAVE) return;
        if(wp_is_post_revision($post_id)||$post->post_type!=='dbd_room') return;
        if(!current_user_can('edit_post',$post_id)) return;
        $ids=isset($_POST['dbd_room_businesses'])?(array)$_POST['dbd_room_businesses']:[];
        $ids=array_values(array_unique(array_filter(array_map('intval',$ids))));

        // هنگام ویرایش Room، اولویت اختصاصی همین Room حفظ می‌شود.
        // موارد جدید در انتهای ترتیب قبلی اضافه می‌شوند.
        $old_order=self::business_ids($post_id);
        $ordered=[];
        foreach($old_order as $old_id){
            if(in_array($old_id,$ids,true)) $ordered[]=$old_id;
        }
        foreach($ids as $new_id){
            if(!in_array($new_id,$ordered,true)) $ordered[]=$new_id;
        }
        update_post_meta($post_id,self::META,$ordered);
    }
}
