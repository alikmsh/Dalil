<?php
/**
 * Elementor widgets — category «دليل الزائر»:
 *  قائمة المتاجر · العرض المميز · صفحة متجر · بنر الخريطة · سجّل متجرك · شبكة الأقسام · خدمات دائرية
 */
if (!defined('ABSPATH')) exit;

use Elementor\Controls_Manager as C;
use Elementor\Repeater;

abstract class DBD_W_Base extends \Elementor\Widget_Base {
    public function get_categories() { return ['dalil-alzaer']; }
    protected static function rooms() {
        $o = [0 => 'همه‌ی کسب‌وکارهای شهر (بدون Room)'];
        foreach (get_posts(['post_type' => 'dbd_room', 'post_status' => 'publish', 'posts_per_page' => 200, 'orderby' => 'title', 'order' => 'ASC']) as $r) $o[$r->ID] = $r->post_title;
        return $o;
    }
    protected static function kinds() {
        $o = ['' => 'خودکار'];
        foreach (DBD_Look::kinds() as $k => $kd) $o[$k] = $kd[1] . ' — ' . $kd[0];
        return $o;
    }
    protected static function businesses() {
        $o = [0 => '— انتخاب کنید —'];
        foreach (get_posts(['post_type' => 'dbd_business', 'post_status' => 'publish', 'posts_per_page' => 300, 'orderby' => 'title', 'order' => 'ASC']) as $b) $o[$b->ID] = $b->post_title;
        return $o;
    }
    protected static function media($v) { return is_array($v) && !empty($v['url']) ? (string) $v['url'] : ''; }
}

/* ------------------------------------------------------------------ قائمة المتاجر */
class DBD_Elementor_Widget extends DBD_W_Base {
    public function get_name() { return 'dalil_businesses'; }
    public function get_title() { return 'قائمة المتاجر (کسب‌وکارها)'; }
    public function get_icon() { return 'eicon-posts-grid'; }
    public function get_keywords() { return ['dalil', 'store', 'shop', 'list', 'متجر', 'فهرست', 'کسب']; }

    protected function register_controls() {
        $this->start_controls_section('src', ['label' => 'کدام مغازه‌ها؟']);
        $this->add_control('room', ['label' => 'Room', 'type' => C::SELECT, 'default' => 0, 'options' => self::rooms(), 'description' => 'اگر Room انتخاب شود فقط مغازه‌های همان Room؛ وگرنه همه‌ی مغازه‌های فعال شهر.']);
        $this->add_control('kind', ['label' => 'نوع این صفحه', 'type' => C::SELECT, 'default' => '', 'options' => self::kinds()]);
        $this->add_control('tags', ['label' => 'فقط این برچسب‌ها (اختیاری)', 'type' => C::TEXT, 'placeholder' => 'مثلاً: زعفران، مكسرات']);
        $this->end_controls_section();

        $this->start_controls_section('look', ['label' => 'ظاهر']);
        $this->add_control('style', ['label' => 'شکل کارت‌ها', 'type' => C::SELECT, 'default' => 'compact', 'options' => [
            'compact' => 'جمع‌وجور — عکس کنار (زعفران، پیش‌فرض)',
            'honey'   => 'عسل — فاصله، امتیاز، سطح قیمت + سه دکمه',
            'salon'   => 'سالن — «موصى به»، قیمت و دکمه‌ی التفاصيل',
            'grid'    => 'دوستونه',
            'large'   => 'کارت بزرگ (طرح قبلی)',
        ]]);
        $this->add_control('title', ['label' => 'عنوان بالای صفحه', 'type' => C::TEXT, 'placeholder' => 'مثلاً: الزعفران والمكسرات']);
        $this->add_control('subtitle', ['label' => 'زیرعنوان', 'type' => C::TEXT, 'placeholder' => 'مثلاً: دليل التسوق في مشهد']);
        $this->add_control('side_image', ['label' => 'تصویر کنار عنوان (چپ)', 'type' => C::MEDIA]);
        $this->add_control('side_image2', ['label' => 'تصویر کنار عنوان (راست)', 'type' => C::MEDIA]);
        $this->add_control('section', ['label' => 'عنوان بالای فهرست (اختیاری)', 'type' => C::TEXT, 'placeholder' => 'مثلاً: صالونات مميزة']);
        $this->end_controls_section();

        $this->start_controls_section('tools', ['label' => 'نقشه، تب، جستجو و فیلتر']);
        $this->add_control('tabs', ['label' => 'تب‌ها (هر خط: عنوان|برچسب)', 'type' => C::TEXTAREA, 'rows' => 3, 'placeholder' => "المحلات|محل\nالمولات|مول", 'description' => 'برچسب همان «دسته / برچسب‌ها» در ویرایش مغازه است. خالی = بدون تب.']);
        $this->add_control('search', ['label' => 'جستجو', 'type' => C::SWITCHER, 'return_value' => '1', 'default' => '']);
        $this->add_control('search_ph', ['label' => 'متن داخل جستجو', 'type' => C::TEXT, 'placeholder' => 'ابحث عن متجر عسل', 'condition' => ['search' => '1']]);
        $this->add_control('filters', ['label' => 'دکمه‌های فیلتر', 'type' => C::SELECT2, 'multiple' => true, 'default' => [], 'options' => [
            'near' => 'الأقرب (با GPS)', 'haram' => 'الأقرب للحرم', 'top' => 'الأعلى تقييماً', 'cats' => 'التصنيفات (منو)', 'vip' => 'VIP', 'arabic' => 'يتكلم العربية',
            'nearharam' => 'قريب من الحرم', 'delivery' => 'توصيل للفندق', 'verified' => 'موثوق', 'recommended' => 'موصى به', 'cheap' => 'الأرخص',
        ]]);
        $this->add_control('featured', ['label' => 'کارت «العرض المميز» بالای فهرست', 'type' => C::SELECT, 'default' => '0', 'options' => ['0' => 'نمایش داده نشود', 'auto' => 'اولین مغازه‌ی VIP'] + array_slice(self::businesses(), 1, null, true)]);
        $this->add_control('featured_label', ['label' => 'متن روبان کارت ویژه', 'type' => C::TEXT, 'default' => 'العرض المميز']);
        $this->end_controls_section();
    }

    protected function render() {
        $s = $this->get_settings_for_display();
        echo DBD_Frontend::shortcode([ // phpcs:ignore
            'style' => (string) ($s['style'] ?? 'compact'), 'room' => (int) ($s['room'] ?? 0), 'kind' => (string) ($s['kind'] ?? ''), 'tags' => (string) ($s['tags'] ?? ''),
            'title' => (string) ($s['title'] ?? ''), 'subtitle' => (string) ($s['subtitle'] ?? ''), 'side_image' => self::media($s['side_image'] ?? ''), 'side_image2' => self::media($s['side_image2'] ?? ''),
            'section' => (string) ($s['section'] ?? ''), 'map' => !empty($s['map']) ? '1' : '0', 'map_title' => (string) ($s['map_title'] ?? ''), 'map_text' => (string) ($s['map_text'] ?? ''),
            'map_image' => self::media($s['map_image'] ?? ''), 'tabs' => (string) ($s['tabs'] ?? ''), 'search' => !empty($s['search']) ? '1' : '0', 'search_ph' => (string) ($s['search_ph'] ?? ''),
            'filters' => implode(',', (array) ($s['filters'] ?? [])), 'featured' => (string) ($s['featured'] ?? '0'), 'featured_label' => (string) ($s['featured_label'] ?? 'العرض المميز'),
            // 2.x settings
            'template' => (string) ($s['template'] ?? ''),
        ]);
    }
}

/* ------------------------------------------------------------------ العرض المميز */
class DBD_W_Featured extends DBD_W_Base {
    public function get_name() { return 'dlz_featured'; }
    public function get_title() { return 'العرض المميز (کارت VIP)'; }
    public function get_icon() { return 'eicon-star'; }
    protected function register_controls() {
        $this->start_controls_section('c', ['label' => 'کارت ویژه']);
        $this->add_control('id', ['label' => 'مغازه', 'type' => C::SELECT, 'default' => 0, 'options' => self::businesses(), 'description' => 'خالی = اولین مغازه‌ای که نشان VIP دارد.']);
        $this->add_control('label', ['label' => 'متن روبان', 'type' => C::TEXT, 'default' => 'العرض المميز']);
        $this->end_controls_section();
    }
    protected function render() {
        $s = $this->get_settings_for_display();
        $id = (int) ($s['id'] ?? 0);
        if (!$id) foreach (DBD_Frontend::ids() as $i) if (in_array('vip', DBD_Look::card($i)['badges'], true)) { $id = $i; break; }
        if (!$id || !DBD_Meta::is_active($id)) { if (\Elementor\Plugin::$instance->editor->is_edit_mode()) echo '<p dir="rtl">مغازه‌ی VIP فعالی پیدا نشد.</p>'; return; }
        echo DBD_Frontend::assets() . '<div class="dbd-directory dbd-v3" dir="rtl">' . DBD_Cards::featured(DBD_Look::card($id), (string) ($s['label'] ?? 'العرض المميز')) . '</div>'; // phpcs:ignore
    }
}

/* ------------------------------------------------------------------ صفحة متجر */
class DBD_W_Store extends DBD_W_Base {
    public function get_name() { return 'dlz_store_page'; }
    public function get_title() { return 'صفحة متجر (صفحه‌ی یک مغازه)'; }
    public function get_icon() { return 'eicon-single-page'; }
    protected function register_controls() {
        $this->start_controls_section('c', ['label' => 'مغازه']);
        $this->add_control('id', ['label' => 'مغازه', 'type' => C::SELECT, 'default' => 0, 'options' => self::businesses()]);
        $this->end_controls_section();
    }
    protected function render() { $s = $this->get_settings_for_display(); echo DBD_Frontend::single_shortcode(['id' => (int) ($s['id'] ?? 0)]); } // phpcs:ignore
}

/* ------------------------------------------------------------------ بنر الخريطة */
class DBD_W_Map extends DBD_W_Base {
    public function get_name() { return 'dlz_map_banner'; }
    public function get_title() { return 'بنر الخريطة (نقشه با GPS)'; }
    public function get_icon() { return 'eicon-google-maps'; }
    protected function register_controls() {
        $this->start_controls_section('c', ['label' => 'بنر نقشه']);
        $this->add_control('title', ['label' => 'عنوان', 'type' => C::TEXT, 'default' => 'الخريطة']);
        $this->add_control('text', ['label' => 'متن', 'type' => C::TEXT, 'default' => 'اعثر على أقرب الأماكن إليك واحصل على الاتجاهات']);
        $this->add_control('image', ['label' => 'عکس (خالی = طرح پیش‌فرض)', 'type' => C::MEDIA]);
        $this->add_control('kind', ['label' => 'کدام مغازه‌ها روی نقشه؟', 'type' => C::SELECT, 'default' => '', 'options' => ['' => 'همه'] + array_slice(self::kinds(), 1, null, true)]);
        $this->add_control('room', ['label' => 'یا یک Room', 'type' => C::SELECT, 'default' => 0, 'options' => self::rooms()]);
        $this->add_control('tags', ['label' => 'فقط این برچسب‌ها (اختیاری)', 'type' => C::TEXT]);
        $this->end_controls_section();
    }
    protected function render() {
        $s = $this->get_settings_for_display();
        echo DBD_Frontend::banner_shortcode(['title' => (string) ($s['title'] ?? ''), 'text' => (string) ($s['text'] ?? ''), 'image' => self::media($s['image'] ?? ''), 'kind' => (string) ($s['kind'] ?? ''), 'room' => (int) ($s['room'] ?? 0), 'tags' => (string) ($s['tags'] ?? '')]); // phpcs:ignore
    }
}

/* ------------------------------------------------------------------ سجّل متجرك */
class DBD_W_Register extends DBD_W_Base {
    public function get_name() { return 'dlz_shop_register'; }
    public function get_title() { return 'سجّل متجرك (ثبت مغازه روی نقشه)'; }
    public function get_icon() { return 'eicon-form-horizontal'; }
    protected function register_controls() {
        $this->start_controls_section('c', ['label' => 'فرم']);
        $this->add_control('title', ['label' => 'عنوان', 'type' => C::TEXT, 'default' => 'سجّل متجرك على الخريطة']);
        $this->add_control('text', ['label' => 'توضیح', 'type' => C::TEXTAREA, 'default' => 'أضف متجرك ليصل إليه آلاف الزوار. سيظهر بعد مراجعة فريق «دليل الزائر».']);
        $this->end_controls_section();
    }
    protected function render() { $s = $this->get_settings_for_display(); echo DBD_Register::shortcode(['title' => (string) ($s['title'] ?? ''), 'text' => (string) ($s['text'] ?? '')]); } // phpcs:ignore
}

/* ------------------------------------------------------------------ متجري */
class DBD_W_Owner extends DBD_W_Base {
    public function get_name() { return 'dlz_my_shop'; }
    public function get_title() { return 'متجري (پنل صاحب مغازه)'; }
    public function get_icon() { return 'eicon-products'; }
    protected function register_controls() {
        $this->start_controls_section('c', ['label' => 'پنل صاحب مغازه']);
        $this->add_control('note', ['type' => C::RAW_HTML, 'raw' => '<div style="line-height:1.9">صاحب هر مغازه (که در فرم آگهی شماره‌اش را وارد کرده‌اید) این‌جا محصولات، قیمت، توضیحات، ساعت کاری و عکس‌ها را خودش ویرایش می‌کند.</div>']);
        $this->add_control('register', ['label' => 'لینک صفحه‌ی «سجّل متجرك» (اختیاری)', 'type' => C::TEXT, 'default' => '']);
        $this->end_controls_section();
    }
    protected function render() { $s = $this->get_settings_for_display(); echo DBD_Owner::shortcode(['register' => (string) ($s['register'] ?? '')]); } // phpcs:ignore
}

/* ------------------------------------------------------------------ شبكة الأقسام */
class DBD_W_CatGrid extends DBD_W_Base {
    public function get_name() { return 'dlz_cat_grid'; }
    public function get_title() { return 'شبكة الأقسام (کارت‌های دسته)'; }
    public function get_icon() { return 'eicon-gallery-grid'; }
    protected function register_controls() {
        $this->start_controls_section('h', ['label' => 'عنوان']);
        $this->add_control('header', ['label' => 'عنوان بالای کارت‌ها', 'type' => C::SELECT, 'default' => 'title', 'options' => ['title' => 'عنوان مینیمال (نام صفحه)', 'none' => 'بدون عنوان']]);
        $this->add_control('title', ['label' => 'عنوان (خالی = نام همین صفحه)', 'type' => C::TEXT, 'default' => '', 'condition' => ['header!' => 'none']]);
        $this->end_controls_section();
        $this->start_controls_section('s', ['label' => 'جستجو']);
        $this->add_control('search', ['label' => 'جستجو', 'type' => C::SWITCHER, 'return_value' => 'yes', 'default' => 'yes']);
        $this->add_control('search_ph', ['label' => 'متن داخل جستجو', 'type' => C::TEXT, 'default' => 'ابحث عن مطعم أو مقهى أو صنف غذائي…', 'condition' => ['search' => 'yes']]);
        $this->add_control('fav', ['label' => 'آیکن قلب (علاقه‌مندی‌ها)', 'type' => C::SWITCHER, 'return_value' => 'yes', 'default' => 'yes', 'condition' => ['search' => 'yes']]);
        $this->end_controls_section();
        $this->start_controls_section('i', ['label' => 'کارت‌ها']);
        $this->add_control('columns', ['label' => 'ستون‌ها', 'type' => C::SELECT, 'default' => '2', 'options' => ['2' => '۲', '3' => '۳']]);
        $this->add_control('tone', ['label' => 'رنگ عنوان کارت', 'type' => C::SELECT, 'default' => 'green', 'options' => ['green' => 'سبز', 'brown' => 'قهوه‌ای']]);
        $r = new Repeater();
        $r->add_control('image', ['label' => 'عکس', 'type' => C::MEDIA]);
        $r->add_control('title', ['label' => 'عنوان', 'type' => C::TEXT, 'default' => 'عنوان']);
        $r->add_control('link', ['label' => 'لینک', 'type' => C::URL, 'placeholder' => 'https://']);
        $def = [];
        foreach ([['food-restaurants.jpg', 'المطاعم'], ['food-fastfood.jpg', 'الوجبات السريعة'], ['food-soup.jpg', 'الكراعين و الباجة'], ['food-cafes.jpg', 'المقاهي و الشاي العراقي'], ['food-fish.jpg', 'الاسماك والمسكوف'], ['food-grill.jpg', 'الكباب والمشويات']] as $x) $def[] = ['image' => ['url' => DBD_UI::img($x[0])], 'title' => $x[1], 'link' => ['url' => '']];
        $this->add_control('items', ['label' => 'دسته‌ها', 'type' => C::REPEATER, 'fields' => $r->get_controls(), 'default' => $def, 'title_field' => '{{{ title }}}']);
        $this->add_control('help', ['type' => C::RAW_HTML, 'raw' => '<div style="line-height:1.8">برای صفحه‌ی خرید، عکس‌های آماده: <code>shop-saffron, shop-perfume, shop-carpet, shop-abaya, shop-clothes, shop-honey</code> در پوشه‌ی <code>dalil-business-directory/assets/ui/</code>.</div>', 'content_classes' => 'elementor-descriptor']);
        $this->end_controls_section();
    }
    protected function render() { echo DBD_UI::catgrid($this->get_settings_for_display()); } // phpcs:ignore
}

/* ------------------------------------------------------------------ خدمات دائرية */
class DBD_W_Circles extends DBD_W_Base {
    public function get_name() { return 'dlz_circle_services'; }
    public function get_title() { return 'خدمات دائرية (سالن‌ها)'; }
    public function get_icon() { return 'eicon-image-rollover'; }
    protected function register_controls() {
        $this->start_controls_section('h', ['label' => 'سربرگ']);
        $this->add_control('brand', ['label' => 'برند بالا', 'type' => C::TEXT, 'default' => 'دليل الزائر']);
        $this->add_control('title', ['label' => 'عنوان', 'type' => C::TEXT, 'default' => 'الصالونات']);
        $this->add_control('subtitle', ['label' => 'زیرعنوان', 'type' => C::TEXT, 'default' => 'خدمات تجميل راقية للزائرات']);
        $this->end_controls_section();
        $this->start_controls_section('i', ['label' => 'خدمات']);
        $r = new Repeater();
        $r->add_control('image', ['label' => 'عکس دایره‌ای', 'type' => C::MEDIA]);
        $r->add_control('title', ['label' => 'عنوان', 'type' => C::TEXT, 'default' => 'خدمة']);
        $r->add_control('link', ['label' => 'لینک', 'type' => C::URL, 'placeholder' => 'https://']);
        $def = [];
        foreach ([['salon-moles.jpg', 'إزالة الشامات'], ['salon-nails.jpg', 'تركيب وتزيين الأظافر'], ['salon-keratin.jpg', 'كيراتين وعلاج الشعر'], ['salon-filler.jpg', 'حقن الفيلر والبوتكس'], ['salon-lashes.jpg', 'تركيب الرموش'], ['salon-massage.jpg', 'المساج والاسترخاء'], ['salon-hair.jpg', 'صبغ وهايلايت الشعر'], ['salon-brows.jpg', 'تاتو وتجميل الحواجب']] as $x) $def[] = ['image' => ['url' => DBD_UI::img($x[0])], 'title' => $x[1], 'link' => ['url' => '']];
        $this->add_control('items', ['label' => 'خدمات', 'type' => C::REPEATER, 'fields' => $r->get_controls(), 'default' => $def, 'title_field' => '{{{ title }}}']);
        $this->add_control('button', ['label' => 'متن دکمه', 'type' => C::TEXT, 'default' => 'احجزي الآن']);
        $this->add_control('button_link', ['label' => 'لینک دکمه', 'type' => C::URL]);
        $this->end_controls_section();
    }
    protected function render() { echo DBD_UI::circles($this->get_settings_for_display()); } // phpcs:ignore
}

/* ------------------------------------------------------------ ready section grids (17.3) */
abstract class DBD_W_Sec extends DBD_W_Base {
    abstract protected function key();
    public function get_icon() { return 'eicon-gallery-grid'; }
    protected function register_controls() {
        $p = DBD_UI::presets()[$this->key()];
        $this->start_controls_section('c', ['label' => 'بخش']);
        $this->add_control('title', ['label' => 'عنوان بالای آیکن‌ها', 'type' => C::TEXT, 'default' => $p[0]]);
        $this->add_control('style', ['label' => 'شکل', 'type' => C::SELECT, 'default' => $p[1], 'options' => ['circle' => 'دایره', 'arrow' => 'دایره با قاب طلایی و دکمه ›', 'photo' => 'عکس کامل', 'list' => 'فهرست یک‌ستونی (مینیمال)']]);
        $this->add_control('columns', ['label' => 'ستون‌ها', 'type' => C::SELECT, 'default' => (string) $p[2], 'options' => ['1' => '۱', '2' => '۲', '3' => '۳'], 'condition' => ['style!' => 'list']]);
        $r = new Repeater();
        $r->add_control('image', ['label' => 'عکس', 'type' => C::MEDIA]);
        $r->add_control('title', ['label' => 'عنوان', 'type' => C::TEXT, 'default' => 'عنوان']);
        $r->add_control('link', ['label' => 'لینک (خالی = خودکار: صفحه‌ای با همین نام)', 'type' => C::URL, 'placeholder' => 'خودکار']);
        $def = [];
        foreach ($p[3] as $x) $def[] = ['image' => ['url' => DBD_UI::img($x[1])], 'title' => $x[0], 'link' => ['url' => '']];
        $this->add_control('items', ['label' => 'آیکن‌ها', 'type' => C::REPEATER, 'fields' => $r->get_controls(), 'default' => $def, 'title_field' => '{{{ title }}}']);
        $this->add_control('help', ['type' => C::RAW_HTML, 'raw' => '<div style="line-height:1.9">لینک هر آیکن خودکار به صفحه‌ای از سایت وصل می‌شود که اسمش با عنوان آیکن یکی است (مثلاً «طب العيون»). اگر صفحه اسم دیگری دارد، لینکش را دستی بدهید. در ویرایشگر، آیکن بدون لینک برچسب قرمز «بدون لینک» دارد.</div>', 'content_classes' => 'elementor-descriptor']);
        $this->end_controls_section();
    }
    protected function render() { echo DBD_UI::sections($this->get_settings_for_display()); } // phpcs:ignore
}
class DBD_W_Sec_Food extends DBD_W_Sec { protected function key() { return 'food'; } public function get_name() { return 'dlz_sec_food'; } public function get_title() { return 'أقسام: المطاعم والمقاهي'; } }
class DBD_W_Sec_Shop extends DBD_W_Sec { protected function key() { return 'shop'; } public function get_name() { return 'dlz_sec_shop'; } public function get_title() { return 'أقسام: التسوق والهدايا'; } }
class DBD_W_Sec_Med extends DBD_W_Sec { protected function key() { return 'med'; } public function get_name() { return 'dlz_sec_med'; } public function get_title() { return 'أقسام: العلاج'; } }
class DBD_W_Sec_Cos extends DBD_W_Sec { protected function key() { return 'cos'; } public function get_name() { return 'dlz_sec_cos'; } public function get_title() { return 'أقسام: التجميل'; } }
class DBD_W_Sec_Sal extends DBD_W_Sec { protected function key() { return 'sal'; } public function get_name() { return 'dlz_sec_sal'; } public function get_title() { return 'أقسام: الصالونات'; } }
class DBD_W_Sec_Leg extends DBD_W_Sec { protected function key() { return 'leg'; } public function get_name() { return 'dlz_sec_leg'; } public function get_title() { return 'أقسام: المساعدة والمشاكل (القانونية)'; } }

/* ------------------------------------------------------------ 17.5: قاعات الأفراح وباغ تالار · صالونات التجميل */
class DBD_W_Venues extends DBD_W_Base {
    public function get_name() { return 'dlz_venues'; }
    public function get_title() { return 'قاعات الأفراح وباغ تالار'; }
    public function get_icon() { return 'eicon-gallery-grid'; }
    public function get_keywords() { return ['dalil', 'تالار', 'قاعة', 'باغ', 'عرس', 'venue', 'wedding']; }
    protected function register_controls() {
        $this->start_controls_section('c', ['label' => 'تالارها']);
        $this->add_control('help', ['type' => C::RAW_HTML, 'raw' => '<div style="line-height:1.9">تالارها از منوی <b>«تالارها و باغ‌تالارها»</b> در پیشخوان اضافه می‌شوند (عکس، آدرس، تلفن، قیمت، ظرفیت، امکانات، نقشه، توضیحات). نظرها و ستاره‌ها را زائران ثبت می‌کنند.</div>', 'content_classes' => 'elementor-descriptor']);
        $this->add_control('title', ['label' => 'عنوان', 'type' => C::TEXT, 'default' => 'قاعات الأفراح وباغ تالار']);
        $this->add_control('subtitle', ['label' => 'زیرعنوان', 'type' => C::TEXT, 'default' => 'اختر قاعة أو باغ تالار لمناسبتك السعيدة']);
        $this->add_control('search', ['label' => 'جستجو', 'type' => C::SWITCHER, 'default' => 'yes']);
        $this->add_control('mobile', ['label' => 'ستون در گوشی', 'type' => C::SELECT, 'default' => '2', 'options' => ['2' => '۲ ستون', '1' => '۱ ستون']]);
        $this->add_control('room', ['label' => 'Room (اختیاری)', 'type' => C::SELECT, 'default' => 0, 'options' => self::rooms()]);
        $this->end_controls_section();
    }
    protected function render() {
        $s = $this->get_settings_for_display();
        echo DBD_Showcase::venues(['title' => (string) ($s['title'] ?? ''), 'subtitle' => (string) ($s['subtitle'] ?? ''), 'search' => 'yes' === ($s['search'] ?? '') ? '1' : '0', 'room' => (int) ($s['room'] ?? 0), 'tags' => '', 'mobile' => (string) ($s['mobile'] ?? '2')]); // phpcs:ignore
    }
}
class DBD_W_Salons extends DBD_W_Base {
    public function get_name() { return 'dlz_salons'; }
    public function get_title() { return 'صالونات التجميل'; }
    public function get_icon() { return 'eicon-post-list'; }
    public function get_keywords() { return ['dalil', 'salon', 'صالون', 'سالن', 'تجميل', 'آرایشگاه']; }
    protected function register_controls() {
        $this->start_controls_section('c', ['label' => 'سالن‌ها']);
        $this->add_control('help', ['type' => C::RAW_HTML, 'raw' => '<div style="line-height:1.9">سالن‌ها از منوی <b>«سالن‌های زیبایی»</b> در پیشخوان اضافه می‌شوند. «خدمات» (كيراتين، صبغ الشعر…) را در فیلد «برچسب‌ها / خدمات» و ساعت کاری را برای «مفتوح الآن / مغلق الآن» وارد کنید.</div>', 'content_classes' => 'elementor-descriptor']);
        $this->add_control('title', ['label' => 'عنوان', 'type' => C::TEXT, 'default' => 'صالونات التجميل']);
        $this->add_control('subtitle', ['label' => 'زیرعنوان (خالی = «اكتشف أفضل الصالونات في» + شهر)', 'type' => C::TEXT, 'default' => '']);
        $this->add_control('search', ['label' => 'جستجو', 'type' => C::SWITCHER, 'default' => 'yes']);
        $this->add_control('tags', ['label' => 'فقط این خدمات (اختیاری)', 'type' => C::TEXT, 'placeholder' => 'مثلاً: كيراتين']);
        $this->add_control('room', ['label' => 'Room (اختیاری)', 'type' => C::SELECT, 'default' => 0, 'options' => self::rooms()]);
        $this->end_controls_section();
    }
    protected function render() {
        $s = $this->get_settings_for_display();
        echo DBD_Showcase::salons(['title' => (string) ($s['title'] ?? ''), 'subtitle' => (string) ($s['subtitle'] ?? ''), 'search' => 'yes' === ($s['search'] ?? '') ? '1' : '0', 'room' => (int) ($s['room'] ?? 0), 'tags' => (string) ($s['tags'] ?? '')]); // phpcs:ignore
    }
}
