<?php
/**
 * Reviews: star rating saved with each comment; the average / count is cached on the listing
 * (one meta read per card instead of one comments query per card) and refreshed whenever a review changes.
 */
if (!defined('ABSPATH')) exit;

class DBD_Reviews {
    const KEY = '_dbd_stats';

    public static function init() {
        add_action('comment_post', [__CLASS__, 'save_rating'], 10, 3);
        add_filter('preprocess_comment', [__CLASS__, 'require_login'], 1);
        foreach (['wp_set_comment_status', 'edit_comment', 'deleted_comment', 'trashed_comment', 'untrashed_comment', 'spammed_comment', 'unspammed_comment'] as $h) {
            add_action($h, [__CLASS__, 'touch']);
        }
    }

    public static function require_login($d) {
        if (!empty($d['comment_post_ID']) && get_post_type($d['comment_post_ID']) === 'dbd_business' && !is_user_logged_in()) {
            wp_die('يرجى تسجيل الدخول أولاً.', 'دليل الزائر', ['response' => 403, 'back_link' => true]);
        }
        return $d;
    }

    public static function save_rating($cid, $approved, $data) {
        $pid = (int) ($data['comment_post_ID'] ?? 0);
        if (!$pid || get_post_type($pid) !== 'dbd_business') return;
        $r = isset($_POST['dbd_rating']) ? (int) $_POST['dbd_rating'] : 0; // phpcs:ignore — nonce-less by WordPress comment design; value is range-checked
        if ($r >= 1 && $r <= 5) update_comment_meta($cid, '_dbd_rating', $r);
        delete_post_meta($pid, self::KEY);
    }

    public static function touch($cid) {
        $c = get_comment($cid);
        if ($c && get_post_type($c->comment_post_ID) === 'dbd_business') delete_post_meta((int) $c->comment_post_ID, self::KEY);
    }

    public static function stats($pid) {
        $s = get_post_meta($pid, self::KEY, true);
        if (is_array($s) && isset($s['average'], $s['count'], $s['comments'])) return $s;
        $cs = get_comments(['post_id' => $pid, 'status' => 'approve', 'type' => 'comment', 'number' => 0, 'fields' => 'ids']);
        $sum = 0; $n = 0;
        foreach ($cs as $cid) { $r = (int) get_comment_meta($cid, '_dbd_rating', true); if ($r >= 1 && $r <= 5) { $sum += $r; $n++; } }
        $s = ['average' => $n ? round($sum / $n, 1) : 0, 'count' => $n, 'comments' => count($cs)];
        update_post_meta($pid, self::KEY, $s);
        return $s;
    }
}
