/* Dalil Al Zaer — «قاعات الأفراح وباغ تالار» + «صالونات التجميل» (17.5): search, type chips, city, «الأقرب» sort,
   «تصفية» (open now + services), open / closed from the working hours, the whole card opens the place. */
(function () {
	'use strict';
	var d = document;

	function norm(s) {
		return String(s || '').toLowerCase().replace(/[ً-ٰٟـ]/g, '')
			.replace(/[ی]/g, 'ي').replace(/[ى]/g, 'ي').replace(/[ک]/g, 'ك').replace(/[ة]/g, 'ه').replace(/[أإآ]/g, 'ا');
	}
	/* minutes since midnight in Iran (the places are in Iranian cities) */
	function nowMin() {
		try {
			var h = 0, m = 0;
			new Intl.DateTimeFormat('en-GB', { timeZone: 'Asia/Tehran', hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }).formatToParts(new Date()).forEach(function (x) { if (x.type === 'hour') h = +x.value; if (x.type === 'minute') m = +x.value; });
			return h * 60 + m;
		} catch (e) { var n = new Date(); return n.getHours() * 60 + n.getMinutes(); }
	}
	function mins(t) { var p = String(t || '').split(':'); return p.length === 2 ? (+p[0]) * 60 + (+p[1]) : -1; }
	function isOpen(card) {
		if (card.getAttribute('data-h24')) return true;
		var f = mins(card.getAttribute('data-from')), t = mins(card.getAttribute('data-to')), n = nowMin();
		if (f < 0 || t < 0) return null;
		return f <= t ? n >= f && n < t : n >= f || n < t; // past midnight
	}
	function meters(a, b) {
		var r = 6371000, p1 = a[0] * Math.PI / 180, p2 = b[0] * Math.PI / 180, dp = p2 - p1, dl = (b[1] - a[1]) * Math.PI / 180;
		var h = Math.sin(dp / 2) * Math.sin(dp / 2) + Math.cos(p1) * Math.cos(p2) * Math.sin(dl / 2) * Math.sin(dl / 2);
		return 2 * r * Math.asin(Math.min(1, Math.sqrt(h)));
	}
	function km(m) { return m < 1000 ? Math.round(m / 10) * 10 + ' م' : (m / 1000).toFixed(1).replace(/\.0$/, '') + ' كم'; }

	function init(root) {
		if (root.getAttribute('data-ready')) return;
		root.setAttribute('data-ready', '1');
		var cards = [].slice.call(root.querySelectorAll('.dsc-v,.dsc-s')), box = root.querySelector('.dsc-grid,.dsc-list');
		var none = root.querySelector('.dsc-none'), q = '', type = '', openNow = false, svc = [], sort = 'near', me = null;

		/* the whole card opens the place (photos, map, reviews, call) */
		root.addEventListener('click', function (e) {
			var t = e.target;
			if (t.closest('a,button,select,input,label,.dlz-unified-favorite')) return;
			var c = t.closest('.dsc-v,.dsc-s'); if (!c) return;
			var o = c.querySelector('.dsc-o'); if (o) o.click();
		});
		root.addEventListener('keydown', function (e) {
			if ((e.key === 'Enter' || e.key === ' ') && e.target.matches && e.target.matches('.dsc-v,.dsc-s')) { e.preventDefault(); var o = e.target.querySelector('.dsc-o'); if (o) o.click(); }
		});

		/* open now / closed */
		function hours() {
			cards.forEach(function (c) {
				var b = c.querySelector('.dsc-open'), o = isOpen(c);
				c.setAttribute('data-open', o === true ? '1' : (o === false ? '0' : ''));
				if (!b) return;
				if (o === null) { b.hidden = true; return; }
				b.hidden = false; b.textContent = o ? 'مفتوح الآن' : 'مغلق الآن'; b.classList.toggle('is-closed', !o);
			});
		}
		hours(); setInterval(hours, 60000);

		function apply() {
			var n = 0, nq = norm(q);
			cards.forEach(function (c) {
				var ok = (!nq || norm(c.getAttribute('data-name')).indexOf(nq) > -1) && (!type || c.getAttribute('data-type') === type);
				if (ok && openNow) ok = c.getAttribute('data-open') === '1';
				if (ok && svc.length) { var tg = (c.getAttribute('data-tags') || '').split('|'); ok = svc.every(function (s) { return tg.indexOf(s) > -1; }); }
				c.hidden = !ok; if (ok) n++;
			});
			if (none) none.hidden = !!n || !cards.length;
			var fb = root.querySelector('[data-filter] em'); if (fb) { var k = (openNow ? 1 : 0) + svc.length; fb.hidden = !k; fb.textContent = k; root.querySelector('[data-filter]').classList.toggle('is-on', !!k); }
		}
		function order() {
			var key = function (c) {
				if (sort === 'top') return -((+c.getAttribute('data-r') || 0) * 1000 + (+c.getAttribute('data-c') || 0));
				if (sort === 'cheap') { var p = +c.getAttribute('data-p') || 0; return p > 0 ? p : 1e15; }
				if (me && c.getAttribute('data-lat')) return meters(me, [+c.getAttribute('data-lat'), +c.getAttribute('data-lng')]);
				return +c.getAttribute('data-m') || 1e9;
			};
			cards.slice().sort(function (a, b) { return key(a) - key(b); }).forEach(function (c) { box.appendChild(c); });
		}

		var s = root.querySelector('.dsc-search input');
		if (s) s.addEventListener('input', function () { q = s.value.trim(); apply(); });
		root.querySelectorAll('.dsc-chips-bar .dsc-chip').forEach(function (b) {
			b.addEventListener('click', function () {
				type = b.getAttribute('data-t') || '';
				root.querySelectorAll('.dsc-chips-bar .dsc-chip').forEach(function (x) { var on = x === b; x.classList.toggle('is-on', on); x.setAttribute('aria-pressed', on ? 'true' : 'false'); });
				apply();
			});
		});
		/* the city is the app's city (same as the header) */
		var cs = root.querySelector('[data-city]');
		if (cs) cs.addEventListener('change', function () {
			var c = cs.value;
			try { localStorage.setItem('dase_city', c); } catch (e) {}
			d.cookie = 'dase_city=' + encodeURIComponent(c) + ';path=/;max-age=' + (60 * 60 * 24 * 365) + ';samesite=lax';
			location.reload();
		});

		/* sheet + menu live on <body> (fixed layers inside page builders can be clipped) */
		var sheet = root.querySelector('.dsc-sheet'), menu = root.querySelector('.dsc-menu'), layer = null;
		if (sheet || menu) {
			layer = d.createElement('div'); layer.className = 'dsc dsc-layer'; layer.setAttribute('dir', 'rtl');
			layer.style.cssText = 'position:static;padding:0;margin:0;width:auto;max-width:none';
			if (sheet) layer.appendChild(sheet);
			if (menu) layer.appendChild(menu);
			d.body.appendChild(layer);
		}
		var fBtn = root.querySelector('[data-filter]'), sBtn = root.querySelector('[data-sort]');
		var pendOpen = false, pendSvc = [];
		function sheetOpen(on) {
			if (!sheet) return;
			sheet.hidden = !on;
			d.documentElement.style.overflow = on ? 'hidden' : '';
			if (on) {
				pendOpen = openNow; pendSvc = svc.slice();
				sheet.querySelector('[data-open-now]').checked = pendOpen;
				sheet.querySelectorAll('[data-svc]').forEach(function (b) { var on2 = pendSvc.indexOf(b.getAttribute('data-svc')) > -1; b.classList.toggle('is-on', on2); b.setAttribute('aria-pressed', on2 ? 'true' : 'false'); });
			}
		}
		if (fBtn && sheet) {
			fBtn.addEventListener('click', function () { sheetOpen(true); });
			sheet.addEventListener('click', function (e) {
				if (e.target.closest('[data-close]')) { sheetOpen(false); return; }
				var b = e.target.closest('[data-svc]');
				if (b) { var v = b.getAttribute('data-svc'), i = pendSvc.indexOf(v); if (i > -1) pendSvc.splice(i, 1); else pendSvc.push(v); b.classList.toggle('is-on', i < 0); b.setAttribute('aria-pressed', i < 0 ? 'true' : 'false'); return; }
				if (e.target.closest('.dsc-apply')) { openNow = sheet.querySelector('[data-open-now]').checked; svc = pendSvc.slice(); apply(); sheetOpen(false); return; }
				if (e.target.closest('.dsc-reset')) { openNow = false; svc = []; pendSvc = []; apply(); sheetOpen(false); }
			});
			d.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !sheet.hidden) sheetOpen(false); });
		}
		if (sBtn && menu) {
			sBtn.addEventListener('click', function (e) {
				e.stopPropagation();
				if (!menu.hidden) { menu.hidden = true; return; }
				var r = sBtn.getBoundingClientRect();
				menu.hidden = false;
				menu.style.top = (r.bottom + window.scrollY + 6) + 'px';
				menu.style.left = Math.max(8, r.right + window.scrollX - menu.offsetWidth) + 'px';
			});
			menu.addEventListener('click', function (e) {
				var b = e.target.closest('[data-s]'); if (!b) return;
				sort = b.getAttribute('data-s');
				menu.querySelectorAll('[data-s]').forEach(function (x) { x.setAttribute('aria-checked', x === b ? 'true' : 'false'); });
				sBtn.querySelector('span').textContent = b.textContent;
				menu.hidden = true;
				if (sort === 'near' && !me && navigator.geolocation) {
					navigator.geolocation.getCurrentPosition(function (p) {
						me = [p.coords.latitude, p.coords.longitude];
						cards.forEach(function (c) { var el = c.querySelector('[data-dist]'); if (el && c.getAttribute('data-lat')) el.textContent = km(meters(me, [+c.getAttribute('data-lat'), +c.getAttribute('data-lng')])) + ' منك'; });
						order();
					}, function () { order(); }, { enableHighAccuracy: true, timeout: 10000, maximumAge: 300000 });
				}
				order();
			});
			d.addEventListener('click', function (e) { if (!menu.hidden && !e.target.closest('.dsc-menu')) menu.hidden = true; });
		}
		apply();
	}
	function boot() { d.querySelectorAll('.dsc').forEach(function (r) { if (!r.classList.contains('dsc-layer')) init(r); }); }
	if (d.readyState === 'loading') d.addEventListener('DOMContentLoaded', boot); else boot();
	if (window.elementorFrontend && window.elementorFrontend.hooks) {
		['dlz_venues', 'dlz_salons'].forEach(function (n) { window.elementorFrontend.hooks.addAction('frontend/element_ready/' + n + '.default', function ($s) { $s[0].querySelectorAll('.dsc').forEach(init); }); });
	}
})();
