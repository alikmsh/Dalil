/* Dalil Al Zaer — listing edit form: repeaters, icon picker, media picker, map pin picker. */
(function () {
	'use strict';
	var d = document, cfg = window.DBDEdit || {};
	var root = d.querySelector('.dbde');
	if (!root) return;

	function svg(k, cls) {
		var ic = (cfg.icons || {})[k] || (cfg.icons || {}).check || ['', ''];
		return '<svg class="' + (cls || 'dbde-ico-svg') + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + ic[1] + '</svg>';
	}

	/* ---------- repeaters ---------- */
	var seq = Date.now() % 100000;
	root.addEventListener('click', function (e) {
		var add = e.target.closest('.dbde-add');
		if (add) {
			var rep = add.closest('.dbde-rep'), tpl = rep.querySelector('template');
			var html = tpl.innerHTML.replace(/__i__/g, 'n' + (seq++));
			rep.querySelector('.dbde-rows').insertAdjacentHTML('beforeend', html);
			var last = rep.querySelector('.dbde-rows').lastElementChild, inp = last.querySelector('input[type=text]');
			if (inp) inp.focus();
			return;
		}
		var del = e.target.closest('.dbde-del');
		if (del) { del.closest('.dbde-row').remove(); return; }
		var pick = e.target.closest('.dbde-pick');
		if (pick) { media(pick.closest('.dbde-media')); return; }
		var un = e.target.closest('.dbde-unpick');
		if (un) { var mb = un.closest('.dbde-media'); mb.querySelector('input').value = ''; mb.querySelector('.dbde-media-ph').style.backgroundImage = ''; return; }
		var ico = e.target.closest('.dbde-ico');
		if (ico) { openIcons(ico); return; }
		var nav = e.target.closest('.dbde-nav a');
		if (nav) { e.preventDefault(); var t = d.querySelector(nav.getAttribute('href')); if (t) t.scrollIntoView({ behavior: 'smooth', block: 'start' }); }
	});

	/* drag to reorder (handle «⋮⋮») */
	var dragRow = null;
	root.addEventListener('dragstart', function (e) {
		var h = e.target.closest && e.target.closest('.dbde-drag');
		if (!h) return;
		dragRow = h.closest('.dbde-row');
		dragRow.classList.add('is-drag');
		try { e.dataTransfer.setData('text/plain', ''); e.dataTransfer.setDragImage(dragRow, 20, 20); } catch (x) {}
	});
	root.addEventListener('dragover', function (e) {
		if (!dragRow) return;
		var over = e.target.closest && e.target.closest('.dbde-row');
		if (!over || over === dragRow || over.parentNode !== dragRow.parentNode) return;
		e.preventDefault();
		var r = over.getBoundingClientRect();
		over.parentNode.insertBefore(dragRow, e.clientY < r.top + r.height / 2 ? over : over.nextSibling);
	});
	root.addEventListener('dragend', function () { if (dragRow) dragRow.classList.remove('is-drag'); dragRow = null; });

	/* ---------- media ---------- */
	function media(box) {
		if (!window.wp || !wp.media) return;
		var f = wp.media({ title: 'انتخاب تصویر', button: { text: 'استفاده از تصویر' }, multiple: false, library: { type: 'image' } });
		f.on('select', function () {
			var a = f.state().get('selection').first().toJSON();
			var url = (a.sizes && a.sizes.large && a.sizes.large.url) || a.url;
			box.querySelector('input').value = url;
			box.querySelector('.dbde-media-ph').style.backgroundImage = 'url("' + url.replace(/"/g, '%22') + '")';
		});
		f.open();
	}

	/* ---------- icon picker ---------- */
	var pop = root.querySelector('.dbde-pop'), popFor = null;
	if (pop) {
		var grid = pop.querySelector('.dbde-pop-g'), q = pop.querySelector('.dbde-pop-q');
		Object.keys(cfg.icons || {}).forEach(function (k) {
			var b = d.createElement('button');
			b.type = 'button'; b.className = 'dbde-pop-i'; b.setAttribute('data-k', k); b.setAttribute('data-l', cfg.icons[k][0]); b.title = cfg.icons[k][0];
			b.innerHTML = svg(k) + '<small>' + cfg.icons[k][0] + '</small>';
			grid.appendChild(b);
		});
		q.addEventListener('input', function () {
			var v = q.value.trim();
			grid.querySelectorAll('.dbde-pop-i').forEach(function (b) { b.hidden = v && b.getAttribute('data-l').indexOf(v) < 0 && b.getAttribute('data-k').indexOf(v) < 0; });
		});
		grid.addEventListener('click', function (e) {
			var b = e.target.closest('.dbde-pop-i');
			if (!b || !popFor) return;
			var k = b.getAttribute('data-k');
			popFor.querySelector('input').value = k;
			popFor.querySelector('svg').outerHTML = svg(k);
			closeIcons();
		});
		d.addEventListener('click', function (e) { if (!pop.hidden && !e.target.closest('.dbde-pop,.dbde-ico')) closeIcons(); });
		d.addEventListener('keydown', function (e) { if (e.key === 'Escape') closeIcons(); });
	}
	function openIcons(btn) {
		popFor = btn;
		var r = btn.getBoundingClientRect(), rr = root.getBoundingClientRect();
		pop.hidden = false;
		pop.style.top = (r.bottom - rr.top + 6) + 'px';
		pop.style.right = Math.max(0, rr.right - r.right) + 'px';
		var cur = btn.querySelector('input').value;
		pop.querySelectorAll('.dbde-pop-i').forEach(function (b) { b.classList.toggle('is-on', b.getAttribute('data-k') === cur); });
		var q2 = pop.querySelector('.dbde-pop-q'); q2.value = ''; q2.dispatchEvent(new Event('input')); q2.focus();
	}
	function closeIcons() { if (pop) pop.hidden = true; popFor = null; }

	/* ---------- map pin picker ---------- */
	var box = root.querySelector('.dbde-map');
	if (box && window.DLZMap) {
		var lat = root.querySelector('.dbde-lat'), lng = root.querySelector('.dbde-lng'), city = root.querySelector('.dbde-city');
		var h = (cfg.haram || {})[city ? city.value : 'mashhad'] || [36.288, 59.6158, ''];
		var map = new DLZMap(box, { tiles: cfg.tiles && cfg.tiles.url, attr: cfg.tiles && cfg.tiles.attr, interactive: true, center: [h[0], h[1]], zoom: 15, onTap: function (a, b) { set(a, b, true); } });
		var hm = map.haram(h), pin = null, info = d.createElement('div');
		info.className = 'dbde-map-info';
		box.parentNode.insertBefore(info, box.nextSibling);
		function num(v) { v = String(v || '').replace(/[۰-۹]/g, function (c) { return '۰۱۲۳۴۵۶۷۸۹'.indexOf(c); }).trim(); return v === '' ? NaN : +v; }
		function show() {
			if (!pin) { info.textContent = 'هنوز پینی ثبت نشده است.'; return; }
			var m = DLZMap.meters([pin.lat, pin.lng], [h[0], h[1]]);
			info.textContent = 'فاصله تا حرم: ' + (m < 1000 ? Math.round(m / 10) * 10 + ' متر' : (m / 1000).toFixed(1) + ' کیلومتر');
		}
		function set(a, b, fromMap) {
			a = +(+a).toFixed(6); b = +(+b).toFixed(6);
			if (!pin) { pin = map.pin(a, b, (cfg.icons.pin || ['', ''])[1], 'موقعیت'); dragPin(pin); } else map.move(pin, a, b);
			if (fromMap !== 'input') { lat.value = a; lng.value = b; }
			if (!fromMap) map.view(a, b, Math.max(map.z, 16));
			show();
		}
		function dragPin(p) {
			p.el.classList.add('is-drag-pin');
			p.el.addEventListener('pointerdown', function (e) {
				e.preventDefault(); e.stopPropagation();
				try { p.el.setPointerCapture(e.pointerId); } catch (x) {}
				function mv(ev) { var ll = map.at(ev.clientX, ev.clientY + 4); set(ll[0], ll[1], true); }
				function up() { p.el.removeEventListener('pointermove', mv); p.el.removeEventListener('pointerup', up); }
				p.el.addEventListener('pointermove', mv);
				p.el.addEventListener('pointerup', up);
			});
		}
		var a0 = num(lat.value), b0 = num(lng.value);
		requestAnimationFrame(function () {
			map.render();
			if (isFinite(a0) && isFinite(b0)) { set(a0, b0, false); map.fit([[a0, b0], [h[0], h[1]]], null, 17); } else show();
		});
		[lat, lng].forEach(function (i) { i.addEventListener('change', function () { var a = num(lat.value), b = num(lng.value); if (isFinite(a) && isFinite(b)) set(a, b, 'input'); }); });
		if (city) city.addEventListener('change', function () {
			h = (cfg.haram || {})[city.value] || h;
			map.unmark(hm); hm = map.haram(h);
			if (!pin) map.view(h[0], h[1], 15);
			show();
		});
		root.querySelector('.dbde-geo-clear').addEventListener('click', function () { if (pin) { map.unmark(pin); pin = null; } lat.value = ''; lng.value = ''; show(); });
		root.querySelector('.dbde-geo-me').addEventListener('click', function () {
			if (!navigator.geolocation) return;
			navigator.geolocation.getCurrentPosition(function (p) { set(p.coords.latitude, p.coords.longitude, false); }, function () { alert('دسترسی به موقعیت داده نشد.'); }, { enableHighAccuracy: true, timeout: 12000 });
		});
		var gq = root.querySelector('.dbde-geo-q'), res = root.querySelector('.dbde-geo-res');
		function search() {
			var v = gq.value.trim();
			if (!v) return;
			res.hidden = false; res.textContent = 'در حال جستجو…';
			var u = 'https://nominatim.openstreetmap.org/search?format=jsonv2&limit=6&accept-language=ar,fa&countrycodes=ir&q=' + encodeURIComponent(v);
			fetch(u, { headers: { 'Accept': 'application/json' } }).then(function (r) { return r.json(); }).then(function (rows) {
				res.innerHTML = '';
				if (!rows || !rows.length) { res.textContent = 'چیزی پیدا نشد؛ روی نقشه بزنید.'; return; }
				rows.forEach(function (r) {
					var b = d.createElement('button');
					b.type = 'button'; b.textContent = r.display_name;
					b.addEventListener('click', function () { set(+r.lat, +r.lon, false); res.hidden = true; });
					res.appendChild(b);
				});
			}).catch(function () { res.textContent = 'جستجو در دسترس نیست؛ روی نقشه بزنید تا پین ثبت شود.'; });
		}
		root.querySelector('.dbde-geo-go').addEventListener('click', search);
		gq.addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); search(); } });
	}
})();
