/* Dalil Al Zaer — listings 3.0: store page sheet, tabs / search / filters, «الخريطة» explorer (GPS, nearest, directions),
   «سجّل متجرك» form. Needs tilemap.js (window.DLZMap). */
(function () {
	'use strict';
	var d = document, cfg = window.DBDMap || {}, M = window.DLZMap;
	/* pull the block up under the app header when only empty theme / Elementor spacing sits above it */
	var lift = window.DLZLift || (window.DLZLift = function (root) {
		if (!root || root.__lift) return;
		root.__lift = 1;
		var pt = d.querySelector('.dlz-ptitle'), hd = pt && pt.offsetHeight ? pt : d.getElementById('dsh-header'), ab = d.getElementById('wpadminbar'); // under the page title when there is one
		var y = window.scrollY || 0, ref = 0;
		if (hd && hd.offsetHeight) ref = getComputedStyle(hd).position === 'fixed' ? hd.offsetHeight : hd.getBoundingClientRect().bottom + y;
		else if (ab && getComputedStyle(ab).position === 'fixed') ref = ab.offsetHeight;
		var gap = root.getBoundingClientRect().top + y - ref - 10;
		if (gap < 6 || gap > 420) return;
		var w = d.createTreeWalker(d.body, NodeFilter.SHOW_ELEMENT), el;
		while ((el = w.nextNode())) {
			if (el === root) break;
			if (el.contains(root) || (hd && (el === hd || hd.contains(el))) || /^(SCRIPT|STYLE|LINK|META|NOSCRIPT|TEMPLATE)$/.test(el.tagName)) continue;
			var r = el.getBoundingClientRect();
			if (r.width < 2 || r.height < 2 || r.bottom + y <= ref) continue;
			var cs = getComputedStyle(el);
			if (cs.visibility === 'hidden' || cs.position === 'fixed' || cs.position === 'absolute' || +cs.opacity === 0) continue;
			if (/^(IMG|SVG|svg|VIDEO|IFRAME|INPUT|BUTTON|CANVAS|SELECT|TEXTAREA)$/.test(el.tagName) || [].some.call(el.childNodes, function (n) { return n.nodeType === 3 && n.textContent.trim(); })) return;
		}
		root.style.marginTop = (-gap) + 'px';
	});
	var IC = {
		close: '<path d="M6.5 6.5l11 11M17.5 6.5l-11 11"/>', locate: '<circle cx="12" cy="12" r="3.2"/><circle cx="12" cy="12" r="7.5"/><path d="M12 2v2.5M12 19.5V22M2 12h2.5M19.5 12H22"/>',
		nav: '<path d="M20.5 3.5 3.8 10.4l7 2.8 2.8 7z"/>', wa: '<path d="M12 3.1a8.9 8.9 0 0 0-7.7 13.3L3.1 20.9l4.6-1.2A8.9 8.9 0 1 0 12 3.1z"/>',
		walk: '<circle cx="13" cy="4.5" r="1.8"/><path d="m9.5 21 2.2-6.2 2.8 2.7V21M8 11.5l2-3.3 3.2-.8 2.2 3 2.6 1.1M11.7 14.8l.6-4"/>',
		car: '<path d="M5 16V11l2-5h10l2 5v5M3.5 16h17M5 11h14"/><circle cx="7.5" cy="16.5" r="1.7"/><circle cx="16.5" cy="16.5" r="1.7"/>',
		ext: '<path d="M14 4h6v6M20 4l-9 9M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5"/>', info: '<circle cx="12" cy="12" r="8.2"/><path d="M12 11v5.2M12 7.8v.4"/>',
		list: '<path d="M8 6h12M8 12h12M8 18h12"/><circle cx="4" cy="6" r="1" fill="currentColor"/><circle cx="4" cy="12" r="1" fill="currentColor"/><circle cx="4" cy="18" r="1" fill="currentColor"/>'
	};
	function ic(n, c) { return '<svg class="' + (c || 'dbd-xi') + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (IC[n] || '') + '</svg>'; }
	/* «افتح في Google Maps / Waze» — the phone's own navigation app, from where the visitor stands */
	function nav2(lat, lng, mode) {
		var ll = (+lat).toFixed(6) + ',' + (+lng).toFixed(6);
		var sv = function (p) { return '<svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + p + '</svg>'; };
		return '<div class="dbd-nav2">'
			+ '<a class="dbd-n2 is-g" href="https://www.google.com/maps/dir/?api=1&destination=' + ll + '&travelmode=' + (mode === 'foot' ? 'walking' : 'driving') + '" target="_blank" rel="noopener"><span class="dbd-n2-i">' + sv('<path d="M12 21.5s-6.5-6.2-6.5-11.6a6.5 6.5 0 0 1 13 0c0 5.4-6.5 11.6-6.5 11.6z"/><circle cx="12" cy="9.8" r="2.4"/>') + '</span><span class="dbd-n2-t"><small>افتح في</small><b>Google Maps</b></span></a>'
			+ '<a class="dbd-n2 is-w" href="https://waze.com/ul?ll=' + ll + '&navigate=yes&zoom=17" target="_blank" rel="noopener"><span class="dbd-n2-i">' + sv('<path d="M20.5 3.5 3.5 10.6l7 2.9 2.9 7z"/>') + '</span><span class="dbd-n2-t"><small>افتح في</small><b>Waze</b></span></a></div>';
	}
	function esc(v) { var x = d.createElement('div'); x.textContent = v == null ? '' : String(v); return x.innerHTML.replace(/"/g, '&quot;').replace(/'/g, '&#39;'); }
	function fmtM(m) { return m < 1000 ? (Math.max(10, Math.round(m / 10) * 10)) + ' م' : (m / 1000).toFixed(m < 10000 ? 1 : 0).replace(/\.0$/, '') + ' كم'; }
	function fmtMin(s) { var m = Math.max(1, Math.round(s / 60)); return m < 60 ? m + ' د' : Math.floor(m / 60) + ' س ' + (m % 60 ? (m % 60) + ' د' : ''); }
	function pushState(key) { try { var st = {}, hs = history.state; if (hs && typeof hs === 'object') for (var k in hs) st[k] = hs[k]; st[key] = 1; history.pushState(st, ''); return true; } catch (e) { return false; } }
	var toastT = 0;
	function toast(t) {
		var x = d.querySelector('.dbd-copied');
		if (!x) { x = d.createElement('div'); x.className = 'dbd-copied'; x.setAttribute('role', 'status'); d.body.appendChild(x); }
		x.textContent = t; x.classList.add('is-on');
		clearTimeout(toastT); toastT = setTimeout(function () { x.classList.remove('is-on'); }, 2000);
	}

	/* ================= visitor position (shared) ================= */
	var me = null, meWatch = null, meSubs = [];
	function locate(cb, quiet) {
		if (me) { cb(me); }
		meSubs.push(cb);
		if (meWatch !== null || !navigator.geolocation) { if (!navigator.geolocation && !quiet) toast('المتصفح لا يدعم تحديد الموقع'); return; }
		meWatch = navigator.geolocation.watchPosition(function (p) {
			me = { lat: p.coords.latitude, lng: p.coords.longitude, acc: p.coords.accuracy };
			meSubs.forEach(function (f) { try { f(me); } catch (e) {} });
		}, function (err) {
			meWatch = null;
			if (!quiet) toast(err && err.code === 1 ? 'لم يتم السماح بالوصول إلى موقعك — فعّل الموقع من إعدادات المتصفح' : 'تعذّر تحديد موقعك، حاول مرة أخرى');
			meSubs.forEach(function (f) { try { f(null); } catch (e) {} });
		}, { enableHighAccuracy: true, timeout: 15000, maximumAge: 20000 });
	}
	function stopLocate() { if (meWatch !== null && navigator.geolocation) navigator.geolocation.clearWatch(meWatch); meWatch = null; meSubs = []; }

	/* ================= store page (sheet) ================= */
	var pushed = null, loading = {};
	function sheetEl(id) { return d.getElementById('dbd-modal-' + id); }
	function openModal(id) {
		var m = sheetEl(id);
		if (m) { show(m); return; }
		if (loading[id]) return;
		loading[id] = 1;
		var sk = d.createElement('div');
		sk.className = 'dbd-modal is-open is-loading'; sk.setAttribute('dir', 'rtl');
		sk.innerHTML = '<div class="dbd-modal-backdrop"></div><div class="dbd-modal-dialog"><div class="dbd-skel"><i></i><b></b><b></b><span></span><span></span></div></div>';
		d.body.appendChild(sk);
		d.documentElement.classList.add('dbd-modal-lock');
		fetch((cfg.ajax || '/wp-admin/admin-ajax.php') + '?action=dbd_detail&id=' + encodeURIComponent(id), { credentials: 'same-origin' })
			.then(function (r) { return r.json(); })
			.then(function (r) {
				sk.remove(); delete loading[id];
				if (!r || !r.success) { d.documentElement.classList.remove('dbd-modal-lock'); toast('هذا المكان غير متاح حالياً'); return; }
				d.body.insertAdjacentHTML('beforeend', r.data.html);
				var el = sheetEl(id);
				if (el) { el.classList.add('is-fast'); show(el); }
			})
			.catch(function () { sk.remove(); delete loading[id]; d.documentElement.classList.remove('dbd-modal-lock'); toast('تعذّر الاتصال، حاول مرة أخرى'); });
	}
	function show(m) {
		d.querySelectorAll('.dbd-modal.is-open').forEach(function (x) { if (x !== m) closeModal(x, true); });
		if (m.parentNode !== d.body) d.body.appendChild(m);
		m.classList.add('is-open'); m.setAttribute('aria-hidden', 'false');
		d.documentElement.classList.add('dbd-modal-lock');
		var sc = m.querySelector('.dbd-modal-scroll'); if (sc) sc.scrollTop = 0;
		enhance(m);
		if (pushed !== m) {
			try {
				var st = {}, hs = history.state; if (hs && typeof hs === 'object') for (var k in hs) st[k] = hs[k];
				var swap = !!st.dbdMap; delete st.dbdMap; st.dbdSheet = 1;
				history[swap ? 'replaceState' : 'pushState'](st, ''); pushed = m;
			} catch (e) { pushed = null; }
		}
	}
	function closeModal(m, fromHistory) {
		if (!m || !m.classList.contains('is-open')) return;
		m.classList.remove('is-open'); m.setAttribute('aria-hidden', 'true');
		if (!d.querySelector('.dbd-modal.is-open') && !d.querySelector('.dbd-ex.is-open')) d.documentElement.classList.remove('dbd-modal-lock');
		if (pushed === m) { pushed = null; if (!fromHistory && history.state && history.state.dbdSheet) { try { history.back(); } catch (e) {} } }
	}

	/* everything inside a store page (sheet or inline widget) */
	function enhance(m) {
		if (m.__dbd) { hours(m); return; }
		m.__dbd = 1;
		hours(m);
		var desc = m.querySelector('.dbd-s-desc.is-clamp'), more = desc && desc.querySelector('.dbd-s-more');
		if (desc && more) requestAnimationFrame(function () { if (desc.scrollHeight > desc.clientHeight + 4) more.hidden = false; else desc.classList.remove('is-clamp'); });
		var tr = m.querySelector('.dbd-s-track'), dots = m.querySelectorAll('.dbd-s-dots i');
		if (tr && dots.length) {
			tr.addEventListener('scroll', function () { var i = Math.round(Math.abs(tr.scrollLeft) / (tr.clientWidth || 1)); dots.forEach(function (x, k) { x.classList.toggle('is-on', k === i); }); }, { passive: true });
			var auto = setInterval(function () {
				if (!m.isConnected) { clearInterval(auto); return; }
				if (!(m.classList.contains('is-open') || m.classList.contains('dbd-store-inline')) || tr.matches(':hover')) return;
				var i = Math.round(Math.abs(tr.scrollLeft) / (tr.clientWidth || 1)), n = tr.children.length, nx = (i + 1) % n, f = tr.children[nx];
				if (f) tr.scrollTo({ left: f.offsetLeft - tr.offsetLeft, behavior: 'smooth' });
			}, 4500);
		}
		var mp = m.querySelector('.dbd-d-map');
		if (mp && M) {
			var io = new IntersectionObserver(function (en) {
				if (!en[0].isIntersecting) return;
				io.disconnect();
				var map = new M(mp, { tiles: cfg.tiles, attr: cfg.attr, center: [+mp.getAttribute('data-lat'), +mp.getAttribute('data-lng')], zoom: 16 });
				map.pin(+mp.getAttribute('data-lat'), +mp.getAttribute('data-lng'), mp.getAttribute('data-icon'));
				map.render();
				var b = d.createElement('span'); b.className = 'dbd-d-mapgo'; b.innerHTML = ic('nav') + '<span>الاتجاهات</span>'; mp.appendChild(b);
			}, { root: m.querySelector('.dbd-modal-scroll') || null, rootMargin: '150px' });
			io.observe(mp);
		}
	}
	function hours(m) {
		m.querySelectorAll('.dbd-d-hours').forEach(function (li) {
			var b = li.querySelector('.dbd-d-open'); if (!b) return;
			var on;
			if (li.getAttribute('data-h24')) on = true;
			else if (li.hasAttribute('data-from')) {
				var f = +li.getAttribute('data-from'), t = +li.getAttribute('data-to'), now;
				try {
					var hh = 0, mm = 0;
					new Intl.DateTimeFormat('en-GB', { timeZone: 'Asia/Tehran', hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }).formatToParts(new Date()).forEach(function (x) { if (x.type === 'hour') hh = +x.value; if (x.type === 'minute') mm = +x.value; });
					now = hh * 60 + mm;
				} catch (e) { var dt = new Date(); now = dt.getHours() * 60 + dt.getMinutes(); }
				on = f === t ? true : (f < t ? now >= f && now < t : now >= f || now < t);
			} else return;
			b.textContent = on ? 'مفتوح الآن' : 'مغلق الآن'; b.classList.toggle('is-on', on); b.hidden = false;
		});
	}

	/* ---------- photo viewer ---------- */
	var gal = { images: [], index: 0, box: null };
	function galBox() {
		if (gal.box) return gal.box;
		var b = d.createElement('div');
		b.className = 'dbd-gallery-lightbox';
		b.innerHTML = '<button class="dbd-gallery-close" type="button" aria-label="إغلاق">×</button><button class="dbd-gallery-prev" type="button" aria-label="السابق">›</button><div class="dbd-gallery-stage"><img alt=""><div class="dbd-gallery-counter"></div></div><button class="dbd-gallery-next" type="button" aria-label="التالي">‹</button>';
		d.body.appendChild(b); gal.box = b;
		b.addEventListener('click', function (e) {
			if (e.target === b || e.target.closest('.dbd-gallery-close')) galClose();
			else if (e.target.closest('.dbd-gallery-prev')) galMove(-1);
			else if (e.target.closest('.dbd-gallery-next')) galMove(1);
		});
		var x = 0;
		b.addEventListener('touchstart', function (e) { if (e.touches[0]) x = e.touches[0].clientX; }, { passive: true });
		b.addEventListener('touchend', function (e) { if (!e.changedTouches[0]) return; var dx = e.changedTouches[0].clientX - x; if (Math.abs(dx) > 45) galMove(dx > 0 ? 1 : -1); }, { passive: true });
		return b;
	}
	function galShow() { var b = galBox(), n = gal.images.length; if (!n) return; b.querySelector('img').src = gal.images[gal.index]; b.querySelector('.dbd-gallery-counter').textContent = (gal.index + 1) + ' / ' + n; b.classList.add('is-open'); }
	function galMove(k) { var n = gal.images.length; if (n) { gal.index = (gal.index + k + n) % n; galShow(); } }
	function galClose() { if (gal.box) gal.box.classList.remove('is-open'); }
	function galOpen() { return gal.box && gal.box.classList.contains('is-open'); }

	function share(btn) {
		var id = btn.getAttribute('data-id'), url = location.origin + location.pathname + location.search + (id ? '#dbd-business-' + id : ''), title = btn.getAttribute('data-title') || d.title;
		if (window.DLZShare) { window.DLZShare({ text: title + ' — «دليل الزائر»', url: url, title: 'مشاركة', sub: 'أرسل هذا المكان عبر أيّ تطبيق تحبّه' }); return; }
		if (navigator.share) { navigator.share({ title: title, text: title, url: url }).catch(function () {}); return; }
		copy(url, null, 'تم نسخ الرابط');
	}
	function copy(text, btn, msg) {
		function done() { toast(msg || 'تم النسخ'); if (btn) { btn.classList.add('is-ok'); setTimeout(function () { btn.classList.remove('is-ok'); }, 1500); } }
		if (navigator.clipboard && window.isSecureContext) { navigator.clipboard.writeText(text).then(done, fallback); return; }
		fallback();
		function fallback() { var t = d.createElement('textarea'); t.value = text; t.setAttribute('readonly', ''); t.style.position = 'fixed'; t.style.opacity = '0'; d.body.appendChild(t); t.select(); try { d.execCommand('copy'); done(); } catch (e) {} t.remove(); }
	}

	/* ================= product view (tap a product on the store page) ================= */
	var pvEl = null;
	function product(card) {
		var it = json(card.getAttribute('data-item')) || {}, box = card.closest('[data-shop]') || card;
		var wa = box.getAttribute('data-wa') || '', tel = box.getAttribute('data-tel') || '', shop = box.getAttribute('data-shop') || '';
		var msg = 'مرحباً ' + shop + '، أريد الاستفسار عن: ' + it.t + (it.p ? ' (' + (it.p0 || it.p) + ')' : '') + '\n— عبر «دليل الزائر»';
		var waUrl = wa ? wa + (wa.indexOf('?') > -1 ? '&' : '?') + 'text=' + encodeURIComponent(msg) : '';
		if (!pvEl) { pvEl = d.createElement('div'); pvEl.className = 'dbd-pv'; pvEl.setAttribute('dir', 'rtl'); d.body.appendChild(pvEl); }
		pvEl.innerHTML = '<div class="dbd-pv-bd" data-pv-close></div><div class="dbd-pv-box" role="dialog" aria-modal="true" aria-label="' + esc(it.t) + '">'
			+ '<button type="button" class="dbd-pv-x" data-pv-close aria-label="إغلاق"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M6 6l12 12M18 6 6 18"/></svg></button>'
			+ (it.img ? '<figure class="dbd-pv-img"><img src="' + esc(it.img) + '" alt="" data-lightbox-image="' + esc(it.img) + '">' + (it.o && it.p ? '<em>خصم</em>' : '') + '</figure>' : '<span class="dbd-pv-noimg"></span>')
			+ '<div class="dbd-pv-b"><h3>' + esc(it.t) + '</h3>'
			+ (it.p ? '<p class="dbd-pv-p"><b dir="auto">' + esc(it.p) + '</b>' + (it.o ? '<s dir="auto">' + esc(it.o) + '</s>' : '') + '</p>' : '')
			+ (it.d ? '<p class="dbd-pv-d">' + esc(it.d).replace(/\n/g, '<br>') + '</p>' : '')
			+ '<small class="dbd-pv-shop">' + esc(shop) + '</small></div>'
			+ '<div class="dbd-pv-f">' + (waUrl ? '<a class="dbd-pv-wa" href="' + esc(waUrl) + '" target="_blank" rel="noopener"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 3.1a8.9 8.9 0 0 0-7.7 13.3L3.1 20.9l4.6-1.2A8.9 8.9 0 1 0 12 3.1z"/></svg>اطلب عبر واتساب</a>' : '')
			+ (tel ? '<a class="dbd-pv-tel" href="tel:' + esc(tel) + '"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M5.6 3.6h3.1l1.6 4.1-2.1 1.3a10.4 10.4 0 0 0 5.2 5.2l1.3-2.1 4.1 1.6v3.1a1.9 1.9 0 0 1-1.9 1.9A14.6 14.6 0 0 1 3.7 5.5a1.9 1.9 0 0 1 1.9-1.9z"/></svg>اتصال</a>' : '') + '</div></div>';
		pvEl.hidden = false;
		requestAnimationFrame(function () { requestAnimationFrame(function () { pvEl.classList.add('is-open'); }); });
		try { var st = {}, hs = history.state; if (hs && typeof hs === 'object') for (var k in hs) st[k] = hs[k]; st.dbdPv = 1; history.pushState(st, ''); } catch (e) {}
	}
	function pvClose(fromHistory) {
		if (!pvEl || !pvEl.classList.contains('is-open')) return false;
		pvEl.classList.remove('is-open');
		setTimeout(function () { if (!pvEl.classList.contains('is-open')) pvEl.hidden = true; }, 260);
		if (!fromHistory && history.state && history.state.dbdPv) try { history.back(); } catch (e) {}
		return true;
	}
	d.addEventListener('keydown', function (e) {
		if (e.key === 'Escape') pvClose();
		if ((e.key === 'Enter' || e.key === ' ') && e.target.matches && e.target.matches('[data-item]')) { e.preventDefault(); product(e.target); }
	});

	/* ================= clicks ================= */
	d.addEventListener('click', function (e) {
		var t = e.target;
		var o = t.closest('[data-open-business]');
		if (o) { e.preventDefault(); openModal(o.getAttribute('data-open-business')); return; }
		// 17.4: the whole list card opens the place (not only the picture / name)
		var card = t.closest('.dbd-c[data-id],.dbd-ft[data-id]');
		if (card && !t.closest('a,button,select,input,label,textarea,.dlz-unified-favorite')) { openModal(card.getAttribute('data-id')); return; }
		var c = t.closest('[data-close-modal]');
		if (c) { closeModal(c.closest('.dbd-modal')); return; }
		var cp = t.closest('[data-dbd-copy]');
		if (cp) { copy(cp.getAttribute('data-dbd-copy'), cp, 'تم نسخ العنوان'); return; }
		var mr = t.closest('.dbd-s-more');
		if (mr) { mr.closest('.dbd-s-desc').classList.remove('is-clamp'); mr.hidden = true; return; }
		var all = t.closest('[data-dbd-more]');
		if (all) { all.parentNode.querySelectorAll('[data-more]').forEach(function (x) { x.hidden = false; }); all.remove(); return; }
		var r = t.closest('[data-open-review]');
		if (r) {
			var f = d.getElementById('dbd-review-form-' + r.getAttribute('data-open-review'));
			if (f) {
				f.hidden = false; var q = r.closest('.dbd-review-cta'); if (q) q.style.display = 'none';
				var sc = f.closest('.dbd-modal-scroll');
				if (sc) sc.scrollTo({ top: sc.scrollTop + f.getBoundingClientRect().top - sc.getBoundingClientRect().top - 70, behavior: 'smooth' }); else f.scrollIntoView({ behavior: 'smooth', block: 'center' });
			}
			return;
		}
		var pi = t.closest('[data-item]');
		if (pi && !t.closest('.dbd-pv')) { product(pi); return; }
		if (t.closest('[data-pv-close]')) { pvClose(); return; }
		var p = t.closest('[data-lightbox-image]');
		if (p) {
			var scope = p.closest('.dbd-modal,.dbd-store-inline'), list = scope ? [].slice.call(scope.querySelectorAll('.dbd-s-track [data-lightbox-image],.dbd-s-gal [data-lightbox-image]')) : [];
			var urls = [], seen = {};
			list.forEach(function (x) { var u = x.getAttribute('data-lightbox-image'); if (!seen[u]) { seen[u] = 1; urls.push(u); } });
			var u0 = p.getAttribute('data-lightbox-image');
			if (urls.indexOf(u0) < 0) urls = [u0];
			gal.images = urls; gal.index = Math.max(0, urls.indexOf(u0)); galShow();
			return;
		}
		var sh = t.closest('[data-dbd-share]');
		if (sh) { e.preventDefault(); share(sh); return; }
		var go = t.closest('[data-dbd-go]');
		if (go) { e.preventDefault(); var g = {}; try { g = JSON.parse(go.getAttribute('data-dbd-go')); } catch (x) {} if (g.lat) explore({ haram: g.h, pins: [g], title: g.t }, g.id, true); return; }
		var rt = t.closest('[data-dbd-route]');
		if (rt) {
			var dir = rt.closest('.dbd-directory'), data = dir ? json(dir.getAttribute('data-explore')) : null, id = +rt.getAttribute('data-dbd-route');
			if (data && data.pins && data.pins.some(function (x) { return +x.id === id; })) { e.preventDefault(); explore(data, id, true); }
			return;
		}
		var xb = t.closest('[data-dbd-explore]');
		if (xb) { e.preventDefault(); var dd = xb.closest('.dbd-directory'); explore(dd ? json(dd.getAttribute('data-explore')) : {}, 0, false); }
	});
	d.addEventListener('keydown', function (e) {
		if (e.key === 'Enter' && e.target.matches && e.target.matches('.dbd-d-map')) e.target.click();
		if (e.key !== 'Escape') return;
		if (galOpen()) { galClose(); return; }
		if (ex) { exClose(); return; }
		var open = d.querySelectorAll('.dbd-modal.is-open');
		if (open.length) open.forEach(function (x) { closeModal(x); });
	});
	window.addEventListener('popstate', function () {
		if (galOpen()) { galClose(); if (pushed || ex) pushState(ex ? 'dbdMap' : 'dbdSheet'); return; }
		if (pvClose(true)) return;
		if (ex) { exClose(true); return; }
		if (pushed) closeModal(pushed, true);
	});
	function json(s) { try { return JSON.parse(s || '{}'); } catch (e) { return {}; } }

	/* reviews: stars + text required */
	d.addEventListener('submit', function (e) {
		var f = e.target;
		if (!f.classList || !f.classList.contains('dbd-d-form')) return;
		var err = f.querySelector('.dbd-d-err');
		if (!err) { err = d.createElement('p'); err.className = 'dbd-d-err'; err.setAttribute('role', 'alert'); f.querySelector('.dbd-d-send').before(err); }
		err.textContent = '';
		if (!f.querySelector('input[name=dbd_rating]:checked')) { e.preventDefault(); err.textContent = 'اختر عدد النجوم أولاً.'; return; }
		if (f.comment.value.trim().length < 2) { e.preventDefault(); err.textContent = 'اكتب رأيك في سطر واحد على الأقل.'; f.comment.focus(); return; }
		var b = f.querySelector('.dbd-d-send'); b.disabled = true; b.textContent = 'جارٍ الإرسال…';
	});

	/* ================= list: tabs, search, filters ================= */
	function initList(root) {
		if (root.__dbd) return; root.__dbd = 1;
		var list = root.querySelector('.dbd-list'); if (!list) return;
		var cards = [].slice.call(list.children), order = cards.slice(), nores = root.querySelector('.dbd-nores');
		var state = { tag: '', q: '', on: {}, cat: '', sort: '' };
		var t0 = root.querySelector('.dbd-tab.is-on'); if (t0) state.tag = t0.getAttribute('data-tag') || '';
		function apply() {
			var shown = 0, q = state.q;
			var sorted = order.slice();
			if (state.sort) sorted.sort(function (a, b) {
				if (state.sort === 'top') return (+b.getAttribute('data-r')) - (+a.getAttribute('data-r'));
				if (state.sort === 'cheap') return (+a.getAttribute('data-p') || 1e12) - (+b.getAttribute('data-p') || 1e12);
				if (state.sort === 'near' && me && a.hasAttribute('data-lat') !== b.hasAttribute('data-lat')) return a.hasAttribute('data-lat') ? -1 : 1;
				if (state.sort === 'near' && me) return M.meters([me.lat, me.lng], [+a.getAttribute('data-lat'), +a.getAttribute('data-lng')]) - M.meters([me.lat, me.lng], [+b.getAttribute('data-lat'), +b.getAttribute('data-lng')]);
				return (+a.getAttribute('data-m') || 1e9) - (+b.getAttribute('data-m') || 1e9);
			});
			sorted.forEach(function (c) {
				var tags = (c.getAttribute('data-tags') || '').split('|'), bd = ' ' + (c.getAttribute('data-badges') || '') + ' ', ok = true;
				if (state.tag && tags.indexOf(state.tag) < 0) ok = false;
				if (ok && state.cat && tags.indexOf(state.cat) < 0) ok = false;
				if (ok && q && (c.getAttribute('data-name') || '').indexOf(q) < 0) ok = false;
				Object.keys(state.on).forEach(function (k) {
					if (!ok) return;
					var b = k === 'nearharam' ? 'near' : k;
					if (bd.indexOf(' ' + b + ' ') < 0) ok = false;
				});
				c.hidden = !ok; if (ok) shown++;
				list.appendChild(c);
			});
			if (nores) nores.hidden = shown > 0;
		}
		root.querySelectorAll('.dbd-tab').forEach(function (b) {
			b.addEventListener('click', function () {
				root.querySelectorAll('.dbd-tab').forEach(function (x) { x.classList.toggle('is-on', x === b); x.setAttribute('aria-selected', x === b ? 'true' : 'false'); });
				state.tag = b.getAttribute('data-tag') || ''; apply();
			});
		});
		var s = root.querySelector('.dbd-search input');
		if (s) { var tm = 0; s.addEventListener('input', function () { clearTimeout(tm); tm = setTimeout(function () { state.q = s.value.trim().toLowerCase(); apply(); }, 120); }); }
		root.querySelectorAll('.dbd-chip').forEach(function (b) {
			b.addEventListener('click', function () {
				var f = b.getAttribute('data-f'), on = b.getAttribute('aria-pressed') !== 'true';
				if (['near', 'haram', 'top', 'cheap'].indexOf(f) > -1) {
					root.querySelectorAll('.dbd-chip').forEach(function (x) { if (['near', 'haram', 'top', 'cheap'].indexOf(x.getAttribute('data-f')) > -1 && x !== b) x.setAttribute('aria-pressed', 'false'); });
					state.sort = on ? f : '';
					if (on && f === 'near') { b.classList.add('is-wait'); locate(function (p) { b.classList.remove('is-wait'); if (!p) { b.setAttribute('aria-pressed', 'false'); state.sort = 'haram'; } apply(); }); }
				} else { if (on) state.on[f] = 1; else delete state.on[f]; }
				b.setAttribute('aria-pressed', on ? 'true' : 'false');
				apply();
			});
		});
		var cs = root.querySelector('.dbd-chip-sel select');
		if (cs) cs.addEventListener('change', function () { state.cat = cs.value; cs.parentNode.classList.toggle('is-on', !!cs.value); apply(); });
		if (state.tag) apply();
	}

	/* ================= «الخريطة» explorer ================= */
	var ex = null;
	function explore(data, focusId, route) {
		if (!M) return;
		data = data || {};
		var pins = (data.pins || []).filter(function (p) { return p && isFinite(p.lat) && isFinite(p.lng); });
		if (ex) exClose(true);
		var el = d.createElement('div');
		el.className = 'dbd-ex'; el.setAttribute('dir', 'rtl'); el.setAttribute('role', 'dialog'); el.setAttribute('aria-modal', 'true'); el.setAttribute('aria-label', 'الخريطة');
		el.innerHTML = '<div class="dbd-ex-top"><button type="button" class="dbd-ex-x" aria-label="إغلاق">' + ic('close') + '</button><div class="dbd-ex-tt"><b></b><small></small></div><button type="button" class="dbd-ex-me" aria-label="موقعي">' + ic('locate') + '</button></div>' +
			'<div class="dbd-ex-map"></div><div class="dbd-ex-route" hidden></div>' +
			'<div class="dbd-ex-sheet"><button type="button" class="dbd-ex-grab" aria-label="القائمة"><i></i></button><div class="dbd-ex-hint"></div><div class="dbd-ex-list" role="list"></div></div>';
		d.body.appendChild(el);
		d.documentElement.classList.add('dbd-modal-lock');
		el.querySelector('.dbd-ex-tt b').textContent = data.title || 'الخريطة';
		el.querySelector('.dbd-ex-tt small').textContent = pins.length > 1 ? pins.length + ' مكاناً على الخريطة' : '';
		var mapEl = el.querySelector('.dbd-ex-map'), sheet = el.querySelector('.dbd-ex-sheet'), listEl = el.querySelector('.dbd-ex-list'), hint = el.querySelector('.dbd-ex-hint'), rbox = el.querySelector('.dbd-ex-route');
		var h = data.haram || null;
		var map = new M(mapEl, { tiles: cfg.tiles, attr: cfg.attr, interactive: true, center: h ? [h[0], h[1]] : [pins[0] ? pins[0].lat : 36.288, pins[0] ? pins[0].lng : 59.6158], zoom: 15 });
		var icons = data.icons || {}, marks = {}, meMark = null, sel = null, routeTo = null, mode = 'foot';
		if (h) map.haram(h);
		pins.forEach(function (p) {
			var mk = map.pin(p.lat, p.lng, icons[p.k] || '', p.t);
			mk.el.addEventListener('click', function (e) { e.stopPropagation(); select(p.id, true); });
			marks[p.id] = mk;
		});
		ex = { el: el, map: map, close: exClose };
		requestAnimationFrame(function () { el.classList.add('is-open'); map.render(); fitAll(); });
		pushState('dbdMap');

		function fitAll() {
			var pts = pins.map(function (p) { return [p.lat, p.lng]; });
			if (h) pts.push([h[0], h[1]]);
			if (me) pts.push([me.lat, me.lng]);
			map.fit(pts, [40, 90, sheet.offsetHeight + 20], 17);
		}
		function dist(p) { return me ? M.meters([me.lat, me.lng], [p.lat, p.lng]) : (h ? M.meters([h[0], h[1]], [p.lat, p.lng]) : 0); }
		function renderList() {
			var rows = pins.slice().sort(function (a, b) { return dist(a) - dist(b); });
			hint.innerHTML = me ? ic('locate', 'dbd-xi') + '<span>الأقرب إليك أولاً</span>' : ic('info', 'dbd-xi') + '<span>فعّل الموقع لترى الأقرب إليك</span><button type="button" class="dbd-ex-on">تفعيل</button>';
			listEl.innerHTML = rows.map(function (p) {
				var m = dist(p), walk = Math.max(1, Math.round(m / 75));
				return '<article class="dbd-ex-it' + (sel === p.id ? ' is-on' : '') + '" data-id="' + esc(p.id) + '" role="listitem">' +
					(p.img ? '<img src="' + esc(p.img) + '" alt="" loading="lazy" decoding="async">' : '<span class="dbd-ex-ph"></span>') +
					'<div class="dbd-ex-it-b"><b>' + esc(p.t) + '</b><small>' + (m ? (me ? 'على بعد ' : '') + fmtM(m) + (me ? ' · ' + walk + ' د مشياً' : ' من الحرم') : '') + (p.r ? ' · ★ ' + (+p.r).toFixed(1) : '') + '</small>' +
					'<nav><button type="button" class="dbd-ex-go">' + ic('nav') + '<span>الاتجاهات</span></button>' + (p.wa ? '<a class="dbd-ex-wa" href="' + esc(p.wa) + '" target="_blank" rel="noopener">' + ic('wa') + '</a>' : '') + (p.id ? '<button type="button" class="dbd-ex-in" aria-label="التفاصيل">' + ic('info') + '</button>' : '') + '</nav></div></article>';
			}).join('') || '<p class="dbd-ex-none">لا توجد أماكن بموقع محدد على الخريطة بعد.</p>';
		}
		function select(id, scroll) {
			sel = id;
			Object.keys(marks).forEach(function (k) { marks[k].el.classList.toggle('is-on', String(k) === String(id)); });
			listEl.querySelectorAll('.dbd-ex-it').forEach(function (x) { var on = x.getAttribute('data-id') === String(id); x.classList.toggle('is-on', on); if (on && scroll) x.scrollIntoView({ block: 'nearest', inline: 'nearest', behavior: 'smooth' }); });
			var p = pins.filter(function (x) { return String(x.id) === String(id); })[0];
			if (p && !routeTo) map.view(p.lat, p.lng, Math.max(map.z, 16));
		}
		function setMe(p) {
			el.querySelector('.dbd-ex-me').classList.remove('is-wait');
			if (!p) { renderList(); return; }
			if (!meMark) meMark = map.mark(p.lat, p.lng, '<i></i>', 'dlzm-me'); else map.move(meMark, p.lat, p.lng);
			var first = !el.__had; el.__had = 1;
			renderList();
			if (routeTo) { if (first) doRoute(routeTo); }
			else if (first && !focusId) fitAll();
		}
		function doRoute(p) {
			routeTo = p;
			select(p.id, true);
			if (!me) {
				rbox.hidden = false;
				rbox.innerHTML = '<p>' + ic('locate', 'dbd-xi') + '<span>نحتاج إلى موقعك لرسم الطريق…</span></p>' + nav2(p.lat, p.lng, mode);
				el.querySelector('.dbd-ex-me').classList.add('is-wait');
				locate(setMe);
				return;
			}
			var a = [me.lat, me.lng], b = [p.lat, p.lng], straight = M.meters(a, b);
			rbox.hidden = false;
			rbox.innerHTML = '<div class="dbd-ex-r1"><b>' + esc(p.t) + '</b><button type="button" class="dbd-ex-rx" aria-label="إلغاء">' + ic('close') + '</button></div><div class="dbd-ex-modes"><button type="button" data-m="foot" class="' + (mode === 'foot' ? 'is-on' : '') + '">' + ic('walk') + '<span>مشياً</span></button><button type="button" data-m="car" class="' + (mode === 'car' ? 'is-on' : '') + '">' + ic('car') + '<span>بالسيارة</span></button></div><p class="dbd-ex-sum">جارٍ حساب أقصر طريق…</p>' + nav2(b[0], b[1], mode);
			map.setRoute([a, b]);
			map.fit([a, b], [50, rbox.offsetHeight + 90, sheet.offsetHeight + 30], 18);
			el.classList.add('has-route');
			var url = (cfg.route || '').replace('{p}', mode === 'foot' ? 'foot' : 'car').replace('{a}', a[1] + ',' + a[0]).replace('{b}', b[1] + ',' + b[0]);
			var ctl = 'AbortController' in window ? new AbortController() : null, tmo = setTimeout(function () { if (ctl) ctl.abort(); }, 9000), want = p;
			fetch(url, ctl ? { signal: ctl.signal } : {}).then(function (r) { return r.json(); }).then(function (r) {
				clearTimeout(tmo);
				if (routeTo !== want || !ex) return;
				var rr = r && r.routes && r.routes[0];
				if (!rr) throw new Error('no route');
				var pts = rr.geometry.coordinates.map(function (c) { return [c[1], c[0]]; });
				map.setRoute(pts);
				map.fit(pts, [50, rbox.offsetHeight + 90, sheet.offsetHeight + 30], 18);
				var dur = mode === 'foot' ? Math.max(rr.duration, rr.distance / 1.3) : rr.duration;
				var s = rbox.querySelector('.dbd-ex-sum'); if (s) s.innerHTML = '<b>' + fmtMin(dur) + '</b><span>' + fmtM(rr.distance) + ' · أقصر طريق ' + (mode === 'foot' ? 'مشياً' : 'بالسيارة') + '</span>';
			}).catch(function () {
				clearTimeout(tmo);
				if (routeTo !== want || !ex) return;
				var s = rbox.querySelector('.dbd-ex-sum'); if (s) s.innerHTML = '<b>' + fmtM(straight) + '</b><span>المسافة المباشرة · للطريق المفصّل افتح Google Maps أو Waze</span>';
				map.svg.classList.add('is-straight');
			});
		}
		function clearRoute() { routeTo = null; rbox.hidden = true; map.setRoute(null); map.svg.classList.remove('is-straight'); el.classList.remove('has-route'); }

		el.addEventListener('click', function (e) {
			var t = e.target;
			if (t.closest('.dbd-ex-x')) { exClose(); return; }
			if (t.closest('.dbd-ex-me') || t.closest('.dbd-ex-on')) {
				el.querySelector('.dbd-ex-me').classList.add('is-wait');
				locate(function (p) { setMe(p); if (p) map.view(p.lat, p.lng, Math.max(map.z, 16)); });
				return;
			}
			if (t.closest('.dbd-ex-grab')) { sheet.classList.toggle('is-min'); return; }
			if (t.closest('.dbd-ex-rx')) { clearRoute(); return; }
			var mb = t.closest('.dbd-ex-modes button');
			if (mb) { mode = mb.getAttribute('data-m'); map.svg.classList.remove('is-straight'); if (routeTo) doRoute(routeTo); return; }
			var it = t.closest('.dbd-ex-it');
			if (it) {
				var id = it.getAttribute('data-id'), p = pins.filter(function (x) { return String(x.id) === id; })[0];
				if (t.closest('.dbd-ex-go')) { if (p) doRoute(p); return; }
				if (t.closest('.dbd-ex-in')) { exClose(); setTimeout(function () { openModal(id); }, 30); return; }
				if (t.closest('a')) return;
				select(id, false);
			}
		});
		renderList();
		if (focusId) { var fp = pins.filter(function (x) { return String(x.id) === String(focusId); })[0]; if (fp) { setTimeout(function () { if (route) doRoute(fp); else select(fp.id, true); }, 60); } }
		locate(setMe, true);
	}
	function exClose(fromHistory) {
		if (!ex) return;
		var el = ex.el;
		ex.map.destroy && ex.map.destroy();
		ex = null;
		stopLocate();
		el.classList.remove('is-open');
		setTimeout(function () { el.remove(); }, 230);
		if (!d.querySelector('.dbd-modal.is-open')) d.documentElement.classList.remove('dbd-modal-lock');
		if (!fromHistory && history.state && history.state.dbdMap) { try { history.back(); } catch (e) {} }
	}

	/* ================= «سجّل متجرك» ================= */
	function initReg(root) {
		if (root.__dbd) return; root.__dbd = 1;
		var f = root.querySelector('.dbd-reg-f'); if (!f || !M) return;
		var h = json(root.getAttribute('data-haram')), box = root.querySelector('.dbd-reg-map'), ll = root.querySelector('.dbd-reg-ll');
		var map = new M(box, { tiles: cfg.tiles, attr: cfg.attr, interactive: true, center: h[0] ? [h[0], h[1]] : [36.288, 59.6158], zoom: 15, onTap: function (a, b) { set(a, b); } }), pin = null;
		if (h[0]) map.haram(h);
		requestAnimationFrame(function () { map.render(); });
		function set(a, b, view) {
			f.lat.value = (+a).toFixed(6); f.lng.value = (+b).toFixed(6);
			if (!pin) pin = map.pin(a, b, '<circle cx="12" cy="10" r="3"/>'); else map.move(pin, a, b);
			if (view) map.view(a, b, 17);
			ll.textContent = 'تم تحديد الموقع ✓ — يمكنك الضغط على الخريطة لتعديله.'; ll.classList.add('is-ok');
		}
		root.querySelector('.dbd-reg-me').addEventListener('click', function () { var b = this; b.classList.add('is-wait'); locate(function (p) { b.classList.remove('is-wait'); if (p) set(p.lat, p.lng, true); stopLocate(); }); });
		var file = f.querySelector('input[type=file]');
		if (file) file.addEventListener('change', function () { var em = file.parentNode.querySelector('em'); if (file.files[0] && em) { file.parentNode.classList.add('is-on'); em.lastChild.textContent = file.files[0].name; } });
		f.addEventListener('submit', function (e) {
			e.preventDefault();
			var msg = root.querySelector('.dbd-reg-msg'), b = f.querySelector('.dbd-reg-go');
			msg.hidden = true;
			function err(t, el) { msg.textContent = t; msg.hidden = false; if (el) el.focus(); }
			if (f.name.value.trim().length < 2) return err('يرجى كتابة اسم المتجر.', f.name);
			if (f.phone.value.replace(/\D/g, '').length < 7) return err('يرجى كتابة رقم هاتف صحيح.', f.phone);
			if (!f.lat.value) return err('يرجى تحديد موقع المتجر على الخريطة.');
			if (file && file.files[0] && file.files[0].size > 4 * 1024 * 1024) return err('حجم الصورة كبير، الحد الأقصى 4 ميغابايت.');
			b.disabled = true; b.classList.add('is-busy');
			fetch(cfg.ajax, { method: 'POST', body: new FormData(f), credentials: 'same-origin' }).then(function (r) { return r.json(); }).then(function (r) {
				b.disabled = false; b.classList.remove('is-busy');
				if (r && r.success) { f.hidden = true; root.querySelector('.dbd-reg-ok').hidden = false; root.scrollIntoView({ behavior: 'smooth', block: 'start' }); return; }
				err((r && r.data && r.data.message) || 'حدث خطأ، حاول مرة أخرى.');
			}).catch(function () { b.disabled = false; b.classList.remove('is-busy'); err('تعذّر الاتصال، حاول مرة أخرى.'); });
		});
	}

	/* ================= boot ================= */
	function openFromUrl() {
		var m = location.hash.match(/^#dbd-business-(\d+)$/), q = new URLSearchParams(location.search), id = m ? m[1] : (q.get('dlz_favorite_open') || '');
		if (id && !d.querySelector('.dbd-store-inline#dbd-business-' + id)) setTimeout(function () { openModal(id); }, 80);
	}
	function sticky() {
		var bars = d.querySelectorAll('.dbd-sticky');
		if (!bars.length || !window.IntersectionObserver) return;
		bars.forEach(function (b) {
			var s = d.createElement('i'); s.style.cssText = 'display:block;height:1px;margin-bottom:-1px'; b.parentNode.insertBefore(s, b);
			new IntersectionObserver(function (en) { b.classList.toggle('is-stuck', !en[0].isIntersecting && en[0].boundingClientRect.top < 200); }, { rootMargin: '-' + (parseInt(getComputedStyle(d.documentElement).getPropertyValue('--dsh-hh'), 10) || 0) + 'px 0px 0px 0px' }).observe(s);
		});
	}
	function boot() {
		sticky();
		d.querySelectorAll('.dbd-directory').forEach(initList);
		var first = d.querySelector('.dbd-directory .dbd-hd, .dbd-directory .dbd-mb, .dbd-store-inline, .dbd-reg');
		if (first) { var blk = first.closest('.dbd-directory') || first; setTimeout(function () { lift(blk); }, 0); }
		d.querySelectorAll('.dbd-store-inline').forEach(enhance);
		d.querySelectorAll('.dbd-reg').forEach(initReg);
	}
	if (d.readyState === 'loading') d.addEventListener('DOMContentLoaded', function () { boot(); openFromUrl(); }); else { boot(); openFromUrl(); }
	window.addEventListener('elementor/frontend/init', function () { setTimeout(boot, 300); });
	window.DBDOpen = openModal;
})();
