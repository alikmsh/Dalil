/* Dalil Al Zaer — «شبكة الأقسام»: filter the categories while typing */
(function () {
	'use strict';
	var d = document;
	/* pull the block up under the app header when only empty theme / Elementor spacing sits above it */
	var lift = window.DLZLift || (window.DLZLift = function (root) {
		if (!root || root.__lift) return;
		root.__lift = 1;
		var pt = d.querySelector('.dlz-ptitle'), hd = pt && pt.offsetHeight ? pt : d.getElementById('dsh-header'), ab = d.getElementById('wpadminbar'); // under the page title when there is one
		var y = window.scrollY || 0, ref = 0;
		if (hd && hd.offsetHeight) ref = getComputedStyle(hd).position === 'fixed' ? hd.offsetHeight : hd.getBoundingClientRect().bottom + y;
		else if (ab && getComputedStyle(ab).position === 'fixed') ref = ab.offsetHeight;
		var gap = root.getBoundingClientRect().top + y - ref - 10;
		if (gap < 6 || gap > 420) return;
		var w = d.createTreeWalker(d.body, NodeFilter.SHOW_ELEMENT), el;
		while ((el = w.nextNode())) {
			if (el === root) break;
			if (el.contains(root) || (hd && (el === hd || hd.contains(el))) || /^(SCRIPT|STYLE|LINK|META|NOSCRIPT|TEMPLATE)$/.test(el.tagName)) continue;
			var r = el.getBoundingClientRect();
			if (r.width < 2 || r.height < 2 || r.bottom + y <= ref) continue;
			var cs = getComputedStyle(el);
			if (cs.visibility === 'hidden' || cs.position === 'fixed' || cs.position === 'absolute' || +cs.opacity === 0) continue;
			if (/^(IMG|SVG|svg|VIDEO|IFRAME|INPUT|BUTTON|CANVAS|SELECT|TEXTAREA)$/.test(el.tagName) || [].some.call(el.childNodes, function (n) { return n.nodeType === 3 && n.textContent.trim(); })) return;
		}
		root.style.marginTop = (-gap) + 'px';
	});
	function init(root) {
		if (root.__dui) return; root.__dui = 1;
		var q = root.querySelector('.dui-sr-in input'), cards = root.querySelectorAll('.dui-cg-c'), none = root.querySelector('.dui-none');
		if (!q) return;
		q.addEventListener('input', function () {
			var v = q.value.trim().toLowerCase(), n = 0;
			cards.forEach(function (c) { var ok = !v || (c.getAttribute('data-t') || '').indexOf(v) > -1; c.hidden = !ok; if (ok) n++; });
			if (none) none.hidden = n > 0;
		});
	}
	function boot() { document.querySelectorAll('.dui-cg').forEach(init); var f = document.querySelector('.dui'); if (f) setTimeout(function () { lift(f); }, 0); }
	if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
	window.addEventListener('elementor/frontend/init', function () { setTimeout(boot, 300); });
})();
