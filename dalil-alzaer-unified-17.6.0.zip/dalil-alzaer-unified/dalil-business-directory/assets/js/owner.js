/* Dalil Al Zaer — «متجري»: the shop owner's panel (products, info, photos). No jQuery. */
(function () {
	'use strict';
	var d = document;
	function esc(s) { var x = d.createElement('div'); x.textContent = s == null ? '' : String(s); return x.innerHTML; }
	function latin(v) { return String(v || '').replace(/[۰-۹]/g, function (c) { return '۰۱۲۳۴۵۶۷۸۹'.indexOf(c); }).replace(/[٠-٩]/g, function (c) { return '٠١٢٣٤٥٦٧٨٩'.indexOf(c); }).replace(/٬/g, ',').replace(/٫/g, '.'); }
	function fmt(v) {
		v = latin(v).replace(/[^\d.]/g, '');
		if (!v) return '';
		var p = v.split('.'), i = p[0].replace(/^0+(?=\d)/, '').replace(/\B(?=(\d{3})+(?!\d))/g, ',');
		return p.length > 1 && p[1] ? i + '.' + p[1].slice(0, 2) : i;
	}
	/* «25,000 د.ع» → ['25,000', 'د.ع'] ; free text stays as it is */
	function split(price, units) {
		price = String(price || '').trim();
		if (!price) return ['', ''];
		var m = latin(price).match(/^([\d.,\s]+)\s*(.*)$/);
		if (!m) return [price, ''];
		return [fmt(m[1]), m[2].trim()];
	}
	var ICON = {
		pen: '<path d="M4 20h4L19 9a2.8 2.8 0 0 0-4-4L4 16z"/><path d="m13.5 6.5 4 4"/>',
		up: '<path d="m6 15 6-6 6 6"/>', down: '<path d="m6 9 6 6 6-6"/>',
		img: '<rect x="3" y="5" width="18" height="14" rx="2.5"/><circle cx="9" cy="10" r="1.8"/><path d="m21 16-5-5-8 8"/>',
		cam: '<path d="M4 8.5h3l1.6-2.5h6.8L17 8.5h3v10.5H4z"/><circle cx="12" cy="13.3" r="3.4"/>',
		x: '<path d="M6 6l12 12M18 6 6 18"/>', trash: '<path d="M4.5 7h15M9.5 7V4.8h5V7M6.5 7l.9 12.2a1.6 1.6 0 0 0 1.6 1.5h6a1.6 1.6 0 0 0 1.6-1.5L17.5 7"/>',
		phone: '<path d="M5.6 3.6h3.1l1.6 4.1-2.1 1.3a10.4 10.4 0 0 0 5.2 5.2l1.3-2.1 4.1 1.6v3.1a1.9 1.9 0 0 1-1.9 1.9A14.6 14.6 0 0 1 3.7 5.5a1.9 1.9 0 0 1 1.9-1.9z"/>'
	};
	function ic(k) { return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (ICON[k] || '') + '</svg>'; }

	/* photos are made smaller on the phone before they are sent (max 1600px, JPEG) */
	function shrink(file) {
		return new Promise(function (ok) {
			if (!/^image\/(jpeg|png|webp)$/.test(file.type) || !window.createImageBitmap) { ok(file); return; }
			createImageBitmap(file).then(function (bm) {
				var max = 1600, s = Math.min(1, max / Math.max(bm.width, bm.height));
				if (s === 1 && file.size < 900 * 1024) { ok(file); return; }
				var c = d.createElement('canvas'); c.width = Math.round(bm.width * s); c.height = Math.round(bm.height * s);
				var x = c.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, c.width, c.height); x.drawImage(bm, 0, 0, c.width, c.height);
				c.toBlob(function (b) { ok(b && b.size < file.size ? new File([b], (file.name || 'photo').replace(/\.\w+$/, '') + '.jpg', { type: 'image/jpeg' }) : file); }, 'image/jpeg', 0.86);
			}).catch(function () { ok(file); });
		});
	}

	function init(root) {
		if (root.__dbo) return; root.__dbo = 1;
		var cfg = {}; try { cfg = JSON.parse(root.getAttribute('data-cfg') || '{}'); } catch (e) {}
		if (!cfg.id) return;
		var items = cfg.items || [], list = root.querySelector('.dbo-items'), empty = root.querySelector('.dbo-empty');
		var toastEl = root.querySelector('.dbo-toast'), tt = 0;
		function toast(m, bad) { toastEl.textContent = m; toastEl.hidden = false; toastEl.classList.toggle('is-bad', !!bad); toastEl.classList.remove('is-on'); void toastEl.offsetWidth; toastEl.classList.add('is-on'); clearTimeout(tt); tt = setTimeout(function () { toastEl.classList.remove('is-on'); }, 2400); }
		function post(action, data, file) {
			var f = new FormData();
			f.append('action', 'dbd_owner_' + action); f.append('nonce', cfg.nonce); f.append('id', cfg.id);
			(function add(pre, v) {
				if (v && typeof v === 'object' && !(v instanceof Blob)) { Object.keys(v).forEach(function (k) { add(pre ? pre + '[' + k + ']' : k, v[k]); }); return; }
				if (v instanceof Blob) f.append(pre, v, v.name || 'photo.jpg'); else f.append(pre, v == null ? '' : v);
			})('', data || {});
			return fetch(cfg.ajax, { method: 'POST', body: f, credentials: 'same-origin' }).then(function (r) { return r.json().catch(function () { return { success: false, data: { message: 'تعذّر الاتصال بالخادم.' } }; }); })
				.then(function (r) {
					if (!r || !r.success) throw new Error((r && r.data && r.data.message) || 'حدث خطأ، حاول مرة أخرى.');
					var old = d.getElementById('dbd-modal-' + cfg.id); if (old && !old.classList.contains('is-open')) old.remove(); // the store page shows the new data next time
					return r.data;
				});
		}
		function upload(file, prog) {
			return shrink(file).then(function (f) {
				if (prog) prog.hidden = false;
				return post('upload', { file: f });
			}).then(function (r) { if (prog) prog.hidden = true; return r.url; }, function (er) { if (prog) prog.hidden = true; throw er; });
		}

		/* ---------- tabs ---------- */
		var tabs = root.querySelectorAll('.dbo-tabs [data-tab]');
		tabs.forEach(function (b) {
			b.addEventListener('click', function () {
				var k = b.getAttribute('data-tab');
				tabs.forEach(function (x) { var on = x === b; x.classList.toggle('is-on', on); x.setAttribute('aria-selected', on ? 'true' : 'false'); });
				root.querySelectorAll('.dbo-pane').forEach(function (p) { p.hidden = p.getAttribute('data-pane') !== k; });
			});
		});

		/* ---------- products ---------- */
		function priceHtml(it) {
			if (!it.p) return '';
			return '<span class="dbo-it-p"><b dir="auto">' + esc(it.p) + '</b>' + (it.o ? '<s dir="auto">' + esc(it.o) + '</s>' : '') + '</span>';
		}
		function render() {
			list.innerHTML = items.map(function (it, i) {
				return '<article class="dbo-it" data-i="' + i + '">'
					+ '<span class="dbo-it-img">' + (it.img ? '<img src="' + esc(it.img) + '" alt="" loading="lazy">' : ic('img')) + (it.o && it.p ? '<em>خصم</em>' : '') + '</span>'
					+ '<div class="dbo-it-t"><b>' + esc(it.t) + '</b>' + priceHtml(it) + (it.d ? '<small>' + esc(it.d) + '</small>' : '') + '</div>'
					+ '<div class="dbo-it-a"><button type="button" class="dbo-ia is-ed" data-act="edit" aria-label="تعديل">' + ic('pen') + '</button>'
					+ '<span class="dbo-ia-mv"><button type="button" class="dbo-ia" data-act="up" aria-label="إلى الأعلى"' + (i ? '' : ' disabled') + '>' + ic('up') + '</button><button type="button" class="dbo-ia" data-act="down" aria-label="إلى الأسفل"' + (i < items.length - 1 ? '' : ' disabled') + '>' + ic('down') + '</button></span></div>'
					+ '</article>';
			}).join('');
			empty.hidden = !!items.length; list.hidden = !items.length;
			root.querySelector('.dbo-pane-h .dbo-add').hidden = !items.length;
			var n = root.querySelector('.dbo-n-items'); if (n) n.textContent = items.length;
		}
		render();
		list.addEventListener('click', function (e) {
			var b = e.target.closest('[data-act]'); if (!b) { var a = e.target.closest('.dbo-it'); if (a) openEd(+a.getAttribute('data-i')); return; }
			var i = +b.closest('.dbo-it').getAttribute('data-i'), act = b.getAttribute('data-act');
			if (act === 'edit') { openEd(i); return; }
			var card = b.closest('.dbo-it'); card.classList.add('is-busy');
			post('item', { op: 'move', index: i, dir: act }).then(function (r) {
				items = r.items; render();
				var moved = list.querySelector('[data-i="' + (i + (act === 'up' ? -1 : 1)) + '"]'); if (moved) { moved.classList.add('is-flash'); }
			}).catch(function (er) { card.classList.remove('is-busy'); toast(er.message, true); });
		});

		/* ---------- product editor (bottom sheet) ---------- */
		var sheet = root.querySelector('.dbo-sheet'), ed = sheet.querySelector('.dbo-ed'), cur = -1, img = '', delArm = 0;
		var drop = ed.querySelector('.dbo-drop'), pimg = drop.querySelector('img'), prog = drop.querySelector('.dbo-prog'), imgX = ed.querySelector('.dbo-img-x');
		var unitSel = ed.querySelector('[name=u]');
		function units(extra) {
			var u = (cfg.units || ['د.ع']).slice(); if (extra && u.indexOf(extra) < 0) u.push(extra);
			unitSel.innerHTML = u.map(function (x) { return '<option>' + esc(x) + '</option>'; }).join('') + '<option value="">بدون</option>';
		}
		function setImg(u) { img = u || ''; pimg.hidden = !img; if (img) pimg.src = img; else pimg.removeAttribute('src'); drop.classList.toggle('has-img', !!img); imgX.hidden = !img; preview(); }
		function val(n) { return ed.querySelector('[name=' + n + ']').value; }
		function compose(num) { num = fmt(num); if (!num) return ''; var u = unitSel.value; return u ? num + ' ' + u : num; }
		function preview() {
			var it = { t: val('t').trim() || 'اسم المنتج', p: compose(val('p')), o: compose(val('o')), d: val('d').trim() };
			ed.querySelector('.dbo-pv-c').innerHTML = '<article class="dbo-pv-card"><span class="dbo-it-img">' + (img ? '<img src="' + esc(img) + '" alt="">' : ic('img')) + '</span><b>' + esc(it.t) + '</b>' + priceHtml(it) + '</article>';
		}
		function counter(t) { var c = t.parentNode.querySelector('.dbo-cnt'); if (c) c.textContent = t.value.length + ' / ' + t.maxLength; }
		function openEd(i) {
			cur = i; delArm = 0;
			var it = i > -1 ? items[i] : { t: '', p: '', o: '', d: '', img: '' };
			var p = split(it.p), o = split(it.o);
			units(p[1] || o[1]);
			unitSel.value = p[1] || o[1] || (cfg.units || [''])[0];
			if (it.p && !p[1] && /\d/.test(p[0])) unitSel.value = '';
			ed.querySelector('[name=t]').value = it.t; ed.querySelector('[name=p]').value = p[0]; ed.querySelector('[name=o]').value = o[0]; ed.querySelector('[name=d]').value = it.d || '';
			counter(ed.querySelector('[name=d]'));
			ed.querySelector('#dbo-ed-t').textContent = i > -1 ? 'تعديل المنتج' : 'منتج جديد';
			var del = ed.querySelector('.is-del'); del.hidden = i < 0; del.classList.remove('is-arm'); del.querySelector('span').textContent = 'حذف';
			setImg(it.img);
			sheet.hidden = false; d.documentElement.classList.add('dbo-lock');
			requestAnimationFrame(function () { requestAnimationFrame(function () { sheet.classList.add('is-open'); }); });
			try { history.pushState(Object.assign({}, history.state || {}, { dboEd: 1 }), ''); } catch (e) {}
			if (i < 0) setTimeout(function () { ed.querySelector('[name=t]').focus(); }, 320);
		}
		function closeEd(fromHistory) {
			if (sheet.hidden) return;
			sheet.classList.remove('is-open'); d.documentElement.classList.remove('dbo-lock');
			setTimeout(function () { if (!sheet.classList.contains('is-open')) sheet.hidden = true; }, 280);
			if (!fromHistory && history.state && history.state.dboEd) try { history.back(); } catch (e) {}
		}
		window.addEventListener('popstate', function () { closeEd(true); });
		d.addEventListener('keydown', function (e) { if (e.key === 'Escape') closeEd(); });
		sheet.addEventListener('click', function (e) { if (e.target.closest('[data-close]')) closeEd(); });
		root.querySelectorAll('.dbo-add').forEach(function (b) { b.addEventListener('click', function () { openEd(-1); }); });
		['t', 'p', 'o', 'd'].forEach(function (n) {
			var f = ed.querySelector('[name=' + n + ']');
			f.addEventListener('input', function () {
				if (n === 'p' || n === 'o') { var s = f.selectionStart, L = f.value.length; var v = fmt(f.value); if (v !== f.value) { f.value = v; try { f.setSelectionRange(s + v.length - L, s + v.length - L); } catch (e) {} } }
				if (n === 'd') counter(f);
				f.classList.remove('is-bad'); preview();
			});
		});
		unitSel.addEventListener('change', preview);
		ed.querySelector('.dbo-file').addEventListener('change', function () {
			var file = this.files && this.files[0]; this.value = '';
			if (!file) return;
			var local = URL.createObjectURL(file); pimg.src = local; pimg.hidden = false; drop.classList.add('has-img', 'is-up');
			upload(file, prog).then(function (u) { drop.classList.remove('is-up'); setImg(u); URL.revokeObjectURL(local); })
				.catch(function (er) { drop.classList.remove('is-up'); setImg(img); toast(er.message, true); });
		});
		imgX.addEventListener('click', function () { setImg(''); });
		ed.addEventListener('submit', function (e) {
			e.preventDefault();
			var t = ed.querySelector('[name=t]');
			if (t.value.trim().length < 2) { t.classList.add('is-bad'); t.focus(); toast('اكتب اسم المنتج', true); return; }
			if (drop.classList.contains('is-up')) { toast('انتظر حتى يكتمل رفع الصورة', true); return; }
			var btn = ed.querySelector('.dbo-ed-f .is-gold'); btn.classList.add('is-busy');
			post('item', { op: 'save', index: cur, t: t.value.trim(), p: compose(val('p')), o: compose(val('o')), d: val('d').trim(), img: img }).then(function (r) {
				btn.classList.remove('is-busy'); items = r.items; render(); closeEd();
				toast(cur > -1 ? 'تم حفظ التعديلات' : 'تمت إضافة المنتج');
				var first = list.querySelector('[data-i="' + (cur > -1 ? cur : 0) + '"]'); if (first) { first.classList.add('is-flash'); first.scrollIntoView({ block: 'nearest', behavior: 'smooth' }); }
			}).catch(function (er) { btn.classList.remove('is-busy'); toast(er.message, true); });
		});
		ed.querySelector('.is-del').addEventListener('click', function () {
			var b = this;
			if (!delArm) { delArm = 1; b.classList.add('is-arm'); b.querySelector('span').textContent = 'اضغط مرة أخرى للتأكيد'; setTimeout(function () { delArm = 0; b.classList.remove('is-arm'); b.querySelector('span').textContent = 'حذف'; }, 3500); return; }
			b.classList.add('is-busy');
			post('item', { op: 'delete', index: cur }).then(function (r) { b.classList.remove('is-busy'); items = r.items; render(); closeEd(); toast('تم حذف المنتج'); })
				.catch(function (er) { b.classList.remove('is-busy'); toast(er.message, true); });
		});

		/* ---------- shop info ---------- */
		var info = root.querySelector('.dbo-info'), I = cfg.info || {}, phones = root.querySelector('.dbo-phones');
		['slogan', 'description', 'items_title', 'whatsapp', 'address', 'hours_from', 'hours_to', 'hours_note', 'instagram', 'telegram'].forEach(function (k) { var f = info.querySelector('[name=' + k + ']'); if (f) f.value = I[k] || ''; });
		var o24 = info.querySelector('[name=open_24]'); o24.checked = I.open_24 === '1';
		function hours() { info.querySelector('.dbo-hours').classList.toggle('is-off', o24.checked); }
		o24.addEventListener('change', hours); hours();
		var desc = info.querySelector('[name=description]'); counter(desc); desc.addEventListener('input', function () { counter(desc); });
		function phoneRow(p) {
			var r = d.createElement('div'); r.className = 'dbo-phr';
			r.innerHTML = '<span class="dbo-phr-i">' + ic('phone') + '</span><input class="dbo-phr-n" dir="ltr" inputmode="tel" maxlength="24" placeholder="رقم الهاتف"><input class="dbo-phr-l" maxlength="30" placeholder="الوصف"><button type="button" class="dbo-phr-x" aria-label="حذف">' + ic('x') + '</button>';
			r.querySelector('.dbo-phr-n').value = p.n || ''; r.querySelector('.dbo-phr-l').value = p.l || '';
			phones.appendChild(r);
		}
		(I.phones && I.phones.length ? I.phones : [{}]).forEach(phoneRow);
		root.querySelector('.dbo-phone-add').addEventListener('click', function () { if (phones.children.length < 5) { phoneRow({}); phones.lastChild.querySelector('input').focus(); } });
		phones.addEventListener('click', function (e) { var x = e.target.closest('.dbo-phr-x'); if (x) x.closest('.dbo-phr').remove(); });
		info.addEventListener('submit', function (e) {
			e.preventDefault();
			var data = {};
			['slogan', 'description', 'items_title', 'whatsapp', 'address', 'hours_from', 'hours_to', 'hours_note', 'instagram', 'telegram'].forEach(function (k) { data[k] = info.querySelector('[name=' + k + ']').value; });
			data.open_24 = o24.checked ? '1' : '';
			data.phones = {};
			[].forEach.call(phones.querySelectorAll('.dbo-phr'), function (r, i) { var n = latin(r.querySelector('.dbo-phr-n').value).trim(); if (n) data.phones[i] = { n: n, l: r.querySelector('.dbo-phr-l').value }; });
			if (!Object.keys(data.phones).length) data.phones = '';
			var b = info.querySelector('.dbo-savebar .dbo-btn'); b.classList.add('is-busy');
			post('info', data).then(function () { b.classList.remove('is-busy'); b.classList.add('is-done'); setTimeout(function () { b.classList.remove('is-done'); }, 1600); toast('تم حفظ المعلومات'); })
				.catch(function (er) { b.classList.remove('is-busy'); toast(er.message, true); });
		});

		/* ---------- photos ---------- */
		var P = cfg.photos || {};
		function slot(el) {
			var k = el.getAttribute('data-slot'), u = P[k] || '', lab = el.querySelector('em');
			el.innerHTML = (u ? '<img src="' + esc(u) + '" alt="">' : '<span class="dbo-ph-add">' + ic('cam') + '<small>' + (k === 'logo' ? 'الشعار' : 'إضافة صورة') + '</small></span>')
				+ (lab ? lab.outerHTML : '') + '<input type="file" accept="image/jpeg,image/png,image/webp">' + (u ? '<button type="button" class="dbo-ph-x" aria-label="حذف الصورة">' + ic('x') + '</button>' : '') + '<i class="dbo-prog" hidden></i>';
			el.classList.toggle('has-img', !!u);
		}
		function save(k, u, el) {
			return post('photo', { slot: k, url: u }).then(function (r) {
				P = r.photos; root.querySelectorAll('[data-slot]').forEach(slot);
				if (k === 'logo') { var lg = root.querySelector('.dbo-logo'); lg.innerHTML = u ? '<img src="' + esc(u) + '" alt="">' : '<b>' + esc((root.querySelector('.dbo-who h2').textContent || '').charAt(0)) + '</b>'; }
				if (k === 'image_1') root.querySelector('.dbo-hero').style.setProperty('--cover', u ? 'url("' + u.replace(/"/g, '%22') + '")' : 'none');
			});
		}
		root.querySelectorAll('[data-slot]').forEach(slot);
		root.querySelector('[data-pane=photos]').addEventListener('change', function (e) {
			var inp = e.target; if (inp.type !== 'file') return;
			var el = inp.closest('[data-slot]'), k = el.getAttribute('data-slot'), file = inp.files && inp.files[0];
			if (!file) return;
			el.classList.add('is-up'); var pr = el.querySelector('.dbo-prog');
			upload(file, pr).then(function (u) { return save(k, u, el); }).then(function () { el.classList.remove('is-up'); toast('تم حفظ الصورة'); })
				.catch(function (er) { el.classList.remove('is-up'); toast(er.message, true); });
		});
		root.querySelector('[data-pane=photos]').addEventListener('click', function (e) {
			var x = e.target.closest('.dbo-ph-x'); if (!x) return;
			e.preventDefault();
			var el = x.closest('[data-slot]');
			if (!el.classList.contains('is-arm')) { el.classList.add('is-arm'); x.innerHTML = ic('trash'); setTimeout(function () { el.classList.remove('is-arm'); if (x.isConnected) x.innerHTML = ic('x'); }, 3000); toast('اضغط مرة أخرى لحذف الصورة'); return; }
			save(el.getAttribute('data-slot'), '', el).then(function () { toast('تم حذف الصورة'); }).catch(function (er) { toast(er.message, true); });
		});
		root.querySelector('.dbo-logo').addEventListener('click', function () { tabs[2].click(); root.querySelector('[data-pane=photos]').scrollIntoView({ behavior: 'smooth', block: 'start' }); });
		if (window.DLZLift) setTimeout(function () { window.DLZLift(root); }, 0);
	}
	function boot() { d.querySelectorAll('.dbo[data-cfg]').forEach(init); }
	if (d.readyState === 'loading') d.addEventListener('DOMContentLoaded', boot); else boot();
})();
