jQuery(function($){
    $('.dbd-media-button').on('click', function(e){
        e.preventDefault();
        const btn=$(this), target=btn.data('target'), preview=btn.data('preview');
        const frame=wp.media({title:'انتخاب تصویر',button:{text:'استفاده از تصویر'},multiple:false});
        frame.on('select',function(){
            const url=frame.state().get('selection').first().toJSON().url;
            $('#'+target).val(url);
            $('#'+preview).attr('src',url).show();
        });
        frame.open();
    });

    const list=$('#dbd-sortable');
    if(list.length){
        list.sortable({placeholder:'dbd-sort-placeholder',update:function(){
            list.children('li').each(function(i){$(this).find('.dbd-priority').text('اولویت '+(i+1));});
        }});
        $('#dbd-save-order').on('click',function(){
            const ids=list.children('li').map(function(){return $(this).data('id');}).get();
            const roomId=$('#dbd-save-order').data('room') || 0;
            $.post(DBDAdmin.ajax,{action:'dbd_reorder',nonce:DBDAdmin.nonce,ids:ids,room_id:roomId},function(r){
                $('#dbd-sort-message').text(r.success ? r.data.message : 'خطا در ذخیره ترتیب');
            });
        });
    }
});