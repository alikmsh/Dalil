/* Dalil Al Zaer — tiny tile map (no library): pan, pinch, wheel, markers, a route line, the visitor's position.
   Used by the listings (mini maps, «الخريطة» explorer, details sheet) and by the admin pin picker. */
(function (w) {
	'use strict';
	var d = document, TS = 256;

	function project(lat, lng, z) {
		var s = TS * Math.pow(2, z), sin = Math.sin(Math.max(-85, Math.min(85, lat)) * Math.PI / 180);
		return [(lng + 180) / 360 * s, (0.5 - Math.log((1 + sin) / (1 - sin)) / (4 * Math.PI)) * s];
	}
	function unproject(x, y, z) {
		var s = TS * Math.pow(2, z), n = Math.PI - 2 * Math.PI * y / s;
		return [180 / Math.PI * Math.atan(0.5 * (Math.exp(n) - Math.exp(-n))), x / s * 360 - 180];
	}
	function meters(a, b) {
		var r = 6371000, p1 = a[0] * Math.PI / 180, p2 = b[0] * Math.PI / 180, dp = p2 - p1, dl = (b[1] - a[1]) * Math.PI / 180;
		var h = Math.sin(dp / 2) * Math.sin(dp / 2) + Math.cos(p1) * Math.cos(p2) * Math.sin(dl / 2) * Math.sin(dl / 2);
		return 2 * r * Math.asin(Math.min(1, Math.sqrt(h)));
	}

	var PIN = function (icon, cls) {
		return '<svg viewBox="0 0 34 42" aria-hidden="true"><path d="M17 41S3 26.5 3 16a14 14 0 0 1 28 0c0 10.5-14 25-14 25z" fill="#D9AE4A" stroke="#7A5410" stroke-width="1"/><path d="M17 41S3 26.5 3 16a14 14 0 0 1 14-14" fill="#F3D68B" opacity=".55"/><circle cx="17" cy="16" r="10" fill="#fff"/>' +
			'<g transform="translate(9.5 8.5) scale(.62)" fill="none" stroke="#0F4D2E" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">' + (icon || '<circle cx="12" cy="10" r="3"/>') + '</g></svg>';
	};
	var DOME = '<svg viewBox="0 0 48 48" aria-hidden="true"><path d="M24 4v4M24 8c-6 3-10 7-10 13h20c0-6-4-10-10-13z" fill="#E2B954" stroke="#7A5410" stroke-width=".8"/><rect x="12" y="21" width="24" height="5" fill="#C8922E"/><path d="M10 26h28v14H10z" fill="#E9C46A" stroke="#7A5410" stroke-width=".8"/>' +
		'<path d="M20 40v-7a4 4 0 0 1 8 0v7" fill="#7A5410"/><path d="M5 40V16l2-3 2 3v24M39 40V16l2-3 2 3v24" fill="#E2B954" stroke="#7A5410" stroke-width=".8"/></svg>';

	function Map(el, o) {
		o = o || {};
		var self = this;
		this.el = el; this.o = o; this.z = o.zoom || 15; this.tiles = {}; this.marks = []; this.route = null;
		this.tpl = o.tiles || 'https://tile.openstreetmap.org/{z}/{x}/{y}.png';
		el.classList.add('dlzm');
		el.innerHTML = '<div class="dlzm-layer"></div><svg class="dlzm-route" aria-hidden="true"></svg><span class="dlzm-attr"></span>';
		el.querySelector('.dlzm-attr').innerHTML = o.attr || '© OpenStreetMap';
		this.layer = el.firstChild;
		this.svg = el.querySelector('.dlzm-route');
		var c = o.center || [36.288, 59.6158];
		this.c = project(c[0], c[1], this.z);
		if (o.interactive) this.bind();
		this._rs = function () { self.render(); };
		w.addEventListener('resize', this._rs);
		if ('ResizeObserver' in w) { this._ro = new ResizeObserver(function () { self.render(); }); this._ro.observe(el); }
	}
	Map.project = project; Map.unproject = unproject; Map.meters = meters; Map.PIN = PIN; Map.DOME = DOME;

	Map.prototype.mark = function (lat, lng, html, cls, label) {
		var b = d.createElement(cls && cls.indexOf('dlzm-pin') > -1 ? 'button' : 'div');
		if (b.tagName === 'BUTTON') { b.type = 'button'; if (label) b.setAttribute('aria-label', label); }
		b.className = cls || 'dlzm-mk';
		b.innerHTML = html || '';
		this.el.appendChild(b);
		var m = { el: b, lat: +lat, lng: +lng };
		this.marks.push(m);
		this.place(m);
		return m;
	};
	Map.prototype.pin = function (lat, lng, icon, label) { return this.mark(lat, lng, PIN(icon), 'dlzm-pin', label); };
	Map.prototype.haram = function (h) {
		var m = this.mark(h[0], h[1], DOME + '<b></b>', 'dlzm-haram');
		m.el.querySelector('b').textContent = h[2] || '';
		return m;
	};
	Map.prototype.move = function (m, lat, lng) { m.lat = +lat; m.lng = +lng; this.place(m); };
	Map.prototype.unmark = function (m) { if (!m) return; m.el.remove(); this.marks = this.marks.filter(function (x) { return x !== m; }); };
	Map.prototype.place = function (m) {
		var wd = this.el.clientWidth, h = this.el.clientHeight;
		if (!wd || !h) return;
		var p = project(m.lat, m.lng, this.z);
		m.el.style.left = (p[0] - (this.c[0] - wd / 2)) + 'px';
		m.el.style.top = (p[1] - (this.c[1] - h / 2)) + 'px';
	};
	Map.prototype.view = function (lat, lng, z) {
		if (z) this.z = Math.max(3, Math.min(19, z));
		this.c = project(lat, lng, this.z);
		this.render();
	};
	/** Fit points ([[lat,lng]…]); pad = [x, y top, y bottom] in px. */
	Map.prototype.fit = function (pts, pad, maxZ) {
		pts = (pts || this.marks.map(function (m) { return [m.lat, m.lng]; })).filter(function (p) { return p && isFinite(p[0]) && isFinite(p[1]); });
		var wd = Math.max(120, this.el.clientWidth), h = Math.max(120, this.el.clientHeight);
		pad = pad || [Math.min(60, wd * 0.15), Math.min(70, h * 0.22), Math.min(40, h * 0.12)];
		if (!pts.length) { this.render(); return; }
		if (pts.length === 1) { this.view(pts[0][0], pts[0][1], maxZ || 16); return; }
		for (var z = maxZ || 18; z > 3; z--) {
			var xs = [], ys = [];
			pts.forEach(function (p) { var q = project(p[0], p[1], z); xs.push(q[0]); ys.push(q[1]); });
			var x0 = Math.min.apply(0, xs), x1 = Math.max.apply(0, xs), y0 = Math.min.apply(0, ys), y1 = Math.max.apply(0, ys);
			if (x1 - x0 < wd - 2 * pad[0] && y1 - y0 < h - pad[1] - pad[2]) {
				this.z = z;
				this.c = [(x0 + x1) / 2, (y0 + y1) / 2 - (pad[1] - pad[2]) / 2];
				break;
			}
		}
		this.render();
	};
	Map.prototype.center = function () { return unproject(this.c[0], this.c[1], this.z); };
	Map.prototype.render = function () {
		var wd = this.el.clientWidth, h = this.el.clientHeight, z = this.z, n = Math.pow(2, z);
		if (!wd || !h) return;
		var left = this.c[0] - wd / 2, top = this.c[1] - h / 2, need = {}, self = this;
		for (var tx = Math.floor(left / TS); tx <= Math.floor((left + wd) / TS); tx++) {
			for (var ty = Math.floor(top / TS); ty <= Math.floor((top + h) / TS); ty++) {
				if (ty < 0 || ty >= n) continue;
				var key = z + '/' + tx + '/' + ty, img = this.tiles[key];
				need[key] = 1;
				if (!img) {
					img = d.createElement('img');
					img.className = 'dlzm-tile'; img.alt = ''; img.decoding = 'async'; img.draggable = false;
					img.onload = function () { this.classList.add('is-on'); };
					img.src = this.tpl.replace('{s}', 'abc'.charAt((tx + ty) % 3)).replace('{z}', z).replace('{x}', ((tx % n) + n) % n).replace('{y}', ty).replace('{r}', (w.devicePixelRatio || 1) > 1.5 ? '@2x' : '');
					this.tiles[key] = img;
					this.layer.appendChild(img);
				}
				img.style.transform = 'translate(' + (tx * TS - left) + 'px,' + (ty * TS - top) + 'px)';
			}
		}
		Object.keys(this.tiles).forEach(function (k) { if (!need[k]) { self.tiles[k].remove(); delete self.tiles[k]; } });
		this.marks.forEach(function (m) { self.place(m); });
		this.drawRoute();
	};
	/** pts: [[lat,lng]…] or null to clear */
	Map.prototype.setRoute = function (pts) { this.route = pts && pts.length > 1 ? pts : null; this.drawRoute(); };
	Map.prototype.drawRoute = function () {
		var wd = this.el.clientWidth, h = this.el.clientHeight;
		this.svg.setAttribute('width', wd); this.svg.setAttribute('height', h);
		if (!this.route) { this.svg.innerHTML = ''; return; }
		var z = this.z, left = this.c[0] - wd / 2, top = this.c[1] - h / 2, dd = '';
		this.route.forEach(function (p, i) { var q = project(p[0], p[1], z); dd += (i ? 'L' : 'M') + (q[0] - left).toFixed(1) + ' ' + (q[1] - top).toFixed(1); });
		this.svg.innerHTML = '<path d="' + dd + '" class="dlzm-r-b"/><path d="' + dd + '" class="dlzm-r-f"/>';
	};
	Map.prototype.zoomBy = function (k, px, py) {
		var nz = Math.max(3, Math.min(19, this.z + k));
		if (nz === this.z) return;
		var wd = this.el.clientWidth, h = this.el.clientHeight, f = Math.pow(2, nz - this.z);
		px = px == null ? wd / 2 : px; py = py == null ? h / 2 : py;
		var wx = this.c[0] - wd / 2 + px, wy = this.c[1] - h / 2 + py;
		this.c = [wx * f - px + wd / 2, wy * f - py + h / 2];
		this.z = nz;
		this.render();
	};
	Map.prototype.at = function (clientX, clientY) {
		var r = this.el.getBoundingClientRect(), wd = this.el.clientWidth, h = this.el.clientHeight;
		return unproject(this.c[0] - wd / 2 + clientX - r.left, this.c[1] - h / 2 + clientY - r.top, this.z);
	};
	Map.prototype.bind = function () {
		var self = this, el = this.el, pts = {}, last = null, raf = 0, pinch = 0, lastTap = 0, moved = 0, start = null;
		var zb = d.createElement('div');
		zb.className = 'dlzm-zoom';
		zb.innerHTML = '<button type="button" aria-label="تكبير">+</button><button type="button" aria-label="تصغير">−</button>';
		zb.children[0].addEventListener('click', function (e) { e.stopPropagation(); self.zoomBy(1); });
		zb.children[1].addEventListener('click', function (e) { e.stopPropagation(); self.zoomBy(-1); });
		el.appendChild(zb);
		function dist() { var a = Object.keys(pts).map(function (k) { return pts[k]; }); return a.length < 2 ? 0 : Math.hypot(a[0][0] - a[1][0], a[0][1] - a[1][1]); }
		el.addEventListener('pointerdown', function (e) {
			if (e.target.closest('.dlzm-pin,.dlzm-zoom,.dlzm-ui,button,a')) return;
			try { el.setPointerCapture(e.pointerId); } catch (x) {}
			pts[e.pointerId] = [e.clientX, e.clientY];
			last = [e.clientX, e.clientY]; start = last; moved = 0;
			pinch = dist();
			var now = Date.now();
			if (now - lastTap < 280 && Object.keys(pts).length === 1) { var r = el.getBoundingClientRect(); self.zoomBy(1, e.clientX - r.left, e.clientY - r.top); lastTap = 0; moved = 99; return; }
			lastTap = now;
		});
		el.addEventListener('pointermove', function (e) {
			if (!pts[e.pointerId]) return;
			pts[e.pointerId] = [e.clientX, e.clientY];
			if (Object.keys(pts).length === 2) {
				moved = 99;
				var dd = dist();
				if (pinch && Math.abs(Math.log2(dd / pinch)) > 0.55) { self.zoomBy(dd > pinch ? 1 : -1); pinch = dd; }
				return;
			}
			moved = Math.max(moved, Math.hypot(e.clientX - start[0], e.clientY - start[1]));
			self.c = [self.c[0] - (e.clientX - last[0]), self.c[1] - (e.clientY - last[1])];
			last = [e.clientX, e.clientY];
			if (!raf) raf = requestAnimationFrame(function () { raf = 0; self.render(); });
			if (self.o.onMove) self.o.onMove();
		});
		function up(e) {
			var was = pts[e.pointerId];
			delete pts[e.pointerId];
			var k = Object.keys(pts);
			if (k.length) last = pts[k[0]];
			pinch = 0;
			if (was && !k.length && moved < 6 && e.type === 'pointerup' && self.o.onTap) {
				var ll = self.at(e.clientX, e.clientY);
				setTimeout(function () { if (lastTap && Date.now() - lastTap >= 260) self.o.onTap(ll[0], ll[1]); }, 290);
			}
		}
		el.addEventListener('pointerup', up);
		el.addEventListener('pointercancel', up);
		el.addEventListener('wheel', function (e) { e.preventDefault(); var r = el.getBoundingClientRect(); self.zoomBy(e.deltaY < 0 ? 1 : -1, e.clientX - r.left, e.clientY - r.top); }, { passive: false });
	};
	Map.prototype.destroy = function () {
		w.removeEventListener('resize', this._rs);
		if (this._ro) this._ro.disconnect();
		this.el.innerHTML = '';
	};
	w.DLZMap = Map;
})(window);
