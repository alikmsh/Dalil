<?php
/**
 * Dalil Al Zaer — hide the header and/or the footer on the pages you tick.
 *
 * Two places to tick: the «هدر و فوتر» box on each page's edit screen, and the
 * «هدر و فوتر صفحات» admin page (one table with every page). Both write the same post meta:
 * _dlz_hide_header / _dlz_hide_footer. Hides the app header + bottom bar (or the classic ones)
 * and the theme / Elementor header and footer.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DLZ_Hide_HF {

	const NONCE = 'dlz_hide_hf';

	public static function init() {
		add_action( 'add_meta_boxes', array( __CLASS__, 'metabox' ) );
		add_action( 'save_post', array( __CLASS__, 'save_box' ), 10, 2 );
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 30 );
		add_action( 'admin_post_dlz_hide_hf', array( __CLASS__, 'save_table' ) );
		add_action( 'admin_init', array( __CLASS__, 'migrate' ) );
		add_action( 'wp_head', array( __CLASS__, 'css' ), 99 );
		add_action( 'wp_head', array( __CLASS__, 'title_css' ), 98 );
		add_action( 'wp_body_open', array( __CLASS__, 'title_bar' ), 3 );
		add_filter( 'body_class', array( __CLASS__, 'body_class' ) );
		foreach ( array( 'page', 'post' ) as $pt ) {
			add_filter( 'manage_' . $pt . '_posts_columns', array( __CLASS__, 'col' ) );
			add_action( 'manage_' . $pt . '_posts_custom_column', array( __CLASS__, 'col_out' ), 10, 2 );
		}
	}

	/** Is the header / footer hidden on this page? $which = header|footer */
	public static function hidden( $which, $id = 0 ) {
		if ( ! $id ) {
			if ( is_admin() || ! is_singular() ) {
				return false;
			}
			if ( 'header' === $which && isset( $_GET['dlz_view'] ) && 'favorites' === $_GET['dlz_view'] ) { // phpcs:ignore
				return false; // «المفضلة» keeps the app header even when the profile page hides it
			}
			$id = (int) get_queried_object_id();
		}
		return $id && (bool) get_post_meta( $id, '_dlz_hide_' . ( 'header' === $which ? 'header' : 'footer' ), true );
	}

	/* ------------------------------------------------------------ the page title (17.3) */

	/** Pages get one minimal, centered title under the app header instead of the theme's big left title. */
	private static function title_on() {
		if ( is_admin() || ! is_page() || is_front_page() ) {
			return false;
		}
		$id = (int) get_queried_object_id();
		if ( get_post_meta( $id, '_dlz_hide_title', true ) || self::hidden( 'header' ) ) {
			return false;
		}
		if ( class_exists( 'DLZ_Profile' ) && DLZ_Profile::is_page() ) {
			return false;
		}
		return '' !== trim( (string) get_the_title( $id ) );
	}

	public static function title_css() {
		if ( is_admin() || ! is_page() ) {
			return;
		}
		// the theme's / Elementor's own page title never shows on pages
		echo '<style id="dlz-ptitle-css">body.page .entry-title,body.page h1.entry-title,body.page .page-title,body.page .wp-block-post-title,body.page .elementor-page-title,body.page .elementor-widget-theme-page-title,body.page .entry-header,body.page .page-header{display:none!important}'
			. '.dlz-ptitle{position:relative;z-index:5;display:flex;flex-direction:column;align-items:center;gap:6px;box-sizing:border-box;width:100%;margin:0 auto;padding:16px 16px 6px;text-align:center;direction:rtl;font-family:"DlzDigits",var(--dsh-font,inherit)}'
			. '.dlz-ptitle h1{margin:0!important;padding:0!important;font-family:inherit!important;font-size:22px!important;font-weight:800!important;line-height:1.4!important;letter-spacing:0!important;color:#0F4D2E!important;text-transform:none!important}'
			. '.dlz-pt-o{display:flex;align-items:center;gap:7px}.dlz-pt-o i{display:block;width:34px;height:1.5px;border-radius:2px;background:linear-gradient(90deg,transparent,#D9AE4A)}.dlz-pt-o i:last-child{background:linear-gradient(-90deg,transparent,#D9AE4A)}.dlz-pt-o b{display:block;width:7px;height:7px;transform:rotate(45deg);border-radius:1.5px;background:#D9AE4A}'
			// a block that already shows its own heading keeps it, without a second title above
			. 'body:has(.dui-mt) .dlz-ptitle,body:has(.dbd-hd) .dlz-ptitle,body:has(.mpl) .dlz-ptitle,body:has(.dpf) .dlz-ptitle,body:has(.dbo) .dlz-ptitle,body:has(.dbd-store-inline) .dlz-ptitle{display:none}'
			. '</style>';
	}

	public static function title_bar() {
		static $done = false;
		if ( $done || ! self::title_on() ) {
			return;
		}
		$done = true;
		$t = class_exists( 'DLZ_Labels' ) ? DLZ_Labels::of() : '';
		$t = '' !== $t ? $t : wp_strip_all_tags( get_the_title( get_queried_object_id() ) );
		echo '<div class="dlz-ptitle"><h1>' . esc_html( $t ) . '</h1><span class="dlz-pt-o" aria-hidden="true"><i></i><b></b><i></i></span></div>';
		// the theme leaves an empty band between the title and the page content: close it (once, after the content is there)
		echo '<script>(function(){function f(){var t=document.querySelector(".dlz-ptitle");if(!t)return;var hd=t.offsetHeight?null:document.querySelector(".dsc .dsc-hd")&&document.getElementById("dsh-header");if(!t.offsetHeight&&!hd)return;var s=t.nextElementSibling;function skip(x){if(/^(SCRIPT|STYLE|LINK|NOSCRIPT|TEMPLATE)$/.test(x.tagName)||x.offsetHeight<3||/screen-reader-text/.test(x.className))return true;var c=getComputedStyle(x);return c.position==="fixed"||c.position==="absolute"||c.visibility==="hidden"||+c.opacity===0;}while(s&&skip(s))s=s.nextElementSibling;if(!s)return;'
			. 'var w=document.createTreeWalker(s,NodeFilter.SHOW_ELEMENT),e,top=null;while((e=w.nextNode())){var r=e.getBoundingClientRect();if(r.width<2||r.height<2)continue;var cs=getComputedStyle(e);if(cs.visibility==="hidden"||cs.position==="fixed")continue;'
			. 'if(/^(IMG|SVG|svg|VIDEO|IFRAME|INPUT|BUTTON|CANVAS|SELECT|TEXTAREA|A)$/.test(e.tagName)||[].some.call(e.childNodes,function(n){return n.nodeType===3&&n.textContent.trim();})||(cs.backgroundImage!=="none")||(cs.backgroundColor!=="rgba(0, 0, 0, 0)"&&cs.backgroundColor!=="transparent"&&e!==s&&r.width<innerWidth)||parseFloat(cs.borderTopWidth)>0||cs.boxShadow!=="none"){top=r.top;break;}}'
			. 'if(top===null)return;var hb=t.getBoundingClientRect().bottom;if(hd){hb=hd.getBoundingClientRect().bottom;[].forEach.call(hd.querySelectorAll("*"),function(x){var q=x.getBoundingClientRect();if(q.height>2&&q.bottom>hb&&q.bottom<hb+60)hb=q.bottom;});}var want=hd?16:12,gap=top-hb;if(gap<500&&Math.abs(gap-want)>3&&(gap>want+6||s.style.marginTop)){s.style.marginTop=(parseFloat(getComputedStyle(s).marginTop)||0)-(gap-want)+"px";}}'
			. 'if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",f);else f();addEventListener("load",f);})();</script>';
	}

	/** The old multi-select lists (تنظیمات ظاهر سایت) become ticks, once. */
	public static function migrate() {
		if ( get_option( 'dlz_hide_hf_migrated' ) ) {
			return;
		}
		$s = get_option( 'dase_settings' );
		if ( is_array( $s ) ) {
			foreach ( array( 'header', 'footer' ) as $w ) {
				foreach ( (array) ( $s[ $w . '_hide_pages' ] ?? array() ) as $id ) {
					if ( (int) $id ) {
						update_post_meta( (int) $id, '_dlz_hide_' . $w, 1 );
					}
				}
			}
		}
		update_option( 'dlz_hide_hf_migrated', 1 );
	}

	/* ------------------------------------------------------------ front */

	public static function body_class( $c ) {
		if ( self::hidden( 'header' ) ) {
			$c[] = 'dlz-no-header';
		}
		if ( self::hidden( 'footer' ) ) {
			$c[] = 'dlz-no-footer';
		}
		return $c;
	}

	private static function sel( $list ) {
		$out = array();
		foreach ( explode( ',', (string) $list ) as $s ) {
			$s = trim( $s );
			if ( '' !== $s && ! preg_match( '/[{}<>]/', $s ) ) {
				$out[] = 'html body ' . $s;
			}
		}
		return implode( ',', $out );
	}

	public static function css() {
		$h = self::hidden( 'header' );
		$f = self::hidden( 'footer' );
		if ( ! $h && ! $f ) {
			return;
		}
		$o   = class_exists( 'DLZ_App_Shell' ) ? DLZ_App_Shell::get() : array();
		$css = '';
		if ( $h ) {
			$sel  = self::sel( ( $o['header_selectors'] ?? '#masthead, .site-header, .elementor-location-header, #header' ) . ', .dsh-header, .dase-header' );
			$css .= $sel . '{display:none!important}html body.dlz-no-header{padding-top:0!important}';
		}
		if ( $f ) {
			$sel  = self::sel( ( $o['footer_selectors'] ?? '#colophon, .site-footer, .elementor-location-footer, #footer' ) . ', .dsh-nav, .dase-footer, .dase-bottom-nav' );
			$css .= $sel . '{display:none!important}html body.dlz-no-footer{padding-bottom:0!important;--dsh-nav:0px}';
		}
		echo '<style id="dlz-hide-hf">' . $css . '</style>'; // phpcs:ignore — selectors are filtered above
	}

	/* ------------------------------------------------------------ edit screen box */

	public static function metabox() {
		foreach ( array( 'page', 'post' ) as $pt ) {
			add_meta_box( 'dlz-hide-hf', 'هدر و فوتر', array( __CLASS__, 'box' ), $pt, 'side', 'default' );
		}
	}

	public static function box( $post ) {
		wp_nonce_field( self::NONCE, self::NONCE );
		$h = (bool) get_post_meta( $post->ID, '_dlz_hide_header', true );
		$f = (bool) get_post_meta( $post->ID, '_dlz_hide_footer', true );
		echo '<p style="margin:0 0 8px"><label><input type="checkbox" name="dlz_hide_header" value="1" ' . checked( $h, true, false ) . '> مخفی کردن <b>هدر</b> در این صفحه</label></p>';
		echo '<p style="margin:0 0 8px"><label><input type="checkbox" name="dlz_hide_footer" value="1" ' . checked( $f, true, false ) . '> مخفی کردن <b>فوتر / نوار پایین</b> در این صفحه</label></p>';
		$t = (bool) get_post_meta( $post->ID, '_dlz_hide_title', true );
		echo '<p style="margin:0 0 8px"><label><input type="checkbox" name="dlz_hide_title" value="1" ' . checked( $t, true, false ) . '> مخفی کردن <b>عنوان صفحه</b> (بالای صفحه، وسط)</label></p>';
		echo '<p class="description" style="margin:0">همه‌ی صفحات یک‌جا: <a href="' . esc_url( admin_url( 'admin.php?page=dlz-hide-hf' ) ) . '">هدر و فوتر صفحات</a></p>';
	}

	public static function save_box( $post_id, $post ) {
		if ( ! isset( $_POST[ self::NONCE ] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST[ self::NONCE ] ) ), self::NONCE ) ) {
			return;
		}
		if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || wp_is_post_revision( $post_id ) || ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}
		foreach ( array( 'header', 'footer', 'title' ) as $w ) {
			if ( empty( $_POST[ 'dlz_hide_' . $w ] ) ) {
				delete_post_meta( $post_id, '_dlz_hide_' . $w );
			} else {
				update_post_meta( $post_id, '_dlz_hide_' . $w, 1 );
			}
		}
	}

	/* ------------------------------------------------------------ pages list column */

	public static function col( $cols ) {
		$cols['dlz_hf'] = 'هدر / فوتر';
		return $cols;
	}

	public static function col_out( $col, $id ) {
		if ( 'dlz_hf' !== $col ) {
			return;
		}
		$h = get_post_meta( $id, '_dlz_hide_header', true );
		$f = get_post_meta( $id, '_dlz_hide_footer', true );
		if ( ! $h && ! $f ) {
			echo '<span style="color:#8c8f94">—</span>';
			return;
		}
		echo '<span style="display:inline-flex;gap:4px;flex-wrap:wrap">' . ( $h ? '<span style="padding:1px 7px;border-radius:9px;background:#fdf0ef;color:#b4232a;font-size:11px">بدون هدر</span>' : '' ) . ( $f ? '<span style="padding:1px 7px;border-radius:9px;background:#fdf0ef;color:#b4232a;font-size:11px">بدون فوتر</span>' : '' ) . '</span>';
	}

	/* ------------------------------------------------------------ admin page: one table, every page */

	public static function menu() {
		add_submenu_page( 'dlz-unified', 'هدر و فوتر صفحات', 'هدر و فوتر صفحات', 'manage_options', 'dlz-hide-hf', array( __CLASS__, 'page' ) );
	}

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$pages = get_posts( array( 'post_type' => 'page', 'post_status' => array( 'publish', 'draft', 'private' ), 'posts_per_page' => 500, 'orderby' => 'title', 'order' => 'ASC', 'no_found_rows' => true ) );
		$front = (int) get_option( 'page_on_front' );
		?>
<div class="wrap dlzhf" dir="rtl">
	<h1>هدر، فوتر و عنوان صفحات</h1>
	<p style="max-width:780px;line-height:2">جلوی هر صفحه تیک بزنید تا <b>هدر</b> (نوار بالا، جستجو، هدر قالب و المنتور) یا <b>فوتر</b> (نوار پایین اپ، فوتر قالب و المنتور) در همان صفحه نمایش داده نشود. همین تیک‌ها در صفحه‌ی ویرایش هر برگه (کادر «هدر و فوتر») هم هست.</p>
	<?php if ( isset( $_GET['saved'] ) ) : // phpcs:ignore ?><div class="notice notice-success is-dismissible"><p>ذخیره شد. (اگر افزونه‌ی کش دارید، کش را پاک کنید.)</p></div><?php endif; ?>
	<style>
		.dlzhf-bar{display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin:14px 0}
		.dlzhf-bar input[type=search]{min-width:280px}
		.dlzhf table{max-width:900px;border-radius:10px;overflow:hidden}
		.dlzhf th.c,.dlzhf td.c{width:110px;text-align:center}
		.dlzhf td{vertical-align:middle}
		.dlzhf tr.is-on td{background:#fffaf0}
		.dlzhf .sw{position:relative;display:inline-block;width:44px;height:24px}
		.dlzhf .sw input{position:absolute;opacity:0;width:100%;height:100%;margin:0;cursor:pointer;z-index:1}
		.dlzhf .sw i{position:absolute;inset:0;border-radius:99px;background:#dcdcde;transition:.2s}
		.dlzhf .sw i::after{content:"";position:absolute;top:3px;right:3px;width:18px;height:18px;border-radius:50%;background:#fff;box-shadow:0 1px 3px rgba(0,0,0,.25);transition:.2s}
		.dlzhf .sw input:checked+i{background:#b4232a}
		.dlzhf .sw input:checked+i::after{transform:translateX(-20px)}
		.dlzhf .sw input:focus-visible+i{outline:2px solid #2271b1;outline-offset:2px}
		.dlzhf .meta{color:#8c8f94;font-size:12px}
		.dlzhf-save{position:sticky;bottom:0;padding:12px 0;background:#f0f0f1}
	</style>
	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<input type="hidden" name="action" value="dlz_hide_hf"><?php wp_nonce_field( 'dlz_hide_hf_table' ); ?>
		<div class="dlzhf-bar">
			<input type="search" class="dlzhf-q" placeholder="جستجوی صفحه…">
			<label><input type="checkbox" class="dlzhf-only"> فقط صفحه‌هایی که چیزی مخفی دارند</label>
		</div>
		<table class="widefat striped">
			<thead><tr><th>صفحه</th><th class="c">مخفی کردن هدر</th><th class="c">مخفی کردن فوتر</th><th class="c">مخفی کردن عنوان</th></tr></thead>
			<tbody>
			<?php foreach ( $pages as $p ) : $h = (bool) get_post_meta( $p->ID, '_dlz_hide_header', true ); $f = (bool) get_post_meta( $p->ID, '_dlz_hide_footer', true ); $tt = (bool) get_post_meta( $p->ID, '_dlz_hide_title', true ); ?>
				<tr class="<?php echo $h || $f ? 'is-on' : ''; ?>" data-t="<?php echo esc_attr( mb_strtolower( $p->post_title . ' ' . $p->post_name ) ); ?>">
					<td><input type="hidden" name="ids[]" value="<?php echo (int) $p->ID; ?>"><b><?php echo esc_html( $p->post_title ? $p->post_title : '#' . $p->ID ); ?></b><?php echo $p->ID === $front ? ' <span class="meta">— صفحه‌ی اصلی</span>' : ''; ?><?php echo 'publish' !== $p->post_status ? ' <span class="meta">(' . esc_html( 'draft' === $p->post_status ? 'پیش‌نویس' : 'خصوصی' ) . ')</span>' : ''; ?>
						<div class="meta"><a href="<?php echo esc_url( get_permalink( $p ) ); ?>" target="_blank" rel="noopener">مشاهده</a> · <a href="<?php echo esc_url( get_edit_post_link( $p->ID ) ); ?>">ویرایش</a></div></td>
					<td class="c"><label class="sw" title="مخفی کردن هدر"><input type="checkbox" name="h[<?php echo (int) $p->ID; ?>]" value="1" <?php checked( $h ); ?>><i></i></label></td>
					<td class="c"><label class="sw" title="مخفی کردن فوتر"><input type="checkbox" name="f[<?php echo (int) $p->ID; ?>]" value="1" <?php checked( $f ); ?>><i></i></label></td>
					<td class="c"><label class="sw" title="مخفی کردن عنوان"><input type="checkbox" name="t[<?php echo (int) $p->ID; ?>]" value="1" <?php checked( $tt ); ?>><i></i></label></td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<div class="dlzhf-save"><?php submit_button( 'ذخیره', 'primary', 'submit', false ); ?></div>
	</form>
	<script>
	(function(){var q=document.querySelector('.dlzhf-q'),only=document.querySelector('.dlzhf-only'),rows=[].slice.call(document.querySelectorAll('.dlzhf tbody tr'));
	function f(){var v=q.value.trim().toLowerCase();rows.forEach(function(r){var on=r.querySelector('input:checked');r.style.display=(!v||r.getAttribute('data-t').indexOf(v)>-1)&&(!only.checked||on)?'':'none';});}
	q.addEventListener('input',f);only.addEventListener('change',f);
	rows.forEach(function(r){r.addEventListener('change',function(){r.classList.toggle('is-on',!!r.querySelector('.sw input:checked'));});});})();
	</script>
</div>
		<?php
	}

	public static function save_table() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'دسترسی ندارید.' );
		}
		check_admin_referer( 'dlz_hide_hf_table' );
		$ids = array_map( 'absint', (array) ( $_POST['ids'] ?? array() ) );
		$h   = array_map( 'absint', array_keys( (array) ( $_POST['h'] ?? array() ) ) );
		$f   = array_map( 'absint', array_keys( (array) ( $_POST['f'] ?? array() ) ) );
		$tt  = array_map( 'absint', array_keys( (array) ( $_POST['t'] ?? array() ) ) );
		foreach ( $ids as $id ) {
			if ( ! $id || 'page' !== get_post_type( $id ) ) {
				continue;
			}
			foreach ( array( 'header' => $h, 'footer' => $f, 'title' => $tt ) as $w => $on ) {
				if ( in_array( $id, $on, true ) ) {
					update_post_meta( $id, '_dlz_hide_' . $w, 1 );
				} else {
					delete_post_meta( $id, '_dlz_hide_' . $w );
				}
			}
		}
		wp_safe_redirect( admin_url( 'admin.php?page=dlz-hide-hf&saved=1' ) );
		exit;
	}
}

DLZ_Hide_HF::init();
