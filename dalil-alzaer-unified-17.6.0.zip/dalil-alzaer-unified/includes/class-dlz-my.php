<?php
/**
 * Dalil Al Zaer — «حجوزاتي» and «طلباتي» (bottom bar).
 *
 * حجوزاتي : travel tickets, daily tours / visits, entertainment centres.
 * طلباتي  : taxi VIP, legal services, treatment & health, beauty centres, wedding,
 *           plus supermarket orders and currency exchange requests when the visitor has any.
 *
 * Everything a logged-in visitor books or asks for shows here automatically — by account,
 * and by the verified phone number for things sent before logging in.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DLZ_My {

	const OPT = 'dlz_my_pages';

	private static $assets = false;

	public static function init() {
		add_action( 'init', array( __CLASS__, 'shortcodes' ), 20 );
		add_action( 'init', array( __CLASS__, 'ensure_page' ), 30 );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'maybe_assets' ), 30 );
	}

	public static function shortcodes() {
		add_shortcode( 'dlz_my_bookings', array( __CLASS__, 'bookings_shortcode' ) );
		add_shortcode( 'dlz_my_requests', array( __CLASS__, 'requests_shortcode' ) );
		add_shortcode( 'dlz_unified_orders', array( __CLASS__, 'requests_shortcode' ) ); // the old «طلباتي» page
	}

	/** One «حجوزاتي» page, created once. */
	public static function ensure_page() {
		$o = get_option( self::OPT, array() );
		if ( ! empty( $o['bookings'] ) && 'publish' === get_post_status( (int) $o['bookings'] ) ) {
			return;
		}
		if ( ! function_exists( 'dlz_unified_get_or_create_page' ) ) {
			return;
		}
		$id = dlz_unified_get_or_create_page( 'حجوزاتي', 'حجوزاتي', '[dlz_my_bookings]' );
		if ( $id ) {
			update_option( self::OPT, array( 'bookings' => (int) $id ), false );
		}
	}

	public static function bookings_url() {
		$o = get_option( self::OPT, array() );
		return ! empty( $o['bookings'] ) ? (string) get_permalink( (int) $o['bookings'] ) : home_url( '/' );
	}

	/* ---------------------------------------------------------
	 * Assets
	 * ------------------------------------------------------- */

	public static function maybe_assets() {
		// nothing to load in <head>: the page carries its own look inline (see assets()).
	}

	/** The look + behaviour travel with the markup, so no theme, cache or optimiser can drop them. */
	private static function assets() {
		if ( self::$assets ) {
			return '';
		}
		self::$assets = true;
		if ( ! function_exists( 'dlz_inline_css' ) ) {
			wp_enqueue_style( 'dlz-my', DASE_URL . 'assets/my.css', array(), DASE_VERSION );
			return '';
		}
		wp_enqueue_script( 'dlz-my', DASE_URL . 'assets/my.js', array(), DASE_VERSION, true );
		return dlz_inline_css( 'dlz-my', DASE_PATH . 'assets/my.css' );
	}

	/* ---------------------------------------------------------
	 * Sections
	 * ------------------------------------------------------- */

	/** key => [label, icon, colour, service key for the empty state] */
	private static function cats( $kind ) {
		if ( 'bookings' === $kind ) {
			return array(
				'tickets' => array( 'حجز التذاكر', 'ticket', '#0284C7', 'tickets' ),
				'tours'   => array( 'الجولات والزيارات', 'map', '#0D9488', 'tours' ),
				'ent'     => array( 'مراكز الترفيه', 'palm', '#DB2777', 'entertainment' ),
			);
		}
		return array(
			'legal'    => array( 'الخدمات القانونية', 'scale', '#4F46E5', 'legal' ),
			'health'   => array( 'العلاج والصحة', 'heart', '#DC2626', 'medical' ),
			'taxi'     => array( 'تاكسي VIP', 'car', '#D97706', 'taxi' ),
			'beauty'   => array( 'مراكز التجميل', 'sparkle', '#C026D3', 'medical' ),
			'wedding'  => array( 'حفل الزواج', 'rings', '#B8862B', 'legal' ),
			'market'   => array( 'السوبرماركت', 'basket', '#16A34A', 'supermarket' ),
			'exchange' => array( 'تبديل العملات', 'coins', '#65A30D', 'currency' ),
		);
	}

	/** Always shown tabs (the others only when the visitor has something there). */
	private static function fixed( $kind ) {
		return 'bookings' === $kind ? array( 'tickets', 'tours', 'ent' ) : array( 'legal', 'health', 'taxi', 'beauty', 'wedding' );
	}

	public static function icon( $n ) {
		$p = array(
			'ticket'  => '<path d="M4 7.5A1.5 1.5 0 0 1 5.5 6h13A1.5 1.5 0 0 1 20 7.5V10a2 2 0 0 0 0 4v2.5a1.5 1.5 0 0 1-1.5 1.5h-13A1.5 1.5 0 0 1 4 16.5V14a2 2 0 0 0 0-4z"/><path d="M14.5 6v12" stroke-dasharray="1.6 2"/>',
			'map'     => '<path d="m9 4-5 2v14l5-2 6 2 5-2V4l-5 2z"/><path d="M9 4v14M15 6v14"/>',
			'palm'    => '<path d="M12 21v-9M12 12c-1.5-3-4.5-4-7.5-3 2 .5 3.5 1.7 4.2 3.4M12 12c1.5-3 4.5-4 7.5-3-2 .5-3.5 1.7-4.2 3.4M12 12c-.5-3.4 1.3-6 4.4-7.4-1 1.8-1.5 3.6-1.3 5.6M12 12c.5-3.4-1.3-6-4.4-7.4 1 1.8 1.5 3.6 1.3 5.6M7 21h10"/>',
			'scale'   => '<path d="M12 4v16M7 20h10M5 7h14M5 7l-3 6a3 3 0 0 0 6 0zM19 7l-3 6a3 3 0 0 0 6 0z"/><circle cx="12" cy="4" r="1"/>',
			'heart'   => '<path d="M12 20s-7.5-4.6-7.5-10A4.3 4.3 0 0 1 12 7.4 4.3 4.3 0 0 1 19.5 10c0 5.4-7.5 10-7.5 10z"/><path d="M8 12h2l1-2 2 4 1-2h2"/>',
			'car'     => '<path d="M5 16V11l2-5h10l2 5v5M3.5 16h17M5 11h14"/><circle cx="7.5" cy="16.5" r="1.7"/><circle cx="16.5" cy="16.5" r="1.7"/>',
			'sparkle' => '<path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8z"/><path d="M18.5 15.5l.7 2 2 .7-2 .7-.7 2-.7-2-2-.7 2-.7z"/>',
			'rings'   => '<circle cx="9" cy="14.5" r="5"/><circle cx="15" cy="14.5" r="5"/><path d="M7.5 6l1.5-2.5L10.5 6M13.5 6l1.5-2.5L16.5 6"/>',
			'basket'  => '<path d="M3.5 10h17l-1.6 8.3a2 2 0 0 1-2 1.7H7.1a2 2 0 0 1-2-1.7zM8 10l3-6M16 10l-3-6M9 14v3M15 14v3"/>',
			'coins'   => '<ellipse cx="9" cy="7" rx="5" ry="2.5"/><path d="M4 7v4c0 1.4 2.2 2.5 5 2.5s5-1.1 5-2.5V7"/><path d="M10 15.5c.9.6 2.4 1 4 1 2.8 0 5-1.1 5-2.5v-4c0-1.4-2.2-2.5-5-2.5"/>',
			'all'     => '<rect x="4" y="4" width="7" height="7" rx="1.5"/><rect x="13" y="4" width="7" height="7" rx="1.5"/><rect x="4" y="13" width="7" height="7" rx="1.5"/><rect x="13" y="13" width="7" height="7" rx="1.5"/>',
			'down'    => '<path d="M12 4v11M7 10.5l5 5 5-5M5 20h14"/>',
			'cal'     => '<rect x="4" y="5.5" width="16" height="14.5" rx="2.5"/><path d="M4 10h16M8.5 3.5v4M15.5 3.5v4"/>',
			'user'    => '<circle cx="12" cy="8.2" r="3.9"/><path d="M4.6 20.2c.7-4 3.6-6.3 7.4-6.3s6.7 2.3 7.4 6.3"/>',
			'pin'     => '<path d="M12 21.2s-6.6-6.1-6.6-11.2a6.6 6.6 0 0 1 13.2 0c0 5.1-6.6 11.2-6.6 11.2z"/><circle cx="12" cy="10" r="2.5"/>',
			'hash'    => '<path d="M9 4 7 20M17 4l-2 16M4.5 9h15M3.5 15h15"/>',
			'cart'    => '<path d="M3 4h2.2l2 11h10.6l2-8H6.4"/><circle cx="9" cy="19" r="1.5"/><circle cx="17" cy="19" r="1.5"/>',
			'chev'    => '<path d="m14.5 6-6 6 6 6"/>',
			'list'    => '<rect x="5" y="3.5" width="14" height="17" rx="2.5"/><path d="M9 3.5h6v2.5H9zM8.5 10.5h7M8.5 14h7M8.5 17.5h4"/>',
			'clock'   => '<circle cx="12" cy="12" r="8"/><path d="M12 7.5V12l3 2"/>',
			'login'   => '<path d="M10 4H6.5A2.5 2.5 0 0 0 4 6.5v11A2.5 2.5 0 0 0 6.5 20H10"/><path d="M14 8l4 4-4 4M18 12H9"/>',
		);
		return '<svg class="dmy-i" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . ( isset( $p[ $n ] ) ? $p[ $n ] : '' ) . '</svg>';
	}

	/* ---------------------------------------------------------
	 * Data
	 * ------------------------------------------------------- */

	private static function tail( $phone ) {
		$d = preg_replace( '/\D/', '', strtr( (string) $phone, array( '۰' => '0', '۱' => '1', '۲' => '2', '۳' => '3', '۴' => '4', '۵' => '5', '۶' => '6', '۷' => '7', '۸' => '8', '۹' => '9' ) ) );
		return strlen( $d ) >= 9 ? substr( $d, -10 ) : '';
	}

	/** Booking posts of the visitor: by account or by phone. */
	private static function posts( $type, $phone_key, $uid, $tail ) {
		$mq = array( 'relation' => 'OR', array( 'key' => '_dlz_user_id', 'value' => $uid, 'compare' => '=' ) );
		if ( $tail ) {
			$mq[] = array( 'key' => $phone_key, 'value' => $tail, 'compare' => 'LIKE' );
		}
		$q = new WP_Query( array( 'post_type' => $type, 'post_status' => array( 'publish', 'private', 'pending', 'draft' ), 'posts_per_page' => 60, 'meta_query' => $mq, 'orderby' => 'date', 'order' => 'DESC', 'no_found_rows' => true ) ); // phpcs:ignore
		return $q->posts;
	}

	/** Persian admin statuses → Arabic + tone. */
	private static function status( $s ) {
		$s = trim( (string) $s );
		$map = array(
			'/لغو|ملغ|cancel|رد شد|مرفوض/u'                         => array( 'ملغى', 'no' ),
			'/تحویل|تم التسليم|delivered|انجام شد|مكتمل|done/u'      => array( 'مكتمل', 'ok' ),
			'/تایید|تأیید|مؤكد|confirm|قطعی/u'                       => array( 'مؤكد', 'ok' ),
			'/ارسال شده|تم الشحن|shipped/u'                          => array( 'في الطريق إليك', 'go' ),
			'/آماده|التجهيز|preparing/u'                             => array( 'قيد التجهيز', 'go' ),
			'/read|بررسی|متابعة|review/u'                            => array( 'قيد المتابعة', 'go' ),
		);
		foreach ( $map as $re => $out ) {
			if ( '' !== $s && preg_match( $re, $s ) ) {
				return $out;
			}
		}
		return array( 'قيد المراجعة', 'wait' );
	}

	private static function city( $k ) {
		$labels = function_exists( 'dlz_city_labels' ) ? dlz_city_labels() : array();
		return isset( $labels[ $k ] ) ? $labels[ $k ] : (string) $k;
	}

	private static function dl( $id ) {
		return wp_nonce_url( admin_url( 'admin-post.php?action=dlz_download_booking_ticket&booking_id=' . (int) $id ), 'dlz_download_booking_ticket_' . (int) $id );
	}

	private static function bookings( $uid, $tail ) {
		$rows = array();
		foreach ( self::posts( 'dalil_ticket_booking', '_dalil_booking_phone', $uid, $tail ) as $p ) {
			$trip  = absint( get_post_meta( $p->ID, '_dalil_booking_trip', true ) );
			$from  = $trip ? self::city( get_post_meta( $trip, '_dalil_origin', true ) ) : '';
			$to    = $trip ? self::city( get_post_meta( $trip, '_dalil_destination', true ) ) : '';
			$tr    = $trip ? get_post_meta( $trip, '_dalil_transport', true ) : '';
			$types = array( 'plane' => 'طائرة', 'bus' => 'حافلة', 'train' => 'قطار' );
			$rows[] = array(
				'cat'    => 'tickets',
				'id'     => $p->ID,
				'time'   => get_post_time( 'U', true, $p ),
				'title'  => trim( $from . ( $from && $to ? ' ← ' : '' ) . $to ) ?: 'تذكرة سفر',
				'sub'    => isset( $types[ $tr ] ) ? 'تذكرة ' . $types[ $tr ] : 'تذكرة سفر',
				'meta'   => array_filter( array(
					'cal'  => $trip ? (string) get_post_meta( $trip, '_dalil_time', true ) : '',
					'user' => ( $n = absint( get_post_meta( $p->ID, '_dalil_booking_passengers', true ) ) ) ? $n . ' مسافر' : '',
				) ),
				'code'   => (string) $p->ID,
				'status' => self::status( get_post_meta( $p->ID, '_dalil_booking_status', true ) ),
				'dl'     => self::dl( $p->ID ),
			);
		}
		foreach ( self::posts( 'dlz_tour_booking', '_dlz_booking_phone', $uid, $tail ) as $p ) {
			$n      = (int) get_post_meta( $p->ID, '_dlz_booking_people', true );
			$total  = (float) get_post_meta( $p->ID, '_dlz_booking_total', true );
			$rows[] = array(
				'cat'    => 'tours',
				'id'     => $p->ID,
				'time'   => get_post_time( 'U', true, $p ),
				'title'  => (string) get_post_meta( $p->ID, '_dlz_booking_tour_title', true ) ?: 'جولة يومية',
				'sub'    => self::city( get_post_meta( $p->ID, '_dlz_booking_city', true ) ),
				'meta'   => array_filter( array(
					'cal'  => (string) get_post_meta( $p->ID, '_dlz_booking_day', true ),
					'user' => $n ? $n . ' أشخاص' : '',
					'pin'  => (string) get_post_meta( $p->ID, '_dlz_booking_location', true ),
				) ),
				'price'  => $total ? self::money( $total ) : '',
				'code'   => (string) get_post_meta( $p->ID, '_dlz_booking_code', true ) ?: (string) $p->ID,
				'status' => self::status( get_post_meta( $p->ID, '_dlz_booking_status', true ) ?: 'تأیید' ),
				'dl'     => self::dl( $p->ID ),
			);
		}
		foreach ( self::posts( 'dlz_ent_booking', '_dlz_booking_phone', $uid, $tail ) as $p ) {
			$men    = (int) get_post_meta( $p->ID, '_dlz_booking_men', true );
			$women  = (int) get_post_meta( $p->ID, '_dlz_booking_women', true );
			$rows[] = array(
				'cat'    => 'ent',
				'id'     => $p->ID,
				'time'   => get_post_time( 'U', true, $p ),
				'title'  => (string) get_post_meta( $p->ID, '_dlz_booking_entertainment', true ) ?: 'مركز ترفيهي',
				'sub'    => self::city( get_post_meta( $p->ID, '_dlz_booking_city', true ) ),
				'meta'   => array_filter( array(
					'cal'  => (string) get_post_meta( $p->ID, '_dlz_booking_date', true ),
					'user' => ( $men + $women ) ? trim( ( $men ? $men . ' رجال' : '' ) . ( $men && $women ? ' · ' : '' ) . ( $women ? $women . ' نساء' : '' ) ) : '',
				) ),
				'code'   => (string) $p->ID,
				'status' => self::status( get_post_meta( $p->ID, '_dlz_booking_status', true ) ?: 'تأیید' ),
				'dl'     => self::dl( $p->ID ),
			);
		}
		return $rows;
	}

	/** An amount in dinars shown in the visitor's currency (country of the profile). */
	private static function money( $v ) {
		return class_exists( 'DLZ_Money' ) ? DLZ_Money::fmt( $v ) : number_format( (float) $v ) . ' د.ع';
	}

	private static function money_text( $v ) {
		return class_exists( 'DLZ_Money' ) ? DLZ_Money::text( $v ) : $v;
	}

	private static function requests( $uid, $tail ) {
		$rows = array();
		foreach ( self::posts( 'dlz_taxi_booking', '_dlz_customer_phone', $uid, $tail ) as $p ) {
			$rows[] = array(
				'cat'    => 'taxi',
				'id'     => $p->ID,
				'time'   => get_post_time( 'U', true, $p ),
				'title'  => (string) get_post_meta( $p->ID, '_dlz_taxi_title', true ) ?: 'تاكسي VIP',
				'sub'    => (string) get_post_meta( $p->ID, '_dlz_service', true ),
				'meta'   => array(),
				'price'  => self::money_text( (string) get_post_meta( $p->ID, '_dlz_price', true ) ),
				'code'   => (string) $p->ID,
				'status' => self::status( get_post_meta( $p->ID, '_dlz_status', true ) ),
				'dl'     => self::dl( $p->ID ),
			);
		}
		// legal → «حفل الزواج» for marriage & family, «الخدمات القانونية» for the rest
		if ( class_exists( 'LCR_DB' ) && class_exists( 'LCR_Data' ) ) {
			LCR_DB::maybe_upgrade();
			foreach ( (array) LCR_DB::for_user( $uid, $tail ) as $r ) {
				$rows[] = array(
					'cat'    => 'family' === $r->category_key ? 'wedding' : 'legal',
					'id'     => 'l' . $r->id,
					'time'   => strtotime( $r->created_at ),
					'title'  => LCR_Data::category_label( $r->category_key ) ?: 'استشارة قانونية',
					'sub'    => wp_trim_words( (string) $r->message, 14, '…' ),
					'meta'   => array_filter( array( 'pin' => (string) $r->city ) ),
					'code'   => 'L-' . $r->id,
					'status' => self::status( $r->status ),
				);
			}
		}
		// medical → «مراكز التجميل» for cosmetic departments, «العلاج والصحة» for the rest
		if ( class_exists( 'MCR_DB' ) && class_exists( 'MCR_Data' ) ) {
			MCR_DB::maybe_upgrade();
			$beauty = array( 'rhinoplasty', 'hair_transplant', 'body_contouring', 'eyelid', 'cosmetic_dental', 'facelift', 'lip_filler', 'necklift', 'other_surgery' );
			foreach ( (array) MCR_DB::for_user( $uid, $tail ) as $r ) {
				$rows[] = array(
					'cat'    => in_array( $r->category_key, $beauty, true ) ? 'beauty' : 'health',
					'id'     => 'm' . $r->id,
					'time'   => strtotime( $r->created_at ),
					'title'  => MCR_Data::category_label( $r->category_key ) ?: 'استشارة طبية',
					'sub'    => wp_trim_words( (string) $r->message, 14, '…' ),
					'meta'   => array_filter( array( 'pin' => (string) $r->city ) ),
					'code'   => 'M-' . $r->id,
					'status' => self::status( $r->status ),
				);
			}
		}
		// supermarket orders (by phone)
		global $wpdb;
		if ( $tail && class_exists( 'DLZ_SM' ) && ! empty( DLZ_SM::$tables['orders'] ) ) {
			$t   = DLZ_SM::$tables['orders'];
			$res = $wpdb->get_results( $wpdb->prepare( "SELECT id,order_number,total,status,items,created_at FROM {$t} WHERE phone LIKE %s OR whatsapp LIKE %s ORDER BY id DESC LIMIT 40", '%' . $wpdb->esc_like( $tail ) . '%', '%' . $wpdb->esc_like( $tail ) . '%' ) ); // phpcs:ignore
			foreach ( (array) $res as $r ) {
				$items = json_decode( (string) $r->items, true );
				$n     = 0;
				foreach ( (array) $items as $it ) {
					$n += isset( $it['qty'] ) ? (int) $it['qty'] : 1;
				}
				$rows[] = array(
					'cat'    => 'market',
					'id'     => 's' . $r->id,
					'time'   => strtotime( $r->created_at ),
					'title'  => 'طلب السوبرماركت',
					'sub'    => $n ? $n . ' منتجات' : '',
					'meta'   => array(),
					'price'  => self::money( (float) $r->total ),
					'code'   => (string) $r->order_number,
					'status' => self::status( $r->status ),
				);
			}
		}
		// currency exchange «نأتي إليك»
		$ex = get_option( 'dalil_cr_requests', array() );
		foreach ( is_array( $ex ) ? $ex : array() as $i => $r ) {
			$mine = ( ! empty( $r['user_id'] ) && (int) $r['user_id'] === $uid ) || ( $tail && false !== strpos( preg_replace( '/\D/', '', (string) ( $r['phone'] ?? '' ) ), $tail ) );
			if ( ! $mine ) {
				continue;
			}
			$rows[] = array(
				'cat'    => 'exchange',
				'id'     => 'x' . $i,
				'time'   => strtotime( (string) ( $r['date'] ?? '' ) ),
				'title'  => ( 'sell' === ( $r['mode'] ?? '' ) ? 'بيع ' : 'شراء ' ) . ( $r['currency_name'] ?? '' ),
				'sub'    => (string) ( $r['address'] ?? '' ),
				'meta'   => array(),
				'price'  => number_format( (float) ( $r['amount'] ?? 0 ) ),
				'code'   => 'X-' . ( $i + 1 ),
				'status' => array( 'قيد المراجعة', 'wait' ),
			);
		}
		return $rows;
	}

	/* ---------------------------------------------------------
	 * Render
	 * ------------------------------------------------------- */

	public static function bookings_shortcode() {
		return self::render( 'bookings' );
	}

	public static function requests_shortcode() {
		return self::render( 'requests' );
	}

	private static function service_url( $key ) {
		if ( class_exists( 'DLZ_App_Shell' ) ) {
			foreach ( DLZ_App_Shell::services( true ) as $s ) {
				if ( isset( $s['key'] ) && $s['key'] === $key && ! empty( $s['url'] ) ) {
					return $s['url'];
				}
			}
		}
		return home_url( '/' );
	}

	private static function render( $kind ) {
		$is_b  = 'bookings' === $kind;
		$title = $is_b ? 'حجوزاتي' : 'طلباتي';
		$sub   = $is_b ? 'التذاكر والجولات ومراكز الترفيه في مكان واحد' : 'التاكسي والاستشارات والتجميل وحفل الزواج';
		$cats  = self::cats( $kind );
		ob_start();
		echo self::assets(); // phpcs:ignore
		echo '<div class="dmy" dir="rtl" data-kind="' . esc_attr( $kind ) . '">';

		$rows = array();
		if ( is_user_logged_in() ) {
			$uid  = get_current_user_id();
			$tail = self::tail( get_user_meta( $uid, 'mp_sms_phone', true ) );
			$rows = $is_b ? self::bookings( $uid, $tail ) : self::requests( $uid, $tail );
			usort( $rows, function ( $a, $b ) { return (int) $b['time'] - (int) $a['time']; } );
		}
		$tone = array( 'wait' => 0, 'go' => 0, 'ok' => 0, 'no' => 0 );
		foreach ( $rows as $r ) {
			$tone[ $r['status'][1] ] = ( $tone[ $r['status'][1] ] ?? 0 ) + 1;
		}

		echo '<header class="dmy-head"><span class="dmy-head-ic">' . self::icon( $is_b ? 'ticket' : 'list' ) . '</span><div class="dmy-head-t"><h1>' . esc_html( $title ) . '</h1><p>' . esc_html( $sub ) . '</p></div>'; // phpcs:ignore
		if ( $rows ) {
			echo '<dl class="dmy-stats"><div><dt>الكل</dt><dd>' . count( $rows ) . '</dd></div><div><dt>قيد المراجعة</dt><dd>' . (int) ( $tone['wait'] + $tone['go'] ) . '</dd></div><div><dt>' . ( $is_b ? 'مؤكدة' : 'منجزة' ) . '</dt><dd>' . (int) $tone['ok'] . '</dd></div></dl>';
		}
		echo '</header>';

		// quick links to every section — used by the empty / login states
		$quick = '<div class="dmy-quick">';
		foreach ( $cats as $k => $c ) {
			if ( in_array( $k, self::fixed( $kind ), true ) ) {
				$quick .= '<a href="' . esc_url( self::service_url( $c[3] ) ) . '"><span>' . self::icon( $c[1] ) . '</span><b>' . esc_html( $c[0] ) . '</b></a>';
			}
		}
		$quick .= '</div>';

		if ( ! is_user_logged_in() ) {
			$login = function_exists( 'dlz_profile_url' ) ? dlz_profile_url() : wp_login_url();
			echo '<div class="dmy-empty dmy-login"><span class="dmy-empty-ic">' . self::icon( 'login' ) . '</span><b>سجّل دخولك أولاً</b><p>' . esc_html( $is_b ? 'سجّل الدخول برقم هاتفك لتشاهد جميع حجوزاتك في مكان واحد.' : 'سجّل الدخول برقم هاتفك لتشاهد جميع طلباتك في مكان واحد.' ) . '</p><a class="dmy-btn" href="' . esc_url( $login ) . '">' . self::icon( 'login' ) . '<span>تسجيل الدخول</span></a></div>'; // phpcs:ignore
			echo '<h2 class="dmy-h2">' . esc_html( $is_b ? 'احجز الآن' : 'اطلب الآن' ) . '</h2>' . $quick . '</div>'; // phpcs:ignore
			return ob_get_clean();
		}

		$count = array();
		foreach ( $rows as $r ) {
			$count[ $r['cat'] ] = isset( $count[ $r['cat'] ] ) ? $count[ $r['cat'] ] + 1 : 1;
		}
		$tabs = array();
		foreach ( $cats as $k => $c ) {
			if ( in_array( $k, self::fixed( $kind ), true ) || ! empty( $count[ $k ] ) ) {
				$tabs[ $k ] = $c;
			}
		}

		if ( ! $is_b ) {
			$cart = class_exists( 'DLZ_App_Shell' ) ? DLZ_App_Shell::links()['cart'] : '';
			if ( $cart ) {
				echo '<a class="dmy-cart" href="' . esc_url( $cart ) . '" hidden><span class="dmy-cart-ic">' . self::icon( 'cart' ) . '</span><span class="dmy-cart-t"><b>سلة التسوق</b><small><em class="dmy-cart-n">0</em> منتجات بانتظار إتمام الطلب</small></span><span class="dmy-cart-go">' . self::icon( 'chev' ) . '</span></a>'; // phpcs:ignore
			}
		}

		echo '<nav class="dmy-tabs" role="tablist" aria-label="' . esc_attr( $title ) . '"><button type="button" class="dmy-tab is-on" data-cat="all" role="tab" aria-selected="true">' . self::icon( 'all' ) . '<span>الكل</span><em>' . count( $rows ) . '</em></button>'; // phpcs:ignore
		foreach ( $tabs as $k => $c ) {
			echo '<button type="button" class="dmy-tab" data-cat="' . esc_attr( $k ) . '" role="tab" aria-selected="false">' . self::icon( $c[1] ) . '<span>' . esc_html( $c[0] ) . '</span>' . ( ! empty( $count[ $k ] ) ? '<em>' . (int) $count[ $k ] . '</em>' : '' ) . '</button>'; // phpcs:ignore
		}
		echo '</nav>';

		echo '<div class="dmy-list">';
		foreach ( $rows as $r ) {
			$c  = $cats[ $r['cat'] ];
			$st = $r['status'];
			if ( ! empty( $r['price'] ) ) {
				$r['meta']['coins'] = $r['price'];
			}
			echo '<article class="dmy-card is-' . esc_attr( $st[1] ) . '" data-cat="' . esc_attr( $r['cat'] ) . '">';
			echo '<div class="dmy-card-top"><span class="dmy-badge">' . self::icon( $c[1] ) . '</span><div class="dmy-card-t"><small>' . esc_html( $c[0] ) . '</small><h3>' . esc_html( $r['title'] ) . '</h3>' . ( ! empty( $r['sub'] ) && $r['sub'] !== $r['title'] ? '<p>' . esc_html( $r['sub'] ) . '</p>' : '' ) . '</div><span class="dmy-st"><i></i>' . esc_html( $st[0] ) . '</span></div>'; // phpcs:ignore
			if ( ! empty( $r['meta'] ) ) {
				echo '<ul class="dmy-meta">';
				foreach ( $r['meta'] as $ic => $v ) {
					echo '<li' . ( 'coins' === $ic ? ' class="is-price"' : '' ) . '>' . self::icon( $ic ) . '<span>' . esc_html( $v ) . '</span></li>'; // phpcs:ignore
				}
				echo '</ul>';
			}
			echo '<div class="dmy-card-foot"><span class="dmy-code">' . self::icon( 'hash' ) . '<b dir="ltr">' . esc_html( $r['code'] ) . '</b></span>'; // phpcs:ignore
			echo '<time datetime="' . esc_attr( gmdate( 'c', (int) $r['time'] ) ) . '">' . self::icon( 'clock' ) . '<span dir="ltr">' . esc_html( $r['time'] ? wp_date( 'Y/m/d', (int) $r['time'] ) : '' ) . '</span></time>'; // phpcs:ignore
			if ( ! empty( $r['dl'] ) ) {
				echo '<a class="dmy-dl" href="' . esc_url( $r['dl'] ) . '">' . self::icon( 'down' ) . '<span>' . esc_html( $is_b ? 'التذكرة' : 'الإيصال' ) . '</span></a>'; // phpcs:ignore
			}
			echo '</div></article>';
		}
		echo '</div>';

		// empty states: one for «all» (with quick links), one per tab
		echo '<div class="dmy-empty" data-for="all"' . ( $rows ? ' hidden' : '' ) . '><span class="dmy-empty-ic">' . self::icon( $is_b ? 'ticket' : 'list' ) . '</span><b>' . esc_html( $is_b ? 'لا توجد حجوزات بعد' : 'لا توجد طلبات بعد' ) . '</b><p>' . esc_html( $is_b ? 'كل تذكرة أو جولة أو مركز ترفيه تحجزه سيظهر هنا تلقائياً.' : 'كل طلب تاكسي أو استشارة أو خدمة سيظهر هنا تلقائياً.' ) . '</p>' . $quick . '</div>'; // phpcs:ignore
		foreach ( $tabs as $k => $c ) {
			echo '<div class="dmy-empty is-tab" data-for="' . esc_attr( $k ) . '" hidden><span class="dmy-empty-ic">' . self::icon( $c[1] ) . '</span><b>' . esc_html( 'لا يوجد شيء في «' . $c[0] . '» بعد' ) . '</b><a class="dmy-btn" href="' . esc_url( self::service_url( $c[3] ) ) . '"><span>' . esc_html( $is_b ? 'احجز الآن' : 'اطلب الآن' ) . '</span>' . self::icon( 'chev' ) . '</a></div>'; // phpcs:ignore
		}
		echo '</div>';
		return ob_get_clean();
	}
}

DLZ_My::init();
