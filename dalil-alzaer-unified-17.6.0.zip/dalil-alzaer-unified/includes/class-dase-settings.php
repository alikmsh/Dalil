<?php
/**
 * تنظیمات ظاهر سایت (هدر، لوگو، منو، فوتر)
 * Admin: Persian — Front: Arabic
 */
if (!defined('ABSPATH')) { exit; }

/** Extra keys added on top of dase_defaults() */
function dase_settings_extra_defaults(){
    return array(
        'logo_w_desktop' => 0,   // 0 = use theme CSS default
        'logo_h_desktop' => 0,
        'logo_w_mobile'  => 0,
        'logo_h_mobile'  => 0,
        'logo_alt'       => '',
        'support_label'  => 'الدعم',
        'show_city'      => 1,
        'show_support'   => 1,
        'header_css'     => '',
    );
}

function dase_get_settings(){
    return wp_parse_args(get_option('dase_settings', array()), array_merge(dase_defaults(), dase_settings_extra_defaults()));
}

/* ---------- Register ---------- */
add_action('admin_init', function(){
    register_setting('dase_settings_group', 'dase_settings', array(
        'type' => 'array',
        'sanitize_callback' => 'dase_settings_sanitize',
    ));
});

function dase_settings_sanitize($in){
    // Merge into existing so keys set elsewhere (activation URLs, etc.) are never lost.
    $out = dase_get_settings();
    if (!is_array($in)) return $out;
    // Internal update_option() calls (activation etc.) are not our form: keep their values as-is.
    if (empty($in['_dase_form'])) return array_merge($out, $in);
    unset($in['_dase_form']);

    $checkboxes = array('header','footer','show_city','show_support');
    foreach ($checkboxes as $k) $out[$k] = empty($in[$k]) ? 0 : 1;

    $urls = array('logo','home_url','articles_url','cart_url','orders_url','profile_url',
                  'city_mashhad_url','city_qom_url','city_shiraz_url','city_tehran_url');
    foreach ($urls as $k) if (isset($in[$k])) $out[$k] = esc_url_raw(trim(wp_unslash($in[$k])));

    $texts = array('logo_alt','menu_title','home_text','articles_text','cart_text','orders_text','profile_text',
                   'support_label','city_mashhad','city_qom','city_shiraz','city_tehran');
    foreach ($texts as $k) if (isset($in[$k])) $out[$k] = sanitize_text_field(wp_unslash($in[$k]));

    foreach (array('logo_w_desktop','logo_h_desktop','logo_w_mobile','logo_h_mobile') as $k)
        if (isset($in[$k])) $out[$k] = min(400, absint($in[$k]));

    if (isset($in['city_default']) && in_array($in['city_default'], dlz_city_keys(), true)) $out['city_default'] = $in['city_default'];

    // header_hide_pages / footer_hide_pages: now ticks per page (DLZ_Hide_HF), kept as they were

    if (isset($in['header_css'])) $out['header_css'] = wp_strip_all_tags(wp_unslash($in['header_css']));

    add_settings_error('dase_settings', 'saved', 'تنظیمات ذخیره شد.', 'updated');
    return $out;
}

/* ---------- Media uploader on our page only ---------- */
add_action('admin_enqueue_scripts', function($hook){
    if (strpos((string)$hook, 'dase-settings') === false) return;
    wp_enqueue_media();
});

/* ---------- Page ---------- */
function dase_settings_page(){
    if (!current_user_can('manage_options')) return;
    $s = dase_get_settings();
    $n = 'dase_settings';
    $pages = get_pages(array('sort_column' => 'post_title'));
    $txt = function($key, $label, $hint = '') use ($s, $n){
        echo '<tr><th><label for="dase-'.esc_attr($key).'">'.esc_html($label).'</label></th><td><input type="text" class="regular-text" id="dase-'.esc_attr($key).'" name="'.$n.'['.esc_attr($key).']" value="'.esc_attr($s[$key]).'">'.($hint ? '<p class="description">'.esc_html($hint).'</p>' : '').'</td></tr>';
    };
    $num = function($key) use ($s, $n){
        return '<input type="number" min="0" max="400" step="1" style="width:80px" name="'.$n.'['.esc_attr($key).']" value="'.esc_attr((int)$s[$key]).'"> px';
    };
    $chk = function($key, $label) use ($s, $n){
        echo '<label style="display:block;margin:4px 0"><input type="checkbox" name="'.$n.'['.esc_attr($key).']" value="1" '.checked(!empty($s[$key]), true, false).'> '.esc_html($label).'</label>';
    };
    $pagesel = function($key) use ($s, $n, $pages){
        echo '<select multiple size="6" style="min-width:320px" name="'.$n.'['.esc_attr($key).'][]">';
        foreach ($pages as $p) echo '<option value="'.(int)$p->ID.'" '.selected(in_array((int)$p->ID, (array)$s[$key], true), true, false).'>'.esc_html($p->post_title ?: '#'.$p->ID).'</option>';
        echo '</select><p class="description">برای انتخاب چند صفحه، Ctrl (یا Cmd) را نگه دارید.</p>';
    };
    ?>
    <div class="wrap" dir="rtl">
      <h1>تنظیمات ظاهر سایت</h1>
      <?php settings_errors('dase_settings'); ?>
      <style>
        .dase-adm .form-table th{width:200px}
        .dase-adm h2{border-bottom:1px solid #dcdcde;padding-bottom:8px;margin-top:28px}
        .dase-logo-preview{display:flex;align-items:center;justify-content:center;width:260px;height:110px;border:2px dashed #d7ad35;border-radius:14px;background:#fffdf4;margin-bottom:10px;overflow:hidden}
        .dase-logo-preview img{max-width:90%;max-height:90%;object-fit:contain}
        .dase-logo-preview span{color:#888}
      </style>
      <form method="post" action="options.php" class="dase-adm">
        <?php settings_fields('dase_settings_group'); ?>
        <input type="hidden" name="<?php echo $n; ?>[_dase_form]" value="1">

        <h2>هدر</h2>
        <table class="form-table" role="presentation">
          <tr><th>نمایش</th><td>
            <?php $chk('header','نمایش هدر'); $chk('show_city','نمایش دکمه انتخاب شهر'); $chk('show_support','نمایش دکمه پشتیبانی'); ?>
          </td></tr>
          <tr><th>لوگو</th><td>
            <div class="dase-logo-preview" id="dase-logo-preview"><?php echo $s['logo'] ? '<img src="'.esc_url($s['logo']).'" alt="">' : '<span>لوگویی انتخاب نشده (نام سایت نمایش داده می‌شود)</span>'; ?></div>
            <input type="hidden" id="dase-logo" name="<?php echo $n; ?>[logo]" value="<?php echo esc_attr($s['logo']); ?>">
            <button type="button" class="button button-primary" id="dase-logo-pick">انتخاب / آپلود لوگو</button>
            <button type="button" class="button" id="dase-logo-remove" <?php echo $s['logo'] ? '' : 'style="display:none"'; ?>>حذف لوگو</button>
            <p class="description">بهترین نتیجه: فایل PNG یا SVG با پس‌زمینه شفاف و بدون حاشیه‌ی خالی اضافه.</p>
          </td></tr>
          <?php $txt('logo_alt','متن جایگزین لوگو (alt)','خالی بماند = نام سایت'); ?>
          <tr><th>اندازه لوگو — دسکتاپ</th><td>عرض حداکثر <?php echo $num('logo_w_desktop'); ?> &nbsp; ارتفاع حداکثر <?php echo $num('logo_h_desktop'); ?></td></tr>
          <tr><th>اندازه لوگو — موبایل</th><td>عرض حداکثر <?php echo $num('logo_w_mobile'); ?> &nbsp; ارتفاع حداکثر <?php echo $num('logo_h_mobile'); ?>
            <p class="description">عدد ۰ یعنی اندازه پیش‌فرض قالب. اگر لوگو کوچک یا بریده دیده می‌شود، این مقادیر را بزرگ‌تر کنید.</p></td></tr>
          <?php $txt('support_label','متن دکمه پشتیبانی'); ?>
          <tr><th>مخفی کردن هدر در صفحات</th><td><a class="button" href="<?php echo esc_url(admin_url('admin.php?page=dlz-hide-hf')); ?>">هدر و فوتر صفحات — تیک بزنید</a></td></tr>
        </table>

        <h2>منوی کناری</h2>
        <table class="form-table" role="presentation">
          <?php $txt('menu_title','عنوان منو'); $txt('home_text','متن «خانه»'); $txt('home_url','لینک «خانه»'); $txt('articles_text','متن «مقالات»'); $txt('articles_url','لینک «مقالات»'); ?>
        </table>

        <h2>شهرها</h2>
        <table class="form-table" role="presentation">
          <tr><th>شهر پیش‌فرض</th><td><select name="<?php echo $n; ?>[city_default]">
            <?php foreach (dlz_city_labels() as $k => $lab) echo '<option value="'.esc_attr($k).'" '.selected($s['city_default'], $k, false).'>'.esc_html($lab).'</option>'; ?>
          </select></td></tr>
          <?php $txt('city_mashhad','نام مشهد'); $txt('city_qom','نام قم'); $txt('city_shiraz','نام شیراز'); $txt('city_tehran','نام تهران'); ?>
        </table>

        <h2>فوتر (نوار پایین)</h2>
        <table class="form-table" role="presentation">
          <tr><th>نمایش</th><td><?php $chk('footer','نمایش نوار پایین'); ?></td></tr>
          <?php $txt('cart_text','متن «سبد خرید»'); $txt('cart_url','لینک «سبد خرید»'); $txt('orders_text','متن «سفارش‌ها»'); $txt('orders_url','لینک «سفارش‌ها»'); $txt('profile_text','متن «پروفایل»'); $txt('profile_url','لینک «پروفایل»'); ?>
          <tr><th>مخفی کردن فوتر در صفحات</th><td><a class="button" href="<?php echo esc_url(admin_url('admin.php?page=dlz-hide-hf')); ?>">هدر و فوتر صفحات — تیک بزنید</a></td></tr>
        </table>

        <h2>CSS سفارشی هدر</h2>
        <table class="form-table" role="presentation">
          <tr><th>کد CSS</th><td><textarea name="<?php echo $n; ?>[header_css]" rows="6" class="large-text code" dir="ltr" placeholder=".dase-header-inner{ background:#fff !important; }"><?php echo esc_textarea($s['header_css']); ?></textarea>
          <p class="description">اختیاری؛ برای تغییرات ظاهری ریز. بعد از بقیه استایل‌ها بارگذاری می‌شود.</p></td></tr>
        </table>

        <?php submit_button('ذخیره تنظیمات'); ?>
      </form>
    </div>
    <script>
    jQuery(function($){
      var frame;
      $('#dase-logo-pick').on('click', function(e){
        e.preventDefault();
        if (frame) { frame.open(); return; }
        frame = wp.media({ title: 'انتخاب لوگو', button: { text: 'استفاده به‌عنوان لوگو' }, library: { type: 'image' }, multiple: false });
        frame.on('select', function(){
          var a = frame.state().get('selection').first().toJSON();
          $('#dase-logo').val(a.url);
          $('#dase-logo-preview').html($('<img>').attr('src', a.url));
          $('#dase-logo-remove').show();
        });
        frame.open();
      });
      $('#dase-logo-remove').on('click', function(){
        $('#dase-logo').val('');
        $('#dase-logo-preview').html('<span>لوگویی انتخاب نشده (نام سایت نمایش داده می‌شود)</span>');
        $(this).hide();
      });
    });
    </script>
    <?php
}

/* ---------- Front-end: apply logo size + custom CSS after all other styles ---------- */
add_action('wp_head', function(){
    if (is_admin()) return;
    $s = dase_get_settings();
    $css = '';
    // "html body" prefix gives higher specificity than every existing !important rule in shell-fix.css
    $rule = function($w, $h){
        $r = '';
        if ($w || $h) $r .= 'html body .dase-header .dase-logo{max-width:none!important;min-width:0!important}';
        $img = '';
        if ($w) $img .= 'max-width:'.$w.'px!important;';
        if ($h) $img .= 'max-height:'.$h.'px!important;';
        if ($img) $r .= 'html body .dase-header .dase-logo img{'.$img.'width:auto!important;height:auto!important;object-fit:contain!important}';
        return $r;
    };
    $d = $rule((int)$s['logo_w_desktop'], (int)$s['logo_h_desktop']);
    $m = $rule((int)$s['logo_w_mobile'],  (int)$s['logo_h_mobile']);
    if ($d) $css .= '@media (min-width:768px){'.$d.'}';
    if ($m) $css .= '@media (max-width:767px){'.$m.'}';
    if (empty($s['show_city']))    $css .= 'html body .dase-header .dase-city-trigger{display:none!important}';
    if (empty($s['show_support'])) $css .= 'html body .dase-header .dase-contact-btn{display:none!important}';
    if (!empty($s['header_css']))  $css .= "\n".str_ireplace('</style', '', $s['header_css']);
    if ($css) echo "<style id=\"dase-header-custom\">".$css."</style>\n";
}, 100);
