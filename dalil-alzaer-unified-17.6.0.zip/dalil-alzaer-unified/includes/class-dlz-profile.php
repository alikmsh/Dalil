<?php
/**
 * Dalil Al Zaer — «الملف الشخصي» (account page opened from «المزيد» → «حسابي»).
 *
 * Replaces the logged-in part of [mp_user_panel] / [mp_sms_login] with the app design:
 * avatar + name, then full name, passport (optional), Iranian phone (the verified login number),
 * international phone, gender, country and travelling companions.
 * Keeps the old meta keys (first_name, last_name, mp_gender, mp_avatar, mp_profile_complete),
 * so bookings and every other module keep working.
 *
 * Front: Arabic — follows the site font.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DLZ_Profile {

	const NONCE = 'dlz_profile';

	private static $assets = false;

	public static function init() {
		add_action( 'wp_ajax_dlz_profile_save', array( __CLASS__, 'save' ) );
		add_action( 'wp_ajax_dlz_set_currency', array( __CLASS__, 'set_currency' ) );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'maybe_assets' ), 30 );
	}

	/* ---------------------------------------------------------
	 * Data
	 * ------------------------------------------------------- */

	/** Kept for older code: the short Arabic names of the ten countries. */
	public static function countries() {
		return wp_list_pluck( DLZ_Countries::all(), 'short' );
	}

	/** 0–50 travelling companions. Old profiles saved a list of relatives: count them. */
	private static function companions_count( $v ) {
		if ( is_array( $v ) ) {
			return count( $v );
		}
		$v = trim( (string) $v );
		return '' === $v ? '' : max( 0, min( 50, (int) $v ) );
	}

	/** «+964 7701234567» → [ 'iq', '7701234567' ] */
	private static function split_intl( $full, $fallback ) {
		$full = preg_replace( '/[^0-9+]/', '', self::latin( (string) $full ) );
		if ( '' === $full ) {
			return array( $fallback, '' );
		}
		if ( 0 === strpos( $full, '00' ) ) {
			$full = '+' . substr( $full, 2 );
		}
		if ( 0 === strpos( $full, '+' ) ) {
			foreach ( DLZ_Countries::all() as $k => $c ) {
				if ( 0 === strpos( $full, $c['dial'] ) ) {
					return array( $k, substr( $full, strlen( $c['dial'] ) ) );
				}
			}
		}
		return array( $fallback, ltrim( $full, '+' ) );
	}

	/** Persian / Arabic-Indic digits → 0-9 */
	public static function latin( $s ) {
		return strtr( (string) $s, array(
			'۰' => '0', '۱' => '1', '۲' => '2', '۳' => '3', '۴' => '4', '۵' => '5', '۶' => '6', '۷' => '7', '۸' => '8', '۹' => '9',
			'٠' => '0', '١' => '1', '٢' => '2', '٣' => '3', '٤' => '4', '٥' => '5', '٦' => '6', '٧' => '7', '٨' => '8', '٩' => '9',
		) );
	}

	private static function data( $uid ) {
		$full = trim( (string) get_user_meta( $uid, 'mp_full_name', true ) );
		if ( '' === $full ) {
			$full = trim( get_user_meta( $uid, 'first_name', true ) . ' ' . get_user_meta( $uid, 'last_name', true ) );
		}
		$country = DLZ_Countries::of_user( $uid );
		$dial    = (string) get_user_meta( $uid, 'mp_intl_dial', true );
		list( $ik, $inum ) = self::split_intl( get_user_meta( $uid, 'mp_intl_phone', true ), $dial && DLZ_Countries::get( $dial ) ? $dial : ( $country ? $country : 'iq' ) );
		return array(
			'name'       => $full,
			'passport'   => (string) get_user_meta( $uid, 'mp_passport', true ),
			'phone'      => self::latin( (string) get_user_meta( $uid, 'mp_sms_phone', true ) ),
			'intl_key'   => $ik,
			'intl'       => $inum,
			'intl_set'   => '' !== $dial,
			'gender'     => (string) get_user_meta( $uid, 'mp_gender', true ),
			'country'    => $country,
			'companions' => self::companions_count( get_user_meta( $uid, 'mp_companions', true ) ),
			'avatar'     => (string) get_user_meta( $uid, 'mp_avatar', true ),
			'complete'   => (bool) get_user_meta( $uid, 'mp_profile_complete', true ),
		);
	}

	/** 09123456789 → +98 912 345 6789 */
	private static function pretty_ir( $p ) {
		$d = preg_replace( '/\D/', '', self::latin( (string) $p ) );
		if ( preg_match( '/^(?:0098|98|0)?(9\d{2})(\d{3})(\d{4})$/', $d, $m ) ) {
			return '+98 ' . $m[1] . ' ' . $m[2] . ' ' . $m[3];
		}
		if ( 0 === strpos( (string) $p, '+' ) ) {
			foreach ( DLZ_Countries::all() as $c ) {
				if ( 0 === strpos( $p, $c['dial'] ) ) {
					$n = substr( $p, strlen( $c['dial'] ) );
					return $c['dial'] . ' ' . ( class_exists( 'MP_SMS_User_Panel' ) ? MP_SMS_User_Panel::group( $n ) : $n );
				}
			}
		}
		return (string) $p;
	}

	/** True on the «الملف الشخصي» page (the app header is hidden there). */
	public static function is_page() {
		if ( ! is_user_logged_in() || ! is_singular() ) {
			return false;
		}
		if ( isset( $_GET['dlz_view'] ) && 'favorites' === $_GET['dlz_view'] ) { // phpcs:ignore
			return false; // «المفضلة» is a normal app page (app header + bottom bar)
		}
		$post = get_queried_object();
		if ( ! $post || ! isset( $post->post_content ) ) {
			return false;
		}
		if ( has_shortcode( $post->post_content, 'mp_user_panel' ) || has_shortcode( $post->post_content, 'mp_sms_login' ) ) {
			return true;
		}
		return function_exists( 'dlz_profile_url' ) && untrailingslashit( (string) get_permalink( $post ) ) === untrailingslashit( dlz_profile_url() );
	}

	/* ---------------------------------------------------------
	 * Assets
	 * ------------------------------------------------------- */

	public static function maybe_assets() {
		if ( self::is_page() ) {
			self::assets();
		}
	}

	private static function assets() {
		if ( self::$assets ) {
			return;
		}
		self::$assets = true;
		$ver          = defined( 'DASE_VERSION' ) ? DASE_VERSION : '15';
		DLZ_Countries::enqueue_style();
		wp_enqueue_style( 'dlz-profile', DASE_URL . 'assets/profile.css', array( 'dlz-flags' ), $ver );
		wp_enqueue_script( 'dlz-profile', DASE_URL . 'assets/profile.js', array(), $ver, true );
		wp_localize_script(
			'dlz-profile',
			'DLZProfile',
			array(
				'ajax'      => admin_url( 'admin-ajax.php' ),
				'nonce'     => wp_create_nonce( self::NONCE ),
				'mpNonce'   => wp_create_nonce( 'mp_sms_login_nonce' ),
				'countries' => DLZ_Countries::js(),
				'curMap'    => class_exists( 'DLZ_Money' ) ? DLZ_Money::country_map() : array(),
				'curNonce'  => wp_create_nonce( 'dlz_currency' ),
				'i18n'      => array(
					'saving'   => 'جارٍ الحفظ…',
					'saved'    => 'تم حفظ التغييرات بنجاح',
					'savedNew' => 'تم حفظ معلوماتك — يمكنك الآن الحجز',
					'failed'   => 'تعذّر الحفظ، حاول مرة أخرى',
					'name'     => 'يرجى إدخال الاسم الكامل',
					'gender'   => 'يرجى اختيار الجنس',
					'country'  => 'يرجى اختيار الدولة',
					'pickC'    => 'اختر الدولة',
					'photo'    => 'جارٍ رفع الصورة…',
					'photoOk'  => 'تم تحديث الصورة',
					'curOk'    => 'تم تغيير العملة — الأسعار تظهر الآن بـ',
				),
			)
		);
	}

	/* ---------------------------------------------------------
	 * Icons (gold line icons)
	 * ------------------------------------------------------- */

	public static function icon( $n ) {
		$p = array(
			'user'     => '<circle cx="12" cy="8.2" r="3.9"/><path d="M4.6 20.2c.7-4 3.6-6.3 7.4-6.3s6.7 2.3 7.4 6.3"/>',
			'passport' => '<rect x="5" y="2.8" width="14" height="18.4" rx="2.2"/><circle cx="12" cy="10.4" r="3.4"/><path d="M8.6 10.4h6.8M12 7c1 .9 1.5 2.1 1.5 3.4S13 12.9 12 13.8M12 7c-1 .9-1.5 2.1-1.5 3.4s.5 2.5 1.5 3.4M9 17.4h6"/>',
			'phone'    => '<path d="M5.6 3.6h3.1l1.6 4.1-2.1 1.3a10.4 10.4 0 0 0 5.2 5.2l1.3-2.1 4.1 1.6v3.1a1.9 1.9 0 0 1-1.9 1.9A14.6 14.6 0 0 1 3.7 5.5a1.9 1.9 0 0 1 1.9-1.9z"/>',
			'phoneg'   => '<path d="M4.6 5.6h2.8l1.4 3.6-1.9 1.2a9.3 9.3 0 0 0 4.6 4.6l1.2-1.9 3.6 1.4v2.8a1.7 1.7 0 0 1-1.7 1.7A13 13 0 0 1 2.9 7.3a1.7 1.7 0 0 1 1.7-1.7z"/><circle cx="17.6" cy="6.6" r="3.9"/><path d="M13.7 6.6h7.8M17.6 2.7c.9.9 1.3 2.4 1.3 3.9s-.4 3-1.3 3.9c-.9-.9-1.3-2.4-1.3-3.9s.4-3 1.3-3.9z"/>',
			'pin'      => '<path d="M12 21.2s-6.6-6.1-6.6-11.2a6.6 6.6 0 0 1 13.2 0c0 5.1-6.6 11.2-6.6 11.2z"/><circle cx="12" cy="10" r="2.5"/>',
			'users'    => '<circle cx="9" cy="8.4" r="3.4"/><path d="M2.9 19.6c.5-3.6 2.9-5.6 6.1-5.6s5.6 2 6.1 5.6"/><circle cx="16.8" cy="7.6" r="2.7"/><path d="M15.6 12.8c2.9-.4 5.1 1.4 5.6 4.6"/>',
			'down'     => '<path d="m6.5 9.5 5.5 5.5 5.5-5.5"/>',
			'save'     => '<path d="M5 3.5h11.2l3.3 3.3V19a1.5 1.5 0 0 1-1.5 1.5H6A1.5 1.5 0 0 1 4.5 19V5A1.5 1.5 0 0 1 6 3.5z"/><path d="M8 3.5v5h7v-5M7.5 20.5v-6.2h9v6.2"/>',
			'camera'   => '<path d="M4 8.2a2 2 0 0 1 2-2h1.8l1.4-2h5.6l1.4 2H18a2 2 0 0 1 2 2V17a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2z"/><circle cx="12" cy="12.4" r="3.4"/>',
			'back'     => '<path d="M10 5.5 3.5 12l6.5 6.5M4 12h16.5"/>',
			'check'    => '<path d="m5 12.5 4.3 4.3L19 7"/>',
			'logout'   => '<path d="M14 4h3.5A2.5 2.5 0 0 1 20 6.5v11a2.5 2.5 0 0 1-2.5 2.5H14"/><path d="M10 8l-4 4 4 4M6 12h9"/>',
			'info'     => '<circle cx="12" cy="12" r="8.5"/><path d="M12 11v5.5"/><circle cx="12" cy="7.8" r=".6"/>',
			'chev'     => '<path d="m14.5 6-6 6 6 6"/>',
			'coins'    => '<ellipse cx="9" cy="7.5" rx="5.5" ry="2.6"/><path d="M3.5 7.5v4c0 1.4 2.5 2.6 5.5 2.6s5.5-1.2 5.5-2.6v-4"/><path d="M9.5 16.6c.9 1.2 3 2 5.5 2 3 0 5.5-1.2 5.5-2.6v-4c0-1.4-2.5-2.6-5.5-2.6"/>',
		);
		return '<svg class="dpf-i" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . ( isset( $p[ $n ] ) ? $p[ $n ] : '' ) . '</svg>';
	}

	private static function default_avatar() {
		return '<svg class="dpf-av-def" viewBox="0 0 120 120" aria-hidden="true"><defs><linearGradient id="dpfAvBg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#E9F1EC"/><stop offset="1" stop-color="#CFE0D6"/></linearGradient><linearGradient id="dpfAvFg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#7FA592"/><stop offset="1" stop-color="#4E7D66"/></linearGradient></defs>'
			. '<rect width="120" height="120" fill="url(#dpfAvBg)"/><circle cx="60" cy="47" r="21" fill="url(#dpfAvFg)"/><path d="M18 120c3-24 20-38 42-38s39 14 42 38z" fill="url(#dpfAvFg)"/></svg>';
	}

	/* ---------------------------------------------------------
	 * Render
	 * ------------------------------------------------------- */

	public static function render() {
		$uid = get_current_user_id();
		if ( ! $uid ) {
			return '';
		}
		$late = ! self::$assets;
		self::assets();
		$d = self::data( $uid );
		ob_start();
		if ( $late ) {
			// Elementor / page builders: print the stylesheets right here so the page never flashes unstyled.
			$v = defined( 'DASE_VERSION' ) ? DASE_VERSION : '15';
			if ( ! wp_style_is( 'dlz-flags', 'done' ) ) {
				echo '<link rel="stylesheet" id="dlz-flags-inline-css" href="' . esc_url( DASE_URL . 'assets/flags.css?ver=' . $v ) . '">'; // phpcs:ignore
				wp_dequeue_style( 'dlz-flags' );
			}
			if ( ! wp_style_is( 'dlz-profile', 'done' ) ) {
				echo '<link rel="stylesheet" id="dlz-profile-inline-css" href="' . esc_url( DASE_URL . 'assets/profile.css?ver=' . $v ) . '">'; // phpcs:ignore
				wp_dequeue_style( 'dlz-profile' );
			}
		}
		$name  = $d['name'] ? $d['name'] : 'مستخدم التطبيق';
		$ctry  = $d['country'] ? DLZ_Countries::get( $d['country'] ) : null;
		$ik    = DLZ_Countries::get( $d['intl_key'] );
		$field = function ( $key, $label, $icon, $req, $control, $cls = '' ) {
			echo '<div class="dpf-f ' . esc_attr( $cls ) . '" data-f="' . esc_attr( $key ) . '"><label class="dpf-lab" for="dpf-' . esc_attr( $key ) . '">' . esc_html( $label ) . ( true === $req ? ' <em>*</em>' : ( false === $req ? ' <small>(اختياري)</small>' : '' ) ) . '</label>'
				. '<div class="dpf-box"><span class="dpf-ic">' . self::icon( $icon ) . '</span>' . $control . '</div><p class="dpf-err" hidden></p></div>'; // phpcs:ignore
		};
		echo DLZ_Countries::defs(); // phpcs:ignore
		?>
<div class="dpf" dir="rtl">
	<div class="dpf-top">
		<span class="dpf-top-sp" aria-hidden="true"></span>
		<h1 class="dpf-title"><span>الملف الشخصي</span><span class="dpf-title-flag"><?php echo $ctry ? DLZ_Countries::flag( $ctry['key'], true, 'dpf-tflag' ) : ''; // phpcs:ignore ?></span></h1>
		<button type="button" class="dpf-back" aria-label="رجوع"><?php echo self::icon( 'back' ); // phpcs:ignore ?></button>
	</div>

	<div class="dpf-hero">
		<div class="dpf-av">
			<span class="dpf-av-ring"><span class="dpf-av-in"><?php echo $d['avatar'] ? '<img src="' . esc_url( $d['avatar'] ) . '" alt="">' : self::default_avatar(); // phpcs:ignore ?></span></span>
			<button type="button" class="dpf-cam" aria-label="تغيير الصورة"><?php echo self::icon( 'camera' ); // phpcs:ignore ?></button>
			<input type="file" class="dpf-file" accept="image/jpeg,image/png,image/webp" hidden>
		</div>
		<div class="dpf-who">
			<h2 class="dpf-name"><?php echo esc_html( $name ); ?></h2>
			<div class="dpf-role"><span>زائر كريم</span><i></i></div>
		</div>
	</div>

	<?php if ( class_exists( 'DBD_Owner' ) && DBD_Owner::shops( $uid ) && DBD_Owner::url() ) : ?>
	<a class="dpf-shop" href="<?php echo esc_url( DBD_Owner::url() ); ?>"><span class="dpf-shop-i"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3.5 9.5 5 4.5h14l1.5 5"/><path d="M3.5 9.5a2.8 2.8 0 0 0 5.6 0 2.9 2.9 0 0 0 5.8 0 2.8 2.8 0 0 0 5.6 0"/><path d="M5 12.2V20h14v-7.8M10 20v-4.5h4V20"/></svg></span><span class="dpf-shop-t"><b>لوحة متجري</b><small>أضف منتجاتك وأسعارك وصور متجرك</small></span><i aria-hidden="true">‹</i></a>
	<?php endif; ?>

	<?php if ( ! $d['complete'] ) : ?>
	<div class="dpf-note"><?php echo self::icon( 'info' ); // phpcs:ignore ?><span>أكمل معلوماتك الأساسية لتفعيل الحجز والطلبات.</span></div>
	<?php endif; ?>

	<form class="dpf-form" novalidate data-complete="<?php echo $d['complete'] ? '1' : '0'; ?>">
		<?php
		$field( 'name', 'الاسم الكامل', 'user', true, '<input id="dpf-name" name="name" type="text" autocomplete="name" value="' . esc_attr( $d['name'] ) . '" placeholder="الاسم الكامل كما في جواز السفر">' );

		$cv = '<input type="hidden" name="country" value="' . esc_attr( $d['country'] ) . '"><button type="button" id="dpf-country" class="dpf-pick" aria-haspopup="dialog">'
			. '<span class="dpf-pick-flag">' . ( $ctry ? DLZ_Countries::flag( $ctry['key'], true, 'dpf-fflag' ) : '' ) . '</span>'
			. '<span class="dpf-pick-t">' . ( $ctry ? esc_html( $ctry['name'] ) : '<span class="dpf-ph">اختر الدولة</span>' ) . '</span></button><span class="dpf-dd">' . self::icon( 'down' ) . '</span>';
		$field( 'country', 'الدولة', 'pin', true, $cv );

		$field( 'passport', 'رقم جواز السفر', 'passport', false, '<input id="dpf-passport" name="passport" type="text" dir="ltr" autocapitalize="characters" autocomplete="off" spellcheck="false" maxlength="20" value="' . esc_attr( $d['passport'] ) . '">' );
		$field( 'phone', 0 === strpos( (string) $d['phone'], '+' ) ? 'رقم الهاتف الموثّق (واتساب)' : 'رقم الهاتف النشط داخل ايران', 'phone', null, '<input id="dpf-phone" type="tel" dir="ltr" value="' . esc_attr( self::pretty_ir( $d['phone'] ) ) . '" readonly tabindex="-1">' . ( $d['phone'] ? '<span class="dpf-ok" title="رقم موثّق">' . self::icon( 'check' ) . '</span>' : '' ) );

		$pre = '<input type="hidden" name="intl_key" value="' . esc_attr( $d['intl_key'] ) . '" data-set="' . ( $d['intl_set'] ? '1' : '0' ) . '">'
			. '<button type="button" class="dpf-pre" aria-haspopup="dialog" aria-label="رمز الدولة"><span class="dpf-pre-flag">' . DLZ_Countries::flag( $d['intl_key'], false, 'dpf-sflag' ) . '</span><b dir="ltr">' . esc_html( $ik ? $ik['dial'] : '' ) . '</b>' . self::icon( 'down' ) . '</button>';
		$field( 'intl', 'رقم الهاتف الخارجي/الدولي', 'phoneg', false, '<input id="dpf-intl" name="intl" type="tel" dir="ltr" inputmode="numeric" autocomplete="tel-national" maxlength="15" value="' . esc_attr( $d['intl'] ) . '">' . $pre, 'dpf-f-intl' );

		$g = '<select id="dpf-gender" name="gender"><option value=""' . ( '' === $d['gender'] ? ' selected' : '' ) . ' disabled hidden>اختر</option>'
			. '<option value="male"' . selected( $d['gender'], 'male', false ) . '>ذكر</option><option value="female"' . selected( $d['gender'], 'female', false ) . '>أنثى</option></select><span class="dpf-dd">' . self::icon( 'down' ) . '</span>';
		$field( 'gender', 'الجنس', 'user', true, $g );

		$field( 'companions', 'عدد المسافرين المرافقين', 'users', false, '<input id="dpf-companions" name="companions" type="text" dir="ltr" inputmode="numeric" pattern="[0-9]*" maxlength="2" autocomplete="off" value="' . esc_attr( (string) $d['companions'] ) . '">', 'dpf-f-num' );
		// «العملة المفضلة»: every price of the app is shown in it (default US dollar; no toman)
		if ( class_exists( 'DLZ_Money' ) ) {
			$cur   = DLZ_Money::code();
			$names = DLZ_Money::names();
			list( $first, $rest ) = DLZ_Money::choices( $d['country'] );
			$row   = function ( $c ) use ( $cur, $names ) {
				return '<button type="button" class="dpf-cur-o' . ( $c === $cur ? ' is-on' : '' ) . '" data-c="' . esc_attr( $c ) . '" role="option" aria-selected="' . ( $c === $cur ? 'true' : 'false' ) . '"><span class="dpf-cur-s">' . esc_html( DLZ_Money::sym( $c ) ) . '</span><span class="dpf-cur-n">' . esc_html( $names[ $c ] ) . ' <small dir="ltr">' . esc_html( $c ) . '</small></span><span class="dpf-cur-ok">' . self::icon( 'check' ) . '</span></button>';
			};
			$cb = '<input type="hidden" name="currency" value="' . esc_attr( $cur ) . '"><button type="button" id="dpf-currency" class="dpf-pick dpf-cur-btn" aria-haspopup="listbox" aria-expanded="false"><span class="dpf-cur-s">' . esc_html( DLZ_Money::sym( $cur ) ) . '</span><span class="dpf-pick-t">' . esc_html( $names[ $cur ] ) . '</span></button><span class="dpf-dd">' . self::icon( 'down' ) . '</span>';
			$field( 'currency', 'العملة المفضلة', 'coins', null, $cb, 'dpf-f-cur' );
			echo '<div class="dpf-cur-pop" role="listbox" aria-label="العملة المفضلة" hidden><div class="dpf-cur-main">';
			foreach ( $first as $c ) {
				echo $row( $c ); // phpcs:ignore
			}
			echo '</div><button type="button" class="dpf-cur-more">عملات أخرى ' . self::icon( 'down' ) . '</button><div class="dpf-cur-rest" hidden>'; // phpcs:ignore
			foreach ( $rest as $c ) {
				echo $row( $c ); // phpcs:ignore
			}
			echo '</div></div>';
		}
		?>
		<button type="submit" class="dpf-save"><?php echo self::icon( 'save' ); // phpcs:ignore ?><span>حفظ التغييرات</span></button>
		<a class="dpf-logout" href="<?php echo esc_url( wp_logout_url( home_url( '/' ) ) ); ?>"><?php echo self::icon( 'logout' ); // phpcs:ignore ?>تسجيل الخروج</a>
	</form>

	<div class="dpf-sheet dpf-cs" hidden>
		<div class="dpf-sheet-bd"></div>
		<div class="dpf-sheet-box dpf-cs-box" role="dialog" aria-modal="true" aria-labelledby="dpf-cs-t">
			<span class="dpf-grip" aria-hidden="true"></span>
			<div class="dpf-cs-head">
				<span class="dpf-cs-orn" aria-hidden="true"><i></i><b></b><i></i></span>
				<h3 id="dpf-cs-t">من أيّ بلدٍ تشرّفنا بزيارتك؟</h3>
				<p>أهلاً وسهلاً بزوّار الإمام الرضا عليه السلام من بلاد المحبّة والولاء</p>
			</div>
			<div class="dpf-cs-list">
				<?php foreach ( DLZ_Countries::all() as $k => $c ) : ?>
				<button type="button" class="dpf-cc<?php echo $k === $d['country'] ? ' is-on' : ''; ?>" data-key="<?php echo esc_attr( $k ); ?>" aria-pressed="<?php echo $k === $d['country'] ? 'true' : 'false'; ?>">
					<span class="dpf-cc-ph" style="background-image:url('<?php echo esc_url( $c['img'] ); ?>')" aria-hidden="true"></span>
					<span class="dpf-cc-orn" aria-hidden="true"></span>
					<span class="dpf-cc-flag"><?php echo DLZ_Countries::flag( $k, true, 'dpf-cflag' ); // phpcs:ignore ?></span>
					<span class="dpf-cc-t"><b><?php echo esc_html( $c['name'] ); ?></b><small>(<?php echo esc_html( $c['tag'] ); ?>)</small></span>
					<span class="dpf-cc-go" aria-hidden="true"><?php echo self::icon( 'chev' ); // phpcs:ignore ?><?php echo self::icon( 'check' ); // phpcs:ignore ?></span>
				</button>
				<?php endforeach; ?>
			</div>
		</div>
	</div>

	<div class="dpf-sheet dpf-ps" hidden>
		<div class="dpf-sheet-bd"></div>
		<div class="dpf-sheet-box" role="dialog" aria-modal="true" aria-labelledby="dpf-ps-t">
			<span class="dpf-grip" aria-hidden="true"></span>
			<h3 id="dpf-ps-t">رمز الدولة</h3>
			<p>اختر رمز الاتصال الدولي لرقمك</p>
			<div class="dpf-ps-list">
				<?php foreach ( DLZ_Countries::all() as $k => $c ) : ?>
				<button type="button" class="dpf-pc<?php echo $k === $d['intl_key'] ? ' is-on' : ''; ?>" data-key="<?php echo esc_attr( $k ); ?>">
					<?php echo DLZ_Countries::flag( $k, false, 'dpf-pflag' ); // phpcs:ignore ?>
					<span class="dpf-pc-n"><?php echo esc_html( $c['short'] ); ?></span>
					<b dir="ltr"><?php echo esc_html( $c['dial'] ); ?></b>
					<span class="dpf-pc-ok"><?php echo self::icon( 'check' ); // phpcs:ignore ?></span>
				</button>
				<?php endforeach; ?>
			</div>
		</div>
	</div>
	<div class="dpf-toast" role="status" aria-live="polite"></div>
</div>
		<?php
		return ob_get_clean();
	}

	/* ---------------------------------------------------------
	 * Save
	 * ------------------------------------------------------- */

	/** «العملة المفضلة» is saved the moment it is picked. */
	public static function set_currency() {
		check_ajax_referer( 'dlz_currency', 'nonce' );
		$uid = get_current_user_id();
		$c   = strtoupper( sanitize_key( isset( $_POST['currency'] ) ? wp_unslash( $_POST['currency'] ) : '' ) ); // phpcs:ignore
		if ( ! $uid || ! class_exists( 'DLZ_Money' ) || ! isset( DLZ_Money::names()[ $c ] ) ) {
			wp_send_json_error( array( 'message' => 'عملة غير صالحة' ), 400 );
		}
		update_user_meta( $uid, 'dlz_currency', $c );
		wp_send_json_success( array( 'currency' => $c, 'name' => DLZ_Money::names()[ $c ] ) );
	}

	public static function save() {
		check_ajax_referer( self::NONCE, 'nonce' );
		$uid = get_current_user_id();
		if ( ! $uid ) {
			wp_send_json_error( array( 'message' => 'يرجى تسجيل الدخول أولاً.' ), 401 );
		}
		$in   = wp_unslash( $_POST ); // phpcs:ignore
		$name = mb_substr( trim( preg_replace( '/\s+/u', ' ', sanitize_text_field( isset( $in['name'] ) ? $in['name'] : '' ) ) ), 0, 80 );
		$gend = sanitize_key( isset( $in['gender'] ) ? $in['gender'] : '' );
		$ctry = sanitize_key( isset( $in['country'] ) ? $in['country'] : '' );
		$errs = array();
		if ( ( function_exists( 'mb_strlen' ) ? mb_strlen( $name ) : strlen( $name ) ) < 3 ) {
			$errs['name'] = 'يرجى إدخال الاسم الكامل';
		}
		if ( ! in_array( $gend, array( 'male', 'female' ), true ) ) {
			$errs['gender'] = 'يرجى اختيار الجنس';
		}
		$c = DLZ_Countries::get( $ctry );
		if ( ! $c ) {
			$errs['country'] = 'يرجى اختيار الدولة';
		}
		if ( $errs ) {
			wp_send_json_error( array( 'fields' => $errs ), 400 );
		}
		$pass = substr( strtoupper( preg_replace( '/[^A-Za-z0-9]/', '', self::latin( isset( $in['passport'] ) ? $in['passport'] : '' ) ) ), 0, 20 );
		$ik   = sanitize_key( isset( $in['intl_key'] ) ? $in['intl_key'] : '' );
		$ik   = DLZ_Countries::get( $ik ) ? $ik : $ctry;
		$num  = ltrim( preg_replace( '/\D/', '', self::latin( isset( $in['intl'] ) ? $in['intl'] : '' ) ), '0' );
		$intl = '' !== $num ? DLZ_Countries::get( $ik )['dial'] . ' ' . substr( $num, 0, 14 ) : '';
		$comp = trim( preg_replace( '/\D/', '', self::latin( isset( $in['companions'] ) ? $in['companions'] : '' ) ) );
		$comp = '' === $comp ? '' : min( 50, (int) $comp );

		$parts = preg_split( '/\s+/u', $name );
		$first = array_shift( $parts );
		$last  = implode( ' ', $parts );

		$was = (bool) get_user_meta( $uid, 'mp_profile_complete', true );
		update_user_meta( $uid, 'mp_full_name', $name );
		update_user_meta( $uid, 'first_name', $first );
		update_user_meta( $uid, 'last_name', $last );
		update_user_meta( $uid, 'mp_gender', $gend );
		update_user_meta( $uid, 'mp_country_code', $ctry );
		update_user_meta( $uid, 'mp_country', $c['short'] );
		update_user_meta( $uid, 'mp_passport', substr( $pass, 0, 20 ) );
		update_user_meta( $uid, 'mp_intl_dial', $ik );
		update_user_meta( $uid, 'mp_intl_phone', $intl );
		update_user_meta( $uid, 'mp_companions', $comp );
		$cur = strtoupper( sanitize_key( isset( $in['currency'] ) ? $in['currency'] : '' ) );
		if ( class_exists( 'DLZ_Money' ) && isset( DLZ_Money::names()[ $cur ] ) ) {
			update_user_meta( $uid, 'dlz_currency', $cur );
		}
		update_user_meta( $uid, 'mp_profile_complete', 1 );
		wp_update_user( array( 'ID' => $uid, 'display_name' => $name ) );

		wp_send_json_success( array( 'name' => $name, 'first' => ! $was, 'country' => $ctry ) );
	}
}

DLZ_Profile::init();
