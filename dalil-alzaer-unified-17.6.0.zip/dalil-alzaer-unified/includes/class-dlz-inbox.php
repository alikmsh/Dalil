<?php
/**
 * Dalil Al Zaer — «درخواست‌های جدید» (17.5): every request a visitor sends shows up for the admin.
 *
 * Supermarket orders, taxi / tour / entertainment / ticket bookings, medical & cosmetic and legal requests,
 * currency exchange («نأتي إليك»), new shops from «سجّل متجرك» and support-chat messages are logged here.
 * The admin sees a bell with the number of unseen requests in the top bar (site and dashboard), a badge on
 * the «دلیل الزائر» menu, a list page, and a small pop-up + sound when a new one arrives while the dashboard
 * is open (WordPress Heartbeat, no extra polling).
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DLZ_Inbox {

	const OPT    = 'dlz_inbox';
	const UNSEEN = 'dlz_inbox_unseen';
	const MAX    = 300;
	const CAP    = 'manage_options';

	/** type => [label, dashicon, colour] */
	public static function types() {
		return array(
			'market'   => array( 'سفارش سوپرمارکت', 'dashicons-cart', '#16A34A' ),
			'taxi'     => array( 'رزرو تاکسی VIP', 'dashicons-car', '#D97706' ),
			'tour'     => array( 'رزرو تور روزانه', 'dashicons-location-alt', '#0D9488' ),
			'ent'      => array( 'رزرو مرکز تفریحی', 'dashicons-tickets-alt', '#DB2777' ),
			'ticket'   => array( 'رزرو بلیت سفر', 'dashicons-airplane', '#0284C7' ),
			'medical'  => array( 'درخواست درمان / زیبایی', 'dashicons-heart', '#DC2626' ),
			'legal'    => array( 'درخواست خدمات حقوقی', 'dashicons-businessperson', '#4F46E5' ),
			'exchange' => array( 'درخواست تبادل ارز', 'dashicons-money-alt', '#65A30D' ),
			'shop'     => array( 'ثبت مغازه‌ی جدید', 'dashicons-store', '#B45309' ),
			'chat'     => array( 'پیام پشتیبانی', 'dashicons-format-chat', '#0F8A5F' ),
			'security' => array( 'هشدار امنیتی', 'dashicons-shield', '#B42318' ),
		);
	}

	public static function init() {
		add_action( 'wp_insert_post', array( __CLASS__, 'on_post' ), 20, 3 );
		add_action( 'dalil_cr_exchange_request', array( __CLASS__, 'on_exchange' ) );
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 30 );
		add_action( 'admin_bar_menu', array( __CLASS__, 'bar' ), 80 );
		add_action( 'admin_post_dlz_inbox_go', array( __CLASS__, 'go' ) );
		add_action( 'admin_post_dlz_inbox_seen', array( __CLASS__, 'seen_all' ) );
		add_filter( 'heartbeat_received', array( __CLASS__, 'heartbeat' ), 10, 2 );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'admin_js' ) );
		add_action( 'admin_head', array( __CLASS__, 'css' ) );
		add_action( 'wp_head', array( __CLASS__, 'css_front' ) );
	}

	/* ------------------------------------------------------------ store */

	private static function all() {
		$a = get_option( self::OPT, array() );
		return is_array( $a ) ? $a : array();
	}

	/**
	 * Log one request. $key groups repeats (e.g. several chat messages of one visitor) into one line.
	 */
	public static function add( $type, $title, $sub = '', $url = '', $key = '' ) {
		if ( ! isset( self::types()[ $type ] ) ) {
			return;
		}
		$a    = self::all();
		$item = array(
			'id'   => substr( md5( uniqid( '', true ) ), 0, 12 ),
			'type' => $type,
			't'    => wp_strip_all_tags( (string) $title ),
			's'    => wp_strip_all_tags( (string) $sub ),
			'u'    => esc_url_raw( (string) $url ),
			'time' => time(),
			'seen' => 0,
			'k'    => (string) $key,
			'n'    => 1,
		);
		if ( '' !== $key ) {
			foreach ( $a as $i => $x ) {
				if ( ( $x['k'] ?? '' ) === $key && empty( $x['seen'] ) ) {
					$item['n']  = (int) ( $x['n'] ?? 1 ) + 1;
					$item['id'] = $x['id'];
					unset( $a[ $i ] );
					break;
				}
			}
		}
		array_unshift( $a, $item );
		$a = array_slice( array_values( $a ), 0, self::MAX );
		update_option( self::OPT, $a, false );
		self::recount( $a );
	}

	private static function recount( $a = null ) {
		$a = null === $a ? self::all() : $a;
		$n = 0;
		foreach ( $a as $x ) {
			if ( empty( $x['seen'] ) ) {
				$n++;
			}
		}
		update_option( self::UNSEEN, $n, true );
		return $n;
	}

	public static function unseen() {
		return (int) get_option( self::UNSEEN, 0 );
	}

	/* ------------------------------------------------------------ sources */

	public static function on_post( $id, $post, $update ) {
		if ( $update || wp_is_post_revision( $id ) || 'auto-draft' === $post->post_status ) {
			return;
		}
		if ( is_admin() && ! wp_doing_ajax() ) {
			return; // made by the admin in the dashboard, not a request
		}
		$map = array(
			'dlz_taxi_booking'     => array( 'taxi', 'edit.php?post_type=dlz_taxi_booking' ),
			'dlz_tour_booking'     => array( 'tour', 'edit.php?post_type=dlz_tour_booking' ),
			'dlz_ent_booking'      => array( 'ent', 'edit.php?post_type=dlz_ent_booking' ),
			'dalil_ticket_booking' => array( 'ticket', 'edit.php?post_type=dalil_ticket_booking' ),
		);
		if ( isset( $map[ $post->post_type ] ) ) {
			self::add( $map[ $post->post_type ][0], $post->post_title, self::who(), admin_url( 'post.php?post=' . (int) $id . '&action=edit' ) );
			return;
		}
		if ( 'dbd_business' === $post->post_type && 'pending' === $post->post_status ) {
			self::add( 'shop', $post->post_title, 'منتظر تأیید شما', admin_url( 'post.php?post=' . (int) $id . '&action=edit' ) );
		}
	}

	public static function on_exchange( $r ) {
		$r = is_array( $r ) ? $r : array();
		self::add( 'exchange', ( 'sell' === ( $r['mode'] ?? '' ) ? 'فروش ' : 'خرید ' ) . ( $r['currency_name'] ?? '' ) . ( ! empty( $r['amount'] ) ? ' — ' . $r['amount'] : '' ), trim( ( $r['name'] ?? '' ) . ' ' . ( $r['phone'] ?? '' ) ), admin_url( 'admin.php?page=dalil-currency-requests' ) );
	}

	/** Name of the signed-in visitor (for the second line). */
	public static function who() {
		if ( ! is_user_logged_in() ) {
			return '';
		}
		$uid = get_current_user_id();
		$n   = trim( (string) get_user_meta( $uid, 'mp_full_name', true ) );
		return $n ? $n : wp_get_current_user()->display_name;
	}

	/* ------------------------------------------------------------ dashboard */

	public static function menu() {
		$n = self::unseen();
		add_submenu_page( 'dlz-unified', 'درخواست‌های جدید', 'درخواست‌های جدید' . ( $n ? ' <span class="awaiting-mod dlz-inbox-c"><span>' . (int) $n . '</span></span>' : '' ), self::CAP, 'dlz-inbox', array( __CLASS__, 'page' ), 0 );
		// the number on the «دلیل الزائر» menu itself
		global $menu;
		if ( $n && is_array( $menu ) ) {
			foreach ( $menu as $i => $m ) {
				if ( isset( $m[2] ) && 'dlz-unified' === $m[2] && false === strpos( $m[0], 'dlz-inbox-c' ) ) {
					$menu[ $i ][0] .= ' <span class="awaiting-mod dlz-inbox-c"><span>' . (int) $n . '</span></span>'; // phpcs:ignore
				}
			}
		}
	}

	private static function ago( $t ) {
		$d = time() - (int) $t;
		if ( $d < 60 ) {
			return 'همین الان';
		}
		if ( $d < 3600 ) {
			return (int) floor( $d / 60 ) . ' دقیقه پیش';
		}
		if ( $d < 86400 ) {
			return (int) floor( $d / 3600 ) . ' ساعت پیش';
		}
		return wp_date( 'Y/m/d H:i', (int) $t );
	}

	private static function go_url( $id ) {
		return wp_nonce_url( admin_url( 'admin-post.php?action=dlz_inbox_go&i=' . rawurlencode( $id ) ), 'dlz_inbox' );
	}

	public static function page() {
		if ( ! current_user_can( self::CAP ) ) {
			return;
		}
		$a     = self::all();
		$types = self::types();
		$n     = self::unseen();
		?>
		<div class="wrap dlz-inbox" dir="rtl">
			<h1>درخواست‌های جدید <?php echo $n ? '<span class="dlz-inbox-n">' . (int) $n . ' خوانده‌نشده</span>' : ''; ?></h1>
			<p class="description">هر درخواستی که زائران در سایت یا اپ ثبت می‌کنند (سفارش، رزرو، مشاوره، تبادل ارز، ثبت مغازه، پیام پشتیبانی) این‌جا نمایش داده می‌شود. با زدن هر ردیف به صفحه‌ی همان درخواست می‌روید و ردیف خوانده‌شده می‌شود.</p>
			<?php if ( $n ) : ?>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin:10px 0 14px"><input type="hidden" name="action" value="dlz_inbox_seen"><?php wp_nonce_field( 'dlz_inbox' ); ?><button class="button">همه را خوانده‌شده کن</button></form>
			<?php endif; ?>
			<?php if ( ! $a ) : ?>
				<div class="dlz-inbox-empty"><span class="dashicons dashicons-bell"></span><p>هنوز درخواستی ثبت نشده است.</p></div>
			<?php else : ?>
				<div class="dlz-inbox-list">
				<?php foreach ( $a as $x ) :
					$ty = isset( $types[ $x['type'] ] ) ? $types[ $x['type'] ] : array( $x['type'], 'dashicons-bell', '#555' );
					?>
					<a class="dlz-inbox-row<?php echo empty( $x['seen'] ) ? ' is-new' : ''; ?>" href="<?php echo esc_url( self::go_url( $x['id'] ) ); ?>">
						<span class="dlz-inbox-ic" style="--c:<?php echo esc_attr( $ty[2] ); ?>"><span class="dashicons <?php echo esc_attr( $ty[1] ); ?>"></span></span>
						<span class="dlz-inbox-t"><small><?php echo esc_html( $ty[0] ); ?><?php echo ! empty( $x['n'] ) && $x['n'] > 1 ? ' × ' . (int) $x['n'] : ''; ?></small><b><?php echo esc_html( $x['t'] ); ?></b><?php echo '' !== $x['s'] ? '<em>' . esc_html( $x['s'] ) . '</em>' : ''; ?></span>
						<span class="dlz-inbox-time"><?php echo esc_html( self::ago( $x['time'] ) ); ?></span>
					</a>
				<?php endforeach; ?>
				</div>
			<?php endif; ?>
		</div>
		<?php
	}

	/** A row was clicked: mark it seen and open the request. */
	public static function go() {
		if ( ! current_user_can( self::CAP ) ) {
			wp_die( 'دسترسی ندارید.', '', array( 'response' => 403 ) );
		}
		check_admin_referer( 'dlz_inbox' );
		$id  = isset( $_GET['i'] ) ? sanitize_key( wp_unslash( $_GET['i'] ) ) : ''; // phpcs:ignore
		$a   = self::all();
		$url = admin_url( 'admin.php?page=dlz-inbox' );
		foreach ( $a as $i => $x ) {
			if ( $x['id'] === $id ) {
				$a[ $i ]['seen'] = 1;
				if ( ! empty( $x['u'] ) ) {
					$url = $x['u'];
				}
			}
		}
		update_option( self::OPT, $a, false );
		self::recount( $a );
		wp_safe_redirect( $url );
		exit;
	}

	public static function seen_all() {
		if ( ! current_user_can( self::CAP ) ) {
			wp_die( 'دسترسی ندارید.', '', array( 'response' => 403 ) );
		}
		check_admin_referer( 'dlz_inbox' );
		$a = self::all();
		foreach ( $a as $i => $x ) {
			$a[ $i ]['seen'] = 1;
		}
		update_option( self::OPT, $a, false );
		self::recount( $a );
		wp_safe_redirect( admin_url( 'admin.php?page=dlz-inbox' ) );
		exit;
	}

	/* ------------------------------------------------------------ the bell (top bar) */

	public static function bar( $bar ) {
		if ( ! current_user_can( self::CAP ) || ! is_admin_bar_showing() ) {
			return;
		}
		$n = self::unseen();
		$bar->add_node( array(
			'id'    => 'dlz-inbox',
			'title' => '<span class="ab-icon dashicons dashicons-bell" aria-hidden="true"></span><span class="ab-label">درخواست‌ها</span><span class="dlz-bell-n"' . ( $n ? '' : ' hidden' ) . '>' . (int) $n . '</span>',
			'href'  => admin_url( 'admin.php?page=dlz-inbox' ),
			'meta'  => array( 'class' => $n ? 'dlz-has-new' : '', 'title' => 'درخواست‌های جدید' ),
		) );
		$types = self::types();
		$k     = 0;
		foreach ( self::all() as $x ) {
			if ( ! empty( $x['seen'] ) ) {
				continue;
			}
			if ( ++$k > 8 ) {
				break;
			}
			$ty = isset( $types[ $x['type'] ] ) ? $types[ $x['type'] ][0] : '';
			$bar->add_node( array(
				'parent' => 'dlz-inbox',
				'id'     => 'dlz-inbox-' . $x['id'],
				'title'  => esc_html( $ty . ' — ' . wp_html_excerpt( $x['t'], 42, '…' ) ) . ' <span class="dlz-bell-ago">' . esc_html( self::ago( $x['time'] ) ) . '</span>',
				'href'   => self::go_url( $x['id'] ),
			) );
		}
		$bar->add_node( array( 'parent' => 'dlz-inbox', 'id' => 'dlz-inbox-all', 'title' => 'همه‌ی درخواست‌ها', 'href' => admin_url( 'admin.php?page=dlz-inbox' ) ) );
	}

	/* ------------------------------------------------------------ live (Heartbeat) */

	public static function heartbeat( $res, $data ) {
		if ( isset( $data['dlz_inbox'] ) && current_user_can( self::CAP ) ) {
			$n    = self::unseen();
			$last = '';
			foreach ( self::all() as $x ) {
				if ( empty( $x['seen'] ) ) {
					$ty   = self::types()[ $x['type'] ] ?? array( '' );
					$last = $ty[0] . ' — ' . $x['t'];
					break;
				}
			}
			$res['dlz_inbox'] = array( 'n' => $n, 'last' => $last );
		}
		return $res;
	}

	public static function admin_js() {
		if ( ! current_user_can( self::CAP ) ) {
			return;
		}
		wp_enqueue_script( 'heartbeat' );
		wp_add_inline_script( 'heartbeat', '(function($){var n=' . (int) self::unseen() . ';$(document).on("heartbeat-send",function(e,d){d.dlz_inbox=1;});$(document).on("heartbeat-tick",function(e,d){if(!d||!d.dlz_inbox)return;var m=+d.dlz_inbox.n||0;$(".dlz-bell-n").text(m).prop("hidden",!m);$("#wp-admin-bar-dlz-inbox").toggleClass("dlz-has-new",!!m);$(".dlz-inbox-c span").text(m);if(m>n&&d.dlz_inbox.last){var t=$("<a class=\"dlz-inbox-toast\" href=\"' . esc_url( admin_url( 'admin.php?page=dlz-inbox' ) ) . '\"><span class=\"dashicons dashicons-bell\"></span><b>درخواست جدید</b><span></span></a>");t.find("span").last().text(d.dlz_inbox.last);$("body").append(t);setTimeout(function(){t.addClass("is-on");},30);setTimeout(function(){t.removeClass("is-on");setTimeout(function(){t.remove();},400);},9000);try{var A=window.AudioContext||window.webkitAudioContext,c=new A(),o=c.createOscillator(),g=c.createGain();o.type="sine";o.frequency.value=880;g.gain.value=.07;o.connect(g);g.connect(c.destination);o.start();o.frequency.setValueAtTime(660,c.currentTime+.15);o.stop(c.currentTime+.32);}catch(x){}}n=m;});})(jQuery);' );
	}

	private static function bar_css() {
		return '#wpadminbar #wp-admin-bar-dlz-inbox>.ab-item{display:flex;align-items:center;gap:4px}'
			. '#wpadminbar #wp-admin-bar-dlz-inbox .ab-icon:before{content:"\f16d";top:2px}'
			. '#wpadminbar .dlz-bell-n{display:inline-block;min-width:18px;height:18px;padding:0 5px;margin-inline-start:4px;border-radius:9px;background:#D63638;color:#fff;font-size:11px;font-weight:700;line-height:18px;text-align:center}'
			. '#wpadminbar .dlz-bell-n[hidden]{display:none}'
			. '#wpadminbar #wp-admin-bar-dlz-inbox.dlz-has-new>.ab-item .ab-icon:before{color:#F3D68B;animation:dlzBell 2.4s ease-in-out infinite}'
			. '@keyframes dlzBell{0%,90%,100%{transform:rotate(0)}92%{transform:rotate(14deg)}94%{transform:rotate(-12deg)}96%{transform:rotate(8deg)}}'
			. '#wpadminbar .dlz-bell-ago{opacity:.65;font-size:11px;margin-inline-start:6px}';
	}

	public static function css_front() {
		if ( is_admin_bar_showing() && current_user_can( self::CAP ) ) {
			echo '<style id="dlz-inbox-bar">' . self::bar_css() . '</style>'; // phpcs:ignore
		}
	}

	public static function css() {
		if ( ! current_user_can( self::CAP ) ) {
			return;
		}
		echo '<style id="dlz-inbox-css">' . self::bar_css() // phpcs:ignore
			. '.dlz-inbox h1{display:flex;align-items:center;gap:10px}.dlz-inbox-n{font-size:13px;padding:3px 10px;border-radius:999px;background:#D63638;color:#fff}'
			. '.dlz-inbox-list{max-width:900px;margin-top:12px;background:#fff;border:1px solid #E4DCC8;border-radius:14px;overflow:hidden}'
			. '.dlz-inbox-row{display:flex;align-items:center;gap:12px;padding:12px 14px;border-bottom:1px solid #F1EBDD;color:#1d2327;text-decoration:none}.dlz-inbox-row:last-child{border-bottom:0}.dlz-inbox-row:hover{background:#FBF7EE}'
			. '.dlz-inbox-row.is-new{background:#FFFBEB}.dlz-inbox-row.is-new .dlz-inbox-t b::after{content:"جدید";margin-inline-start:8px;padding:1px 7px;border-radius:999px;background:#D63638;color:#fff;font-size:10px;font-weight:700;vertical-align:middle}'
			. '.dlz-inbox-ic{flex:none;display:flex;align-items:center;justify-content:center;width:40px;height:40px;border-radius:12px;color:#fff;background:var(--c)}'
			. '.dlz-inbox-t{flex:1;min-width:0;display:flex;flex-direction:column;gap:2px}.dlz-inbox-t small{color:#787C82;font-size:12px}.dlz-inbox-t b{font-size:14px}.dlz-inbox-t em{font-style:normal;color:#50575E;font-size:12.5px}'
			. '.dlz-inbox-time{flex:none;color:#787C82;font-size:12px}'
			. '.dlz-inbox-empty{max-width:900px;margin-top:14px;padding:40px;border-radius:14px;background:#fff;border:1px dashed #DCD3BE;text-align:center;color:#787C82}.dlz-inbox-empty .dashicons{font-size:40px;width:40px;height:40px;color:#C9A44A}'
			. '.dlz-inbox-toast{position:fixed;bottom:24px;left:24px;z-index:99999;display:flex;align-items:center;gap:8px;max-width:420px;padding:14px 16px;border-radius:14px;background:#0F4D2E;color:#fff!important;text-decoration:none;box-shadow:0 14px 30px -10px rgba(0,0,0,.45);transform:translateY(30px);opacity:0;transition:.35s}.dlz-inbox-toast.is-on{transform:none;opacity:1}.dlz-inbox-toast .dashicons{color:#F3D68B}.dlz-inbox-toast b{white-space:nowrap}.dlz-inbox-toast span:last-child{opacity:.85;font-size:12.5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}'
			. '</style>';
	}
}
DLZ_Inbox::init();
