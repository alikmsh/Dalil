<?php
/**
 * Dalil Al Zaer — «المفضلة» page (17.4).
 *
 * 17.4.1: the same cards as the listings (cream, gold hairline, photo with the heart to remove it),
 * a gold kind chip, name, place, price in the visitor's currency, round call / map buttons.
 * The whole card opens the place (business details sheet / tour / entertainment centre).
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DLZ_Favorites_Page {

	private static function svc( $key ) {
		return method_exists( 'DLZ_App_Shell', 'url_of' ) ? DLZ_App_Shell::url_of( $key ) : '';
	}

	private static function maps_url( $lat, $lng ) {
		return ( $lat && $lng ) ? 'https://www.google.com/maps/search/?api=1&query=' . round( (float) $lat, 6 ) . ',' . round( (float) $lng, 6 ) : '';
	}

	/** Everything one card needs. */
	public static function item( $type, $id, $snap ) {
		$it = array(
			'type'  => $type,
			'id'    => $id,
			'title' => '',
			'sub'   => '',
			'price' => '',
			'img'   => '',
			'phone' => '',
			'tel'   => '',
			'map'   => '',
			'url'   => '',
			'open'  => 0,
			'btn'   => 'عرض العنوان',
			'kind'  => '',
		);
		if ( 'publish' !== get_post_status( $id ) ) {
			return null;
		}
		if ( 'dbd_business' === $type && class_exists( 'DBD_Look' ) ) {
			$c            = DBD_Look::card( $id );
			$it['title']  = $c['title'];
			$it['sub']    = $c['slogan'] ? $c['slogan'] : ( $c['dist'] ? $c['dist'] : '' );
			$it['img']    = $c['img'] ? $c['img'] : $c['logo'];
			$it['price']  = $c['price'] > 0 ? $c['pnum'] . ' ' . trim( preg_replace( '#/.*#u', '', $c['unit'] ) ) : '';
			$it['phone']  = $c['phones'] ? (string) $c['phones'][0][1] : '';
			$it['tel']    = $c['tel'];
			$it['map']    = $c['map'] ? $c['map'] : self::maps_url( $c['lat'], $c['lng'] );
			$it['open']   = $id;
			$it['kind']   = $c['kind'];
			return $it;
		}
		if ( 'dlz_daily_tour' === $type ) {
			$days        = function_exists( 'dlzdt_days' ) ? dlzdt_days() : array();
			$td          = (array) get_post_meta( $id, '_dlz_tour_days', true );
			$time        = (string) get_post_meta( $id, '_dlz_tour_time', true );
			$p           = (float) get_post_meta( $id, '_dlz_tour_price', true );
			$it['title'] = get_the_title( $id );
			$it['sub']   = trim( ( $time ? 'الحركة ' . $time : '' ) . ( $td ? ' · ' . implode( '، ', array_map( function ( $x ) use ( $days ) { return isset( $days[ $x ] ) ? $days[ $x ] : $x; }, $td ) ) : '' ), ' ·' );
			$it['img']   = (string) get_post_meta( $id, '_dlz_tour_image', true );
			$it['price'] = $p > 0 ? ( class_exists( 'DLZ_Money' ) ? DLZ_Money::fmt( $p ) : number_format( $p ) . ' د.ع' ) . ' / للفرد' : '';
			$it['map']   = (string) get_post_meta( $id, '_dlz_tour_map_url', true );
			$base        = self::svc( 'tours' );
			$it['url']   = $base ? $base . '#tour-' . $id : '';
			$it['btn']   = $it['map'] ? 'عرض العنوان' : 'احجز';
			return $it;
		}
		if ( 'dlz_entertainment' === $type ) {
			$it['title'] = get_the_title( $id );
			$it['sub']   = (string) get_post_meta( $id, '_dlz_ent_location', true );
			$it['img']   = (string) get_post_meta( $id, '_dlz_ent_image', true );
			$pr          = (string) get_post_meta( $id, '_dlz_ent_price', true );
			$free        = 'free' === get_post_meta( $id, '_dlz_ent_type', true );
			$it['price'] = $free ? 'مجاني' : ( class_exists( 'DLZ_Money' ) ? DLZ_Money::text( $pr ) : $pr );
			$lat         = (float) get_post_meta( $id, '_dlz_ent_lat', true );
			$lng         = (float) get_post_meta( $id, '_dlz_ent_lng', true );
			$it['map']   = (string) get_post_meta( $id, '_dlz_ent_map_url', true );
			if ( ! $it['map'] ) {
				$it['map'] = self::maps_url( $lat, $lng );
			}
			$base      = self::svc( 'entertainment' );
			$it['url'] = $base ? $base . '#ent-' . $id : '';
			$it['btn'] = $it['map'] ? 'عرض العنوان' : 'التفاصيل';
			return $it;
		}
		// unknown / module missing: the saved snapshot
		$it['title'] = isset( $snap['title'] ) ? $snap['title'] : get_the_title( $id );
		$it['sub']   = isset( $snap['description'] ) ? wp_trim_words( $snap['description'], 8, '…' ) : '';
		$it['img']   = isset( $snap['image'] ) ? $snap['image'] : '';
		$it['phone'] = isset( $snap['phone'] ) ? $snap['phone'] : '';
		$it['map']   = isset( $snap['map'] ) ? $snap['map'] : '';
		return $it;
	}

	private static function i( $k ) {
		$p = array(
			'phone' => '<path d="M6.6 10.8a15.1 15.1 0 0 0 6.6 6.6l2.2-2.2c.3-.3.7-.4 1-.2 1.1.4 2.3.6 3.6.6.6 0 1 .4 1 1V20c0 .6-.4 1-1 1A17 17 0 0 1 3 4c0-.6.4-1 1-1h3.5c.6 0 1 .4 1 1 0 1.3.2 2.5.6 3.6.1.3 0 .7-.2 1l-2.3 2.2z" fill="currentColor" stroke="none"/>',
			'pin'   => '<path d="M12 22s-7-6.6-7-12.2A7 7 0 0 1 19 9.8C19 15.4 12 22 12 22z" fill="currentColor" stroke="none"/><circle cx="12" cy="9.8" r="2.6" fill="#0F4D2E" stroke="none"/>',
			'back'  => '<path d="M9 5l7 7-7 7"/>',
			'heart' => '<path d="M12 20.6l-1.3-1.2C5.9 15.1 3 12.4 3 8.9 3 6.1 5.2 4 7.9 4c1.6 0 3.1.7 4.1 1.9C13 4.7 14.5 4 16.1 4 18.8 4 21 6.1 21 8.9c0 3.5-2.9 6.2-7.7 10.5L12 20.6z"/>',
			'chev'  => '<path d="m14.5 6-6 6 6 6"/>',
			'img'   => '<rect x="3" y="5" width="18" height="14" rx="3"/><circle cx="9" cy="10" r="1.8"/><path d="M21 16l-5-5-8 8"/>',
		);
		return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . $p[ $k ] . '</svg>';
	}

	/** Short kind label shown as a gold chip on the card. */
	private static function kind( $it ) {
		if ( 'dlz_daily_tour' === $it['type'] ) {
			return 'جولة';
		}
		if ( 'dlz_entertainment' === $it['type'] ) {
			return 'ترفيه';
		}
		$k = array( 'hotel' => 'فندق', 'restaurant' => 'مطعم', 'sim' => 'شحن وإنترنت', 'shopping' => 'متجر', 'salon' => 'صالون', 'venue' => 'قاعة', 'other' => 'خدمة' );
		return isset( $k[ $it['kind'] ] ) ? $k[ $it['kind'] ] : '';
	}

	public static function render() {
		if ( ! is_user_logged_in() ) {
			return '<div dir="rtl">يرجى تسجيل الدخول أولاً.</div>';
		}
		$items = array();
		foreach ( dlz_favorites_get() as $x ) {
			$snap = isset( $x['snapshot'] ) && is_array( $x['snapshot'] ) ? $x['snapshot'] : array();
			$it   = self::item( $x['type'], (int) $x['id'], $snap );
			if ( $it && '' !== $it['title'] ) {
				$items[] = $it;
			}
		}
		$has_biz = false;
		foreach ( $items as $it ) {
			if ( $it['open'] ) {
				$has_biz = true;
			}
		}
		$out = '';
		if ( $has_biz && class_exists( 'DBD_Frontend' ) ) {
			$out .= DBD_Frontend::assets(); // the business sheet (call / WhatsApp / map) opens right here
		}
		$n    = count( $items );
		$out .= '<div class="dlz-fv" dir="rtl">';
		$out .= '<header class="dlz-fv-hd"><h1>المفضلة</h1><span class="dlz-fv-orn" aria-hidden="true"><i></i><b></b><i></i></span><p class="dlz-fv-n"' . ( $n ? '' : ' hidden' ) . '><b>' . (int) $n . '</b> ' . ( 1 === $n ? 'مكان محفوظ' : 'أماكن محفوظة' ) . '</p></header>';
		$out .= '<div class="dlz-fv-empty"' . ( $items ? ' hidden' : '' ) . '><span>' . self::i( 'heart' ) . '</span><b>لا توجد أماكن في المفضلة بعد</b><small>اضغط على القلب في أي مكان لحفظه هنا.</small></div>';
		$out .= '<div class="dlz-fv-list">';
		foreach ( $items as $k => $it ) {
			$attr = $it['open'] ? ' data-biz="' . (int) $it['open'] . '"' : ( $it['url'] ? ' data-href="' . esc_url( $it['url'] ) . '"' : '' );
			$kind = self::kind( $it );
			$out .= '<article class="dlz-fv-card" style="--d:' . (int) min( $k, 8 ) * 40 . 'ms" tabindex="0" role="link" aria-label="' . esc_attr( $it['title'] ) . '"' . $attr . '>';
			$out .= '<div class="dlz-fv-b">';
			$out .= ( $kind ? '<span class="dlz-fv-k">' . esc_html( $kind ) . '</span>' : '' ) . '<h3>' . esc_html( $it['title'] ) . '</h3>';
			if ( $it['sub'] ) {
				$out .= '<p class="dlz-fv-s">' . self::i( 'pin' ) . '<span>' . esc_html( wp_trim_words( $it['sub'], 9, '…' ) ) . '</span></p>';
			}
			$out .= '<div class="dlz-fv-f">';
			$out .= $it['price'] ? '<span class="dlz-fv-p" dir="auto">' . esc_html( $it['price'] ) . '</span>' : '<span class="dlz-fv-more">التفاصيل' . self::i( 'chev' ) . '</span>';
			$out .= '<span class="dlz-fv-a">';
			if ( $it['phone'] ) {
				$tel  = $it['tel'] ? $it['tel'] : 'tel:' . preg_replace( '/[^\d+]/', '', $it['phone'] );
				$out .= '<a class="dlz-fv-btn is-call" href="' . esc_attr( $tel ) . '" aria-label="اتصال ' . esc_attr( $it['phone'] ) . '">' . self::i( 'phone' ) . '</a>';
			}
			if ( $it['map'] ) {
				$out .= '<a class="dlz-fv-btn is-map" href="' . esc_url( $it['map'] ) . '" target="_blank" rel="noopener" aria-label="عرض العنوان">' . self::i( 'pin' ) . '</a>';
			}
			$out .= '</span></div></div>';
			$out .= '<div class="dlz-fv-ph">' . ( $it['img'] ? '<img src="' . esc_url( $it['img'] ) . '" alt="" loading="lazy" decoding="async">' : '<span class="dlz-fv-noimg">' . self::i( 'img' ) . '</span>' ) . dlz_favorite_button( $it['type'], $it['id'] ) . '</div>';
			if ( $it['open'] ) {
				$out .= '<span class="dlz-fv-o" data-open-business="' . (int) $it['open'] . '" aria-hidden="true"></span>';
			}
			$out .= '</article>';
		}
		$out .= '</div></div>';
		// the script goes to the footer (post-content filters would mangle inline code)
		if ( ! has_action( 'wp_footer', array( __CLASS__, 'footer' ) ) ) {
			add_action( 'wp_footer', array( __CLASS__, 'footer' ), 5 );
		}
		return self::css() . $out;
	}

	private static function css() {
		return '<style id="dlz-fv-css">'
			. 'body:has(.dlz-fv) .dlz-ptitle,body:has(.dlz-fv) .entry-title,body:has(.dlz-fv) .wp-block-post-title,body:has(.dlz-fv) .page-header{display:none!important}'
			. '.dlz-fv{box-sizing:border-box;--g:#0F4D2E;--g2:#17643E;--a:#D9AE4A;--a2:#F3D68B;--ad:#A87A22;--ink:#1D2A22;--mute:#7C8580;--line:#EADFC4;--card:#FFFDF8;max-width:620px;margin:0 auto;padding:4px 12px 28px;font-family:"DlzDigits",var(--dsh-font,inherit);color:var(--ink);-webkit-tap-highlight-color:transparent}'
			. '.dlz-fv *{box-sizing:border-box;font-family:inherit}'
			. '.dlz-fv-hd{display:flex;flex-direction:column;align-items:center;gap:6px;margin:6px 0 16px;text-align:center}'
			. '.dlz-fv-hd h1{margin:0!important;padding:0!important;font-size:23px!important;font-weight:800!important;line-height:1.35!important;color:var(--g)!important;letter-spacing:0}'
			. '.dlz-fv-orn{display:flex;align-items:center;gap:7px}.dlz-fv-orn i{display:block;width:34px;height:1.5px;border-radius:2px;background:linear-gradient(90deg,transparent,var(--a))}.dlz-fv-orn i:last-child{background:linear-gradient(90deg,var(--a),transparent)}.dlz-fv-orn b{display:block;width:7px;height:7px;transform:rotate(45deg);border-radius:1.5px;background:var(--a)}'
			. '.dlz-fv-n{margin:2px 0 0!important;font-size:12.5px!important;color:var(--mute)!important;line-height:1.5!important}.dlz-fv-n b{color:var(--ad);font-weight:800}.dlz-fv-n[hidden]{display:none!important}'
			. '.dlz-fv-list{display:flex;flex-direction:column;gap:10px}'
			. '.dlz-fv-card{position:relative;display:flex;align-items:stretch;gap:12px;padding:9px;border-radius:18px;background:var(--card);box-shadow:inset 0 0 0 1px var(--line),0 8px 20px -16px rgba(90,64,12,.55);cursor:pointer;outline:0;transition:transform .16s ease,box-shadow .16s ease,opacity .25s;animation:dlzFvIn .4s cubic-bezier(.2,.7,.2,1) both;animation-delay:var(--d,0ms)}'
			. '.dlz-fv-card:active{transform:scale(.985)}.dlz-fv-card:focus-visible{box-shadow:inset 0 0 0 2px var(--a)}'
			. '@media (hover:hover){.dlz-fv-card:hover{box-shadow:inset 0 0 0 1px #E2CF9F,0 12px 26px -16px rgba(90,64,12,.6)}}'
			. '.dlz-fv-card.is-gone{opacity:0;transform:scale(.96)}'
			. '@keyframes dlzFvIn{from{opacity:0;transform:translateY(8px)}}'
			. '.dlz-fv-b{flex:1 1 auto;min-width:0;display:flex;flex-direction:column;gap:4px;padding:2px 2px 0 0}'
			. '.dlz-fv-k{align-self:flex-start;padding:1px 9px;border-radius:999px;font-size:11px;font-weight:800;line-height:1.7;color:var(--ad);background:#FBF3E0;box-shadow:inset 0 0 0 1px #F0E1BB}'
			. '.dlz-fv .dlz-fv-b h3{margin:0!important;padding:0!important;font-size:16px!important;font-weight:800!important;line-height:1.45!important;color:var(--ink)!important;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}'
			. '.dlz-fv .dlz-fv-s{display:flex;align-items:center;gap:5px;margin:0!important;font-size:12.5px!important;line-height:1.5!important;color:var(--mute)!important;min-width:0}'
			. '.dlz-fv-s svg{flex:none;width:14px;height:14px;color:var(--a)}.dlz-fv-s span{min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}'
			. '.dlz-fv-f{display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between;gap:6px 8px;margin-top:auto;padding-top:6px}.dlz-fv-a{margin-inline-start:auto}'
			. '.dlz-fv-p{font-size:13.5px;font-weight:800;color:var(--g);white-space:nowrap}'
			. '.dlz-fv-more{display:inline-flex;align-items:center;gap:2px;font-size:12.5px;font-weight:800;color:var(--ad)}.dlz-fv-more svg{width:15px;height:15px}'
			. '.dlz-fv-a{display:flex;gap:7px;flex:none}'
			. '.dlz-fv .dlz-fv-btn{display:flex;align-items:center;justify-content:center;width:36px;height:36px;border-radius:50%;text-decoration:none!important;transition:transform .15s}.dlz-fv-btn:active{transform:scale(.9)}'
			. '.dlz-fv-btn svg{width:17px;height:17px}'
			. '.dlz-fv .dlz-fv-btn.is-call{color:var(--g)!important;background:#fff;box-shadow:inset 0 0 0 1.5px #CFE0D5}'
			. '.dlz-fv .dlz-fv-btn.is-map{color:#fff!important;background:radial-gradient(120% 140% at 50% -20%,var(--g2),var(--g) 70%);box-shadow:inset 0 0 0 1.5px rgba(217,174,74,.75),0 6px 12px -8px rgba(8,47,28,.8)}.dlz-fv-btn.is-map svg circle{fill:var(--g)}.dlz-fv .dlz-fv-btn.is-map svg path{fill:var(--a2)}'
			. '.dlz-fv-ph{position:relative;flex:0 0 118px;width:118px;min-height:118px;border-radius:14px;overflow:hidden;background:#EEE6D2}'
			. '.dlz-fv-ph img{position:absolute;inset:0;display:block;width:100%!important;height:100%!important;max-width:none!important;margin:0!important;object-fit:cover;border-radius:0!important}'
			. '.dlz-fv-noimg{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;color:#C9B78E}.dlz-fv-noimg svg{width:34px;height:34px}'
			. '.dlz-fv .dlz-fv-ph .dlz-unified-favorite{position:absolute;top:6px;right:6px;z-index:2;width:30px!important;height:30px!important;min-width:0!important;margin:0!important;border:0!important;background:rgba(255,255,255,.94)!important;box-shadow:0 2px 8px rgba(0,0,0,.18)!important;cursor:pointer}'
			. '.dlz-fv .dlz-fv-ph .dlz-unified-favorite .dlz-hrt{width:16px;height:16px}'
			. '.dlz-fv .dlz-fv-o{display:none!important}'
			. '.dlz-fv-empty{display:flex;flex-direction:column;align-items:center;gap:6px;margin:34px 0;padding:28px 18px;border-radius:20px;background:var(--card);box-shadow:inset 0 0 0 1px var(--line);text-align:center}.dlz-fv-empty[hidden]{display:none!important}'
			. '.dlz-fv-empty span{display:flex;width:64px;height:64px;border-radius:50%;align-items:center;justify-content:center;color:var(--a2);background:radial-gradient(120% 140% at 50% -20%,var(--g2),var(--g) 70%);box-shadow:0 0 0 3px #fff,0 0 0 4.5px var(--a)}.dlz-fv-empty span svg{width:28px;height:28px}'
			. '.dlz-fv-empty b{font-size:15px;color:var(--g)}.dlz-fv-empty small{font-size:12.5px;color:var(--mute)}'
			. '@media (max-width:700px){.dlz-fv{width:100vw;max-width:100vw;margin-left:calc(50% - 50vw)!important;margin-right:calc(50% - 50vw)!important}}'
			. '@media (max-width:370px){.dlz-fv-ph{flex-basis:104px;width:104px;min-height:104px}.dlz-fv .dlz-fv-b h3{font-size:15px!important}}'
			. '@media (prefers-reduced-motion:reduce){.dlz-fv-card{animation:none}}'
			. '</style>';
	}

	public static function footer() {
		echo self::js(); // phpcs:ignore
	}

	private static function js() {
		return '<script id="dlz-fv-js">(function(){var d=document,r=d.querySelector(".dlz-fv");if(!r)return;'
			// the theme leaves an empty band above the page content: close it to the app header
			. 'function gap(){var h=d.getElementById("dsh-header");if(!h||!h.offsetHeight)return;var g=r.getBoundingClientRect().top-h.getBoundingClientRect().bottom,m=parseFloat(r.style.marginTop)||0;if(g>22&&g<400)r.style.marginTop=(m-(g-14))+"px";}gap();addEventListener("load",gap);'
			. 'r.addEventListener("click",function(e){var t=e.target;if(t.closest("a,button"))return;var c=t.closest(".dlz-fv-card");if(!c)return;var o=c.querySelector(".dlz-fv-o");if(o){o.click();return;}var h=c.getAttribute("data-href");if(h){location.href=h;}});'
			. 'r.addEventListener("keydown",function(e){if(e.key!=="Enter")return;var c=e.target.closest&&e.target.closest(".dlz-fv-card");if(c&&e.target===c)c.click();});'
			. 'd.addEventListener("dlz:favorite",function(){setTimeout(function(){r.querySelectorAll(".dlz-fv-card").forEach(function(c){var b=c.querySelector(".dlz-unified-favorite");if(b&&!b.classList.contains("is-favorite")&&!c.classList.contains("is-gone")){c.classList.add("is-gone");setTimeout(function(){c.remove();var n=r.querySelectorAll(".dlz-fv-card").length,s=r.querySelector(".dlz-fv-n");if(s){s.innerHTML="<b>"+n+"</b> "+(n===1?"مكان محفوظ":"أماكن محفوظة");s.hidden=!n;}if(!n)r.querySelector(".dlz-fv-empty").hidden=false;},260);}});},30);});'
			. '})();</script>';
	}
}
