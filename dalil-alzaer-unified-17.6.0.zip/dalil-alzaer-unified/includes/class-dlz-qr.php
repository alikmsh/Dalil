<?php
/**
 * Dalil Al Zaer — tiny QR code encoder (byte mode, error correction level M, versions 1–10).
 *
 * Used only for the «ورود دومرحله‌ای» set-up screen (the otpauth:// link for Google Authenticator,
 * Microsoft Authenticator …), so the secret never leaves the site for an online QR service.
 * Follows the ISO/IEC 18004 algorithm (Reed–Solomon over GF(256), interleaving, masking).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DLZ_QR {

	private static $ecc = array( -1, 10, 16, 26, 18, 24, 16, 18, 22, 22, 26 );   // ECC codewords per block (M)
	private static $blk = array( -1, 1, 1, 1, 2, 2, 4, 4, 4, 5, 5 );           // number of blocks (M)

	private $size;
	private $m = array();
	private $f = array();

	/** SVG markup of the QR code, or '' when the text is too long. */
	public static function svg( $text, $px = 220 ) {
		$q = new self();
		if ( ! $q->make( (string) $text ) ) {
			return '';
		}
		$n    = $q->size;
		$path = '';
		for ( $y = 0; $y < $n; $y++ ) {
			for ( $x = 0; $x < $n; $x++ ) {
				if ( $q->m[ $y ][ $x ] ) {
					$path .= 'M' . ( $x + 4 ) . ' ' . ( $y + 4 ) . 'h1v1h-1z';
				}
			}
		}
		$w = $n + 8;
		return '<svg xmlns="http://www.w3.org/2000/svg" width="' . (int) $px . '" height="' . (int) $px . '" viewBox="0 0 ' . $w . ' ' . $w . '" shape-rendering="crispEdges" role="img" aria-label="QR"><rect width="100%" height="100%" fill="#fff"/><path d="' . $path . '" fill="#000"/></svg>';
	}

	/** Matrix (rows of 0/1) — for tests. */
	public static function matrix( $text ) {
		$q = new self();
		return $q->make( (string) $text ) ? $q->m : array();
	}

	private static function raw_modules( $v ) {
		$r = ( 16 * $v + 128 ) * $v + 64;
		if ( $v >= 2 ) {
			$na = intdiv( $v, 7 ) + 2;
			$r -= ( 25 * $na - 10 ) * $na - 55;
			if ( $v >= 7 ) {
				$r -= 36;
			}
		}
		return $r;
	}

	private static function data_codewords( $v ) {
		return intdiv( self::raw_modules( $v ), 8 ) - self::$ecc[ $v ] * self::$blk[ $v ];
	}

	private function make( $text ) {
		$bytes = array_values( unpack( 'C*', $text ) ?: array() );
		$len   = count( $bytes );
		$ver   = 0;
		for ( $v = 1; $v <= 10; $v++ ) {
			$cc = $v < 10 ? 8 : 16;
			if ( 4 + $cc + 8 * $len <= self::data_codewords( $v ) * 8 ) {
				$ver = $v;
				break;
			}
		}
		if ( ! $ver ) {
			return false;
		}
		// data bits
		$bits = array();
		$put  = function ( $val, $n ) use ( &$bits ) {
			for ( $i = $n - 1; $i >= 0; $i-- ) {
				$bits[] = ( $val >> $i ) & 1;
			}
		};
		$put( 4, 4 );
		$put( $len, $ver < 10 ? 8 : 16 );
		foreach ( $bytes as $b ) {
			$put( $b, 8 );
		}
		$cap = self::data_codewords( $ver ) * 8;
		$put( 0, min( 4, $cap - count( $bits ) ) );
		$put( 0, ( 8 - count( $bits ) % 8 ) % 8 );
		for ( $pad = 0xEC; count( $bits ) < $cap; $pad ^= 0xEC ^ 0x11 ) {
			$put( $pad, 8 );
		}
		$data = array();
		for ( $i = 0; $i < count( $bits ); $i += 8 ) {
			$c = 0;
			for ( $j = 0; $j < 8; $j++ ) {
				$c = ( $c << 1 ) | $bits[ $i + $j ];
			}
			$data[] = $c;
		}
		$all = $this->ecc_interleave( $data, $ver );

		$this->size = $ver * 4 + 17;
		$n          = $this->size;
		$this->m    = array_fill( 0, $n, array_fill( 0, $n, 0 ) );
		$this->f    = array_fill( 0, $n, array_fill( 0, $n, false ) );
		$this->patterns( $ver );
		$this->codewords( $all );

		$best = 0;
		$min  = PHP_INT_MAX;
		for ( $k = 0; $k < 8; $k++ ) {
			$this->mask( $k );
			$this->format( $k );
			$p = $this->penalty();
			if ( $p < $min ) {
				$min  = $p;
				$best = $k;
			}
			$this->mask( $k ); // undo (xor)
		}
		$this->mask( $best );
		$this->format( $best );
		return true;
	}

	private function set( $x, $y, $dark ) {
		$this->m[ $y ][ $x ] = $dark ? 1 : 0;
		$this->f[ $y ][ $x ] = true;
	}

	private function patterns( $ver ) {
		$n = $this->size;
		for ( $i = 0; $i < $n; $i++ ) {
			$this->set( 6, $i, 0 === $i % 2 );
			$this->set( $i, 6, 0 === $i % 2 );
		}
		foreach ( array( array( 3, 3 ), array( $n - 4, 3 ), array( 3, $n - 4 ) ) as $c ) {
			for ( $dy = -4; $dy <= 4; $dy++ ) {
				for ( $dx = -4; $dx <= 4; $dx++ ) {
					$d  = max( abs( $dx ), abs( $dy ) );
					$xx = $c[0] + $dx;
					$yy = $c[1] + $dy;
					if ( $xx >= 0 && $xx < $n && $yy >= 0 && $yy < $n ) {
						$this->set( $xx, $yy, 2 !== $d && 4 !== $d );
					}
				}
			}
		}
		$pos = array();
		if ( $ver > 1 ) {
			$na   = intdiv( $ver, 7 ) + 2;
			$step = (int) ceil( ( $ver * 4 + 4 ) / ( $na * 2 - 2 ) ) * 2;
			$pos  = array( 6 );
			for ( $p = $n - 7; count( $pos ) < $na; $p -= $step ) {
				array_splice( $pos, 1, 0, array( $p ) );
			}
		}
		$c = count( $pos );
		for ( $i = 0; $i < $c; $i++ ) {
			for ( $j = 0; $j < $c; $j++ ) {
				if ( ( 0 === $i && 0 === $j ) || ( 0 === $i && $c - 1 === $j ) || ( $c - 1 === $i && 0 === $j ) ) {
					continue;
				}
				for ( $dy = -2; $dy <= 2; $dy++ ) {
					for ( $dx = -2; $dx <= 2; $dx++ ) {
						$this->set( $pos[ $i ] + $dx, $pos[ $j ] + $dy, 1 !== max( abs( $dx ), abs( $dy ) ) );
					}
				}
			}
		}
		$this->format( 0 ); // reserve
		if ( $ver >= 7 ) {
			$rem = $ver;
			for ( $i = 0; $i < 12; $i++ ) {
				$rem = ( $rem << 1 ) ^ ( ( $rem >> 11 ) * 0x1F25 );
			}
			$b = ( $ver << 12 ) | $rem;
			for ( $i = 0; $i < 18; $i++ ) {
				$bit = ( $b >> $i ) & 1;
				$a   = $n - 11 + $i % 3;
				$bb  = intdiv( $i, 3 );
				$this->set( $a, $bb, $bit );
				$this->set( $bb, $a, $bit );
			}
		}
	}

	private function format( $mask ) {
		$n    = $this->size;
		$data = ( 0 << 3 ) | $mask; // level M = 00
		$rem  = $data;
		for ( $i = 0; $i < 10; $i++ ) {
			$rem = ( $rem << 1 ) ^ ( ( $rem >> 9 ) * 0x537 );
		}
		$b   = ( ( $data << 10 ) | $rem ) ^ 0x5412;
		$bit = function ( $i ) use ( $b ) {
			return ( $b >> $i ) & 1;
		};
		for ( $i = 0; $i <= 5; $i++ ) {
			$this->set( 8, $i, $bit( $i ) );
		}
		$this->set( 8, 7, $bit( 6 ) );
		$this->set( 8, 8, $bit( 7 ) );
		$this->set( 7, 8, $bit( 8 ) );
		for ( $i = 9; $i < 15; $i++ ) {
			$this->set( 14 - $i, 8, $bit( $i ) );
		}
		for ( $i = 0; $i < 8; $i++ ) {
			$this->set( $n - 1 - $i, 8, $bit( $i ) );
		}
		for ( $i = 8; $i < 15; $i++ ) {
			$this->set( 8, $n - 15 + $i, $bit( $i ) );
		}
		$this->set( 8, $n - 8, 1 );
	}

	private static function gmul( $x, $y ) {
		$z = 0;
		for ( $i = 7; $i >= 0; $i-- ) {
			$z  = ( ( $z << 1 ) ^ ( ( $z >> 7 ) * 0x11D ) ) & 0xFF;
			$z ^= ( ( $y >> $i ) & 1 ) * $x;
		}
		return $z;
	}

	private static function rs_divisor( $deg ) {
		$r      = array_fill( 0, $deg, 0 );
		$r[ $deg - 1 ] = 1;
		$root   = 1;
		for ( $i = 0; $i < $deg; $i++ ) {
			for ( $j = 0; $j < $deg; $j++ ) {
				$r[ $j ] = self::gmul( $r[ $j ], $root );
				if ( $j + 1 < $deg ) {
					$r[ $j ] ^= $r[ $j + 1 ];
				}
			}
			$root = self::gmul( $root, 0x02 );
		}
		return $r;
	}

	private static function rs_rem( $data, $div ) {
		$r = array_fill( 0, count( $div ), 0 );
		foreach ( $data as $b ) {
			$f   = $b ^ array_shift( $r );
			$r[] = 0;
			foreach ( $div as $i => $d ) {
				$r[ $i ] ^= self::gmul( $d, $f );
			}
		}
		return $r;
	}

	private function ecc_interleave( $data, $ver ) {
		$nb    = self::$blk[ $ver ];
		$el    = self::$ecc[ $ver ];
		$raw   = intdiv( self::raw_modules( $ver ), 8 );
		$short = $nb - $raw % $nb;
		$slen  = intdiv( $raw, $nb );
		$div   = self::rs_divisor( $el );
		$blocks = array();
		$k      = 0;
		for ( $i = 0; $i < $nb; $i++ ) {
			$l   = $slen - $el + ( $i < $short ? 0 : 1 );
			$dat = array_slice( $data, $k, $l );
			$k  += $l;
			$e   = self::rs_rem( $dat, $div );
			if ( $i < $short ) {
				$dat[] = 0;
			}
			$blocks[] = array_merge( $dat, $e );
		}
		$out = array();
		$bl  = count( $blocks[0] );
		for ( $i = 0; $i < $bl; $i++ ) {
			foreach ( $blocks as $j => $b ) {
				if ( $i !== $slen - $el || $j >= $short ) {
					$out[] = $b[ $i ];
				}
			}
		}
		return $out;
	}

	private function codewords( $data ) {
		$n   = $this->size;
		$i   = 0;
		$tot = count( $data ) * 8;
		for ( $right = $n - 1; $right >= 1; $right -= 2 ) {
			if ( 6 === $right ) {
				$right = 5;
			}
			for ( $vert = 0; $vert < $n; $vert++ ) {
				for ( $j = 0; $j < 2; $j++ ) {
					$x  = $right - $j;
					$up = 0 === ( ( $right + 1 ) & 2 );
					$y  = $up ? $n - 1 - $vert : $vert;
					if ( ! $this->f[ $y ][ $x ] && $i < $tot ) {
						$this->m[ $y ][ $x ] = ( $data[ $i >> 3 ] >> ( 7 - ( $i & 7 ) ) ) & 1;
						$i++;
					}
				}
			}
		}
	}

	private function mask( $k ) {
		$n = $this->size;
		for ( $y = 0; $y < $n; $y++ ) {
			for ( $x = 0; $x < $n; $x++ ) {
				if ( $this->f[ $y ][ $x ] ) {
					continue;
				}
				switch ( $k ) {
					case 0: $inv = 0 === ( $x + $y ) % 2; break;
					case 1: $inv = 0 === $y % 2; break;
					case 2: $inv = 0 === $x % 3; break;
					case 3: $inv = 0 === ( $x + $y ) % 3; break;
					case 4: $inv = 0 === ( intdiv( $x, 3 ) + intdiv( $y, 2 ) ) % 2; break;
					case 5: $inv = 0 === $x * $y % 2 + $x * $y % 3; break;
					case 6: $inv = 0 === ( $x * $y % 2 + $x * $y % 3 ) % 2; break;
					default: $inv = 0 === ( ( $x + $y ) % 2 + $x * $y % 3 ) % 2;
				}
				if ( $inv ) {
					$this->m[ $y ][ $x ] ^= 1;
				}
			}
		}
	}

	/** Simplified penalty (runs, 2×2 blocks, dark balance) — enough to pick a readable mask. */
	private function penalty() {
		$n = $this->size;
		$p = 0;
		$dark = 0;
		for ( $y = 0; $y < $n; $y++ ) {
			$rx = 1;
			$ry = 1;
			for ( $x = 0; $x < $n; $x++ ) {
				$dark += $this->m[ $y ][ $x ];
				if ( $x > 0 ) {
					if ( $this->m[ $y ][ $x ] === $this->m[ $y ][ $x - 1 ] ) {
						$rx++;
						if ( 5 === $rx ) {
							$p += 3;
						} elseif ( $rx > 5 ) {
							$p++;
						}
					} else {
						$rx = 1;
					}
					if ( $this->m[ $x ][ $y ] === $this->m[ $x - 1 ][ $y ] ) {
						$ry++;
						if ( 5 === $ry ) {
							$p += 3;
						} elseif ( $ry > 5 ) {
							$p++;
						}
					} else {
						$ry = 1;
					}
				}
				if ( $x > 0 && $y > 0 ) {
					$c = $this->m[ $y ][ $x ];
					if ( $c === $this->m[ $y ][ $x - 1 ] && $c === $this->m[ $y - 1 ][ $x ] && $c === $this->m[ $y - 1 ][ $x - 1 ] ) {
						$p += 3;
					}
				}
			}
		}
		$tot = $n * $n;
		$k   = (int) ceil( abs( $dark * 20 - $tot * 10 ) / $tot ) - 1;
		return $p + max( 0, $k ) * 10;
	}
}
