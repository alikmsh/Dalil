<?php
/**
 * Dalil Al Zaer — the page title is the text of the icon that opens the page (17.4).
 *
 * The home page icons («الجولات والزيارات», «مراكز الترفيه», «الخدمات القانونية» …) are read from the
 * home page (HTML widget / Elementor / blocks): every «<a href=PAGE> … <span class="dz-lb">LABEL</span>»
 * maps PAGE → LABEL. The page title bar and the first title of the page's own widget then show LABEL,
 * so the icon and the header always match. The map is cached and rebuilt when a page is saved.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DLZ_Labels {

	const OPT = 'dlz_icon_labels';

	public static function init() {
		add_action( 'save_post_page', array( __CLASS__, 'flush' ) );
		add_action( 'elementor/editor/after_save', array( __CLASS__, 'flush' ) );
		add_action( 'update_option_page_on_front', array( __CLASS__, 'flush' ) );
	}

	public static function flush() {
		delete_option( self::OPT );
	}

	/** Slug path of a link («/الجولات/» → «الجولات»), host ignored. */
	private static function path( $url ) {
		$p = (string) wp_parse_url( html_entity_decode( (string) $url ), PHP_URL_PATH );
		$p = rawurldecode( $p );
		$p = trim( preg_replace( '#/+#', '/', $p ), '/' );
		// a sub-folder install: drop the home path
		$home = trim( (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH ), '/' );
		if ( '' !== $home && 0 === strpos( $p, $home . '/' ) ) {
			$p = substr( $p, strlen( $home ) + 1 );
		}
		return mb_strtolower( $p );
	}

	/** All strings of an Elementor data tree. */
	private static function strings( $node, &$out ) {
		if ( is_string( $node ) ) {
			if ( false !== strpos( $node, 'dz-lb' ) ) {
				$out[] = $node;
			}
			return;
		}
		if ( is_array( $node ) || is_object( $node ) ) {
			foreach ( (array) $node as $v ) {
				self::strings( $v, $out );
			}
		}
	}

	/** [url, title] of the repeater items of our icon widgets. */
	private static function items( $node, &$out, $in = false ) {
		if ( ! is_array( $node ) ) {
			return;
		}
		if ( isset( $node['widgetType'] ) && is_string( $node['widgetType'] ) ) {
			$in = (bool) preg_match( '/^dlz_(sec_|cat_grid|circle_services)/', $node['widgetType'] );
		}
		if ( $in && isset( $node['title'], $node['link']['url'] ) && is_string( $node['title'] ) && '' !== trim( (string) $node['link']['url'] ) && '' !== trim( $node['title'] ) ) {
			$out[] = array( (string) $node['link']['url'], trim( wp_strip_all_tags( $node['title'] ) ) );
		}
		foreach ( $node as $v ) {
			self::items( $v, $out, $in );
		}
	}

	/** page id => label */
	public static function map() {
		static $map = null;
		if ( null !== $map ) {
			return $map;
		}
		$c = get_option( self::OPT );
		if ( is_array( $c ) && isset( $c['v'] ) && 2 === $c['v'] ) {
			return $map = $c['m'];
		}
		$map  = array();
		$html = array();
		$ids  = array();
		$front = (int) get_option( 'page_on_front' );
		if ( $front ) {
			$ids[] = $front;
		}
		// any page holding the icon grid (the HTML widget can live on another page or a template)
		global $wpdb;
		$more = $wpdb->get_col( "SELECT DISTINCT p.ID FROM {$wpdb->posts} p LEFT JOIN {$wpdb->postmeta} m ON m.post_id=p.ID AND m.meta_key='_elementor_data' WHERE p.post_status='publish' AND p.post_type IN ('page','elementor_library','wp_block') AND (p.post_content LIKE '%dz-lb%' OR m.meta_value LIKE '%dz-lb%') LIMIT 30" ); // phpcs:ignore
		$ids  = array_values( array_unique( array_merge( $ids, array_map( 'intval', (array) $more ) ) ) );
		foreach ( $ids as $id ) {
			$html[] = (string) get_post_field( 'post_content', $id );
			$el     = get_post_meta( $id, '_elementor_data', true );
			if ( is_string( $el ) && false !== strpos( $el, 'dz-lb' ) ) {
				$tree = json_decode( $el, true );
				$found = array();
				self::strings( $tree, $found );
				$html = array_merge( $html, $found );
			}
		}
		foreach ( $html as $h ) {
			if ( ! preg_match_all( '#<a\b[^>]*\bhref\s*=\s*["\']([^"\']+)["\'][^>]*>(.*?)</a>#is', $h, $mm, PREG_SET_ORDER ) ) {
				continue;
			}
			foreach ( $mm as $m ) {
				if ( ! preg_match( '#class\s*=\s*["\'][^"\']*\bdz-lb\b[^"\']*["\'][^>]*>(.*?)</#is', $m[2], $lb ) ) {
					continue;
				}
				$label = trim( preg_replace( '/\s+/u', ' ', wp_strip_all_tags( html_entity_decode( $lb[1], ENT_QUOTES, 'UTF-8' ) ) ) );
				$path  = self::path( $m[1] );
				if ( '' === $label || '' === $path || '#' === $m[1] ) {
					continue;
				}
				$page = get_page_by_path( $path );
				if ( ! $page ) {
					// the slug may be stored url-encoded
					$page = get_page_by_path( implode( '/', array_map( 'rawurlencode', explode( '/', $path ) ) ) );
				}
				if ( $page && ! isset( $map[ $page->ID ] ) ) {
					$map[ $page->ID ] = $label;
				}
			}
		}
		// then the icons of our section widgets (أقسام / شبكة الأقسام / خدمات دائرية) with a typed link
		$pages = $wpdb->get_col( "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key='_elementor_data' AND (meta_value LIKE '%dlz_sec_%' OR meta_value LIKE '%dlz_cat_grid%' OR meta_value LIKE '%dlz_circle_services%') LIMIT 200" ); // phpcs:ignore
		foreach ( (array) $pages as $pid ) {
			$tree = json_decode( (string) get_post_meta( (int) $pid, '_elementor_data', true ), true );
			$items = array();
			self::items( $tree, $items );
			foreach ( $items as $it ) {
				$page = get_page_by_path( self::path( $it[0] ) );
				if ( $page && ! isset( $map[ $page->ID ] ) ) {
					$map[ $page->ID ] = $it[1];
				}
			}
		}
		update_option( self::OPT, array( 'v' => 2, 'm' => $map ), true );
		return $map;
	}

	/** The icon text of a page ('' when no icon opens it). */
	public static function of( $page_id = 0 ) {
		$page_id = $page_id ? (int) $page_id : ( is_singular() ? (int) get_queried_object_id() : 0 );
		if ( ! $page_id ) {
			return '';
		}
		$m = self::map();
		return isset( $m[ $page_id ] ) ? (string) $m[ $page_id ] : '';
	}

	/**
	 * The page-level title of a widget: the icon text replaces the first one drawn on a page that an icon
	 * opens (later section titles of the same page stay as they are).
	 */
	public static function heading( $title ) {
		static $used = false;
		if ( $used || is_admin() || wp_doing_ajax() ) {
			return $title;
		}
		$l = self::of();
		if ( '' === $l ) {
			return $title;
		}
		$used = true;
		return $l;
	}
}
DLZ_Labels::init();
