<?php
/**
 * Dalil Al Zaer — «امنیت سایت».
 *
 * One place for the site's protection, and one dashboard page (with a tile on the Dashboard) that
 * checks the 27 items of the security list live:
 *  - login: limited tries (5 a minute per connection, then longer and longer locks), the same
 *    message for a wrong user and a wrong password, a 15-minute single-use reset link, and
 *    two-step login (Google / Microsoft Authenticator codes + backup codes) for staff accounts;
 *  - passwords stored with Argon2id (WordPress re-hashes each one at the next login);
 *  - session cookies HttpOnly + Secure + SameSite, HTTPS forced, HSTS, security headers, CORS and
 *    cross-site (CSRF) requests limited to this site's own address;
 *  - customers who open /wp-admin get «403»; XML-RPC off; error details hidden from visitors;
 *  - leaked files (.env, backups, .git, debug.log …) answered with 404, uploads checked by type,
 *    content and size, private documents (medical files) kept out of the public uploads folder;
 *  - SMS and Servix secrets stored encrypted;
 *  - a log of suspicious activity (failed logins, locks, foreign requests, file probes, new admins).
 *
 * Emergency switch (in wp-config.php):  define( 'DLZ_SEC_OFF', true );   — everything here stops.
 * Only two-step login:                  define( 'DLZ_2FA_OFF', true );
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DLZ_Security {

	const OPT  = 'dlz_security';
	const VER  = 3;
	const CAP  = 'manage_options';
	const SLUG = 'dlz-security';

	private static $raw_caps = false;   // true while asking WordPress for the real capabilities
	private static $o        = null;
	private static $verified = array();

	/* =========================================================
	 * Settings
	 * ======================================================= */

	public static function defaults() {
		return array(
			'login_limit' => 1,
			'login_max'   => 5,
			'admin_lock'  => 1,
			'twofa_force' => 0,
			'argon'       => 1,
			'reset15'     => 1,
			'cookies'     => 1,
			'https'       => 1,
			'hsts'        => 1,
			'headers'     => 1,
			'csp'         => 1,
			'cors'        => 1,
			'csrf'        => 1,
			'origins'     => '',
			'debug_hide'  => 1,
			'files'       => 1,
			'uploads'     => 1,
			'upload_mb'   => 16,
			'xmlrpc'      => 1,
			'alert'       => 1,
		);
	}

	public static function opt( $k = null ) {
		if ( null === self::$o ) {
			self::$o = wp_parse_args( (array) get_option( self::OPT, array() ), self::defaults() );
		}
		return null === $k ? self::$o : ( isset( self::$o[ $k ] ) ? self::$o[ $k ] : null );
	}

	public static function off() {
		return defined( 'DLZ_SEC_OFF' ) && DLZ_SEC_OFF;
	}

	/* =========================================================
	 * Boot
	 * ======================================================= */

	public static function boot() {
		// behind Cloudflare / a proxy the site is still HTTPS
		self::normalize_https();
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 12 );
		add_action( 'admin_post_dlz_sec_save', array( __CLASS__, 'save' ) );
		add_action( 'admin_post_dlz_sec_scan', array( __CLASS__, 'scan_now' ) );
		add_action( 'admin_post_dlz_sec_2fa', array( __CLASS__, 'twofa_action' ) );
		add_action( 'admin_post_dlz_sec_tool', array( __CLASS__, 'tool' ) );
		add_action( 'admin_post_dlz_private_file', array( __CLASS__, 'private_file' ) );
		add_action( 'admin_init', array( __CLASS__, 'upgrade' ), 2 );
		if ( self::off() ) {
			return;
		}

		/* --- login */
		add_filter( 'authenticate', array( __CLASS__, 'auth_gate' ), 30, 3 );
		add_filter( 'authenticate', array( __CLASS__, 'auth_generic' ), 99, 3 );
		add_action( 'wp_login_failed', array( __CLASS__, 'login_failed' ), 10, 2 );
		add_action( 'wp_login', array( __CLASS__, 'login_ok' ), 10, 2 );
		add_action( 'lostpassword_post', array( __CLASS__, 'lostpassword_limit' ), 10, 2 );
		if ( self::opt( 'reset15' ) ) {
			add_filter( 'password_reset_expiration', array( __CLASS__, 'reset_ttl' ) );
		}
		add_action( 'after_password_reset', array( __CLASS__, 'after_reset' ) );
		if ( self::opt( 'argon' ) && defined( 'PASSWORD_ARGON2ID' ) ) {
			add_filter( 'wp_hash_password_algorithm', array( __CLASS__, 'argon' ) );
		}

		/* --- two-step login */
		if ( ! self::twofa_disabled() ) {
			add_filter( 'user_has_cap', array( __CLASS__, 'caps' ), 999, 4 );
			add_action( 'login_form_dlz2fa', array( __CLASS__, 'challenge' ) );
		}
		add_action( 'admin_init', array( __CLASS__, 'admin_gate' ), 0 );
		add_action( 'admin_page_access_denied', array( __CLASS__, 'admin_gate' ), 0 ); // menu.php refuses pages before admin_init
		add_action( 'admin_notices', array( __CLASS__, 'notice' ) );

		/* --- cookies, HTTPS, headers */
		if ( self::opt( 'cookies' ) ) {
			self::cookie_flags();
		}
		add_action( 'template_redirect', array( __CLASS__, 'force_https' ), 0 );
		add_action( 'login_init', array( __CLASS__, 'force_https' ), 0 );
		add_action( 'send_headers', array( __CLASS__, 'headers' ), 20 );
		add_action( 'login_init', array( __CLASS__, 'headers_basic' ), 1 );
		add_action( 'admin_init', array( __CLASS__, 'headers_basic' ), 1 );
		add_filter( 'wp_headers', array( __CLASS__, 'strip_headers' ) );

		/* --- CORS + cross-site requests */
		if ( self::opt( 'cors' ) ) {
			add_action( 'rest_api_init', array( __CLASS__, 'cors_setup' ), 15 );
		}
		add_filter( 'allowed_http_origins', array( __CLASS__, 'allowed_origins' ) );
		if ( self::opt( 'csrf' ) ) {
			add_action( 'admin_init', array( __CLASS__, 'csrf' ), -1 );
			add_action( 'login_init', array( __CLASS__, 'csrf' ), 0 );
		}

		/* --- debug, XML-RPC, probes, uploads */
		if ( self::opt( 'debug_hide' ) ) {
			self::hide_errors();
		}
		if ( self::opt( 'xmlrpc' ) ) {
			add_filter( 'xmlrpc_enabled', '__return_false' );
			add_filter( 'xmlrpc_methods', '__return_empty_array' );
			add_action( 'plugins_loaded', array( __CLASS__, 'xmlrpc_block' ), 0 );
			remove_action( 'wp_head', 'rsd_link' );
		}
		add_action( 'template_redirect', array( __CLASS__, 'probe_404' ), 99 );
		if ( self::opt( 'uploads' ) ) {
			add_filter( 'wp_handle_upload_prefilter', array( __CLASS__, 'upload_check' ) );
			add_filter( 'wp_handle_sideload_prefilter', array( __CLASS__, 'upload_check' ) );
		}

		/* --- watch */
		add_action( 'set_user_role', array( __CLASS__, 'role_watch' ), 10, 3 );
		add_action( 'user_register', array( __CLASS__, 'user_watch' ), 20 );
		add_action( 'activated_plugin', array( __CLASS__, 'plugin_watch' ) );
		add_filter( 'show_admin_bar', array( __CLASS__, 'admin_bar' ), 50 );
		add_filter( 'login_redirect', array( __CLASS__, 'login_redirect' ), 50, 3 );
	}

	/* =========================================================
	 * Helpers
	 * ======================================================= */

	/** The visitor's address (Cloudflare's real address when the request came through Cloudflare). */
	public static function ip() {
		static $ip = null;
		if ( null !== $ip ) {
			return $ip;
		}
		$r  = isset( $_SERVER['REMOTE_ADDR'] ) ? (string) $_SERVER['REMOTE_ADDR'] : ''; // phpcs:ignore
		$ip = $r;
		if ( ! empty( $_SERVER['HTTP_CF_CONNECTING_IP'] ) && self::is_cloudflare( $r ) ) {
			$c = trim( (string) $_SERVER['HTTP_CF_CONNECTING_IP'] ); // phpcs:ignore
			if ( filter_var( $c, FILTER_VALIDATE_IP ) ) {
				$ip = $c;
			}
		}
		$ip = preg_replace( '/[^0-9a-f:.]/i', '', $ip );
		return $ip;
	}

	private static function is_cloudflare( $ip ) {
		$nets = array( '173.245.48.0/20', '103.21.244.0/22', '103.22.200.0/22', '103.31.4.0/22', '141.101.64.0/18', '108.162.192.0/18', '190.93.240.0/20', '188.114.96.0/20', '197.234.240.0/22', '198.41.128.0/17', '162.158.0.0/15', '104.16.0.0/13', '104.24.0.0/14', '172.64.0.0/13', '131.0.72.0/22', '2400:cb00::/32', '2606:4700::/32', '2803:f800::/32', '2405:b500::/32', '2405:8100::/32', '2a06:98c0::/29', '2c0f:f248::/32' );
		$bin  = @inet_pton( $ip ); // phpcs:ignore
		if ( false === $bin ) {
			return false;
		}
		foreach ( $nets as $n ) {
			list( $net, $bits ) = explode( '/', $n );
			$nb = @inet_pton( $net ); // phpcs:ignore
			if ( false === $nb || strlen( $nb ) !== strlen( $bin ) ) {
				continue;
			}
			$bytes = intdiv( (int) $bits, 8 );
			$rest  = (int) $bits % 8;
			if ( substr( $bin, 0, $bytes ) !== substr( $nb, 0, $bytes ) ) {
				continue;
			}
			if ( $rest ) {
				$mask = chr( ( 0xFF << ( 8 - $rest ) ) & 0xFF );
				if ( ( $bin[ $bytes ] & $mask ) !== ( $nb[ $bytes ] & $mask ) ) {
					continue;
				}
			}
			return true;
		}
		return false;
	}

	private static function normalize_https() {
		if ( ! empty( $_SERVER['HTTPS'] ) && 'off' !== strtolower( (string) $_SERVER['HTTPS'] ) ) { // phpcs:ignore
			return;
		}
		$fp  = strtolower( isset( $_SERVER['HTTP_X_FORWARDED_PROTO'] ) ? (string) $_SERVER['HTTP_X_FORWARDED_PROTO'] : '' ); // phpcs:ignore
		$cfv = isset( $_SERVER['HTTP_CF_VISITOR'] ) ? (string) $_SERVER['HTTP_CF_VISITOR'] : ''; // phpcs:ignore
		$ssl = isset( $_SERVER['HTTP_X_FORWARDED_SSL'] ) ? strtolower( (string) $_SERVER['HTTP_X_FORWARDED_SSL'] ) : ''; // phpcs:ignore
		if ( 0 === strpos( $fp, 'https' ) || false !== strpos( $cfv, '"https"' ) || 'on' === $ssl ) {
			$_SERVER['HTTPS']       = 'on';
			$_SERVER['SERVER_PORT'] = 443;
		}
	}

	/** Can the user really do it (ignores the «waiting for the two-step code» limit). */
	public static function real_can( $cap, $uid = 0 ) {
		self::$raw_caps = true;
		$ok             = $uid ? user_can( $uid, $cap ) : current_user_can( $cap );
		self::$raw_caps = false;
		return $ok;
	}

	private static function home_hosts() {
		$h = array();
		foreach ( array( home_url(), site_url(), admin_url() ) as $u ) {
			$x = wp_parse_url( $u, PHP_URL_HOST );
			if ( $x ) {
				$x   = strtolower( $x );
				$h[] = $x;
				$h[] = 0 === strpos( $x, 'www.' ) ? substr( $x, 4 ) : 'www.' . $x;
			}
		}
		foreach ( preg_split( '/[\s,]+/', (string) self::opt( 'origins' ) ) as $o ) {
			$x = wp_parse_url( trim( $o ), PHP_URL_HOST );
			if ( ! $x && '' !== trim( $o ) && false === strpos( $o, '/' ) ) {
				$x = trim( $o );
			}
			if ( $x ) {
				$h[] = strtolower( $x );
			}
		}
		return array_values( array_unique( $h ) );
	}

	/**
	 * A request may come from this site, from the app (file://, capacitor://, https://localhost …)
	 * or with no origin at all; any other website is foreign.
	 */
	public static function origin_ok( $origin ) {
		$o = strtolower( trim( (string) $origin ) );
		if ( '' === $o || 'null' === $o ) {
			return true;
		}
		$scheme = preg_match( '#^([a-z][a-z0-9+.\-]*):#', $o, $mm ) ? $mm[1] : '';
		if ( '' !== $scheme && ! in_array( $scheme, array( 'http', 'https' ), true ) ) {
			return true;
		}
		$host = strtolower( (string) wp_parse_url( $o, PHP_URL_HOST ) );
		if ( in_array( $host, array( 'localhost', '127.0.0.1', '::1', 'appassets.androidplatform.net' ), true ) ) {
			return true;
		}
		return '' !== $host && in_array( $host, self::home_hosts(), true );
	}

	/* ------------------------------------------------------------ secrets at rest */

	private static function key() {
		$k = defined( 'DLZ_SECRET_KEY' ) ? DLZ_SECRET_KEY : ( ( defined( 'AUTH_KEY' ) ? AUTH_KEY : '' ) . ( defined( 'SECURE_AUTH_KEY' ) ? SECURE_AUTH_KEY : '' ) );
		return hash( 'sha256', 'dlz-sec|' . $k, true );
	}

	/** Encrypt a secret before it is saved in the database. */
	public static function seal( $plain ) {
		$plain = (string) $plain;
		if ( '' === $plain || 0 === strpos( $plain, 'dlzenc:' ) || ! function_exists( 'sodium_crypto_secretbox' ) ) {
			return $plain;
		}
		$n = random_bytes( SODIUM_CRYPTO_SECRETBOX_NONCEBYTES );
		return 'dlzenc:' . base64_encode( $n . sodium_crypto_secretbox( $plain, $n, self::key() ) ); // phpcs:ignore
	}

	/** Read a secret saved with seal() (old plain values are returned as they are). */
	public static function unseal( $v ) {
		$v = (string) $v;
		if ( 0 !== strpos( $v, 'dlzenc:' ) ) {
			return $v;
		}
		$raw = base64_decode( substr( $v, 7 ), true ); // phpcs:ignore
		if ( ! $raw || strlen( $raw ) <= SODIUM_CRYPTO_SECRETBOX_NONCEBYTES || ! function_exists( 'sodium_crypto_secretbox_open' ) ) {
			return '';
		}
		$p = sodium_crypto_secretbox_open( substr( $raw, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES ), substr( $raw, 0, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES ), self::key() );
		return false === $p ? '' : $p;
	}

	/* =========================================================
	 * Log
	 * ======================================================= */

	private static function table() {
		global $wpdb;
		return $wpdb->prefix . 'dlz_sec_log';
	}

	public static function types() {
		return array(
			'login_fail' => array( 'ورود ناموفق', '#B45309' ),
			'lock'       => array( 'قفل موقت به‌خاطر تلاش زیاد', '#DC2626' ),
			'login_ok'   => array( 'ورود مدیر / کارمند', '#0F8A5F' ),
			'2fa_fail'   => array( 'کد دومرحله‌ای اشتباه', '#DC2626' ),
			'2fa'        => array( 'ورود دومرحله‌ای', '#0F8A5F' ),
			'admin403'   => array( 'کاربر عادی در پیشخوان (403)', '#7C3AED' ),
			'csrf'       => array( 'درخواست از سایت دیگر (رد شد)', '#DC2626' ),
			'cors'       => array( 'دسترسی از دامنه‌ی دیگر (رد شد)', '#B45309' ),
			'flood'      => array( 'درخواست‌های پشت‌سرهم (رد شد)', '#B45309' ),
			'probe'      => array( 'جستجوی فایل حساس', '#DC2626' ),
			'xmlrpc'     => array( 'درخواست XML-RPC (رد شد)', '#B45309' ),
			'upload'     => array( 'فایل آپلودی رد شد', '#B45309' ),
			'admin_new'  => array( 'مدیر جدید ساخته شد', '#DC2626' ),
			'plugin'     => array( 'افزونه فعال شد', '#0369A1' ),
			'reset'      => array( 'بازیابی رمز', '#0369A1' ),
			'settings'   => array( 'تغییر تنظیمات امنیت', '#0369A1' ),
		);
	}

	public static function install() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$c = $wpdb->get_charset_collate();
		dbDelta( 'CREATE TABLE ' . self::table() . " (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			t int(10) unsigned NOT NULL DEFAULT 0,
			type varchar(20) NOT NULL DEFAULT '',
			lvl tinyint(3) unsigned NOT NULL DEFAULT 1,
			ip varchar(45) NOT NULL DEFAULT '',
			uid bigint(20) unsigned NOT NULL DEFAULT 0,
			who varchar(60) NOT NULL DEFAULT '',
			msg varchar(255) NOT NULL DEFAULT '',
			PRIMARY KEY  (id),
			KEY t (t),
			KEY type (type)
		) {$c};" );
	}

	/**
	 * Write one line. $lvl: 1 info, 2 warning, 3 critical (critical ones also reach «درخواست‌های جدید»).
	 */
	public static function log( $type, $msg = '', $lvl = 1, $who = '' ) {
		global $wpdb;
		if ( (int) get_option( 'dlz_sec_db', 0 ) < self::VER ) {
			return;
		}
		$wpdb->insert( // phpcs:ignore
			self::table(),
			array(
				't'    => time(),
				'type' => substr( (string) $type, 0, 20 ),
				'lvl'  => (int) $lvl,
				'ip'   => substr( self::ip(), 0, 45 ),
				'uid'  => get_current_user_id(),
				'who'  => mb_substr( sanitize_text_field( (string) $who ), 0, 60 ),
				'msg'  => mb_substr( sanitize_text_field( (string) $msg ), 0, 250 ),
			),
			array( '%d', '%s', '%d', '%s', '%d', '%s', '%s' )
		);
		if ( 0 === wp_rand( 0, 60 ) ) {
			$max = (int) $wpdb->get_var( 'SELECT MAX(id) FROM ' . self::table() ); // phpcs:ignore
			if ( $max > 4000 ) {
				$wpdb->query( $wpdb->prepare( 'DELETE FROM ' . self::table() . ' WHERE id < %d', $max - 4000 ) ); // phpcs:ignore
			}
		}
		if ( $lvl >= 3 && self::opt( 'alert' ) && class_exists( 'DLZ_Inbox' ) ) {
			$ty = self::types();
			DLZ_Inbox::add( 'security', ( isset( $ty[ $type ] ) ? $ty[ $type ][0] : $type ) . ( $who ? ' — ' . $who : '' ), $msg . ' · IP ' . self::ip(), admin_url( 'admin.php?page=' . self::SLUG . '&tab=log' ), 'sec-' . $type . '-' . md5( $who . self::ip() ) );
		}
	}

	/** Log a repeated event once per window (a flood would otherwise fill the log). */
	public static function log_once( $key, $ttl, $type, $msg, $lvl = 1, $who = '' ) {
		$k = 'dlz_sec_lo_' . md5( $key . '|' . self::ip() );
		if ( get_transient( $k ) ) {
			return;
		}
		set_transient( $k, 1, $ttl );
		self::log( $type, $msg, $lvl, $who );
	}

	/* =========================================================
	 * Upgrade (on version change)
	 * ======================================================= */

	public static function upgrade() {
		if ( (int) get_option( 'dlz_sec_db', 0 ) >= self::VER ) {
			return;
		}
		self::install();
		update_option( 'dlz_sec_db', self::VER );
		// existing plain secrets → encrypted
		$m = get_option( 'mp_sms_login_options' );
		if ( is_array( $m ) && ! empty( $m['password'] ) && 0 !== strpos( $m['password'], 'dlzenc:' ) ) {
			$m['password'] = self::seal( $m['password'] );
			update_option( 'mp_sms_login_options', $m );
		}
		$c = get_option( 'dalil_cr_options' );
		if ( is_array( $c ) && ! empty( $c['api_key'] ) && 0 !== strpos( $c['api_key'], 'dlzenc:' ) ) {
			$c['api_key'] = self::seal( $c['api_key'] );
			update_option( 'dalil_cr_options', $c );
		}
		self::htaccess();
		self::private_dir();
	}

	/* =========================================================
	 * Login: limits, generic errors, reset link
	 * ======================================================= */

	private static function lock_left() {
		$until = (int) get_transient( 'dlz_lk_' . md5( self::ip() ) );
		return $until > time() ? $until - time() : 0;
	}

	private static function wait_text( $s ) {
		return $s < 90 ? 'یک دقیقه' : ( (int) ceil( $s / 60 ) . ' دقیقه' );
	}

	public static function auth_gate( $user, $username, $password ) {
		if ( ! self::opt( 'login_limit' ) || ( '' === (string) $username && '' === (string) $password ) ) {
			return $user;
		}
		$left = self::lock_left();
		if ( $left ) {
			return new WP_Error( 'dlz_locked', '<strong>تعداد تلاش‌ها زیاد بود.</strong> برای امنیت حساب‌ها، ورود از این اتصال ' . self::wait_text( $left ) . ' بسته است.' );
		}
		$uk = (int) get_transient( 'dlz_luk_' . md5( strtolower( (string) $username ) ) );
		if ( $uk > time() ) {
			return new WP_Error( 'dlz_locked', '<strong>تلاش‌های زیادی برای این حساب انجام شده است.</strong> لطفاً ' . self::wait_text( $uk - time() ) . ' دیگر دوباره امتحان کنید.' );
		}
		return $user;
	}

	/** Same message for an unknown user and a wrong password (nobody can test which accounts exist). */
	public static function auth_generic( $user, $username, $password ) {
		if ( is_wp_error( $user ) && array_intersect( $user->get_error_codes(), array( 'invalid_username', 'incorrect_password', 'invalid_email', 'invalidcombo' ) ) ) {
			return new WP_Error( 'dlz_bad_login', '<strong>خطا:</strong> نام کاربری یا رمز عبور درست نیست.' );
		}
		return $user;
	}

	public static function login_failed( $username, $error = null ) {
		$name  = mb_substr( sanitize_user( (string) $username, true ), 0, 60 );
		$u     = $name ? ( get_user_by( 'login', $name ) ?: get_user_by( 'email', $name ) ) : false;
		$admin = $u && self::real_can( 'edit_posts', $u->ID );
		if ( $error instanceof WP_Error && in_array( 'dlz_locked', $error->get_error_codes(), true ) ) {
			return; // already locked: no new count
		}
		self::log( 'login_fail', $admin ? 'رمز اشتباه برای حساب مدیریتی' : ( $u ? 'رمز اشتباه' : 'نام کاربری ناشناخته' ), $admin ? 2 : 1, $name );
		if ( ! self::opt( 'login_limit' ) ) {
			return;
		}
		$ip  = md5( self::ip() );
		$max = max( 3, min( 20, (int) self::opt( 'login_max' ) ) );
		$w   = get_transient( 'dlz_lf_' . $ip );
		$w   = is_array( $w ) && $w[1] > time() - 60 ? $w : array( 0, time() );
		$w[0]++;
		set_transient( 'dlz_lf_' . $ip, $w, 60 );
		if ( $w[0] >= $max ) {
			$lvl  = (int) get_transient( 'dlz_ll_' . $ip ) + 1;
			$secs = array( 1 => 60, 2 => 300, 3 => 900 );
			$dur  = isset( $secs[ $lvl ] ) ? $secs[ $lvl ] : 3600;
			set_transient( 'dlz_ll_' . $ip, $lvl, DAY_IN_SECONDS );
			set_transient( 'dlz_lk_' . $ip, time() + $dur, $dur );
			delete_transient( 'dlz_lf_' . $ip );
			self::log( 'lock', $w[0] . ' تلاش ناموفق در یک دقیقه — ' . self::wait_text( $dur ) . ' قفل (مرحله ' . $lvl . ')', $admin || $lvl >= 3 ? 3 : 2, $name );
		}
		// many wrong passwords for one account from anywhere: slow that account down
		if ( $u ) {
			$k = 'dlz_luf_' . md5( strtolower( $name ) );
			$n = (int) get_transient( $k ) + 1;
			set_transient( $k, $n, 15 * MINUTE_IN_SECONDS );
			if ( $n >= 10 ) {
				set_transient( 'dlz_luk_' . md5( strtolower( $name ) ), time() + 60, 60 );
				delete_transient( $k );
			}
		}
	}

	public static function login_ok( $login, $user ) {
		delete_transient( 'dlz_lf_' . md5( self::ip() ) );
		if ( $user instanceof WP_User && self::real_can( 'edit_posts', $user->ID ) ) {
			self::log( 'login_ok', self::is_on( $user->ID ) ? 'رمز درست — منتظر کد دومرحله‌ای' : 'ورود با رمز', 1, $login );
		}
	}

	public static function lostpassword_limit( $errors, $user = null ) {
		$k = 'dlz_lp_' . md5( self::ip() );
		$n = (int) get_transient( $k ) + 1;
		set_transient( $k, $n, 15 * MINUTE_IN_SECONDS );
		if ( $n > 5 && $errors instanceof WP_Error ) {
			$errors->add( 'dlz_locked', '<strong>درخواست‌های بازیابی زیاد بود.</strong> لطفاً ۱۵ دقیقه دیگر امتحان کنید.' );
			self::log_once( 'lp', 900, 'reset', 'درخواست‌های بازیابی رمز پشت‌سرهم', 2 );
		} elseif ( $user instanceof WP_User ) {
			self::log( 'reset', 'لینک بازیابی رمز درخواست شد (۱۵ دقیقه اعتبار)', 1, $user->user_login );
		}
	}

	public static function reset_ttl() {
		return 15 * MINUTE_IN_SECONDS;
	}

	/** After a new password: every old session of that user is closed. */
	public static function after_reset( $user ) {
		if ( $user instanceof WP_User ) {
			WP_Session_Tokens::get_instance( $user->ID )->destroy_all();
			delete_user_meta( $user->ID, 'dlz_2fa_tries' );
			self::log( 'reset', 'رمز عوض شد و همه‌ی نشست‌های قبلی بسته شد', 1, $user->user_login );
		}
	}

	public static function argon() {
		return PASSWORD_ARGON2ID;
	}

	/* =========================================================
	 * Two-step login (TOTP)
	 * ======================================================= */

	public static function twofa_disabled() {
		return ( defined( 'DLZ_2FA_OFF' ) && DLZ_2FA_OFF ) || self::off();
	}

	public static function is_on( $uid ) {
		return ! self::twofa_disabled() && $uid && get_user_meta( $uid, 'dlz_2fa_on', true ) && '' !== (string) get_user_meta( $uid, 'dlz_2fa_secret', true );
	}

	private static function b32e( $bin ) {
		$a    = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
		$bits = '';
		foreach ( str_split( $bin ) as $c ) {
			$bits .= str_pad( decbin( ord( $c ) ), 8, '0', STR_PAD_LEFT );
		}
		$out = '';
		foreach ( str_split( $bits, 5 ) as $b ) {
			$out .= $a[ bindec( str_pad( $b, 5, '0' ) ) ];
		}
		return $out;
	}

	private static function b32d( $s ) {
		$a    = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
		$s    = strtoupper( preg_replace( '/[^A-Za-z2-7]/', '', (string) $s ) );
		$bits = '';
		foreach ( str_split( $s ) as $c ) {
			$bits .= str_pad( decbin( strpos( $a, $c ) ), 5, '0', STR_PAD_LEFT );
		}
		$out = '';
		foreach ( str_split( $bits, 8 ) as $b ) {
			if ( 8 === strlen( $b ) ) {
				$out .= chr( bindec( $b ) );
			}
		}
		return $out;
	}

	public static function totp( $secret, $step ) {
		$h = hash_hmac( 'sha1', pack( 'N', 0 ) . pack( 'N', $step ), self::b32d( $secret ), true );
		$o = ord( $h[19] ) & 0xF;
		$c = ( ( ord( $h[ $o ] ) & 0x7F ) << 24 ) | ( ord( $h[ $o + 1 ] ) << 16 ) | ( ord( $h[ $o + 2 ] ) << 8 ) | ord( $h[ $o + 3 ] );
		return str_pad( (string) ( $c % 1000000 ), 6, '0', STR_PAD_LEFT );
	}

	/** Checks a 6-digit code (±30 s) and refuses a code that was already used. */
	private static function code_ok( $secret, $code, $uid = 0 ) {
		$code = preg_replace( '/\D/', '', strtr( (string) $code, array( '۰' => '0', '۱' => '1', '۲' => '2', '۳' => '3', '۴' => '4', '۵' => '5', '۶' => '6', '۷' => '7', '۸' => '8', '۹' => '9', '٠' => '0', '١' => '1', '٢' => '2', '٣' => '3', '٤' => '4', '٥' => '5', '٦' => '6', '٧' => '7', '٨' => '8', '٩' => '9' ) ) );
		if ( 6 !== strlen( $code ) || '' === $secret ) {
			return false;
		}
		$now  = (int) floor( time() / 30 );
		$last = $uid ? (int) get_user_meta( $uid, 'dlz_2fa_last', true ) : 0;
		for ( $i = -1; $i <= 1; $i++ ) {
			$s = $now + $i;
			if ( $s > $last && hash_equals( self::totp( $secret, $s ), $code ) ) {
				if ( $uid ) {
					update_user_meta( $uid, 'dlz_2fa_last', $s );
				}
				return true;
			}
		}
		return false;
	}

	private static function backup_ok( $uid, $code ) {
		$code  = strtoupper( preg_replace( '/[^A-Za-z0-9]/', '', (string) $code ) );
		$codes = (array) get_user_meta( $uid, 'dlz_2fa_codes', true );
		if ( strlen( $code ) < 8 ) {
			return false;
		}
		foreach ( $codes as $i => $h ) {
			if ( is_string( $h ) && password_verify( $code, $h ) ) {
				unset( $codes[ $i ] );
				update_user_meta( $uid, 'dlz_2fa_codes', array_values( $codes ) );
				return true;
			}
		}
		return false;
	}

	private static function new_backup_codes( $uid ) {
		$plain = array();
		$hash  = array();
		for ( $i = 0; $i < 8; $i++ ) {
			$c       = strtoupper( substr( self::b32e( random_bytes( 7 ) ), 0, 10 ) );
			$plain[] = substr( $c, 0, 5 ) . '-' . substr( $c, 5 );
			$hash[]  = password_hash( $c, PASSWORD_DEFAULT );
		}
		update_user_meta( $uid, 'dlz_2fa_codes', $hash );
		return $plain;
	}

	/** Has this login session already passed the second step? */
	public static function verified( $uid = 0 ) {
		$uid = $uid ? $uid : get_current_user_id();
		if ( ! self::is_on( $uid ) ) {
			return true;
		}
		if ( isset( self::$verified[ $uid ] ) ) {
			return self::$verified[ $uid ];
		}
		$tok = wp_get_session_token();
		$ok  = false;
		if ( $tok && $uid === get_current_user_id() ) {
			$s  = WP_Session_Tokens::get_instance( $uid )->get( $tok );
			$ok = is_array( $s ) && ! empty( $s['dlz2fa'] );
		}
		self::$verified[ $uid ] = $ok;
		return $ok;
	}

	private static function mark_verified( $uid ) {
		$tok = wp_get_session_token();
		if ( ! $tok ) {
			return;
		}
		$m = WP_Session_Tokens::get_instance( $uid );
		$s = $m->get( $tok );
		if ( is_array( $s ) ) {
			$s['dlz2fa'] = time();
			$m->update( $tok, $s );
		}
		self::$verified[ $uid ] = true;
	}

	/**
	 * Until the code is entered the account works like a plain visitor account: no dashboard, no
	 * admin requests, no REST writes — even with the right password.
	 */
	public static function caps( $all, $caps, $args, $user ) {
		if ( self::$raw_caps || ! $user || ! $user->ID || ( defined( 'WP_CLI' ) && WP_CLI ) ) {
			return $all;
		}
		if ( get_current_user_id() !== (int) $user->ID || ! self::is_on( $user->ID ) ) {
			return $all;
		}
		if ( self::verified( $user->ID ) ) {
			return $all;
		}
		return array( 'read' => true, 'level_0' => true );
	}

	public static function challenge_url( $redirect = '' ) {
		return add_query_arg( array( 'action' => 'dlz2fa', 'redirect_to' => rawurlencode( $redirect ? $redirect : admin_url() ) ), wp_login_url() );
	}

	/** Dashboard entry: two-step code first, then forced set-up, then «403» for customers. */
	public static function admin_gate() {
		if ( wp_doing_ajax() || ! is_user_logged_in() || ( defined( 'WP_CLI' ) && WP_CLI ) ) {
			return;
		}
		global $pagenow;
		$uid  = get_current_user_id();
		$here = ( is_ssl() ? 'https://' : 'http://' ) . ( isset( $_SERVER['HTTP_HOST'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_HOST'] ) ) : '' ) . ( isset( $_SERVER['REQUEST_URI'] ) ? esc_url_raw( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '' ); // phpcs:ignore
		if ( 'admin-post.php' !== $pagenow && ! self::verified( $uid ) ) {
			wp_safe_redirect( self::challenge_url( $here ) );
			exit;
		}
		$page = isset( $_GET['page'] ) ? sanitize_key( $_GET['page'] ) : ''; // phpcs:ignore
		if ( self::opt( 'twofa_force' ) && ! self::twofa_disabled() && ! self::is_on( $uid ) && self::real_can( 'edit_posts' ) && self::SLUG !== $page && 'admin-post.php' !== $pagenow ) {
			wp_safe_redirect( admin_url( 'admin.php?page=' . self::SLUG . '&tab=2fa&must=1' ) );
			exit;
		}
		if ( self::opt( 'admin_lock' ) && ! self::real_can( 'edit_posts' ) && ! in_array( $pagenow, array( 'admin-post.php', 'async-upload.php' ), true ) ) {
			self::log_once( 'a403', 600, 'admin403', 'باز کردن ' . ( $pagenow ? $pagenow : 'wp-admin' ), 1, wp_get_current_user()->user_login );
			self::forbidden();
		}
	}

	public static function forbidden() {
		status_header( 403 );
		nocache_headers();
		header( 'Content-Type: text/html; charset=utf-8' );
		echo '<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex"><title>403</title><style>body{margin:0;min-height:100vh;display:grid;place-items:center;background:#F7F1E3;font-family:Tahoma,Arial,sans-serif;color:#1F2A24}.b{max-width:380px;margin:20px;padding:30px 26px;border-radius:22px;background:#FFFDF7;box-shadow:inset 0 0 0 1px #E8D9AE,0 18px 40px -26px rgba(90,64,12,.5);text-align:center}.c{font-size:46px;font-weight:800;color:#0F4D2E;margin:0}.t{margin:6px 0 18px;line-height:1.9}a{display:inline-block;padding:11px 22px;border-radius:999px;background:#0F4D2E;color:#fff;text-decoration:none;font-weight:700}</style></head><body><div class="b"><p class="c">403</p><p class="t">هذه الصفحة خاصة بإدارة الموقع.<br>يمكنك متابعة طلباتك وحسابك من التطبيق.</p><a href="' . esc_url( home_url( '/' ) ) . '">العودة إلى الرئيسية</a></div></body></html>';
		exit;
	}

	/** The «enter your code» screen (wp-login.php?action=dlz2fa). */
	public static function challenge() {
		$redirect = isset( $_REQUEST['redirect_to'] ) ? wp_validate_redirect( wp_unslash( $_REQUEST['redirect_to'] ), admin_url() ) : admin_url(); // phpcs:ignore
		if ( ! is_user_logged_in() ) {
			wp_safe_redirect( wp_login_url( $redirect ) );
			exit;
		}
		$uid = get_current_user_id();
		if ( self::verified( $uid ) ) {
			wp_safe_redirect( $redirect );
			exit;
		}
		$err = '';
		if ( 'POST' === ( isset( $_SERVER['REQUEST_METHOD'] ) ? $_SERVER['REQUEST_METHOD'] : '' ) ) { // phpcs:ignore
			if ( ! isset( $_POST['_dlzn'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_dlzn'] ) ), 'dlz2fa' ) ) {
				$err = 'صفحه منقضی شده بود، دوباره امتحان کنید.';
			} else {
				$tries = (array) get_user_meta( $uid, 'dlz_2fa_tries', true );
				$tries = array_values( array_filter( $tries, function ( $t ) {
					return (int) $t > time() - 300;
				} ) );
				if ( count( $tries ) >= 5 ) {
					self::log( '2fa_fail', '۵ کد اشتباه در ۵ دقیقه — خروج از حساب', 3, wp_get_current_user()->user_login );
					delete_user_meta( $uid, 'dlz_2fa_tries' );
					WP_Session_Tokens::get_instance( $uid )->destroy( wp_get_session_token() );
					wp_clear_auth_cookie();
					wp_safe_redirect( add_query_arg( 'dlz2fa', 'locked', wp_login_url() ) );
					exit;
				}
				$code   = isset( $_POST['code'] ) ? sanitize_text_field( wp_unslash( $_POST['code'] ) ) : '';
				$secret = self::unseal( get_user_meta( $uid, 'dlz_2fa_secret', true ) );
				$ok     = self::code_ok( $secret, $code, $uid );
				$backup = false;
				if ( ! $ok && strlen( preg_replace( '/[^A-Za-z0-9]/', '', $code ) ) >= 8 ) {
					$ok     = self::backup_ok( $uid, $code );
					$backup = $ok;
				}
				if ( $ok ) {
					delete_user_meta( $uid, 'dlz_2fa_tries' );
					self::mark_verified( $uid );
					self::log( '2fa', $backup ? 'ورود با کد پشتیبان (یکی از کدها مصرف شد)' : 'کد درست وارد شد', $backup ? 2 : 1, wp_get_current_user()->user_login );
					wp_safe_redirect( $redirect );
					exit;
				}
				$tries[] = time();
				update_user_meta( $uid, 'dlz_2fa_tries', $tries );
				self::log( '2fa_fail', 'کد اشتباه', 2, wp_get_current_user()->user_login );
				$err = 'کد درست نیست. کد ۶ رقمی فعلی برنامه را وارد کنید (' . ( 5 - count( $tries ) ) . ' تلاش دیگر).';
			}
		}
		login_header( 'ورود دومرحله‌ای', '', $err ? new WP_Error( 'dlz2fa', $err ) : null );
		?>
		<style>#login{direction:rtl}.dlz2fa-in{font-size:26px!important;letter-spacing:6px;text-align:center;direction:ltr;font-family:monospace}.dlz2fa-p{margin:0 0 14px;line-height:1.9;font-size:13px}.dlz2fa-alt{margin-top:14px;font-size:12px;color:#646970;line-height:1.8}</style>
		<form name="dlz2fa" method="post" action="<?php echo esc_url( self::challenge_url( $redirect ) ); ?>">
			<p class="dlz2fa-p">کد ۶ رقمی برنامه‌ی <b>Google Authenticator</b> (یا Microsoft Authenticator) را برای «<?php echo esc_html( get_bloginfo( 'name' ) ); ?>» وارد کنید.</p>
			<p><input type="text" name="code" class="input dlz2fa-in" inputmode="numeric" autocomplete="one-time-code" maxlength="11" autofocus required></p>
			<?php wp_nonce_field( 'dlz2fa', '_dlzn' ); ?>
			<p class="submit"><button type="submit" class="button button-primary button-large" style="width:100%">تأیید و ورود</button></p>
			<p class="dlz2fa-alt">گوشی در دسترس نیست؟ یکی از <b>کدهای پشتیبان</b> (مثل ABCDE-12345) را در همین کادر بنویسید.</p>
		</form>
		<p id="nav"><a href="<?php echo esc_url( wp_logout_url() ); ?>">خروج از حساب</a></p>
		<?php
		login_footer();
		exit;
	}

	/** Set-up / turn off / new backup codes (from «امنیت سایت → ورود دومرحله‌ای»). */
	public static function twofa_action() {
		if ( ! is_user_logged_in() ) {
			wp_die( 'login' );
		}
		check_admin_referer( 'dlz_sec_2fa' );
		$uid  = get_current_user_id();
		$op   = isset( $_POST['op'] ) ? sanitize_key( $_POST['op'] ) : '';
		$back = admin_url( 'admin.php?page=' . self::SLUG . '&tab=2fa' );
		if ( ! self::real_can( 'edit_posts' ) ) {
			wp_die( 'forbidden', 403 );
		}
		if ( self::is_on( $uid ) && ! self::verified( $uid ) ) {
			wp_safe_redirect( self::challenge_url( $back ) );
			exit;
		}
		$code = isset( $_POST['code'] ) ? sanitize_text_field( wp_unslash( $_POST['code'] ) ) : '';
		if ( 'start' === $op ) {
			update_user_meta( $uid, 'dlz_2fa_pending', self::seal( self::b32e( random_bytes( 20 ) ) ) );
		} elseif ( 'confirm' === $op ) {
			$sec = self::unseal( get_user_meta( $uid, 'dlz_2fa_pending', true ) );
			delete_user_meta( $uid, 'dlz_2fa_last' );
			if ( ! self::code_ok( $sec, $code, $uid ) ) {
				wp_safe_redirect( add_query_arg( 'e', 'code', $back ) );
				exit;
			}
			update_user_meta( $uid, 'dlz_2fa_secret', self::seal( $sec ) );
			update_user_meta( $uid, 'dlz_2fa_on', 1 );
			delete_user_meta( $uid, 'dlz_2fa_pending' );
			set_transient( 'dlz_2fa_show_' . $uid, self::new_backup_codes( $uid ), 600 );
			self::mark_verified( $uid );
			self::log( '2fa', 'ورود دومرحله‌ای فعال شد', 2, wp_get_current_user()->user_login );
		} elseif ( 'codes' === $op && self::is_on( $uid ) ) {
			set_transient( 'dlz_2fa_show_' . $uid, self::new_backup_codes( $uid ), 600 );
		} elseif ( 'disable' === $op && self::is_on( $uid ) ) {
			$sec = self::unseal( get_user_meta( $uid, 'dlz_2fa_secret', true ) );
			if ( ! self::code_ok( $sec, $code, $uid ) && ! self::backup_ok( $uid, $code ) ) {
				wp_safe_redirect( add_query_arg( 'e', 'code', $back ) );
				exit;
			}
			foreach ( array( 'dlz_2fa_on', 'dlz_2fa_secret', 'dlz_2fa_codes', 'dlz_2fa_last', 'dlz_2fa_pending' ) as $k ) {
				delete_user_meta( $uid, $k );
			}
			self::log( '2fa', 'ورود دومرحله‌ای خاموش شد', 3, wp_get_current_user()->user_login );
		} elseif ( 'cancel' === $op ) {
			delete_user_meta( $uid, 'dlz_2fa_pending' );
		}
		wp_safe_redirect( $back );
		exit;
	}

	public static function notice() {
		if ( self::twofa_disabled() || ! self::real_can( self::CAP ) || self::is_on( get_current_user_id() ) ) {
			return;
		}
		$s = get_current_screen();
		if ( $s && ( 'dashboard' === $s->id || false !== strpos( (string) $s->id, self::SLUG ) ) ) {
			echo '<div class="notice notice-warning"><p><b>ورود دومرحله‌ای</b> برای حساب شما خاموش است. با یک دقیقه وقت و برنامه‌ی Google Authenticator، حتی اگر رمز لو برود کسی نمی‌تواند وارد شود. <a href="' . esc_url( admin_url( 'admin.php?page=' . self::SLUG . '&tab=2fa' ) ) . '">فعال‌سازی</a></p></div>';
		}
	}

	/* =========================================================
	 * Cookies, HTTPS, headers, CORS, CSRF
	 * ======================================================= */

	private static function cookie_flags() {
		@ini_set( 'session.cookie_httponly', '1' ); // phpcs:ignore
		@ini_set( 'session.cookie_samesite', 'Lax' ); // phpcs:ignore
		@ini_set( 'session.use_strict_mode', '1' ); // phpcs:ignore
		if ( is_ssl() ) {
			@ini_set( 'session.cookie_secure', '1' ); // phpcs:ignore
		}
		if ( function_exists( 'header_register_callback' ) ) {
			header_register_callback( array( __CLASS__, 'fix_cookies' ) );
		}
	}

	/** Every cookie the site sends: SameSite=Lax, Secure on HTTPS, HttpOnly on login cookies. */
	public static function fix_cookies() {
		$out = array();
		foreach ( headers_list() as $h ) {
			if ( 0 !== stripos( $h, 'Set-Cookie:' ) ) {
				continue;
			}
			$c = trim( substr( $h, 11 ) );
			if ( ! preg_match( '/;\s*samesite=/i', $c ) ) {
				$c .= '; SameSite=Lax';
			}
			if ( is_ssl() && ! preg_match( '/;\s*secure\s*(;|$)/i', $c ) ) {
				$c .= '; Secure';
			}
			if ( preg_match( '/^(wordpress_|wp-postpass_|PHPSESSID)/i', $c ) && ! preg_match( '/;\s*httponly\s*(;|$)/i', $c ) ) {
				$c .= '; HttpOnly';
			}
			$out[] = $c;
		}
		if ( $out ) {
			header_remove( 'Set-Cookie' );
			foreach ( $out as $c ) {
				header( 'Set-Cookie: ' . $c, false );
			}
		}
	}

	public static function force_https() {
		if ( ! self::opt( 'https' ) || is_ssl() || ( defined( 'WP_CLI' ) && WP_CLI ) || wp_doing_cron() ) {
			return;
		}
		if ( 'https' !== wp_parse_url( home_url(), PHP_URL_SCHEME ) ) {
			return; // the site itself is not on HTTPS yet
		}
		$m = isset( $_SERVER['REQUEST_METHOD'] ) ? strtoupper( (string) $_SERVER['REQUEST_METHOD'] ) : 'GET'; // phpcs:ignore
		if ( ! in_array( $m, array( 'GET', 'HEAD' ), true ) || empty( $_SERVER['HTTP_HOST'] ) ) {
			return;
		}
		wp_redirect( 'https://' . sanitize_text_field( wp_unslash( $_SERVER['HTTP_HOST'] ) ) . ( isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '/' ), 301 ); // phpcs:ignore
		exit;
	}

	public static function headers_basic() {
		if ( headers_sent() || ! self::opt( 'headers' ) ) {
			return;
		}
		header( 'X-Content-Type-Options: nosniff' );
		header( 'X-Frame-Options: SAMEORIGIN' );
		header( 'Referrer-Policy: strict-origin-when-cross-origin' );
		if ( is_ssl() && self::opt( 'hsts' ) ) {
			header( 'Strict-Transport-Security: max-age=31536000' );
		}
		if ( function_exists( 'header_remove' ) ) {
			header_remove( 'X-Powered-By' );
		}
	}

	public static function csp() {
		$src = array();
		foreach ( array( home_url(), site_url() ) as $u ) {
			$sc   = wp_parse_url( $u, PHP_URL_SCHEME );
			$h    = strtolower( (string) wp_parse_url( $u, PHP_URL_HOST ) );
			$port = wp_parse_url( $u, PHP_URL_PORT );
			if ( ! $h ) {
				continue;
			}
			foreach ( array( $h, 0 === strpos( $h, 'www.' ) ? substr( $h, 4 ) : 'www.' . $h ) as $x ) {
				$src[] = $sc . '://' . $x . ( $port ? ':' . $port : '' );
			}
		}
		$p = "object-src 'none'; base-uri 'self'; frame-ancestors 'self'; form-action 'self' " . implode( ' ', array_unique( $src ) );
		if ( is_ssl() ) {
			$p .= '; upgrade-insecure-requests';
		}
		return $p;
	}

	public static function headers() {
		if ( is_admin() || headers_sent() ) {
			return;
		}
		self::headers_basic();
		if ( self::opt( 'headers' ) ) {
			header( 'Permissions-Policy: geolocation=(self), microphone=(self), camera=(self), payment=()' );
			if ( self::opt( 'csp' ) ) {
				header( 'Content-Security-Policy: ' . self::csp() );
			}
		}
	}

	public static function strip_headers( $h ) {
		unset( $h['X-Pingback'] );
		return $h;
	}

	public static function cors_setup() {
		remove_filter( 'rest_pre_serve_request', 'rest_send_cors_headers' );
		add_filter( 'rest_pre_serve_request', array( __CLASS__, 'cors' ) );
	}

	/** REST API: only this site's own address may read with the visitor's cookies. */
	public static function cors( $v ) {
		$o = get_http_origin();
		if ( $o && 'null' !== $o && self::origin_ok( $o ) ) {
			header( 'Access-Control-Allow-Origin: ' . esc_url_raw( $o ) );
			header( 'Access-Control-Allow-Methods: OPTIONS, GET, POST, PUT, PATCH, DELETE' );
			header( 'Access-Control-Allow-Credentials: true' );
			header( 'Vary: Origin', false );
		} elseif ( $o && 'null' !== $o ) {
			self::log_once( 'cors' . $o, 3600, 'cors', 'Origin: ' . $o, 1 );
		}
		return $v;
	}

	public static function allowed_origins( $o ) {
		foreach ( self::home_hosts() as $h ) {
			$o[] = 'https://' . $h;
			$o[] = 'http://' . $h;
		}
		return array_values( array_unique( $o ) );
	}

	/** A form or request sent to the dashboard / login from another website is refused. */
	public static function csrf() {
		$m = isset( $_SERVER['REQUEST_METHOD'] ) ? strtoupper( (string) $_SERVER['REQUEST_METHOD'] ) : 'GET'; // phpcs:ignore
		if ( 'POST' !== $m ) {
			return;
		}
		$o = isset( $_SERVER['HTTP_ORIGIN'] ) ? (string) $_SERVER['HTTP_ORIGIN'] : ''; // phpcs:ignore
		if ( '' === $o && ! empty( $_SERVER['HTTP_REFERER'] ) ) {
			$r = wp_parse_url( (string) $_SERVER['HTTP_REFERER'] ); // phpcs:ignore
			$o = ! empty( $r['host'] ) ? ( isset( $r['scheme'] ) ? $r['scheme'] : 'https' ) . '://' . $r['host'] : '';
		}
		if ( '' === $o || self::origin_ok( $o ) ) {
			return;
		}
		$act = isset( $_REQUEST['action'] ) ? sanitize_key( $_REQUEST['action'] ) : ''; // phpcs:ignore
		self::log( 'csrf', 'از ' . mb_substr( $o, 0, 80 ) . ( $act ? ' — action=' . $act : '' ), 2 );
		if ( wp_doing_ajax() ) {
			wp_send_json_error( array( 'message' => 'Forbidden' ), 403 );
		}
		wp_die( 'درخواست از سایت دیگری ارسال شده و رد شد.', 403, array( 'response' => 403 ) );
	}

	/* =========================================================
	 * Debug, XML-RPC, probes, uploads
	 * ======================================================= */

	private static function hide_errors() {
		if ( defined( 'WP_CLI' ) && WP_CLI ) {
			return;
		}
		@ini_set( 'display_errors', '0' ); // phpcs:ignore
		@ini_set( 'expose_php', '0' ); // phpcs:ignore
		add_filter( 'wp_php_error_message', array( __CLASS__, 'error_message' ) );
	}

	public static function error_message() {
		return '<p>Something went wrong. — حدث خطأ ما، يرجى المحاولة بعد قليل.</p>';
	}

	public static function xmlrpc_block() {
		if ( defined( 'XMLRPC_REQUEST' ) && XMLRPC_REQUEST ) {
			self::log_once( 'xmlrpc', 3600, 'xmlrpc', 'xmlrpc.php', 1 );
			status_header( 403 );
			header( 'Content-Type: text/plain; charset=utf-8' );
			echo 'XML-RPC is disabled.';
			exit;
		}
	}

	/** Patterns of files that must never be public. */
	public static function sensitive_re() {
		return '#(^|/)(\.(?!well-known)[^/]+|[^/]*\.(env|ini|log|sql|sqlite|bak|backup|old|orig|save|swp|sh)|wp-config\.php\..*|backup[^/]*\.(zip|tar|gz|tgz|rar|7z)|phpinfo\.php|adminer[^/]*\.php|debug\.log|error_log)$#i';
	}

	public static function probe_404() {
		if ( ! is_404() ) {
			return;
		}
		$p = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_parse_url( wp_unslash( $_SERVER['REQUEST_URI'] ), PHP_URL_PATH ) : ''; // phpcs:ignore
		if ( $p && preg_match( self::sensitive_re(), rawurldecode( $p ) ) ) {
			self::log_once( 'probe', 600, 'probe', mb_substr( $p, 0, 120 ), 2 );
		}
	}

	/** Every upload: no programs or pages (also not hidden as «x.php.jpg»), sane size for visitors. */
	public static function upload_check( $file ) {
		if ( ! is_array( $file ) || ! empty( $file['error'] ) || empty( $file['name'] ) ) {
			return $file;
		}
		$name = strtolower( (string) $file['name'] );
		$bad  = 'php|php\d|pht|phtml|phar|phps|pl|py|cgi|sh|bash|exe|bat|cmd|msi|dll|jsp|asp|aspx|htaccess|htpasswd|html?|xhtml|shtml|svg|svgz|xml|js|mjs|swf';
		$parts = explode( '.', $name );
		array_shift( $parts );
		foreach ( $parts as $ext ) {
			if ( preg_match( '/^(' . $bad . ')$/', $ext ) ) {
				$file['error'] = 'این نوع فایل برای امنیت سایت قابل آپلود نیست.';
				self::log( 'upload', 'رد شد: ' . mb_substr( $file['name'], 0, 80 ), 2 );
				return $file;
			}
		}
		$mb = max( 1, (int) self::opt( 'upload_mb' ) );
		if ( ! self::real_can( 'upload_files' ) && ! empty( $file['size'] ) && (int) $file['size'] > $mb * MB_IN_BYTES ) {
			$file['error'] = 'حجم فایل بیشتر از ' . $mb . ' مگابایت است.';
			self::log( 'upload', 'حجم زیاد: ' . size_format( (int) $file['size'] ) . ' — ' . mb_substr( $file['name'], 0, 60 ), 1 );
		}
		return $file;
	}

	/* ------------------------------------------------------------ private documents */

	public static function private_dir() {
		$u   = wp_upload_dir( null, false );
		$dir = trailingslashit( $u['basedir'] ) . 'dlz-private';
		if ( ! is_dir( $dir ) ) {
			wp_mkdir_p( $dir );
		}
		if ( is_dir( $dir ) ) {
			if ( ! file_exists( $dir . '/.htaccess' ) ) {
				@file_put_contents( $dir . '/.htaccess', "# Dalil Al Zaer — private documents (opened only from the dashboard)\n<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\nOrder allow,deny\nDeny from all\n</IfModule>\n" ); // phpcs:ignore
			}
			if ( ! file_exists( $dir . '/index.php' ) ) {
				@file_put_contents( $dir . '/index.php', "<?php\n// Silence is golden.\n" ); // phpcs:ignore
			}
		}
		if ( ! file_exists( trailingslashit( $u['basedir'] ) . 'index.php' ) ) {
			@file_put_contents( trailingslashit( $u['basedir'] ) . 'index.php', "<?php\n// Silence is golden.\n" ); // phpcs:ignore
		}
		return $dir;
	}

	public static function private_filter( $d ) {
		$d['subdir'] = '/dlz-private';
		$d['path']   = $d['basedir'] . '/dlz-private';
		$d['url']    = $d['baseurl'] . '/dlz-private';
		return $d;
	}

	/** Medical / legal documents go to uploads/dlz-private (closed to the public). */
	public static function private_uploads( $on ) {
		if ( $on ) {
			self::private_dir();
			add_filter( 'upload_dir', array( __CLASS__, 'private_filter' ), 99 );
		} else {
			remove_filter( 'upload_dir', array( __CLASS__, 'private_filter' ), 99 );
		}
	}

	/** Link for the dashboard: private files open through a checked download. */
	public static function file_url( $url ) {
		$url = (string) $url;
		if ( false === strpos( $url, '/dlz-private/' ) ) {
			return $url;
		}
		$f = basename( wp_parse_url( $url, PHP_URL_PATH ) );
		return wp_nonce_url( admin_url( 'admin-post.php?action=dlz_private_file&f=' . rawurlencode( $f ) ), 'dlz_private_file' );
	}

	public static function private_file() {
		if ( ! self::real_can( 'edit_posts' ) || ! self::verified() ) {
			wp_die( 'forbidden', 403 );
		}
		check_admin_referer( 'dlz_private_file' );
		$f    = isset( $_GET['f'] ) ? sanitize_file_name( wp_unslash( $_GET['f'] ) ) : '';
		$path = self::private_dir() . '/' . $f;
		if ( '' === $f || ! is_file( $path ) || '.' === $f[0] || 'index.php' === $f ) {
			wp_die( 'not found', 404 );
		}
		$t = wp_check_filetype( $f );
		nocache_headers();
		header( 'Content-Type: ' . ( $t['type'] ? $t['type'] : 'application/octet-stream' ) );
		header( 'Content-Disposition: inline; filename="' . $f . '"' );
		header( 'Content-Length: ' . filesize( $path ) );
		header( 'X-Content-Type-Options: nosniff' );
		readfile( $path ); // phpcs:ignore
		exit;
	}

	/* ------------------------------------------------------------ .htaccess */

	public static function htaccess_lines() {
		return array(
			'<IfModule mod_rewrite.c>',
			'RewriteEngine On',
			'RewriteRule (^|/)\.(?!well-known(/|$)) - [R=404,L]',
			'RewriteRule (^|/)(wp-config\.php\..+|readme\.html|license\.txt|debug\.log|error_log|php_errors\.log|phpinfo\.php|adminer[^/]*\.php|composer\.(json|lock)|package(-lock)?\.json)$ - [NC,R=404,L]',
			'RewriteRule \.(env|ini|log|sql|sqlite|bak|backup|old|orig|save|swp|swo|sh)$ - [NC,R=404,L]',
			'RewriteRule ^(wp-content/)?[^/]+\.(zip|tar|gz|tgz|rar|7z)$ - [NC,R=404,L]',
			'RewriteRule ^wp-content/uploads/.*\.(php[0-9]?|phtml|phar|pl|py|cgi|asp|aspx|jsp)$ - [NC,R=404,L]',
			'RewriteRule ^wp-content/uploads/dlz-private/ - [NC,R=404,L]',
			'</IfModule>',
		);
	}

	/** Writes (or removes) the «Dalil Security» block in the site's .htaccess (Apache / LiteSpeed). */
	public static function htaccess() {
		$f = ABSPATH . '.htaccess';
		if ( ! file_exists( $f ) || ! is_writable( $f ) ) {
			return false;
		}
		require_once ABSPATH . 'wp-admin/includes/misc.php';
		return insert_with_markers( $f, 'Dalil Security', ( self::opt( 'files' ) && ! self::off() ) ? self::htaccess_lines() : array() );
	}

	/* =========================================================
	 * Watching
	 * ======================================================= */

	public static function role_watch( $uid, $role, $old ) {
		if ( 'administrator' === $role && ! in_array( 'administrator', (array) $old, true ) ) {
			$u = get_userdata( $uid );
			self::log( 'admin_new', 'نقش «مدیر کل» به ' . ( $u ? $u->user_login : '#' . $uid ) . ' داده شد', 3, $u ? $u->user_login : '' );
		}
	}

	public static function user_watch( $uid ) {
		$u = get_userdata( $uid );
		if ( $u && in_array( 'administrator', (array) $u->roles, true ) ) {
			self::log( 'admin_new', 'حساب مدیر جدید ساخته شد', 3, $u->user_login );
		}
	}

	public static function plugin_watch( $plugin ) {
		self::log( 'plugin', (string) $plugin, 2 );
	}

	/** A visitor who signs in on wp-login.php goes to the site (the dashboard would be «403»). */
	public static function login_redirect( $to, $requested, $user ) {
		if ( self::opt( 'admin_lock' ) && $user instanceof WP_User && ! self::real_can( 'edit_posts', $user->ID ) && 0 === strpos( (string) $to, admin_url() ) ) {
			return function_exists( 'dlz_profile_url' ) ? dlz_profile_url() : home_url( '/' );
		}
		return $to;
	}

	public static function admin_bar( $show ) {
		return ( $show && is_user_logged_in() && self::opt( 'admin_lock' ) && ! self::real_can( 'edit_posts' ) ) ? false : $show;
	}

	/* =========================================================
	 * Dashboard page
	 * ======================================================= */

	public static function menu() {
		$n = (int) get_transient( 'dlz_sec_issues' );
		add_submenu_page( 'dlz-unified', 'امنیت سایت', 'امنیت سایت' . ( $n ? ' <span class="awaiting-mod dlz-sec-c"><span>' . $n . '</span></span>' : '' ), self::CAP, self::SLUG, array( __CLASS__, 'page' ), 1 );
	}

	public static function save() {
		if ( ! current_user_can( self::CAP ) ) {
			wp_die( 'forbidden', 403 );
		}
		check_admin_referer( 'dlz_sec_save' );
		$in  = isset( $_POST['s'] ) ? (array) wp_unslash( $_POST['s'] ) : array(); // phpcs:ignore
		$d   = self::defaults();
		$out = array();
		foreach ( $d as $k => $v ) {
			if ( 'login_max' === $k ) {
				$out[ $k ] = max( 3, min( 20, (int) ( isset( $in[ $k ] ) ? $in[ $k ] : $v ) ) );
			} elseif ( 'upload_mb' === $k ) {
				$out[ $k ] = max( 1, min( 200, (int) ( isset( $in[ $k ] ) ? $in[ $k ] : $v ) ) );
			} elseif ( 'origins' === $k ) {
				$lines = array();
				foreach ( preg_split( '/[\r\n,]+/', isset( $in[ $k ] ) ? (string) $in[ $k ] : '' ) as $l ) {
					$l = esc_url_raw( trim( $l ), array( 'http', 'https' ) );
					if ( $l ) {
						$lines[] = untrailingslashit( $l );
					}
				}
				$out[ $k ] = implode( "\n", array_slice( array_unique( $lines ), 0, 20 ) );
			} else {
				$out[ $k ] = empty( $in[ $k ] ) ? 0 : 1;
			}
		}
		update_option( self::OPT, $out );
		self::log( 'settings', 'تنظیمات امنیت ذخیره شد', 1, wp_get_current_user()->user_login );
		self::$o = null;
		self::htaccess();
		delete_transient( 'dlz_sec_probe' );
		wp_safe_redirect( admin_url( 'admin.php?page=' . self::SLUG . '&tab=settings&saved=1' ) );
		exit;
	}

	public static function scan_now() {
		if ( ! current_user_can( self::CAP ) ) {
			wp_die( 'forbidden', 403 );
		}
		check_admin_referer( 'dlz_sec_scan' );
		self::probe( true );
		self::code_scan( true );
		wp_safe_redirect( admin_url( 'admin.php?page=' . self::SLUG . '&scanned=1' ) );
		exit;
	}

	/** Small tools: close every session, delete a leaked file. */
	public static function tool() {
		if ( ! current_user_can( self::CAP ) ) {
			wp_die( 'forbidden', 403 );
		}
		check_admin_referer( 'dlz_sec_tool' );
		$op = isset( $_POST['op'] ) ? sanitize_key( $_POST['op'] ) : '';
		if ( 'logout_all' === $op ) {
			self::log( 'settings', 'همه‌ی کاربران از همه‌ی دستگاه‌ها خارج شدند', 2, wp_get_current_user()->user_login );
			WP_Session_Tokens::destroy_all_for_all_users();
			wp_safe_redirect( wp_login_url( admin_url( 'admin.php?page=' . self::SLUG ) ) );
			exit;
		}
		if ( 'delete_file' === $op ) {
			$rel = isset( $_POST['f'] ) ? (string) wp_unslash( $_POST['f'] ) : ''; // phpcs:ignore
			foreach ( self::leaked_files() as $x ) {
				if ( $x['rel'] === $rel && is_file( $x['path'] ) ) {
					wp_delete_file( $x['path'] );
					self::log( 'settings', 'فایل حساس حذف شد: ' . $rel, 2, wp_get_current_user()->user_login );
				}
			}
			delete_transient( 'dlz_sec_probe' );
		}
		wp_safe_redirect( admin_url( 'admin.php?page=' . self::SLUG . '&tab=files' ) );
		exit;
	}

	/* ------------------------------------------------------------ scans */

	/** Sensitive files lying in the site folder (backups, dumps, .env, logs, tools). */
	public static function leaked_files() {
		$out  = array();
		$dirs = array( ABSPATH, WP_CONTENT_DIR . '/' );
		$re   = '#^(\.env.*|\.git|\.svn|\.hg|\.DS_Store|.*\.(sql|sqlite|bak|backup|old|orig|save|swp|log)|wp-config\.php\..+|.*backup.*\.(zip|tar|gz|tgz|rar|7z)|.*\.(zip|tar|gz|tgz|rar|7z)|phpinfo\.php|info\.php|adminer.*\.php|phpmyadmin|pma|error_log|debug\.log)$#i';
		foreach ( $dirs as $dir ) {
			$h = @opendir( $dir ); // phpcs:ignore
			if ( ! $h ) {
				continue;
			}
			while ( false !== ( $f = readdir( $h ) ) ) {
				if ( '.' === $f || '..' === $f || '.htaccess' === $f || '.well-known' === $f || '.user.ini' === $f ) {
					continue;
				}
				if ( preg_match( $re, $f ) ) {
					$p     = $dir . $f;
					$out[] = array(
						'rel'  => str_replace( ABSPATH, '/', $p ),
						'path' => $p,
						'dir'  => is_dir( $p ),
						'size' => is_file( $p ) ? (int) filesize( $p ) : 0,
					);
				}
			}
			closedir( $h );
		}
		return $out;
	}

	/** Requests the site makes to itself, like a stranger would (cached 6 hours). */
	public static function probe( $force = false ) {
		$c = get_transient( 'dlz_sec_probe' );
		if ( ! $force && is_array( $c ) ) {
			return $c;
		}
		$home = untrailingslashit( home_url() );
		$args = array( 'timeout' => 6, 'redirection' => 0, 'sslverify' => false, 'headers' => array( 'User-Agent' => 'DalilSecurityCheck/1.0' ), 'cookies' => array() );
		$r    = array( 't' => time(), 'paths' => array(), 'headers' => array(), 'ok' => false );
		$paths = array( '/.env', '/backup.zip', '/.git/config', '/wp-config.php.bak', '/wp-content/debug.log', '/readme.html', '/wp-content/uploads/', '/wp-json/wp/v2/users', '/?author=1', '/xmlrpc.php', '/wp-admin/' );
		foreach ( $paths as $p ) {
			$res = wp_remote_get( $home . $p, $args );
			if ( is_wp_error( $res ) ) {
				$r['paths'][ $p ] = array( 'code' => 0, 'err' => $res->get_error_message() );
				continue;
			}
			$code = (int) wp_remote_retrieve_response_code( $res );
			$body = (string) wp_remote_retrieve_body( $res );
			$r['paths'][ $p ] = array(
				'code'    => $code,
				'index'   => false !== stripos( $body, 'Index of' ),
				'users'   => '/wp-json/wp/v2/users' === $p && false !== strpos( $body, '"slug"' ),
				'loc'     => (string) wp_remote_retrieve_header( $res, 'location' ),
			);
			$r['ok'] = true;
		}
		$res = wp_remote_get( $home . '/', $args );
		if ( ! is_wp_error( $res ) ) {
			foreach ( array( 'content-security-policy', 'strict-transport-security', 'x-frame-options', 'x-content-type-options', 'referrer-policy', 'permissions-policy', 'x-powered-by', 'server' ) as $h ) {
				$v = wp_remote_retrieve_header( $res, $h );
				$r['headers'][ $h ] = is_array( $v ) ? implode( ', ', $v ) : (string) $v;
			}
			$ck = wp_remote_retrieve_header( $res, 'set-cookie' );
			$r['cookies'] = is_array( $ck ) ? $ck : ( $ck ? array( $ck ) : array() );
		}
		$cors = wp_remote_get( $home . '/wp-json/', array_merge( $args, array( 'headers' => array( 'Origin' => 'https://evil.example' ) ) ) );
		$r['cors'] = is_wp_error( $cors ) ? null : (string) wp_remote_retrieve_header( $cors, 'access-control-allow-origin' );
		// plain http → https
		if ( 'https' === wp_parse_url( $home, PHP_URL_SCHEME ) ) {
			$h = wp_remote_get( 'http://' . wp_parse_url( $home, PHP_URL_HOST ) . '/', $args );
			$r['http'] = is_wp_error( $h ) ? null : array( (int) wp_remote_retrieve_response_code( $h ), (string) wp_remote_retrieve_header( $h, 'location' ) );
			$r['tls13'] = self::tls13( wp_parse_url( $home, PHP_URL_HOST ) );
		}
		set_transient( 'dlz_sec_probe', $r, 6 * HOUR_IN_SECONDS );
		return $r;
	}

	private static function tls13( $host ) {
		if ( ! function_exists( 'curl_init' ) || ! defined( 'CURL_SSLVERSION_TLSv1_3' ) ) {
			return null;
		}
		$ch = curl_init( 'https://' . $host . '/' ); // phpcs:ignore
		curl_setopt_array( $ch, array( CURLOPT_NOBODY => true, CURLOPT_TIMEOUT => 6, CURLOPT_SSLVERSION => CURL_SSLVERSION_TLSv1_3, CURLOPT_RETURNTRANSFER => true ) ); // phpcs:ignore
		curl_exec( $ch ); // phpcs:ignore
		$ok = 0 === curl_errno( $ch ); // phpcs:ignore
		curl_close( $ch ); // phpcs:ignore
		return $ok;
	}

	/** Looks for keys written into code (themes, plugins, site root). */
	public static function code_scan( $force = false ) {
		$c = get_transient( 'dlz_sec_keys' );
		if ( ! $force && is_array( $c ) ) {
			return $c;
		}
		$pats = array(
			'AWS'          => '/AKIA[0-9A-Z]{16}/',
			'Google'       => '/AIza[0-9A-Za-z_\-]{35}/',
			'Stripe'       => '/sk_live_[0-9A-Za-z]{20,}/',
			'GitHub'       => '/gh[pousr]_[0-9A-Za-z]{36}/',
			'Slack'        => '/xox[baprs]-[0-9A-Za-z\-]{10,}/',
			'Private key'  => '/-----BEGIN (RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----/',
			'OpenAI'       => '/sk-(proj-)?[A-Za-z0-9_\-]{32,}/',
			'Telegram bot' => '/\b\d{8,10}:AA[0-9A-Za-z_\-]{33}\b/',
		);
		$roots = array( WP_CONTENT_DIR . '/themes', WP_CONTENT_DIR . '/plugins', WP_CONTENT_DIR . '/mu-plugins' );
		$found = array();
		$files = 0;
		$t0    = microtime( true );
		foreach ( $roots as $root ) {
			if ( ! is_dir( $root ) ) {
				continue;
			}
			$it = new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $root, FilesystemIterator::SKIP_DOTS ) );
			foreach ( $it as $f ) {
				if ( microtime( true ) - $t0 > 12 || count( $found ) > 40 ) {
					break 2;
				}
				if ( ! $f->isFile() || $f->getSize() > 600000 || ! preg_match( '/\.(php|js|json|env|ini|ya?ml|txt|config)$/i', $f->getFilename() ) || false !== strpos( $f->getPathname(), '/node_modules/' ) ) {
					continue;
				}
				$files++;
				$s = (string) @file_get_contents( $f->getPathname() ); // phpcs:ignore
				foreach ( $pats as $name => $re ) {
					if ( preg_match( $re, $s, $m ) ) {
						$found[] = array( 'file' => str_replace( ABSPATH, '/', $f->getPathname() ), 'type' => $name, 'hint' => substr( $m[0], 0, 6 ) . '…' );
					}
				}
			}
		}
		$r = array( 't' => time(), 'files' => $files, 'found' => $found, 'git' => is_dir( ABSPATH . '.git' ) );
		set_transient( 'dlz_sec_keys', $r, DAY_IN_SECONDS );
		return $r;
	}

	/* ------------------------------------------------------------ the 27 checks */

	private static function st( $id, $group, $title, $state, $text, $fix = '' ) {
		return compact( 'id', 'group', 'title', 'state', 'text', 'fix' );
	}

	public static function checks() {
		global $wpdb;
		$o     = self::opt();
		$p     = self::probe();
		$keys  = self::code_scan();
		$ssl   = 'https' === wp_parse_url( home_url(), PHP_URL_SCHEME );
		$off   = self::off();
		$P     = isset( $p['paths'] ) ? $p['paths'] : array();
		$code  = function ( $path ) use ( $P ) {
			return isset( $P[ $path ]['code'] ) ? (int) $P[ $path ]['code'] : 0;
		};
		$hdr   = isset( $p['headers'] ) ? $p['headers'] : array();
		$on    = function ( $k ) use ( $o, $off ) {
			return ! $off && ! empty( $o[ $k ] );
		};
		$c     = array();
		$admins = get_users( array( 'role__in' => array( 'administrator', 'editor' ), 'fields' => array( 'ID' ) ) );
		$n2    = 0;
		foreach ( $admins as $a ) {
			$n2 += self::is_on( $a->ID ) ? 1 : 0;
		}
		$me2 = self::is_on( get_current_user_id() );

		// ---------------------------------------------------------------- login
		$wpadmin = $code( '/wp-admin/' );
		$c[] = self::st( 1, 'login', 'احراز هویت و ورود دومرحله‌ای (2FA)',
			( $wpadmin && 302 !== $wpadmin ) ? 'bad' : ( $me2 ? 'ok' : 'warn' ),
			'بدون ورود، پیشخوان باز نمی‌شود' . ( $wpadmin ? ' (آزمایش: /wp-admin/ برای مهمان ← ' . $wpadmin . ')' : '' ) . '. نشست‌ها با کوکی امن وردپرس نگه داشته می‌شوند. ورود دومرحله‌ای: ' . ( $me2 ? 'برای حساب شما فعال است' : 'برای حساب شما هنوز فعال نشده' ) . ' — ' . $n2 . ' از ' . count( $admins ) . ' حساب مدیر/ویرایشگر.',
			$me2 ? '' : 'از زبانه‌ی «ورود دومرحله‌ای» با Google Authenticator فعالش کنید؛ بعد می‌توانید «اجباری برای همه‌ی کارمندان» را روشن کنید.' );

		$hashes = $wpdb->get_results( "SELECT SUBSTRING(user_pass,1,8) p, COUNT(*) n FROM {$wpdb->users} GROUP BY SUBSTRING(user_pass,1,8)" ); // phpcs:ignore
		$plain  = 0;
		$argon  = 0;
		$total  = 0;
		foreach ( (array) $hashes as $h ) {
			$total += (int) $h->n;
			if ( 0 === strpos( $h->p, '$argon2' ) ) {
				$argon += (int) $h->n;
			} elseif ( '$' !== substr( $h->p, 0, 1 ) && strlen( $h->p ) < 8 ) {
				$plain += (int) $h->n;
			}
		}
		$argon_ok = $on( 'argon' ) && defined( 'PASSWORD_ARGON2ID' ) && has_filter( 'wp_hash_password_algorithm' );
		$c[] = self::st( 5, 'login', 'هش کردن پسوردها (Argon2)',
			$plain ? 'bad' : ( $argon_ok ? 'ok' : 'warn' ),
			'هیچ رمزی به‌صورت متن ساده ذخیره نمی‌شود (یک‌طرفه). ' . ( $argon_ok ? 'رمزهای جدید و هر رمزی که صاحبش وارد شود با Argon2id ذخیره می‌شود — الان ' . $argon . ' از ' . $total . ' حساب Argon2id است، بقیه bcrypt امن وردپرس و در اولین ورود خودکار تبدیل می‌شوند. ورود زائران با کد پیامکی است و رمزی ندارند.' : ( defined( 'PASSWORD_ARGON2ID' ) ? 'Argon2 خاموش است (bcrypt وردپرس).' : 'PHP این سرور Argon2 ندارد؛ bcrypt وردپرس استفاده می‌شود که آن هم یک‌طرفه و امن است.' ) ) );

		$c[] = self::st( 12, 'login', 'محدودیت تلاش ورود (Rate Limit)',
			$on( 'login_limit' ) ? 'ok' : 'bad',
			$on( 'login_limit' ) ? (int) $o['login_max'] . ' تلاش ناموفق در دقیقه از هر اتصال، بعد قفل ۱ دقیقه، ۵ دقیقه، ۱۵ دقیقه و ۱ ساعت (هر بار طولانی‌تر). ۱۰ رمز اشتباه برای یک حساب از هر جا = آن حساب ۱ دقیقه کند می‌شود. ورود پیامکی، کد دومرحله‌ای و بازیابی رمز هم محدودیت جدا دارند. پیام خطا برای نام کاربری و رمز یکی است.' : 'خاموش است.' );

		$ck = isset( $p['cookies'] ) ? implode( ' | ', (array) $p['cookies'] ) : '';
		$c[] = self::st( 15, 'login', 'کوکی‌های امن (HttpOnly، Secure، SameSite)',
			$on( 'cookies' ) ? ( $ssl ? 'ok' : 'warn' ) : 'bad',
			$on( 'cookies' ) ? 'همه‌ی کوکی‌ها SameSite=Lax' . ( $ssl ? ' و Secure' : ' (Secure فقط روی HTTPS)' ) . '، کوکی‌های ورود HttpOnly (جاوااسکریپت به آن‌ها دسترسی ندارد).' : 'خاموش است.' );

		$c[] = self::st( 17, 'login', 'لینک ریست پسورد زمان‌دار و یک‌بارمصرف',
			$on( 'reset15' ) ? 'ok' : 'warn',
			$on( 'reset15' ) ? 'لینک بازیابی فقط ۱۵ دقیقه اعتبار دارد و بعد از یک بار استفاده باطل می‌شود؛ بعد از عوض شدن رمز، همه‌ی نشست‌های قبلی آن حساب بسته می‌شود. بیشتر از ۵ درخواست در ۱۵ دقیقه از یک اتصال رد می‌شود.' : 'اعتبار پیش‌فرض وردپرس (۲۴ ساعت).' );

		$c[] = self::st( 9, 'login', 'قفل مسیر ادمین (403 برای کاربر عادی)',
			$on( 'admin_lock' ) ? 'ok' : 'bad',
			$on( 'admin_lock' ) ? 'زائری که وارد حسابش شده و /wp-admin یا /admin را باز کند صفحه‌ی 403 می‌بیند (نوار مدیریت هم برایش نمایش داده نمی‌شود). فقط مدیر، ویرایشگر و نویسنده وارد پیشخوان می‌شوند.' : 'خاموش است.' );

		// ---------------------------------------------------------------- data
		$tools = array_filter( self::leaked_files(), function ( $x ) {
			return preg_match( '#(adminer|phpmyadmin|pma|\.sql|\.sqlite)#i', $x['rel'] );
		} );
		$users_open = ! empty( $P['/wp-json/wp/v2/users']['users'] );
		$c[] = self::st( 3, 'data', 'امنیت دیتابیس (دسترسی مستقیم از مرورگر ممنوع)',
			$tools || $users_open ? 'bad' : 'ok',
			'مرورگر فقط با کدهای سایت حرف می‌زند، نه با دیتابیس. ' . ( $tools ? 'اما این فایل‌ها پیدا شد: ' . implode( '، ', wp_list_pluck( $tools, 'rel' ) ) . '.' : 'ابزار دیتابیس (Adminer / phpMyAdmin) یا فایل .sql در پوشه‌ی سایت نیست.' ) . ' فهرست کاربران برای مهمان‌ها از REST بسته است' . ( $users_open ? ' — ولی آزمایش نشان داد باز است!' : '' ) . '. پیشوند جدول‌ها: ' . esc_html( $wpdb->prefix ) . '.' );

		$c[] = self::st( 10, 'data', 'کوئری‌های پارامتردار (ضد SQL Injection)', 'ok',
			'همه‌ی کوئری‌های افزونه بازبینی شد: ورودی کاربر همیشه با $wpdb->prepare (پارامتر %s / %d) یا insert/update وردپرس به دیتابیس می‌رسد و فقط «داده» خوانده می‌شود.' );

		$c[] = self::st( 6, 'data', 'بررسی فرم‌ها سمت سرور', 'ok',
			'همه‌ی فرم‌ها (رزروها، سفارش، مشاوره، تبادل ارز، ثبت مغازه، پروفایل، چت) دوباره روی سرور چک می‌شوند: تعداد نفرات و اقلام محدوده‌ی مجاز دارند (مثلاً عدد منفی یا ۱۰۰۰ نفر رد می‌شود)، طول متن‌ها محدود است، شماره‌ی تلفن و تاریخ و نوع خدمت معتبر است و رحلة/تور/مرکز باید منتشرشده باشد. درخواست‌های بیش از ۲۰ هزار کاراکتر رد می‌شوند.' );

		$c[] = self::st( 7, 'data', 'جلوگیری از XSS', ( $on( 'csp' ) && $on( 'headers' ) ) ? 'ok' : 'warn',
			'هر متنی که زائر می‌فرستد (نام، پیام، نظر، چت) در سرور پاک‌سازی و در صفحه با esc_html / textContent به‌صورت متن نمایش داده می‌شود؛ «<script>» اجرا نمی‌شود. ' . ( $on( 'csp' ) ? 'Content-Security-Policy هم بارگذاری object / base / قاب از سایت‌های دیگر را می‌بندد.' : '' ) );

		$c[] = self::st( 19, 'data', 'قیمت و پرداخت سمت سرور', 'ok',
			'قیمت هیچ‌جا از مرورگر قبول نمی‌شود: سبد سوپرمارکت، تورها، تاکسی و بلیت‌ها قیمت را از دیتابیس می‌خوانند و جمع را روی سرور حساب می‌کنند؛ موجودی و ظرفیت هم روی سرور کم می‌شود. پرداخت آنلاینی در سایت نیست.' );

		$c[] = self::st( 18, 'data', 'محدودیت نوع و حجم فایل آپلودی',
			$on( 'uploads' ) ? 'ok' : 'warn',
			$on( 'uploads' ) ? 'فایل‌های اجرایی و صفحه‌ای (php، phtml، phar، html، svg، js، exe و …) حتی با دو پسوند مثل shell.php.jpg رد می‌شوند. زائران حداکثر ' . (int) $o['upload_mb'] . ' مگابایت (عکس پروفایل ۳، مغازه ۴ تا ۵، چت ۱۲، مدارک پزشکی ۵) و محتوای عکس‌ها واقعاً بررسی می‌شود. اجرای PHP در پوشه‌ی آپلود بسته است و مدارک پزشکی/حقوقی در پوشه‌ی خصوصی ذخیره می‌شوند.' : 'خاموش است (فقط محدودیت‌های فرم‌ها).' );

		// ---------------------------------------------------------------- keys
		$mp  = (array) get_option( 'mp_sms_login_options', array() );
		$cr  = (array) get_option( 'dalil_cr_options', array() );
		$enc = ( empty( $mp['password'] ) || 0 === strpos( $mp['password'], 'dlzenc:' ) ) && ( empty( $cr['api_key'] ) || 0 === strpos( $cr['api_key'], 'dlzenc:' ) );
		$c[] = self::st( 2, 'keys', 'مخفی بودن کلیدهای API',
			$enc ? 'ok' : 'warn',
			'هیچ کلیدی در کد سمت کاربر (جاوااسکریپت یا HTML) نیست؛ رمز پنل ملی‌پیامک و کلید Servix فقط روی سرور استفاده می‌شوند، ' . ( $enc ? 'رمزنگاری‌شده (sodium) ذخیره شده‌اند' : 'ولی هنوز رمزنگاری نشده‌اند (یک بار تنظیماتشان را ذخیره کنید)' ) . ' و در صفحه‌ی تنظیمات هم دیگر نمایش داده نمی‌شوند. (معادل process.env در وردپرس: wp-config.php)' );

		$cfg_pub = $code( '/wp-config.php.bak' ) === 200 || $code( '/.env' ) === 200;
		$c[] = self::st( 11, 'keys', 'متغیرهای محیطی (.env / wp-config) عمومی نباشند',
			$cfg_pub ? 'bad' : ( file_exists( ABSPATH . '.env' ) ? 'warn' : 'ok' ),
			'رمز دیتابیس و کلیدهای امنیتی در wp-config.php هستند که سرور اجرایش می‌کند و محتوایش هرگز نمایش داده نمی‌شود. ' . ( file_exists( ABSPATH . '.env' ) ? 'یک فایل .env در ریشه‌ی سایت هست؛ اگر لازم نیست حذفش کنید.' : 'فایل .env در ریشه‌ی سایت نیست.' ) . ( $cfg_pub ? ' هشدار: آزمایش نشان داد یکی از این فایل‌ها از اینترنت باز می‌شود!' : '' ) );

		$leak = array();
		foreach ( array( '/.env', '/backup.zip', '/.git/config', '/wp-config.php.bak', '/wp-content/debug.log' ) as $x ) {
			$k = $code( $x );
			if ( 200 === $k ) {
				$leak[] = $x;
			}
		}
		$files = self::leaked_files();
		$c[] = self::st( 23, 'keys', 'فایل‌های لورفته (/.env، /backup.zip، /.git/config)',
			$leak ? 'bad' : ( $files ? 'warn' : ( empty( $p['ok'] ) ? 'warn' : 'ok' ) ),
			( empty( $p['ok'] ) ? 'آزمایش اینترنتی انجام نشد (سرور به خودش وصل نشد). ' : 'آزمایش: ' . implode( '، ', array_map( function ( $x ) use ( $code ) {
				return $x . ' ← ' . ( $code( $x ) ? $code( $x ) : '؟' );
			}, array( '/.env', '/backup.zip', '/.git/config' ) ) ) . '. ' ) . ( $files ? count( $files ) . ' فایل حساس در پوشه‌ی سایت پیدا شد (زبانه‌ی «فایل‌ها»).' : 'فایل حساسی در پوشه‌ی سایت نیست.' ) . ' روی Apache / LiteSpeed قانون‌های .htaccess این آدرس‌ها را 404 می‌کنند' . ( self::htaccess_has() ? ' (نصب شده).' : ' (نصب نشد — .htaccess قابل نوشتن نیست یا سرور Nginx است).' ) );

		$c[] = self::st( 24, 'keys', 'اسکن تاریخچه‌ی گیت و کد برای کلید',
			$keys['git'] || $keys['found'] ? 'warn' : 'ok',
			( $keys['git'] ? 'پوشه‌ی .git روی سرور هست؛ تاریخچه‌اش ممکن است کلید داشته باشد — از سرور حذفش کنید. ' : 'پوشه‌ی .git روی سرور نیست (این افزونه هم بدون تاریخچه‌ی گیت تحویل داده می‌شود). ' ) . (int) $keys['files'] . ' فایل قالب و افزونه‌ها برای کلیدهای AWS، Google، Stripe، GitHub، OpenAI، Telegram و کلید خصوصی اسکن شد: ' . ( $keys['found'] ? count( $keys['found'] ) . ' مورد مشکوک (زبانه‌ی «فایل‌ها»).' : 'چیزی پیدا نشد.' ) );

		$c[] = self::st( 25, 'keys', 'باطل کردن کلیدهای لورفته',
			$keys['found'] ? 'warn' : 'ok',
			$keys['found'] ? 'کلیدهای پیدا شده را در پنل همان سرویس باطل کنید و کلید جدید بسازید.' : 'کلید لورفته‌ای پیدا نشد. اگر روزی شک کردید: رمز پنل ملی‌پیامک و کلید Servix را در پنل خودشان عوض کنید و این‌جا دوباره ذخیره کنید، و با دکمه‌ی «خروج همه از همه‌ی دستگاه‌ها» همه‌ی نشست‌ها را ببندید.' );

		// ---------------------------------------------------------------- network
		$http = isset( $p['http'] ) ? $p['http'] : null;
		$https_ok = $ssl && is_ssl();
		$c[] = self::st( 4, 'net', 'HTTPS اجباری، TLS 1.3 و HSTS',
			! $ssl ? 'bad' : ( $on( 'https' ) && $on( 'hsts' ) ? ( isset( $p['tls13'] ) && false === $p['tls13'] ? 'warn' : 'ok' ) : 'warn' ),
			! $ssl ? 'آدرس سایت هنوز http است؛ اول گواهی SSL را در هاست / Cloudflare فعال و آدرس را در «تنظیمات ← عمومی» https کنید.' : ( 'آدرس http به https منتقل می‌شود' . ( $http ? ' (آزمایش: ' . $http[0] . ')' : '' ) . '، HSTS یک‌ساله فرستاده می‌شود. TLS 1.3: ' . ( isset( $p['tls13'] ) ? ( $p['tls13'] ? 'پشتیبانی می‌شود' : 'سرور پشتیبانی نمی‌کند — در Cloudflare / هاست روشنش کنید' ) : 'قابل آزمایش نبود' ) . '.' ) );

		$acao = isset( $p['cors'] ) ? $p['cors'] : null;
		$c[] = self::st( 13, 'net', 'محدود کردن CORS',
			$acao && ( '*' === $acao || false !== strpos( $acao, 'evil' ) ) ? 'bad' : ( $on( 'cors' ) ? 'ok' : 'warn' ),
			$on( 'cors' ) ? 'به‌جای «*» فقط ' . implode( '، ', self::home_hosts() ) . ' اجازه‌ی خواندن API را با کوکی دارند' . ( null !== $acao ? ' (آزمایش با دامنه‌ی بیگانه: ' . ( $acao ? $acao : 'رد شد' ) . ')' : '' ) . '.' : 'خاموش است (وردپرس به هر دامنه‌ای پاسخ می‌دهد).' );

		$need = array( 'content-security-policy', 'x-frame-options', 'x-content-type-options' );
		if ( $ssl ) {
			$need[] = 'strict-transport-security';
		}
		$miss = array();
		foreach ( $need as $h ) {
			if ( empty( $hdr[ $h ] ) ) {
				$miss[] = $h;
			}
		}
		$c[] = self::st( 14, 'net', 'هدرهای امنیتی',
			! $on( 'headers' ) ? 'bad' : ( $hdr && $miss ? 'warn' : 'ok' ),
			'Content-Security-Policy، ' . ( $ssl ? 'Strict-Transport-Security، ' : '' ) . 'X-Frame-Options، X-Content-Type-Options، Referrer-Policy و Permissions-Policy' . ( $hdr ? ( $miss ? ' — در آزمایش پیدا نشد: ' . implode( '، ', $miss ) . ' (شاید کش قدیمی است؛ کش را پاک کنید).' : ' — در آزمایش همه دیده شدند.' ) : '.' ) . ' هدر X-Powered-By و نسخه‌ی وردپرس پنهان است.' );

		$c[] = self::st( 16, 'net', 'محافظت CSRF',
			$on( 'csrf' ) ? 'ok' : 'warn',
			'هر فرم و درخواست ajax سایت توکن یک‌بارمصرف (nonce) دارد و بدون آن رد می‌شود. ' . ( $on( 'csrf' ) ? 'به‌علاوه درخواست POST به پیشخوان، admin-ajax و صفحه‌ی ورود از دامنه‌ی دیگر (Origin / Referer بیگانه) رد و ثبت می‌شود، و کوکی SameSite=Lax هم کوکی را به سایت‌های دیگر نمی‌دهد.' : '' ) );

		$disp = (string) ini_get( 'display_errors' );
		$dbg_on = ( defined( 'WP_DEBUG' ) && WP_DEBUG && defined( 'WP_DEBUG_DISPLAY' ) && WP_DEBUG_DISPLAY && in_array( strtolower( $disp ), array( '1', 'on', 'stdout' ), true ) );
		$c[] = self::st( 20, 'net', 'خاموش بودن حالت دیباگ',
			$dbg_on ? 'bad' : ( 200 === $code( '/wp-content/debug.log' ) ? 'bad' : 'ok' ),
			'WP_DEBUG: ' . ( defined( 'WP_DEBUG' ) && WP_DEBUG ? 'روشن' : 'خاموش' ) . ' — نمایش خطا برای بازدیدکننده‌ها: ' . ( $on( 'debug_hide' ) || ! $dbg_on ? 'بسته (فقط «Something went wrong» / «حدث خطأ ما» می‌بینند)' : 'باز!' ) . '. فایل debug.log ' . ( 200 === $code( '/wp-content/debug.log' ) ? 'از اینترنت باز می‌شود!' : 'از اینترنت در دسترس نیست' ) . '.' );

		$cnt = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . self::table() . ' WHERE t > %d', time() - DAY_IN_SECONDS ) ); // phpcs:ignore
		$c[] = self::st( 8, 'net', 'لاگ فعالیت مشکوک', ( (int) get_option( 'dlz_sec_db', 0 ) >= self::VER ) ? 'ok' : 'warn',
			'ورودهای ناموفق (به‌خصوص برای حساب مدیر)، قفل‌ها، کد دومرحله‌ای اشتباه، درخواست از سایت دیگر، جستجوی فایل‌های حساس، آپلود رد شده، ساخت مدیر جدید و فعال شدن افزونه ثبت می‌شود (۲۴ ساعت اخیر: ' . $cnt . ' رویداد). موارد خطرناک در «درخواست‌های جدید» و زنگوله هم نمایش داده می‌شوند.' );

		// ---------------------------------------------------------------- packages
		$up = self::updates();
		$c[] = self::st( 21, 'pkg', 'به‌روزرسانی پکیج‌های آسیب‌پذیر (CVE)',
			$up['count'] ? 'warn' : ( version_compare( PHP_VERSION, '8.1', '<' ) ? 'warn' : 'ok' ),
			'افزونه‌ی دلیل الزائر کتابخانه‌ی بیرونی (npm / composer) ندارد. ' . ( $up['count'] ? $up['count'] . ' به‌روزرسانی منتظر است (معمولاً شامل وصله‌های امنیتی): ' . implode( '، ', array_slice( $up['names'], 0, 8 ) ) . '.' : 'وردپرس، قالب‌ها و افزونه‌ها به‌روز هستند.' ) . ' PHP ' . PHP_VERSION . ( version_compare( PHP_VERSION, '8.1', '<' ) ? ' — قدیمی است، از هاست نسخه‌ی ۸.۲ یا بالاتر بخواهید.' : '.' ) );

		$un = self::unused();
		$c[] = self::st( 22, 'pkg', 'حذف پکیج‌های بدون استفاده',
			$un ? 'warn' : 'ok',
			( $un ? 'غیرفعال و بلااستفاده: ' . implode( '، ', array_slice( $un, 0, 10 ) ) . ' — اگر لازم نیستند حذفشان کنید (کد غیرفعال هم روی سرور قابل حمله است).' : 'افزونه یا قالب غیرفعال بلااستفاده‌ای نیست.' ) . ' فایل‌های readme اضافه‌ی زیرماژول‌ها (که نسخه را لو می‌دادند) از افزونه حذف شد.' );

		// ---------------------------------------------------------------- summary
		$bad = 0;
		foreach ( $c as $x ) {
			$bad += 'ok' !== $x['state'] ? 1 : 0;
		}
		$c[] = self::st( 26, 'sum', 'بررسی امنیتی کامل', 'ok', 'همین صفحه: هر ۲۷ مورد هر بار که باز می‌شود زنده بررسی می‌شود؛ آزمایش‌های اینترنتی هر ۶ ساعت (یا با «اسکن دوباره»). الان ' . ( $bad ? $bad . ' مورد بالا نیاز به توجه دارد.' : 'همه‌ی موارد سبز است.' ) );
		$c[] = self::st( 27, 'sum', 'تست و گزارش', 'ok', 'گزارش پایین صفحه: مشکلات پیداشده و رفع‌شده در بازبینی کد، و وضعیت فعلی این سایت.' );

		$issues = 0;
		foreach ( $c as $x ) {
			$issues += 'bad' === $x['state'] ? 1 : 0;
		}
		set_transient( 'dlz_sec_issues', $issues, DAY_IN_SECONDS );
		usort( $c, function ( $a, $b ) {
			return $a['id'] - $b['id'];
		} );
		return $c;
	}

	private static function htaccess_has() {
		$f = ABSPATH . '.htaccess';
		return file_exists( $f ) && false !== strpos( (string) @file_get_contents( $f ), '# BEGIN Dalil Security' ); // phpcs:ignore
	}

	private static function updates() {
		$n     = array();
		$core  = get_site_transient( 'update_core' );
		if ( $core && ! empty( $core->updates ) ) {
			foreach ( $core->updates as $u ) {
				if ( isset( $u->response ) && 'upgrade' === $u->response ) {
					$n[] = 'وردپرس ' . $u->current;
					break;
				}
			}
		}
		$pl = get_site_transient( 'update_plugins' );
		if ( $pl && ! empty( $pl->response ) ) {
			if ( ! function_exists( 'get_plugins' ) ) {
				require_once ABSPATH . 'wp-admin/includes/plugin.php';
			}
			$all = get_plugins();
			foreach ( $pl->response as $f => $u ) {
				$n[] = isset( $all[ $f ] ) ? $all[ $f ]['Name'] : $f;
			}
		}
		$th = get_site_transient( 'update_themes' );
		if ( $th && ! empty( $th->response ) ) {
			foreach ( $th->response as $s => $u ) {
				$n[] = 'قالب ' . $s;
			}
		}
		return array( 'count' => count( $n ), 'names' => $n );
	}

	private static function unused() {
		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
		$out = array();
		foreach ( get_plugins() as $f => $d ) {
			if ( ! is_plugin_active( $f ) ) {
				$out[] = $d['Name'];
			}
		}
		$cur = get_stylesheet();
		$par = get_template();
		foreach ( wp_get_themes() as $s => $t ) {
			if ( $s !== $cur && $s !== $par ) {
				$out[] = 'قالب ' . $t->get( 'Name' );
			}
		}
		return $out;
	}

	/* ------------------------------------------------------------ page */

	private static function groups() {
		return array(
			'login' => array( 'ورود و حساب کاربری', 'dashicons-admin-users' ),
			'data'  => array( 'داده و دیتابیس', 'dashicons-database' ),
			'keys'  => array( 'کلیدها و اطلاعات محرمانه', 'dashicons-admin-network' ),
			'net'   => array( 'شبکه و سرور', 'dashicons-admin-site-alt3' ),
			'pkg'   => array( 'پکیج‌ها', 'dashicons-admin-plugins' ),
			'sum'   => array( 'جمع‌بندی', 'dashicons-yes-alt' ),
		);
	}

	/** What the code review of this version found and fixed (shown in the report). */
	public static function audit() {
		return array(
			array( 'بلیت سفر: رزرو برای هر شناسه‌ای (حتی غیر از سفر) قبول می‌شد؛ طول نام / تلفن محدود نبود', 1 ),
			array( 'تورهای روزانه: تعداد نفرات سقف نداشت (۱ تا بی‌نهایت) و طول نام / تلفن محدود نبود', 1 ),
			array( 'مراکز تفریحی: طول نام و تلفن محدود نبود', 1 ),
			array( 'تبادل ارز: مبلغ سقف نداشت', 1 ),
			array( 'مشاوره درمان / حقوقی: طول پیام، شهر و ملیت محدود نبود؛ محتوای فایل پیوست (عکس / PDF واقعی) بررسی نمی‌شد', 1 ),
			array( 'مدارک پزشکی و حقوقی در پوشه‌ی عمومی آپلود ذخیره می‌شد — حالا در پوشه‌ی خصوصی و فقط از پیشخوان باز می‌شود', 1 ),
			array( 'عکس پروفایل: محتوای فایل (عکس واقعی بودن) بررسی نمی‌شد', 1 ),
			array( 'پروفایل: طول نام و شماره‌ی پاسپورت محدود نبود', 1 ),
			array( 'رمز پنل ملی‌پیامک و کلید Servix به‌صورت متن ساده در دیتابیس و داخل صفحه‌ی تنظیمات بود', 1 ),
			array( 'سه فایل PHP محافظ دسترسی مستقیم (ABSPATH) نداشتند', 1 ),
			array( '۹ فایل readme زیرماژول‌ها نسخه‌ها را عمومی نشان می‌داد', 1 ),
			array( 'محدودیت درخواست‌ها پشت Cloudflare آدرس واقعی زائر را نمی‌دید (همه یک IP)', 1 ),
			array( 'ورود وردپرس محدودیت تلاش نداشت و پیام خطا وجود نام کاربری را لو می‌داد', 1 ),
			array( 'ورود دومرحله‌ای، Argon2، لینک ریست ۱۵ دقیقه‌ای، SameSite، HSTS، CSP، CORS محدود، رد درخواست‌های سایت‌های دیگر، بستن XML-RPC، 404 برای فایل‌های حساس و لاگ امنیتی نبود', 1 ),
		);
	}

	public static function page() {
		if ( ! current_user_can( self::CAP ) ) {
			return;
		}
		$tab    = isset( $_GET['tab'] ) ? sanitize_key( $_GET['tab'] ) : 'check'; // phpcs:ignore
		$checks = self::checks();
		$ok     = 0;
		$bad    = 0;
		foreach ( $checks as $x ) {
			$ok  += 'ok' === $x['state'] ? 1 : 0;
			$bad += 'bad' === $x['state'] ? 1 : 0;
		}
		$pct  = (int) round( $ok * 100 / max( 1, count( $checks ) ) );
		$base = admin_url( 'admin.php?page=' . self::SLUG );
		$tabs = array( 'check' => 'بررسی ۲۷ مورد', '2fa' => 'ورود دومرحله‌ای', 'log' => 'لاگ فعالیت مشکوک', 'files' => 'فایل‌ها و کلیدها', 'settings' => 'تنظیمات', 'report' => 'گزارش' );
		$p    = self::probe();
		?>
		<div class="wrap dsec" dir="rtl">
			<?php self::css(); ?>
			<hr class="wp-header-end" style="display:none">
			<div class="dsec-hero">
				<div class="dsec-ring" style="--p:<?php echo (int) $pct; ?>"><b><?php echo (int) $ok; ?></b><small>از <?php echo count( $checks ); ?></small></div>
				<div class="dsec-hero-t">
					<h1><span class="dashicons dashicons-shield"></span> امنیت سایت</h1>
					<p><?php echo self::off() ? '<b style="color:#DC2626">همه‌ی محافظت‌ها با DLZ_SEC_OFF در wp-config.php خاموش است.</b>' : ( $bad ? '<b>' . (int) $bad . ' مورد نیاز به اقدام دارد.</b> بقیه سبز یا هشدار کوچک هستند.' : 'همه‌ی موارد مهم امن است.' ); ?></p>
					<p class="dsec-sub">آخرین آزمایش اینترنتی: <?php echo ! empty( $p['t'] ) ? esc_html( wp_date( 'Y/m/d H:i', (int) $p['t'] ) ) : '—'; ?>
						<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline"><input type="hidden" name="action" value="dlz_sec_scan"><?php wp_nonce_field( 'dlz_sec_scan' ); ?><button class="button button-small">اسکن دوباره</button></form></p>
				</div>
			</div>
			<nav class="dsec-tabs">
				<?php foreach ( $tabs as $k => $l ) : ?>
					<a class="<?php echo $tab === $k ? 'is-on' : ''; ?>" href="<?php echo esc_url( add_query_arg( 'tab', $k, $base ) ); ?>"><?php echo esc_html( $l ); ?></a>
				<?php endforeach; ?>
			</nav>
			<?php
			if ( '2fa' === $tab ) {
				self::page_2fa();
			} elseif ( 'log' === $tab ) {
				self::page_log();
			} elseif ( 'files' === $tab ) {
				self::page_files();
			} elseif ( 'settings' === $tab ) {
				self::page_settings();
			} elseif ( 'report' === $tab ) {
				self::page_report( $checks );
			} else {
				self::page_checks( $checks );
			}
			?>
		</div>
		<?php
	}

	private static function badge( $s ) {
		$m = array( 'ok' => array( 'امن', 'yes' ), 'warn' => array( 'توجه', 'warning' ), 'bad' => array( 'نیاز به اقدام', 'dismiss' ), 'info' => array( 'اطلاع', 'info' ) );
		$x = isset( $m[ $s ] ) ? $m[ $s ] : $m['info'];
		return '<span class="dsec-pill is-' . esc_attr( $s ) . '"><span class="dashicons dashicons-' . $x[1] . '"></span>' . esc_html( $x[0] ) . '</span>';
	}

	private static function page_checks( $checks ) {
		$by = array();
		foreach ( $checks as $x ) {
			$by[ $x['group'] ][] = $x;
		}
		foreach ( self::groups() as $g => $info ) {
			if ( empty( $by[ $g ] ) ) {
				continue;
			}
			echo '<section class="dsec-group"><h2><span class="dashicons ' . esc_attr( $info[1] ) . '"></span>' . esc_html( $info[0] ) . '</h2><div class="dsec-list">';
			foreach ( $by[ $g ] as $x ) {
				echo '<div class="dsec-item is-' . esc_attr( $x['state'] ) . '"><span class="dsec-no">' . (int) $x['id'] . '</span><div class="dsec-b"><div class="dsec-h"><b>' . esc_html( $x['title'] ) . '</b>' . self::badge( $x['state'] ) . '</div><p>' . esc_html( $x['text'] ) . '</p>' . ( $x['fix'] ? '<p class="dsec-fix"><span class="dashicons dashicons-arrow-left-alt"></span>' . esc_html( $x['fix'] ) . '</p>' : '' ) . '</div></div>'; // phpcs:ignore
			}
			echo '</div></section>';
		}
	}

	private static function page_2fa() {
		$uid  = get_current_user_id();
		$on   = self::is_on( $uid );
		$pend = self::unseal( get_user_meta( $uid, 'dlz_2fa_pending', true ) );
		$show = get_transient( 'dlz_2fa_show_' . $uid );
		$err  = isset( $_GET['e'] ) ? 'کد درست نبود؛ کد ۶ رقمی فعلی برنامه را وارد کنید.' : ''; // phpcs:ignore
		$f    = function ( $op, $label, $cls = 'button-primary', $code = false ) {
			echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="dsec-inline"><input type="hidden" name="action" value="dlz_sec_2fa"><input type="hidden" name="op" value="' . esc_attr( $op ) . '">';
			wp_nonce_field( 'dlz_sec_2fa' );
			if ( $code ) {
				echo '<input type="text" name="code" class="dsec-code" inputmode="numeric" autocomplete="one-time-code" placeholder="کد ۶ رقمی" required> ';
			}
			echo '<button class="button ' . esc_attr( $cls ) . '">' . esc_html( $label ) . '</button></form>';
		};
		echo '<section class="dsec-card">';
		if ( isset( $_GET['must'] ) ) { // phpcs:ignore
			echo '<div class="notice notice-error inline"><p>ورود دومرحله‌ای برای کارمندان اجباری است؛ اول آن را فعال کنید.</p></div>';
		}
		if ( self::twofa_disabled() ) {
			echo '<p><b>ورود دومرحله‌ای با DLZ_2FA_OFF در wp-config.php خاموش است.</b></p></section>';
			return;
		}
		if ( $err ) {
			echo '<div class="notice notice-error inline"><p>' . esc_html( $err ) . '</p></div>';
		}
		if ( is_array( $show ) && $show ) {
			echo '<div class="dsec-codes"><h3>کدهای پشتیبان شما</h3><p>این ۸ کد را جایی امن (کاغذ یا مدیر رمز) نگه دارید. اگر گوشی در دسترس نبود، هر کد یک بار به‌جای کد برنامه کار می‌کند. <b>این کدها فقط همین یک بار نمایش داده می‌شوند.</b></p><ol>';
			foreach ( $show as $cd ) {
				echo '<li><code>' . esc_html( $cd ) . '</code></li>';
			}
			echo '</ol></div>';
			delete_transient( 'dlz_2fa_show_' . $uid );
		}
		if ( $on ) {
			$left = count( (array) get_user_meta( $uid, 'dlz_2fa_codes', true ) );
			echo '<h2><span class="dashicons dashicons-yes-alt" style="color:#0F8A5F"></span> ورود دومرحله‌ای برای حساب شما فعال است</h2><p>بعد از رمز، کد ۶ رقمی برنامه پرسیده می‌شود. کدهای پشتیبان باقی‌مانده: <b>' . (int) $left . '</b></p><div class="dsec-row">';
			$f( 'codes', 'ساخت کدهای پشتیبان جدید', 'button-secondary' );
			echo '</div><hr><p>خاموش کردن (نیاز به کد فعلی برنامه یا یک کد پشتیبان):</p>';
			$f( 'disable', 'خاموش کردن', 'button-secondary', true );
		} elseif ( $pend ) {
			$label = rawurlencode( get_bloginfo( 'name' ) . ':' . wp_get_current_user()->user_login );
			$uri   = 'otpauth://totp/' . $label . '?secret=' . $pend . '&issuer=' . rawurlencode( get_bloginfo( 'name' ) ) . '&digits=6&period=30';
			echo '<h2>فعال‌سازی ورود دومرحله‌ای — ۲ قدم</h2><div class="dsec-setup"><div class="dsec-qr">' . DLZ_QR::svg( $uri, 210 ) . '</div><div><ol class="dsec-steps"><li>برنامه‌ی <b>Google Authenticator</b> یا <b>Microsoft Authenticator</b> را روی گوشی باز کنید و «+» ← «اسکن کد QR» را بزنید و این کد را اسکن کنید.<br><small>اسکن ممکن نیست؟ «وارد کردن کلید» را بزنید و این را بنویسید:</small><br><code class="dsec-secret">' . esc_html( trim( chunk_split( $pend, 4, ' ' ) ) ) . '</code><br><small>روی خود گوشی هستید؟ <a href="' . esc_attr( $uri ) . '">این لینک را بزنید</a>.</small></li><li>کد ۶ رقمی که برنامه نشان می‌دهد را این‌جا بنویسید:</li></ol>'; // phpcs:ignore
			$f( 'confirm', 'تأیید و فعال‌سازی', 'button-primary', true );
			echo ' ';
			$f( 'cancel', 'انصراف', 'button-link' );
			echo '</div></div>';
		} else {
			echo '<h2>ورود دومرحله‌ای (2FA)</h2><p>با روشن کردنش، بعد از رمز، یک کد ۶ رقمی که هر ۳۰ ثانیه در گوشی شما عوض می‌شود هم پرسیده می‌شود. حتی اگر رمز کسی لو برود، بدون گوشی او نمی‌شود وارد پیشخوان شد. تا کد وارد نشود، حساب هیچ دسترسی مدیریتی ندارد.</p>';
			$f( 'start', 'شروع فعال‌سازی' );
		}
		echo '<p class="dsec-note">گوشی گم شد و کد پشتیبان هم ندارید؟ مدیر دیگری می‌تواند از «کاربران» برای شما خاموشش کند، یا در wp-config.php بنویسید: <code>define( \'DLZ_2FA_OFF\', true );</code></p></section>';

		// staff overview
		$staff = get_users( array( 'capability' => 'edit_posts', 'number' => 50 ) );
		echo '<section class="dsec-card"><h3>کارمندان</h3><table class="widefat striped"><thead><tr><th>کاربر</th><th>نقش</th><th>ورود دومرحله‌ای</th></tr></thead><tbody>';
		foreach ( $staff as $u ) {
			echo '<tr><td>' . esc_html( $u->user_login ) . '</td><td>' . esc_html( implode( '، ', $u->roles ) ) . '</td><td>' . ( self::is_on( $u->ID ) ? '<span style="color:#0F8A5F">فعال</span>' : '<span style="color:#B45309">خاموش</span>' ) . '</td></tr>';
		}
		echo '</tbody></table></section>';
	}

	private static function page_log() {
		global $wpdb;
		$types = self::types();
		$f     = isset( $_GET['type'] ) ? sanitize_key( $_GET['type'] ) : ''; // phpcs:ignore
		$rows  = $f && isset( $types[ $f ] )
			? $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . self::table() . ' WHERE type = %s ORDER BY id DESC LIMIT 300', $f ) ) // phpcs:ignore
			: $wpdb->get_results( 'SELECT * FROM ' . self::table() . ' ORDER BY id DESC LIMIT 300' ); // phpcs:ignore
		$base  = admin_url( 'admin.php?page=' . self::SLUG . '&tab=log' );
		echo '<section class="dsec-card"><div class="dsec-filter"><a class="' . ( $f ? '' : 'is-on' ) . '" href="' . esc_url( $base ) . '">همه</a>';
		foreach ( $types as $k => $t ) {
			echo '<a class="' . ( $f === $k ? 'is-on' : '' ) . '" href="' . esc_url( add_query_arg( 'type', $k, $base ) ) . '">' . esc_html( $t[0] ) . '</a>';
		}
		echo '</div>';
		if ( ! $rows ) {
			echo '<p class="dsec-empty">هنوز رویدادی ثبت نشده است.</p></section>';
			return;
		}
		echo '<table class="widefat dsec-log"><thead><tr><th>زمان</th><th>رویداد</th><th>حساب</th><th>جزئیات</th><th>IP</th></tr></thead><tbody>';
		foreach ( $rows as $r ) {
			$t = isset( $types[ $r->type ] ) ? $types[ $r->type ] : array( $r->type, '#555' );
			echo '<tr class="lvl-' . (int) $r->lvl . '"><td>' . esc_html( wp_date( 'Y/m/d H:i:s', (int) $r->t ) ) . '</td><td><span class="dsec-tag" style="--c:' . esc_attr( $t[1] ) . '">' . esc_html( $t[0] ) . '</span></td><td>' . esc_html( $r->who ) . '</td><td>' . esc_html( $r->msg ) . '</td><td dir="ltr">' . esc_html( $r->ip ) . '</td></tr>';
		}
		echo '</tbody></table></section>';
	}

	private static function page_files() {
		$files = self::leaked_files();
		$keys  = self::code_scan();
		$p     = self::probe();
		echo '<section class="dsec-card"><h3>فایل‌های حساس در پوشه‌ی سایت</h3>';
		if ( ! $files ) {
			echo '<p class="dsec-empty">چیزی پیدا نشد (.env، پشتیبان zip / sql، .git، debug.log، phpinfo، adminer …).</p>';
		} else {
			echo '<table class="widefat striped"><thead><tr><th>فایل</th><th>حجم</th><th></th></tr></thead><tbody>';
			foreach ( $files as $x ) {
				echo '<tr><td dir="ltr" style="text-align:right">' . esc_html( $x['rel'] ) . '</td><td>' . ( $x['dir'] ? 'پوشه' : esc_html( size_format( $x['size'] ) ) ) . '</td><td>';
				if ( ! $x['dir'] ) {
					echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" onsubmit="return confirm(\'این فایل برای همیشه حذف شود؟\')"><input type="hidden" name="action" value="dlz_sec_tool"><input type="hidden" name="op" value="delete_file"><input type="hidden" name="f" value="' . esc_attr( $x['rel'] ) . '">';
					wp_nonce_field( 'dlz_sec_tool' );
					echo '<button class="button button-small">حذف</button></form>';
				} else {
					echo '<small>از طریق هاست حذف کنید</small>';
				}
				echo '</td></tr>';
			}
			echo '</tbody></table>';
		}
		echo '</section><section class="dsec-card"><h3>آزمایش از دید یک غریبه</h3>';
		if ( empty( $p['ok'] ) ) {
			echo '<p class="dsec-empty">سرور نتوانست به خودش وصل شود (بعضی هاست‌ها اجازه نمی‌دهند). از مرورگر خودتان این آدرس‌ها را باز کنید؛ همه باید 404 یا 403 بدهند.</p>';
		}
		echo '<table class="widefat striped"><thead><tr><th>آدرس</th><th>پاسخ</th><th>انتظار</th></tr></thead><tbody>';
		$expect = array( '/.env' => '404', '/backup.zip' => '404', '/.git/config' => '404', '/wp-config.php.bak' => '404', '/wp-content/debug.log' => '404', '/readme.html' => '404', '/wp-content/uploads/' => 'بدون فهرست فایل‌ها', '/wp-json/wp/v2/users' => 'بدون فهرست کاربران', '/?author=1' => 'بدون نام کاربری (301 به خانه)', '/xmlrpc.php' => '403', '/wp-admin/' => '302 به صفحه‌ی ورود' );
		foreach ( $expect as $path => $want ) {
			$r  = isset( $p['paths'][ $path ] ) ? $p['paths'][ $path ] : null;
			$cd = $r ? (int) $r['code'] : 0;
			$good = $r && ( ( '/wp-content/uploads/' === $path && empty( $r['index'] ) ) || ( '/wp-json/wp/v2/users' === $path && empty( $r['users'] ) ) || ( '/?author=1' === $path && false === strpos( (string) $r['loc'], 'author/' ) ) || ( '/wp-admin/' === $path && 302 === $cd ) || in_array( $cd, array( 403, 404, 410 ), true ) );
			echo '<tr><td dir="ltr" style="text-align:right"><a href="' . esc_url( home_url( $path ) ) . '" target="_blank" rel="noopener">' . esc_html( $path ) . '</a></td><td>' . ( $r ? ( $cd ? (int) $cd : 'خطا' ) : '—' ) . ' ' . ( $r ? self::badge( $good ? 'ok' : 'bad' ) : '' ) . '</td><td>' . esc_html( $want ) . '</td></tr>'; // phpcs:ignore
		}
		echo '</tbody></table>';
		if ( ! self::htaccess_has() ) {
			echo '<p class="dsec-note">سرور شما Nginx است یا .htaccess قابل نوشتن نیست؛ این قانون را به پیکربندی Nginx اضافه کنید:<br><code dir="ltr" style="display:block;text-align:left;white-space:pre">location ~ /\.(?!well-known) { return 404; }' . "\n" . 'location ~* \.(env|ini|log|sql|bak|old|swp|sh)$ { return 404; }' . "\n" . 'location ~* ^/wp-content/uploads/.*\.php$ { return 404; }' . "\n" . 'location ^~ /wp-content/uploads/dlz-private/ { return 404; }</code></p>';
		}
		echo '</section><section class="dsec-card"><h3>کلیدهای نوشته‌شده در کد</h3><p>' . (int) $keys['files'] . ' فایل قالب و افزونه‌ها اسکن شد' . ( ! empty( $keys['t'] ) ? ' (' . esc_html( wp_date( 'Y/m/d H:i', (int) $keys['t'] ) ) . ')' : '' ) . '.' . ( $keys['git'] ? ' <b style="color:#DC2626">پوشه‌ی .git روی سرور هست.</b>' : '' ) . '</p>';
		if ( $keys['found'] ) {
			echo '<table class="widefat striped"><thead><tr><th>فایل</th><th>نوع</th><th>شروع</th></tr></thead><tbody>';
			foreach ( $keys['found'] as $k ) {
				echo '<tr><td dir="ltr" style="text-align:right">' . esc_html( $k['file'] ) . '</td><td>' . esc_html( $k['type'] ) . '</td><td dir="ltr"><code>' . esc_html( $k['hint'] ) . '</code></td></tr>';
			}
			echo '</tbody></table>';
		} else {
			echo '<p class="dsec-empty">کلیدی پیدا نشد.</p>';
		}
		echo '<hr><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" onsubmit="return confirm(\'همه (از جمله خود شما) از همه‌ی دستگاه‌ها خارج می‌شوند. ادامه؟\')"><input type="hidden" name="action" value="dlz_sec_tool"><input type="hidden" name="op" value="logout_all">';
		wp_nonce_field( 'dlz_sec_tool' );
		echo '<button class="button">خروج همه‌ی کاربران از همه‌ی دستگاه‌ها</button> <small>بعد از لو رفتن رمز یا کلید.</small></form></section>';
	}

	private static function page_settings() {
		$o   = self::opt();
		$box = function ( $k, $label, $help = '' ) use ( $o ) {
			echo '<label class="dsec-sw"><input type="checkbox" name="s[' . esc_attr( $k ) . ']" value="1" ' . checked( ! empty( $o[ $k ] ), true, false ) . '><span class="dsec-tg"></span><span><b>' . esc_html( $label ) . '</b>' . ( $help ? '<small>' . esc_html( $help ) . '</small>' : '' ) . '</span></label>';
		};
		if ( isset( $_GET['saved'] ) ) { // phpcs:ignore
			echo '<div class="notice notice-success inline"><p>ذخیره شد.</p></div>';
		}
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="dsec-card dsec-set"><input type="hidden" name="action" value="dlz_sec_save">';
		wp_nonce_field( 'dlz_sec_save' );
		echo '<h3>ورود</h3>';
		$box( 'login_limit', 'محدودیت تلاش ورود', 'قفل موقت بعد از تلاش‌های ناموفق' );
		echo '<p class="dsec-num">حداکثر تلاش در دقیقه: <input type="number" min="3" max="20" name="s[login_max]" value="' . (int) $o['login_max'] . '"></p>';
		$box( 'twofa_force', 'ورود دومرحله‌ای اجباری برای همه‌ی کارمندان', 'هر مدیر / ویرایشگر / نویسنده‌ای که فعالش نکرده، اول به صفحه‌ی فعال‌سازی فرستاده می‌شود' );
		$box( 'argon', 'ذخیره‌ی رمزها با Argon2id' );
		$box( 'reset15', 'لینک بازیابی رمز ۱۵ دقیقه‌ای' );
		$box( 'admin_lock', 'قفل پیشخوان برای زائران (403)' );
		echo '<h3>شبکه</h3>';
		$box( 'https', 'انتقال اجباری به HTTPS', 'فقط وقتی آدرس سایت https است' );
		$box( 'hsts', 'HSTS (Strict-Transport-Security)' );
		$box( 'cookies', 'کوکی‌های امن (SameSite، Secure، HttpOnly)' );
		$box( 'headers', 'هدرهای امنیتی' );
		$box( 'csp', 'Content-Security-Policy' );
		$box( 'cors', 'CORS فقط برای دامنه‌ی خود سایت' );
		$box( 'csrf', 'رد درخواست‌هایی که از سایت دیگر می‌آیند' );
		echo '<p class="dsec-num">دامنه‌های مجاز دیگر (هر کدام یک خط، مثلاً آدرس اپ):<br><textarea name="s[origins]" rows="3" dir="ltr" style="width:100%;max-width:420px">' . esc_textarea( $o['origins'] ) . '</textarea></p>';
		echo '<h3>فایل‌ها و خطاها</h3>';
		$box( 'files', '404 برای فایل‌های حساس (.env، پشتیبان‌ها، .git، لاگ‌ها) و بستن PHP در آپلودها', 'قانون‌ها در .htaccess (Apache / LiteSpeed) نوشته می‌شوند' );
		$box( 'uploads', 'بررسی آپلودها (نوع و حجم)' );
		echo '<p class="dsec-num">حداکثر حجم آپلود زائران (مگابایت): <input type="number" min="1" max="200" name="s[upload_mb]" value="' . (int) $o['upload_mb'] . '"></p>';
		$box( 'debug_hide', 'پنهان کردن جزئیات خطا از بازدیدکننده‌ها' );
		$box( 'xmlrpc', 'بستن XML-RPC', 'راه قدیمی ورود که برای حدس رمز استفاده می‌شود' );
		$box( 'alert', 'نمایش رویدادهای خطرناک در «درخواست‌های جدید»' );
		echo '<p><button class="button button-primary button-large">ذخیره</button></p><p class="dsec-note">اگر روزی تنظیمی دسترسی را قطع کرد، در wp-config.php بنویسید <code>define( \'DLZ_SEC_OFF\', true );</code> تا همه‌ی این محافظت‌ها موقتاً خاموش شوند.</p></form>';
	}

	private static function page_report( $checks ) {
		$a     = self::audit();
		$fixed = 0;
		foreach ( $a as $x ) {
			$fixed += $x[1] ? 1 : 0;
		}
		$now = array( 'ok' => 0, 'warn' => 0, 'bad' => 0 );
		foreach ( $checks as $x ) {
			if ( isset( $now[ $x['state'] ] ) ) {
				$now[ $x['state'] ]++;
			}
		}
		echo '<section class="dsec-card"><h3>گزارش بازبینی کد (نسخه‌ی ' . esc_html( DASE_VERSION ) . ')</h3><div class="dsec-stats"><div><b>' . count( $a ) . '</b><span>مشکل پیدا شد</span></div><div><b>' . (int) $fixed . '</b><span>رفع شد</span></div><div><b>' . (int) $now['ok'] . '/' . count( $checks ) . '</b><span>مورد امن روی این سایت</span></div><div><b>' . (int) ( $now['warn'] + $now['bad'] ) . '</b><span>نیاز به توجه شما</span></div></div><ol class="dsec-audit">';
		foreach ( $a as $x ) {
			echo '<li>' . esc_html( $x[0] ) . ' — ' . ( $x[1] ? '<span style="color:#0F8A5F">رفع شد</span>' : '<span style="color:#B45309">باز</span>' ) . '</li>';
		}
		echo '</ol></section><section class="dsec-card"><h3>کارهایی که فقط شما (یا هاست) می‌توانید انجام دهید</h3><ul class="dsec-todo">';
		foreach ( $checks as $x ) {
			if ( 'ok' !== $x['state'] && $x['id'] < 26 ) {
				echo '<li><b>' . (int) $x['id'] . '. ' . esc_html( $x['title'] ) . ':</b> ' . esc_html( $x['fix'] ? $x['fix'] : $x['text'] ) . '</li>';
			}
		}
		echo '</ul></section>';
	}

	private static function css() {
		?>
		<style>
		.dsec{--g:#0F4D2E;--g2:#0F8A5F;--a:#C9A227;--card:#FFFDF7;--line:#EADFBF;max-width:1100px}
		.dsec .dashicons{vertical-align:middle}
		.dsec-hero{display:flex;align-items:center;gap:22px;margin:14px 0 16px;padding:22px 24px;border-radius:22px;background:linear-gradient(135deg,#0F4D2E,#0B3A23);color:#fff;box-shadow:0 18px 40px -26px rgba(15,77,46,.9)}
		.dsec-hero h1{color:#fff;margin:0 0 6px;font-size:23px;font-weight:800;padding:0}.dsec-hero h1 .dashicons{color:var(--a);font-size:26px;width:26px;height:26px}
		.dsec-hero p{margin:0 0 4px;color:#E9F2EC}.dsec-sub{font-size:12px;opacity:.9}.dsec-hero .button{background:transparent;border-color:var(--a);color:#F3D67A;border-radius:999px;margin-inline-start:6px}.dsec-hero .button:hover{background:var(--a);color:#0F4D2E}
		.dsec-ring{--p:0;flex:none;width:92px;height:92px;border-radius:50%;display:grid;place-items:center;align-content:center;background:radial-gradient(closest-side,#0F4D2E 78%,transparent 80% 100%),conic-gradient(var(--a) calc(var(--p)*1%),rgba(255,255,255,.18) 0)}
		.dsec-ring b{font-size:28px;line-height:1}.dsec-ring small{font-size:11px;opacity:.85}
		.dsec-tabs{display:flex;flex-wrap:wrap;gap:6px;margin:0 0 14px}
		.dsec-tabs a{padding:8px 14px;border-radius:999px;background:#fff;box-shadow:inset 0 0 0 1px var(--line);color:#1F2A24;text-decoration:none;font-weight:600}
		.dsec-tabs a.is-on{background:var(--g);color:#fff;box-shadow:none}
		.dsec-group{margin:0 0 18px}.dsec-group h2{display:flex;align-items:center;gap:8px;font-size:16px;margin:0 0 10px;color:var(--g)}
		.dsec-list{display:grid;gap:8px}
		.dsec-item{display:flex;gap:12px;padding:13px 14px;border-radius:16px;background:var(--card);box-shadow:inset 0 0 0 1px var(--line)}
		.dsec-item.is-bad{box-shadow:inset 0 0 0 1.5px #F2B8B5;background:#FFF8F7}
		.dsec-no{flex:none;width:30px;height:30px;border-radius:50%;display:grid;place-items:center;background:#F3EAD0;color:#7A5A12;font-weight:800}
		.dsec-b{flex:1;min-width:0}.dsec-h{display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap}.dsec-h b{font-size:14px}
		.dsec-b p{margin:5px 0 0;color:#3C4A42;line-height:1.85}.dsec-fix{color:#7A5A12!important;font-weight:600}
		.dsec-pill{display:inline-flex;align-items:center;gap:3px;padding:2px 10px 2px 8px;border-radius:999px;font-size:12px;font-weight:700}
		.dsec-pill .dashicons{font-size:16px;width:16px;height:16px}
		.dsec-pill.is-ok{background:#E3F4EA;color:#0F7A4E}.dsec-pill.is-warn{background:#FFF1D6;color:#9A6200}.dsec-pill.is-bad{background:#FDE2E1;color:#B42318}.dsec-pill.is-info{background:#E5EEF9;color:#1D4E89}
		.dsec-card{margin:0 0 14px;padding:18px 20px;border-radius:18px;background:var(--card);box-shadow:inset 0 0 0 1px var(--line)}
		.dsec-card h2,.dsec-card h3{margin-top:0;color:var(--g)}
		.dsec-inline{display:inline-flex;gap:6px;align-items:center;margin:4px 0}
		.dsec-code{width:130px;font-size:18px;letter-spacing:3px;text-align:center;direction:ltr}
		.dsec-setup{display:flex;gap:22px;flex-wrap:wrap;align-items:flex-start}.dsec-qr{padding:10px;border-radius:16px;background:#fff;box-shadow:inset 0 0 0 1px var(--line)}
		.dsec-steps{margin:0 18px 10px 0;line-height:2}.dsec-secret{display:inline-block;direction:ltr;font-size:15px;padding:4px 8px;margin:4px 0;letter-spacing:1px}
		.dsec-codes{padding:14px 16px;border-radius:14px;background:#FFF8E5;box-shadow:inset 0 0 0 1px #F0D88A;margin:0 0 14px}.dsec-codes ol{columns:2;max-width:380px}.dsec-codes code{font-size:15px;direction:ltr}
		.dsec-note{color:#646970;font-size:12px;line-height:1.9}
		.dsec-filter{display:flex;flex-wrap:wrap;gap:6px;margin:0 0 12px}.dsec-filter a{padding:4px 10px;border-radius:999px;background:#fff;box-shadow:inset 0 0 0 1px var(--line);text-decoration:none;font-size:12px}.dsec-filter a.is-on{background:var(--g);color:#fff}
		.dsec-log td{vertical-align:middle}.dsec-log tr.lvl-3 td{background:#FFF4F3}.dsec-log tr.lvl-2 td{background:#FFFBF0}
		.dsec-tag{--c:#555;display:inline-block;padding:2px 9px;border-radius:999px;font-size:12px;font-weight:700;color:var(--c);background:color-mix(in srgb,var(--c) 12%,#fff)}
		.dsec-empty{color:#646970}
		.dsec-set h3{margin:18px 0 8px}.dsec-sw{display:flex;align-items:flex-start;gap:10px;padding:8px 0;cursor:pointer}.dsec-sw input{position:absolute;opacity:0}.dsec-sw small{display:block;color:#646970;font-weight:400}
		.dsec-tg{flex:none;position:relative;width:38px;height:22px;border-radius:999px;background:#CFC7B0;transition:.2s}.dsec-tg:after{content:"";position:absolute;top:3px;right:3px;width:16px;height:16px;border-radius:50%;background:#fff;transition:.2s}
		.dsec-sw input:checked+.dsec-tg{background:var(--g2)}.dsec-sw input:checked+.dsec-tg:after{right:19px}.dsec-sw input:focus-visible+.dsec-tg{outline:2px solid var(--a)}
		.dsec-num{margin:6px 48px 8px 0}
		.dsec-stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px;margin:0 0 14px}.dsec-stats div{padding:14px;border-radius:14px;background:#fff;box-shadow:inset 0 0 0 1px var(--line);text-align:center}.dsec-stats b{display:block;font-size:26px;color:var(--g)}.dsec-stats span{color:#646970}
		.dsec-audit li,.dsec-todo li{line-height:1.9;margin-bottom:4px}
		@media (max-width:700px){.dsec-hero{flex-direction:column;text-align:center}}
		</style>
		<?php
	}
}

DLZ_Security::boot();
