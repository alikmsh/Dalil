<?php
/**
 * Dalil Al Zaer — prices in the visitor's own currency.
 *
 * Every price on the site is entered in Iraqi dinars (or with its own unit written next to it:
 * «تومان», «$», «ريال» …). On the front end it is shown in the visitor's «العملة المفضلة» of
 * «الملف الشخصي» (user meta dlz_currency): $, €, or an Arab currency with its short symbol
 * (د.ع، ل.ل، د.ب، ر.س، د.ك، ر.ع، د.إ، ر.ق، ل.س، ر.ي). Default (guests too): US dollar. No toman.
 *
 * Rates: IQD / USD / KWD / SAR / OMR / Iranian rial come from «أسعار العملات» (the live Servix cache,
 * read only — a page view never waits on the API); AED, QAR and BHD follow their dollar peg; LBP, SYP
 * and YER have default dollar rates. Every rate can be fixed by hand in «دلیل الزائر → ارز قیمت‌ها».
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DLZ_Money {

	const OPT  = 'dlz_money';
	const LAST = 'dlz_money_live';

	/** code => [Arabic symbol, decimals, rounding step, Persian name, units per 1 USD (default)] */
	public static function defs() {
		return array(
			'USD' => array( '$', 2, 0, 'دلار آمریکا', 1 ),
			'EUR' => array( '€', 2, 0, 'یورو', 0.86 ),
			'IQD' => array( 'د.ع', 0, 1, 'دینار عراق', 1400 ),
			'LBP' => array( 'ل.ل', 0, 100, 'لیره لبنان', 89500 ),
			'BHD' => array( 'د.ب', 3, 0, 'دینار بحرین', 0.376 ),
			'SAR' => array( 'ر.س', 2, 0, 'ریال عربستان', 3.75 ),
			'KWD' => array( 'د.ك', 3, 0, 'دینار کویت', 0.307 ),
			'OMR' => array( 'ر.ع', 3, 0, 'ریال عمان', 0.3845 ),
			'AED' => array( 'د.إ', 2, 0, 'درهم امارات', 3.6725 ),
			'QAR' => array( 'ر.ق', 2, 0, 'ریال قطر', 3.64 ),
			'SYP' => array( 'ل.س', 0, 1, 'لیره سوریه (جدید)', 122 ),
			'YER' => array( 'ر.ي', 0, 1, 'ریال یمن (عدن)', 1576 ),
		);
	}

	/** Arabic names for the «العملة المفضلة» list. */
	public static function names() {
		return array(
			'USD' => 'دولار أمريكي', 'EUR' => 'يورو', 'IQD' => 'دينار عراقي', 'LBP' => 'ليرة لبنانية', 'BHD' => 'دينار بحريني',
			'SAR' => 'ريال سعودي', 'KWD' => 'دينار كويتي', 'OMR' => 'ريال عماني', 'AED' => 'درهم إماراتي', 'QAR' => 'ريال قطري',
			'SYP' => 'ليرة سورية', 'YER' => 'ريال يمني',
		);
	}

	/** profile country => currency */
	public static function country_map() {
		return array(
			'iq' => 'IQD', 'lb' => 'LBP', 'bh' => 'BHD', 'sa' => 'SAR', 'kw' => 'KWD',
			'om' => 'OMR', 'ae' => 'AED', 'qa' => 'QAR', 'sy' => 'SYP', 'ye' => 'YER',
		);
	}

	/** Words / symbols a price may be written with => currency code (longest first). */
	private static function tokens() {
		static $t = null;
		if ( null === $t ) {
			$t = array(
				'دينار عراقي' => 'IQD', 'دینار عراقی' => 'IQD', 'ألف دينار' => 'IQD1000', 'الف دينار' => 'IQD1000',
				'دنانير' => 'IQD', 'دينار' => 'IQD', 'دینار' => 'IQD', 'د.ع' => 'IQD', 'ع.د' => 'IQD', 'IQD' => 'IQD',
				'دولار' => 'USD', 'دلار' => 'USD', 'USD' => 'USD', '$' => 'USD', 'يورو' => 'EUR', 'یورو' => 'EUR',
				'تومان' => 'IRT', 'تومن' => 'IRT', 'IRT' => 'IRT',
				'ريال إيراني' => 'IRR', 'ریال' => 'IRR', 'ريال' => 'IRR', 'IRR' => 'IRR',
			);
			foreach ( self::defs() as $code => $d ) {
				$t[ $d[0] ] = $code;
				$t[ $code ] = $code;
			}
			uksort( $t, function ( $a, $b ) {
				return mb_strlen( $b ) - mb_strlen( $a );
			} );
		}
		return $t;
	}

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 22 );
		add_action( 'admin_init', array( __CLASS__, 'register' ) );
		add_action( 'wp_head', array( __CLASS__, 'head_js' ), 1 );
		add_action( 'dalil_cr_refresh', array( __CLASS__, 'snapshot' ), 20 );
	}

	/* ---------------------------------------------------------
	 * Rates — how many Iraqi dinars one unit is worth
	 * ------------------------------------------------------- */

	public static function settings() {
		$o = get_option( self::OPT, array() );
		return wp_parse_args( is_array( $o ) ? $o : array(), array( 'def' => 'USD', 'usd' => array(), 'fix' => array() ) );
	}

	/** Live rates from «أسعار العملات» (rials per unit) — the cache only, never the API. */
	public static function snapshot() {
		$c = get_transient( 'dalil_cr_cache' );
		if ( ! is_array( $c ) || empty( $c['IQD_RLS']['value'] ) || empty( $c['USD_RLS']['value'] ) ) {
			return get_option( self::LAST, array() );
		}
		$live = array();
		foreach ( array( 'USD', 'IQD', 'KWD', 'SAR', 'OMR' ) as $k ) {
			if ( ! empty( $c[ $k . '_RLS' ]['value'] ) && $c[ $k . '_RLS' ]['value'] > 0 ) {
				$live[ $k ] = (float) $c[ $k . '_RLS' ]['value'];
			}
		}
		$old = get_option( self::LAST, array() );
		if ( $old !== $live ) {
			update_option( self::LAST, $live, true );
		}
		return $live;
	}

	/** code => IQD per 1 unit (all known currencies + USD, IRT, IRR). */
	public static function rates() {
		static $r = null;
		if ( null !== $r ) {
			return $r;
		}
		$o    = self::settings();
		$defs = self::defs();
		$live = self::snapshot();
		$fix  = is_array( $o['fix'] ) ? $o['fix'] : array();
		$usd  = is_array( $o['usd'] ) ? $o['usd'] : array();

		// dinars per dollar
		$iqd_usd = ! empty( $live['USD'] ) && ! empty( $live['IQD'] ) ? $live['USD'] / $live['IQD'] : $defs['IQD'][4];
		if ( ! empty( $usd['IQD'] ) && $usd['IQD'] > 0 ) {
			$iqd_usd = (float) $usd['IQD'];
		}
		$r = array( 'IQD' => 1.0, 'USD' => $iqd_usd );
		foreach ( $defs as $code => $d ) {
			if ( 'IQD' === $code ) {
				continue;
			}
			if ( ! empty( $usd[ $code ] ) && $usd[ $code ] > 0 ) {
				$r[ $code ] = $iqd_usd / (float) $usd[ $code ];
			} elseif ( ! empty( $live[ $code ] ) && ! empty( $live['IQD'] ) ) {
				$r[ $code ] = $live[ $code ] / $live['IQD'];
			} else {
				$r[ $code ] = $iqd_usd / $d[4];
			}
		}
		// Iranian rial / toman — only as a source unit («تومان» prices of the owners)
		if ( ! empty( $live['IQD'] ) ) {
			$r['IRR'] = 1 / $live['IQD'];
		} else {
			$r['IRR'] = $iqd_usd / 1150000;
		}
		$r['IRT']     = $r['IRR'] * 10;
		$r['IQD1000'] = 1000.0;
		foreach ( $fix as $code => $v ) {
			if ( isset( $r[ $code ] ) && (float) $v > 0 ) {
				$r[ $code ] = (float) $v;
			}
		}
		return $r;
	}

	/* ---------------------------------------------------------
	 * The visitor's currency
	 * ------------------------------------------------------- */

	/** The visitor's currency: «العملة المفضلة» of the profile, else the default (US dollar). */
	public static function code() {
		static $base = null;
		if ( null === $base ) {
			$o    = self::settings();
			$base = isset( self::defs()[ $o['def'] ] ) ? $o['def'] : 'USD';
			if ( is_user_logged_in() ) {
				$c = (string) get_user_meta( get_current_user_id(), 'dlz_currency', true );
				if ( isset( self::defs()[ $c ] ) ) {
					$base = $c;
				}
			}
		}
		/** Filter: the currency a visitor sees. */
		$c = apply_filters( 'dlz_money_code', $base );
		return isset( self::defs()[ $c ] ) ? $c : 'USD';
	}

	/** USD, EUR and the currency of the visitor's country first, then the other Arab currencies. */
	public static function choices( $country = '' ) {
		$map   = self::country_map();
		$first = array( 'USD', 'EUR' );
		if ( $country && isset( $map[ $country ] ) ) {
			$first[] = $map[ $country ];
		}
		$rest = array_values( array_diff( array_keys( self::names() ), $first ) );
		return array( $first, $rest );
	}

	public static function sym( $code = null ) {
		$d = self::defs();
		$code = $code ? $code : self::code();
		return isset( $d[ $code ] ) ? $d[ $code ][0] : 'د.ع';
	}

	/** Amount in $from → visitor currency (number). */
	public static function conv( $amount, $from = 'IQD', $to = null ) {
		$r    = self::rates();
		$to   = $to ? $to : self::code();
		$from = isset( $r[ $from ] ) ? $from : 'IQD';
		$iqd  = (float) $amount * $r[ $from ];
		return $iqd / $r[ $to ];
	}

	/** Number only, formatted for the visitor currency. */
	public static function num( $v, $code = null ) {
		$code = $code ? $code : self::code();
		$d    = self::defs()[ $code ];
		$v    = (float) $v;
		if ( $d[2] > 1 && $v >= $d[2] * 10 ) {
			$v = round( $v / $d[2] ) * $d[2];
		}
		$dec = $d[1];
		if ( $dec && $v >= 100 ) {
			$dec = 0; // «1,881 $» not «1,881.11 $»
		}
		// small amounts of a zero-decimal currency keep one decimal instead of turning into «0»
		if ( 0 === $dec && $v > 0 && $v < 10 && floor( $v ) != $v ) {
			$dec = 1;
		}
		if ( $v > 0 && 0.0 === (float) round( $v, $dec ) ) {
			$dec = min( 6, (int) ceil( -log10( $v ) ) + 1 ); // a tiny amount never shows as «0»
		}
		$s = number_format( $v, $dec, '.', ',' );
		if ( $dec ) {
			$s = rtrim( rtrim( $s, '0' ), '.' );
		}
		return $s;
	}

	/** «12,500 د.ع» — an amount entered in $from shown in the visitor currency. */
	public static function fmt( $amount, $from = 'IQD' ) {
		return self::num( self::conv( $amount, $from ) ) . ' ' . self::sym();
	}

	/** The currency a unit text is written in («د.ع / ليلة», «تومان», «$»), or ''. */
	public static function detect( $text ) {
		$text = (string) $text;
		foreach ( self::tokens() as $tok => $code ) {
			if ( false !== mb_strpos( $text, $tok ) ) {
				return $code;
			}
		}
		return '';
	}

	/** «د.ع / ليلة» → «د.ك / ليلة» (unit text with the visitor symbol). */
	public static function unit( $unit ) {
		$unit = trim( (string) $unit );
		if ( '' === $unit ) {
			return self::sym();
		}
		$out   = $unit;
		$found = false;
		foreach ( self::tokens() as $tok => $code ) {
			if ( false !== mb_strpos( $out, $tok ) ) {
				$out   = str_replace( $tok, "\x01", $out );
				$found = true;
			}
		}
		$out = trim( preg_replace( '/\s{2,}/u', ' ', preg_replace( "/\x01+(\s*\x01)*/", ' ' . self::sym() . ' ', $out ) ) );
		return $found ? $out : self::sym() . ' ' . $unit;
	}

	/** A number + its unit text → [formatted number, unit text] in the visitor currency. */
	public static function pair( $amount, $unit = '' ) {
		$from = self::detect( $unit );
		return array( self::num( self::conv( $amount, $from ? $from : 'IQD' ) ), self::unit( $unit ) );
	}

	private static function latin( $s ) {
		return strtr( (string) $s, array(
			'٠' => '0', '١' => '1', '٢' => '2', '٣' => '3', '٤' => '4', '٥' => '5', '٦' => '6', '٧' => '7', '٨' => '8', '٩' => '9',
			'۰' => '0', '۱' => '1', '۲' => '2', '۳' => '3', '۴' => '4', '۵' => '5', '۶' => '6', '۷' => '7', '۸' => '8', '۹' => '9',
			'٬' => ',', '٫' => '.',
		) );
	}

	/**
	 * A free-text price («25,000 دينار», «15$», «10 - 15 ألف دينار», «مجاني») in the visitor currency.
	 * Text without a number is returned as it is.
	 */
	public static function text( $text, $default = 'IQD' ) {
		$text = trim( (string) $text );
		if ( '' === $text ) {
			return '';
		}
		$t = self::latin( $text );
		if ( ! preg_match( '/\d/', $t ) ) {
			return $text;
		}
		$from = self::detect( $t );
		$from = $from ? $from : ( self::detect( $default ) ? self::detect( $default ) : 'IQD' );
		$t    = preg_replace_callback( '/(?<![\d.,])\d[\d,]*+(?:\.\d+)?+(?!\s*%)/u', function ( $m ) use ( $from ) {
			$n = (float) str_replace( ',', '', $m[0] );
			return "\x02" . self::num( self::conv( $n, $from ) ) . "\x02";
		}, $t );
		$had = false;
		foreach ( self::tokens() as $tok => $code ) {
			if ( false !== mb_strpos( $t, $tok ) ) {
				$t   = str_replace( $tok, "\x01", $t );
				$had = true;
			}
		}
		$t = preg_replace( "/\x01+(\s*\x01)*/", ' ' . self::sym() . ' ', $t );
		if ( ! $had ) {
			// put the symbol right after the last number
			$p = strrpos( $t, "\x02" );
			$t = substr( $t, 0, $p + 1 ) . ' ' . self::sym() . substr( $t, $p + 1 );
		}
		$t = str_replace( "\x02", '', $t );
		return trim( preg_replace( '/\s{2,}/u', ' ', $t ) );
	}

	/** window.DLZM for prices drawn by scripts (supermarket cart, tours total, taxi …). */
	public static function cfg() {
		$c = self::code();
		$d = self::defs()[ $c ];
		$r = self::rates();
		return array(
			'c'  => $c,
			's'  => $d[0],
			'd'  => $d[1],
			'st' => $d[2],
			'r'  => 1 / $r[ $c ],
		);
	}

	public static function head_js() {
		if ( is_admin() ) {
			return;
		}
		echo '<script id="dlz-money">window.DLZM=' . wp_json_encode( self::cfg() ) . ';DLZM.n=function(v){var m=DLZM,x=(+v||0)*m.r,d=m.d;if(d&&x>=100)d=0;if(m.st>1&&x>=m.st*10)x=Math.round(x/m.st)*m.st;if(!d&&x>0&&x<10&&x%1)d=1;if(x>0&&+x.toFixed(d)===0)d=Math.min(6,Math.ceil(-Math.log10(x))+1);var s=x.toFixed(d).replace(/\B(?=(\d{3})+(?!\d))/g,",");if(d)s=s.replace(/(\.\d*?)0+$/,"$1").replace(/\.$/,"");return s};DLZM.f=function(v){return DLZM.n(v)+" "+DLZM.s};</script>' . "\n"; // phpcs:ignore
	}

	/* ---------------------------------------------------------
	 * Admin: «ارز قیمت‌ها»
	 * ------------------------------------------------------- */

	public static function menu() {
		add_submenu_page( 'dlz-unified', 'ارز قیمت‌ها', 'ارز قیمت‌ها (تبدیل خودکار)', 'manage_options', 'dlz-money', array( __CLASS__, 'page' ) );
	}

	public static function register() {
		register_setting( 'dlz_money', self::OPT, array( 'sanitize_callback' => array( __CLASS__, 'sanitize' ) ) );
	}

	public static function sanitize( $in ) {
		$in   = is_array( $in ) ? $in : array();
		$defs = self::defs();
		$out  = array( 'def' => isset( $in['def'], $defs[ $in['def'] ] ) ? $in['def'] : 'USD', 'usd' => array(), 'fix' => array() );
		foreach ( array( 'usd', 'fix' ) as $g ) {
			if ( ! empty( $in[ $g ] ) && is_array( $in[ $g ] ) ) {
				foreach ( $in[ $g ] as $k => $v ) {
					$v = (float) str_replace( ',', '', self::latin( $v ) );
					if ( $v > 0 && ( isset( $defs[ $k ] ) || in_array( $k, array( 'IRT', 'IRR' ), true ) ) ) {
						$out[ $g ][ $k ] = $v;
					}
				}
			}
		}
		return $out;
	}

	public static function page() {
		$o    = self::settings();
		$defs = self::defs();
		$r    = self::rates();
		$live = get_option( self::LAST, array() );
		$auto = array( 'USD', 'IQD', 'KWD', 'SAR', 'OMR' );
		$fmt  = function ( $v ) {
			return $v >= 100 ? number_format( $v, 0 ) : rtrim( rtrim( number_format( $v, 4 ), '0' ), '.' );
		};
		?>
		<div class="wrap" dir="rtl">
			<h1>ارز قیمت‌ها</h1>
			<p style="max-width:780px;line-height:1.9">همهٔ قیمت‌های سایت (سوپرمارکت، تاکسی، تورها، مراکز تفریحی، بلیت، مراکز و محصولات، «طلباتي» و «حجوزاتي») به‌صورت <b>دینار عراق</b> (یا با واحدی که کنار قیمت نوشته شده) وارد می‌شوند و برای هر زائر به ارزی که در «الملف الشخصي» ← «العملة المفضلة» انتخاب کرده نمایش داده می‌شوند (پیش‌فرض: دلار آمریکا؛ تومان در فهرست زائران نیست). نرخ دینار عراق، دینار کویت، ریال عربستان و ریال عمان خودکار از «أسعار العملات» می‌آید؛ درهم امارات، ریال قطر و دینار بحرین ثابت به دلار وصل‌اند؛ لیره لبنان، لیره سوریه و ریال یمن را این‌جا بررسی کنید.</p>
			<form method="post" action="options.php">
				<?php settings_fields( 'dlz_money' ); ?>
				<table class="widefat striped" style="max-width:980px">
					<thead><tr><th>ارز</th><th>نماد</th><th>منبع نرخ</th><th>هر ۱ دلار =</th><th>۱ واحد = ؟ دینار عراق</th><th>۱۰٬۰۰۰ دینار عراق =</th><th>نرخ دستی (۱ واحد = ؟ دینار عراق)</th></tr></thead>
					<tbody>
					<?php foreach ( $defs as $code => $d ) :
						$src = in_array( $code, $auto, true ) && ! empty( $live[ $code ] ) ? '<span style="color:#15803d">خودکار (أسعار العملات)</span>' : ( in_array( $code, array( 'AED', 'QAR', 'BHD' ), true ) ? 'ثابت به دلار' : ( in_array( $code, $auto, true ) ? '<span style="color:#b45309">پیش‌فرض (نرخ زنده نیست)</span>' : 'پیش‌فرض — بررسی کنید' ) );
						if ( ! empty( $o['fix'][ $code ] ) || ! empty( $o['usd'][ $code ] ) ) {
							$src = '<b>دستی</b>';
						}
						$per_usd = $r['USD'] / $r[ $code ];
						?>
						<tr>
							<td><b><?php echo esc_html( $d[3] ); ?></b> <code><?php echo esc_html( $code ); ?></code></td>
							<td style="font-size:16px"><?php echo esc_html( $d[0] ); ?></td>
							<td><?php echo $src; // phpcs:ignore ?></td>
							<td><input type="text" dir="ltr" style="width:110px" name="<?php echo esc_attr( self::OPT ); ?>[usd][<?php echo esc_attr( $code ); ?>]" value="<?php echo esc_attr( isset( $o['usd'][ $code ] ) ? $o['usd'][ $code ] : '' ); ?>" placeholder="<?php echo esc_attr( $fmt( $per_usd ) ); ?>"></td>
							<td dir="ltr" style="text-align:right"><?php echo esc_html( $fmt( $r[ $code ] ) ); ?></td>
							<td dir="ltr" style="text-align:right"><?php echo esc_html( self::num( 10000 / $r[ $code ], $code ) . ' ' . $d[0] ); ?></td>
							<td><input type="text" dir="ltr" style="width:110px" name="<?php echo esc_attr( self::OPT ); ?>[fix][<?php echo esc_attr( $code ); ?>]" value="<?php echo esc_attr( isset( $o['fix'][ $code ] ) ? $o['fix'][ $code ] : '' ); ?>" placeholder="خالی = خودکار"></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
				<p class="description">برای دینار عراق، «هر ۱ دلار =» نرخ دلار به دینار است (پایهٔ همهٔ ارزهای ثابت). خالی گذاشتن هر خانه یعنی نرخ خودکار یا پیش‌فرض. پیش‌فرض‌ها: یورو ۰٫۸۶، لیره لبنان ۸۹٬۵۰۰، لیره سوریهٔ جدید ۱۲۲، ریال یمن (عدن) ۱٬۵۷۶ برای هر دلار.</p>
				<table class="form-table" style="max-width:980px">
					<tr><th>ارز پیش‌فرض</th><td><select name="<?php echo esc_attr( self::OPT ); ?>[def]"><?php foreach ( $defs as $code => $d ) : ?><option value="<?php echo esc_attr( $code ); ?>" <?php selected( $o['def'], $code ); ?>><?php echo esc_html( $d[3] . ' (' . $d[0] . ')' ); ?></option><?php endforeach; ?></select><p class="description">برای مهمان‌ها و کسانی که در «الملف الشخصي» «العملة المفضلة» را انتخاب نکرده‌اند (پیش‌فرض: دلار).</p></td></tr>
					<tr><th>تومان (قیمت‌های تومانی صاحبان مراکز)</th><td><input type="text" dir="ltr" style="width:140px" name="<?php echo esc_attr( self::OPT ); ?>[fix][IRT]" value="<?php echo esc_attr( isset( $o['fix']['IRT'] ) ? $o['fix']['IRT'] : '' ); ?>" placeholder="<?php echo esc_attr( $fmt( $r['IRT'] ) ); ?>"> <span class="description">۱ تومان = ؟ دینار عراق (خالی = خودکار)</span></td></tr>
				</table>
				<?php submit_button( 'ذخیره' ); ?>
			</form>
		</div>
		<?php
	}
}
DLZ_Money::init();
