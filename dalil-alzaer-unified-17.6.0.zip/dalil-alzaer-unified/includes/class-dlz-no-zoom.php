<?php
/**
 * Dalil Al Zaer — app-like pages: no pinch / double-tap zoom on any front-end page.
 * Setting: «هدر و نوار اپ» → «زوم صفحه» (on by default).
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DLZ_No_Zoom {

	const META = '<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, user-scalable=no, viewport-fit=cover">';

	private static $done = false;

	public static function init() {
		add_action( 'template_redirect', array( __CLASS__, 'start' ), 0 );
		add_action( 'wp_head', array( __CLASS__, 'head' ), 0 );
		add_action( 'wp_footer', array( __CLASS__, 'script' ), 99 );
		add_action( 'login_init', array( __CLASS__, 'start' ), 0 );
		add_action( 'login_head', array( __CLASS__, 'head' ), 0 );
		add_action( 'login_footer', array( __CLASS__, 'script' ), 99 );
	}

	private static function on() {
		if ( ( is_admin() && ! did_action( 'login_init' ) ) || wp_doing_ajax() || is_feed() || is_customize_preview() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
			return false;
		}
		if ( isset( $_GET['elementor-preview'] ) ) { // phpcs:ignore -- the Elementor editor canvas keeps its own viewport
			return false;
		}
		$o = class_exists( 'DLZ_App_Shell' ) ? DLZ_App_Shell::get() : array();
		return ! isset( $o['no_zoom'] ) || ! empty( $o['no_zoom'] );
	}

	/** Rewrites the theme's / Elementor's viewport tag so there is exactly one, with zoom locked. */
	public static function start() {
		if ( self::on() ) {
			ob_start( array( __CLASS__, 'filter' ) );
		}
	}

	public static function filter( $html ) {
		if ( ! is_string( $html ) || '' === $html ) {
			return $html;
		}
		$html = preg_replace( '/<meta\b[^>]*\bname\s*=\s*["\']viewport["\'][^>]*>\s*/i', '', $html );
		if ( ! self::$done ) {
			$new = preg_replace( '/<head\b[^>]*>/i', '$0' . "\n" . self::META, $html, 1, $count );
			if ( $count ) {
				self::$done = true;
				return $new;
			}
		}
		return $html;
	}

	/** Fallback when output buffering is unavailable: a later viewport tag wins in every browser. */
	public static function head() {
		if ( ! self::on() ) {
			return;
		}
		echo self::META . "\n"; // phpcs:ignore
		echo '<style id="dlz-no-zoom">html,body{touch-action:manipulation;-webkit-text-size-adjust:100%;text-size-adjust:100%}</style>' . "\n";
	}

	/** iOS Safari ignores user-scalable=no: block pinch gestures directly. */
	public static function script() {
		if ( ! self::on() ) {
			return;
		}
		echo "<script>(function(){var d=document,o={passive:false};['gesturestart','gesturechange','gestureend'].forEach(function(t){d.addEventListener(t,function(e){e.preventDefault();},o);});d.addEventListener('touchmove',function(e){if((e.touches&&e.touches.length>1)||(typeof e.scale==='number'&&e.scale!==1))e.preventDefault();},o);})();</script>\n";
	}
}

DLZ_No_Zoom::init();
