<?php
/**
 * Dalil Al Zaer — App Shell (merged from the standalone "Dalil App Shell" plugin).
 *
 * App-style header, bottom navigation, «المزيد» page, services launcher and live search,
 * wired directly into the unified system: global city cookie, live support chat,
 * favorites, supermarket cart, unified orders and the FAQ / privacy / about panels.
 *
 * Admin: Persian — Front: Arabic.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DLZ_App_Shell {

	const OPT    = 'dalil_app_shell';
	const SCHEMA = 6;

	private static $inst    = null;
	private $header_done    = false;
	private $footer_done    = false;

	/* =========================================================
	 * Boot
	 * ======================================================= */

	public static function boot() {
		if ( self::$inst ) {
			return;
		}
		// The old standalone plugin is still active: do not render twice.
		if ( class_exists( 'Dalil_App_Shell', false ) ) {
			add_action( 'admin_notices', function () {
				if ( ! current_user_can( 'activate_plugins' ) ) {
					return;
				}
				echo '<div class="notice notice-warning" dir="rtl"><p><b>دلیل الزائر:</b> هدر و نوار اپ اکنون داخل «سیستم یکپارچه» است. لطفاً افزونه‌ی جداگانه‌ی <b>Dalil App Shell</b> را غیرفعال کنید تا هدر دوبار نمایش داده نشود.</p></div>';
			} );
			return;
		}
		self::$inst = new self();
	}

	public static function running() {
		return (bool) self::$inst;
	}

	public static function instance() {
		return self::$inst;
	}

	/** Admin page callback (works even when the standalone plugin blocks the merged shell). */
	public static function admin_page() {
		if ( self::$inst ) {
			self::$inst->settings_page();
			return;
		}
		echo '<div class="wrap" dir="rtl"><h1>هدر و نوار اپ</h1><div class="notice notice-warning inline"><p>افزونه‌ی جداگانه‌ی <b>Dalil App Shell</b> هنوز فعال است. آن را از صفحه افزونه‌ها غیرفعال کنید تا نسخه‌ی ادغام‌شده (با جستجوی زنده، منوی خدمات و اتصال به چت و شهرها) فعال شود. تنظیمات قبلی شما (رنگ، لوگو، فونت) حفظ می‌شوند.</p></div></div>';
	}

	public function __construct() {
		add_action( 'admin_init', array( $this, 'register_settings' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'admin_assets' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'front_assets' ), 20 );
		add_action( 'wp_body_open', array( $this, 'render_header' ), 1 );
		add_action( 'wp_footer', array( $this, 'render_footer' ), 5 );
		add_filter( 'body_class', array( $this, 'body_class' ) );
		add_filter( 'upload_mimes', array( $this, 'font_mimes' ) );
		add_filter( 'wp_check_filetype_and_ext', array( $this, 'font_filetype' ), 10, 4 );
		add_action( 'wp_ajax_dlz_shell_search', array( $this, 'ajax_search' ) );
		add_action( 'wp_ajax_nopriv_dlz_shell_search', array( $this, 'ajax_search' ) );
		add_action( 'save_post_page', array( __CLASS__, 'flush_services' ) );
		add_action( 'elementor/editor/after_save', array( __CLASS__, 'flush_services' ) );
		add_action( 'update_option_' . self::OPT, array( __CLASS__, 'flush_services' ) );
	}

	/* =========================================================
	 * Settings
	 * ======================================================= */

	public static function default_more_menu() {
		return "# الدعم والتواصل\n"
			. "headset|الدعم المباشر|@chat\n"
			. "whatsapp|واتساب|https://wa.me/9647822719796\n"
			. "phone|اتصال فوري|tel:09152082983\n"
			. "mail|تواصل معنا|@contact\n"
			. "# محتوى مفيد\n"
			. "book|المقالات|{articles}\n"
			. "heart|المفضلة|{favorites}\n"
			. "pin|تغيير المدينة|@city\n"
			. "grid|جميع الخدمات|@services\n"
			. "# معلومات عامة\n"
			. "question|الأسئلة الشائعة|@faq\n"
			. "shield|سياسة الخصوصية|@privacy\n"
			. "info|من نحن|@about";
	}

	public static function defaults() {
		return array(
			'schema'           => self::SCHEMA,
			'enabled'          => 1,
			'mode'             => 'app',      // app | hybrid | classic
			'surface'          => 'dark',     // dark = green / gold header & nav (15.0 default) | light = white
			'breakpoint'       => 900,
			'hide_header'      => 1,
			'header_selectors' => '#masthead, .site-header, .elementor-location-header, #header, .whb-header, .main-header, header.wp-block-template-part',
			'hide_footer'      => 1,
			'footer_selectors' => '#colophon, .site-footer, .elementor-location-footer, #footer, .footer-wrapper, footer.wp-block-template-part',
			'logo_id'          => 0,
			'logo_url'         => '',
			'name_en'          => 'Dalil Al-Zaer',
			'name_ar'          => 'دليل الزائر',
			'search_ph'        => 'ابحث عن فندق، مطعم، خدمة...',
			'live_search'      => 1,
			'no_zoom'          => 1,          // block pinch / double-tap zoom on every front-end page
			'latin_digits'     => 1,          // show every number with English digits (0-9) across the site
			'search_type'      => '',
			'fav_url'          => '',
			'support_url'      => '',
			'cart_url'         => '',
			'orders_url'       => '',
			'center_mode'      => 'explore', // explore | services | link
			'center_label'     => 'نفحات',
			'center_url'       => '',
			'more_title'       => 'المزيد',
			'more_menu'        => self::default_more_menu(),
			'help_url'         => 'https://wa.me/9647822719796', // «المساعدة» → WhatsApp
			'invite_text'      => 'إذا كنت ترغب في سفرٍ مريح وقليل التكلفة إلى إيران، تفضّل بزيارة موقع «دليل الزائر»:', // sent by SMS with the site link under it
			'social_whatsapp'  => '',
			'social_instagram' => '',
			'social_facebook'  => '',
			'social_linkedin'  => '',
			'app_url'          => '',
			'app_title'        => 'حمّل تطبيق دليل الزائر',
			'app_sub'          => 'تجربة أسرع ووصول مباشر من شاشتك الرئيسية',
			'services'         => array(),
			'services_extra'   => '',
			'color'            => '#0a4425',
			'color_dark'       => '#032514',
			'accent'           => '#d9ae4a',
			'font'             => 'site',
			'font_site'        => 0,
			'font_reg_url'     => '',
			'font_bold_url'    => '',
		);
	}

	public static function get() {
		static $cache = null;
		if ( null !== $cache && ! is_admin() ) {
			return $cache;
		}
		$saved = get_option( self::OPT, array() );
		if ( ! is_array( $saved ) ) {
			$saved = array();
		}
		// Migration from the standalone plugin (no schema key): keep colors/logo/fonts, adopt the new menu.
		if ( $saved && empty( $saved['schema'] ) ) {
			if ( isset( $saved['mobile_only'] ) && ! isset( $saved['mode'] ) ) {
				$saved['mode'] = 'app';
			}
			unset( $saved['more_menu'], $saved['cities'], $saved['mobile_only'] );
		}
		// 14.1: the shell follows the site's own font unless another font was chosen on purpose.
		if ( $saved && ( empty( $saved['schema'] ) || (int) $saved['schema'] < 3 ) && ( empty( $saved['font'] ) || 'cairo' === $saved['font'] ) ) {
			$saved['font'] = 'site';
		}
		// 14.4: the center button is «نفحات» and opens the built-in Explore of the site's posts.
		if ( $saved && ( empty( $saved['schema'] ) || (int) $saved['schema'] < 5 ) ) {
			$saved['center_mode'] = 'explore';
			$saved['center_url']  = '';
			$saved['surface']     = 'light';
			if ( empty( $saved['center_label'] ) || 'خدماتنا' === $saved['center_label'] ) {
				$saved['center_label'] = 'نفحات';
			}
		}
		// 15.0: green / gold header and bottom bar (as in the app design) + «نفحات» = Instagram-style Explore.
		if ( $saved && ( empty( $saved['schema'] ) || (int) $saved['schema'] < 6 ) ) {
			$saved['surface']     = 'dark';
			$saved['center_mode'] = 'explore';
			$saved['font']        = ( empty( $saved['font'] ) || 'cairo' === $saved['font'] ) ? 'site' : $saved['font'];
			unset( $saved['explore_type'] );
			// the old default emerald becomes the deeper green of the app design (custom colors are kept)
			if ( empty( $saved['color'] ) || '#0c4a3a' === strtolower( $saved['color'] ) ) {
				$saved['color']      = '#0a4425';
				$saved['color_dark'] = '#032514';
			}
		}
		if ( isset( $saved['invite_text'] ) && 'حمّل تطبيق «دليل الزائر» — كل خدمات الزيارة في مكان واحد 🕌' === $saved['invite_text'] ) {
			unset( $saved['invite_text'] ); // 15.3: SMS invitation text
		}
		$cache = wp_parse_args( $saved, self::defaults() );
		if ( ! in_array( $cache['mode'], array( 'app', 'hybrid', 'classic' ), true ) ) {
			$cache['mode'] = 'app';
		}
		return $cache;
	}

	/** Effective mode used by the unified plugin to decide whether the classic shell renders. */
	public static function mode() {
		if ( ! self::running() ) {
			return 'classic';
		}
		$o = self::get();
		return $o['enabled'] ? $o['mode'] : 'classic';
	}

	public static function fonts() {
		return array(
			'site'    => array( 'همان فونت سایت (خودکار)', '' ),
			'cairo'   => array( 'Cairo', 'Cairo:wght@400;500;600;700;800' ),
			'tajawal' => array( 'Tajawal', 'Tajawal:wght@400;500;700;800' ),
			'almarai' => array( 'Almarai', 'Almarai:wght@400;700;800' ),
			'plex'    => array( 'IBM Plex Sans Arabic', 'IBM+Plex+Sans+Arabic:wght@400;500;600;700' ),
			'kufi'    => array( 'Noto Kufi Arabic', 'Noto+Kufi+Arabic:wght@400;500;600;700;800' ),
			'vazir'   => array( 'Vazirmatn', 'Vazirmatn:wght@400;500;700;800' ),
			'custom'  => array( 'فونت دلخواه (آپلود فایل)', '' ),
			'theme'   => array( 'فونت خود قالب', '' ),
		);
	}

	public function font_mimes( $m ) {
		if ( current_user_can( 'manage_options' ) ) {
			$m['woff2'] = 'font/woff2';
			$m['woff']  = 'font/woff';
			$m['ttf']   = 'font/ttf';
		}
		return $m;
	}

	public function font_filetype( $data, $file, $filename, $mimes ) {
		$ext = strtolower( pathinfo( $filename, PATHINFO_EXTENSION ) );
		if ( current_user_can( 'manage_options' ) && in_array( $ext, array( 'woff2', 'woff', 'ttf' ), true ) ) {
			$data['ext']             = $ext;
			$data['type']            = 'font/' . $ext;
			$data['proper_filename'] = $filename;
		}
		return $data;
	}

	public static function font_stack( $o ) {
		$base = "system-ui,-apple-system,'Segoe UI',Tahoma,Arial,sans-serif";
		$f    = self::fonts();
		if ( 'custom' === $o['font'] ) {
			return $o['font_reg_url'] ? "'DalilFont'," . $base : $base;
		}
		if ( 'site' === $o['font'] ) {
			return $base; // replaced at runtime by the site's real font (see font_probe_script)
		}
		if ( 'theme' === $o['font'] || empty( $f[ $o['font'] ][1] ) ) {
			return $base;
		}
		return "'" . $f[ $o['font'] ][0] . "'," . $base;
	}

	public function register_settings() {
		register_setting( 'dalil_app_shell_group', self::OPT, array( 'sanitize_callback' => array( $this, 'sanitize' ) ) );
	}

	public function sanitize( $in ) {
		$d   = self::defaults();
		$out = array( 'schema' => self::SCHEMA );
		if ( ! is_array( $in ) ) {
			$in = array();
		}

		foreach ( array( 'enabled', 'hide_header', 'hide_footer', 'font_site', 'live_search', 'no_zoom', 'latin_digits' ) as $k ) {
			$out[ $k ] = empty( $in[ $k ] ) ? 0 : 1;
		}
		$out['mode']        = ( isset( $in['mode'] ) && in_array( $in['mode'], array( 'app', 'hybrid', 'classic' ), true ) ) ? $in['mode'] : 'app';
		$out['surface']     = ( isset( $in['surface'] ) && 'light' === $in['surface'] ) ? 'light' : 'dark';
		$out['center_mode'] = ( isset( $in['center_mode'] ) && in_array( $in['center_mode'], array( 'explore', 'services', 'link' ), true ) ) ? $in['center_mode'] : 'explore';
		$out['breakpoint']  = isset( $in['breakpoint'] ) ? max( 320, min( 2000, absint( $in['breakpoint'] ) ) ) : 900;
		$out['logo_id']     = isset( $in['logo_id'] ) ? absint( $in['logo_id'] ) : 0;
		$out['font']        = ( isset( $in['font'] ) && isset( self::fonts()[ $in['font'] ] ) ) ? $in['font'] : $d['font'];

		foreach ( array( 'font_reg_url', 'font_bold_url', 'logo_url', 'fav_url', 'support_url', 'cart_url', 'orders_url', 'center_url', 'app_url', 'help_url', 'social_whatsapp', 'social_instagram', 'social_facebook', 'social_linkedin' ) as $k ) {
			$out[ $k ] = isset( $in[ $k ] ) ? esc_url_raw( trim( wp_unslash( $in[ $k ] ) ) ) : '';
		}
		foreach ( array( 'name_en', 'name_ar', 'search_ph', 'search_type', 'center_label', 'more_title', 'app_title', 'app_sub', 'invite_text' ) as $k ) {
			$out[ $k ] = isset( $in[ $k ] ) ? sanitize_text_field( wp_unslash( $in[ $k ] ) ) : $d[ $k ];
		}
		foreach ( array( 'header_selectors', 'footer_selectors' ) as $k ) {
			$out[ $k ] = isset( $in[ $k ] ) ? trim( str_replace( array( '{', '}', '<', '>', ';' ), '', wp_strip_all_tags( wp_unslash( $in[ $k ] ) ) ) ) : $d[ $k ];
		}
		foreach ( array( 'more_menu', 'services_extra' ) as $k ) {
			$out[ $k ] = isset( $in[ $k ] ) ? sanitize_textarea_field( wp_unslash( $in[ $k ] ) ) : $d[ $k ];
		}
		if ( '' === trim( $out['more_menu'] ) ) {
			$out['more_menu'] = self::default_more_menu();
		}
		foreach ( array( 'color', 'color_dark', 'accent' ) as $k ) {
			$c         = isset( $in[ $k ] ) ? sanitize_hex_color( $in[ $k ] ) : '';
			$out[ $k ] = $c ? $c : $d[ $k ];
		}
		$out['services'] = array();
		$raw             = isset( $in['services'] ) && is_array( $in['services'] ) ? $in['services'] : array();
		foreach ( array_keys( self::service_defs() ) as $key ) {
			$row                     = isset( $raw[ $key ] ) && is_array( $raw[ $key ] ) ? $raw[ $key ] : array();
			$out['services'][ $key ] = array(
				'url' => isset( $row['url'] ) ? esc_url_raw( trim( wp_unslash( $row['url'] ) ) ) : '',
				'off' => empty( $row['off'] ) ? 0 : 1,
			);
		}
		return $out;
	}

	/* =========================================================
	 * Unified data helpers
	 * ======================================================= */

	private static function url( $u ) {
		$u = trim( (string) $u );
		if ( '' === $u ) {
			return '';
		}
		if ( 0 === strpos( $u, '/' ) && 0 !== strpos( $u, '//' ) ) {
			return home_url( $u );
		}
		return $u;
	}

	private static function dase() {
		return function_exists( 'dase_get_settings' ) ? dase_get_settings() : array();
	}

	public static function links() {
		$o       = self::get();
		$s       = self::dase();
		$profile = function_exists( 'dlz_profile_url' ) ? dlz_profile_url() : home_url( '/' );
		$l       = array(
			'home'      => ! empty( $s['home_url'] ) ? self::url( $s['home_url'] ) : home_url( '/' ),
			'cart'      => $o['cart_url'] ? $o['cart_url'] : ( ! empty( $s['cart_url'] ) ? $s['cart_url'] : '' ),
			'orders'    => $o['orders_url'] ? $o['orders_url'] : ( ! empty( $s['orders_url'] ) ? $s['orders_url'] : '' ),
			'bookings'  => class_exists( 'DLZ_My' ) ? DLZ_My::bookings_url() : home_url( '/' ),
			'profile'   => $profile,
			'favorites' => $o['fav_url'] ? $o['fav_url'] : add_query_arg( 'dlz_view', 'favorites', $profile ),
			'articles'  => ! empty( $s['articles_url'] ) ? $s['articles_url'] : '',
			'support'   => $o['support_url'],
			'center'    => $o['center_url'] ? self::url( $o['center_url'] ) : home_url( '/' ),
		);
		return $l;
	}

	/**
	 * Built-in brand mark: the golden «D» with the dome inside it.
	 * Shown whenever no logo image is set (settings → «هدر و نوار اپ» → لوگو).
	 */
	public static function logo_svg() {
		return '<svg class="dsh-logo" viewBox="0 0 100 100" role="img" aria-label="دليل الزائر"><defs>'
			. '<linearGradient id="dlzLogoG" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#FFF0C2"/><stop offset=".38" stop-color="#E9BE5A"/><stop offset=".7" stop-color="#C8922E"/><stop offset="1" stop-color="#8E5F12"/></linearGradient>'
			. '<linearGradient id="dlzLogoS" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#FFE9A8"/><stop offset="1" stop-color="#C08A2A"/></linearGradient>'
			. '</defs>'
			. '<path fill="url(#dlzLogoG)" fill-rule="evenodd" d="M12 11h40c25.5 0 40 16.8 40 39S77.5 89 52 89H12v-4.2h9.6V15.2H12zM40.6 17.6V82.4H51c17 0 27.6-12.4 27.6-32.4S68 17.6 51 17.6z"/>'
			. '<path fill="none" stroke="url(#dlzLogoS)" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" d="M40.8 69c1.8-11 8.2-15.2 13.4-19.6 3-2.6 4.6-5.2 4.8-9.4.2 4.2 1.8 6.8 4.8 9.4 5.2 4.4 11.4 8.6 13.6 19.6"/>'
			. '<path fill="none" stroke="url(#dlzLogoS)" stroke-width="2.2" stroke-linecap="round" d="M59 40v-11"/>'
			. '<circle cx="59" cy="33.5" r="2.1" fill="url(#dlzLogoS)"/>'
			. '<path fill="#fff" opacity=".28" d="M23.5 17h4.2v66h-4.2z"/>'
			. '</svg>';
	}

	/** Logo used by the header, the center button and «نفحات». */
	public static function logo() {
		return self::logo_for( self::get() );
	}

	private function logo_url( $o ) {
		return self::logo_for( $o );
	}

	private static function logo_for( $o ) {
		if ( $o['logo_url'] ) {
			return $o['logo_url'];
		}
		$s = self::dase();
		if ( ! empty( $s['logo'] ) ) {
			return $s['logo'];
		}
		$notice = get_option( 'dalil_app_notice', array() );
		if ( ! empty( $notice['logo_url'] ) ) {
			return $notice['logo_url'];
		}
		return get_site_icon_url( 192 );
	}

	private static function cities() {
		$labels = function_exists( 'dlz_city_labels' ) ? dlz_city_labels() : array( 'mashhad' => 'مشهد' );
		$cur    = function_exists( 'dlz_current_city' ) ? dlz_current_city() : 'mashhad';
		return array( $labels, $cur );
	}

	private static function fav_count() {
		return ( is_user_logged_in() && function_exists( 'dlz_favorites_get' ) ) ? count( dlz_favorites_get() ) : 0;
	}

	/** Pages hidden from header/footer in «تنظیمات ظاهر سایت» apply to the app shell as well. */
	private static function page_hidden( $which ) {
		return class_exists( 'DLZ_Hide_HF' ) && DLZ_Hide_HF::hidden( $which );
	}

	/* =========================================================
	 * Services launcher
	 * ======================================================= */

	public static function service_defs() {
		return array(
			'supermarket'   => array( 'السوبرماركت', 'basket', array( 'dalil_supermarket', 'dlz_sm_store', 'dlz_sm_mini_supermarket', 'dalil_sm_products', 'dlz_sm_categories', 'dalil_sm_categories', 'dlz_sm_quick', 'dalil_sm_quick' ), 'سوبر ماركت بقالة تسوق طعام مواد غذائية' ),
			'directory'     => array( 'الفنادق والمطاعم', 'store', array( 'dalil_businesses' ), 'فندق فنادق مطعم مطاعم سكن إقامة حسينية أعمال إعلانات' ),
			'tickets'       => array( 'تذاكر السفر', 'plane', array( 'dalil_ticket_search' ), 'تذكرة تذاكر طيران طائرة قطار حافلة باص سفر' ),
			'tours'         => array( 'جولات يومية', 'compass', array( 'dlz_daily_tours' ), 'جولة جولات رحلة سياحة زيارة مزارات' ),
			'entertainment' => array( 'مراكز ترفيهية', 'ticket', array( 'dlz_entertainment', 'dlz_entertainment_cards' ), 'ترفيه ترفيهي ملاهي حديقة ألعاب أطفال' ),
			'taxi'          => array( 'تاكسي VIP', 'car', array( 'dlz_taxi_vip_cards' ), 'تاكسي سيارة سائق نقل توصيل مطار' ),
			'medical'       => array( 'استشارة طبية', 'medical', array( 'mcr_form', 'mcr_consultation_form' ), 'طبيب طبية مستشفى علاج دواء صحة' ),
			'legal'         => array( 'استشارة قانونية', 'scale', array( 'lcr_form', 'lcr_consultation_form' ), 'محامي قانون قانونية حقوق شكوى' ),
			'currency'      => array( 'أسعار العملات', 'coins', array( 'dalil_currency_rates' ), 'عملة عملات صرف دولار دينار تومان سعر' ),
			'articles'      => array( 'المقالات', 'book', array( 'dalil_articles' ), 'مقالات مقال دليل معلومات أدعية' ),
		);
	}

	public static function flush_services() {
		delete_transient( 'dlz_shell_services_v2' );
		delete_transient( 'dlz_shell_explore_v1' );
	}

	/**
	 * Finds the site's Explore page: a page/post type whose slug or title says explore / اکسپلور / اكسبلور / استكشف / نفحات,
	 * or a page that holds an "explore" shortcode / Elementor widget. Cached 12h; '' when nothing is found.
	 */
	public static function explore_url() {
		$cached = get_transient( 'dlz_shell_explore_v1' );
		if ( is_string( $cached ) ) {
			return $cached;
		}
		global $wpdb;
		$url   = '';
		$words = array( 'explore', 'اکسپلور', 'اكسبلور', 'إكسبلور', 'اكسپلور', 'استكشف', 'استكشاف', 'نفحات' );
		// 1) a public post type with an archive (e.g. dlz_explore / explore / nafahat)
		foreach ( get_post_types( array( 'public' => true ), 'objects' ) as $pt ) {
			if ( preg_match( '/explore|nafahat|reel/i', $pt->name ) && $pt->has_archive ) {
				$url = (string) get_post_type_archive_link( $pt->name );
				if ( $url ) {
					break;
				}
			}
		}
		// 2) a published page by slug / title, or one that holds an explore shortcode / widget
		if ( ! $url ) {
			$where = array();
			$args  = array();
			foreach ( $words as $w ) {
				$where[] = 'p.post_name LIKE %s';
				$args[]  = '%' . $wpdb->esc_like( rawurlencode( $w ) ) . '%';
				$where[] = 'p.post_name LIKE %s';
				$args[]  = '%' . $wpdb->esc_like( strtolower( rawurlencode( $w ) ) ) . '%';
				$where[] = 'p.post_title LIKE %s';
				$args[]  = '%' . $wpdb->esc_like( $w ) . '%';
			}
			$where[] = 'p.post_content LIKE %s';
			$args[]  = '%' . $wpdb->esc_like( '[' ) . '%explore%';
			$where[] = 'pm.meta_value LIKE %s';
			$args[]  = '%' . $wpdb->esc_like( '"widgetType":"' ) . '%explore%';
			$sql = "SELECT p.ID FROM {$wpdb->posts} p LEFT JOIN {$wpdb->postmeta} pm ON pm.post_id=p.ID AND pm.meta_key='_elementor_data'
				WHERE p.post_type='page' AND p.post_status='publish' AND (" . implode( ' OR ', $where ) . ')
				ORDER BY p.menu_order ASC, p.ID ASC LIMIT 1';
			$id  = (int) $wpdb->get_var( $wpdb->prepare( $sql, $args ) ); // phpcs:ignore
			$url = $id ? (string) get_permalink( $id ) : '';
		}
		set_transient( 'dlz_shell_explore_v1', $url, 12 * HOUR_IN_SECONDS );
		return $url;
	}

	/** Where the center button goes: 'explore' / 'services' (built-in panels) or a URL. */
	private static function center_target( $o ) {
		if ( 'services' === $o['center_mode'] ) {
			return 'services';
		}
		if ( 'link' === $o['center_mode'] ) {
			return $o['center_url'] ? self::url( $o['center_url'] ) : 'services';
		}
		// «نفحات» needs the merged Explore module (it steps aside while the old standalone plugin is active).
		return ( class_exists( 'DLZ_Nafahat' ) && DLZ_Nafahat::active() ) ? 'explore' : 'services';
	}

	/** Finds the page that hosts each module (shortcode in content or widget in Elementor data). Cached 12h. */
	private static function detect_service_urls() {
		$cached = get_transient( 'dlz_shell_services_v2' );
		if ( is_array( $cached ) ) {
			return $cached;
		}
		global $wpdb;
		$front = (int) get_option( 'page_on_front' );
		$found = array();
		foreach ( self::service_defs() as $key => $def ) {
			$where = array();
			$args  = array();
			foreach ( $def[2] as $m ) {
				$where[] = 'p.post_content LIKE %s';
				$args[]  = '%[' . $wpdb->esc_like( $m ) . '%';
				$where[] = 'pm.meta_value LIKE %s';
				$args[]  = '%' . $wpdb->esc_like( '"widgetType":"' . $m . '"' ) . '%';
				$where[] = 'pm.meta_value LIKE %s';
				$args[]  = '%' . $wpdb->esc_like( '[' . $m ) . '%';
			}
			$args[] = $front;
			$sql    = "SELECT p.ID FROM {$wpdb->posts} p LEFT JOIN {$wpdb->postmeta} pm ON pm.post_id=p.ID AND pm.meta_key='_elementor_data'
				WHERE p.post_type='page' AND p.post_status='publish' AND (" . implode( ' OR ', $where ) . ')
				ORDER BY (p.ID=%d) ASC, p.menu_order ASC, p.ID ASC LIMIT 1';
			$id     = (int) $wpdb->get_var( $wpdb->prepare( $sql, $args ) ); // phpcs:ignore
			$found[ $key ] = $id ? get_permalink( $id ) : '';
		}
		set_transient( 'dlz_shell_services_v2', $found, 12 * HOUR_IN_SECONDS );
		return $found;
	}

	public static function services( $with_hidden = false ) {
		$o        = self::get();
		$detected = self::detect_service_urls();
		$l        = self::links();
		$out      = array();
		foreach ( self::service_defs() as $key => $def ) {
			$row  = isset( $o['services'][ $key ] ) ? $o['services'][ $key ] : array();
			$auto = ! empty( $detected[ $key ] ) ? $detected[ $key ] : '';
			if ( 'articles' === $key && ! $auto ) {
				$auto = $l['articles'];
			}
			$url = ! empty( $row['url'] ) ? $row['url'] : $auto;
			$off = ! empty( $row['off'] );
			if ( ! $with_hidden && ( $off || ! $url ) ) {
				continue;
			}
			$out[] = array( 'key' => $key, 'label' => $def[0], 'icon' => $def[1], 'url' => $url, 'auto' => $auto, 'off' => $off, 'kw' => $def[3] );
		}
		if ( ! $with_hidden ) {
			foreach ( preg_split( '/\r\n|\n/', (string) $o['services_extra'] ) as $line ) {
				$p = array_map( 'trim', explode( '|', $line ) );
				if ( count( $p ) < 3 || '' === $p[1] ) {
					continue;
				}
				$out[] = array( 'key' => 'x' . md5( $line ), 'label' => $p[1], 'icon' => $p[0], 'url' => self::resolve( $p[2] ), 'auto' => '', 'off' => false, 'kw' => '' );
			}
		}
		return $out;
	}

	/** Page URL of a service (tours, entertainment …) for other modules. */
	public static function url_of( $key ) {
		return self::service_url( $key );
	}

	private static function service_url( $key ) {
		foreach ( self::services() as $s ) {
			if ( $s['key'] === $key ) {
				return $s['url'];
			}
		}
		return '';
	}

	/* =========================================================
	 * Menu tokens: @chat @faq … and {articles} {favorites} …
	 * ======================================================= */

	private static function resolve( $u ) {
		$l = self::links();
		$u = strtr(
			trim( (string) $u ),
			array(
				'{home}'      => $l['home'],
				'{articles}'  => $l['articles'],
				'{favorites}' => $l['favorites'],
				'{orders}'    => $l['orders'],
				'{cart}'      => $l['cart'],
				'{profile}'   => $l['profile'],
			)
		);
		return 0 === strpos( $u, '@' ) ? $u : self::url( $u );
	}

	/** Returns the attributes for a link/action. */
	private static function action_attrs( $u ) {
		$u = self::resolve( $u );
		if ( 0 === strpos( $u, '@' ) ) {
			$a = substr( $u, 1 );
			if ( 'chat' === $a ) {
				return 'href="#" data-dlz-chat="1"';
			}
			if ( in_array( $a, array( 'faq', 'privacy', 'about', 'contact' ), true ) ) {
				return 'href="#" data-dlz-info="' . esc_attr( $a ) . '"';
			}
			if ( in_array( $a, array( 'city', 'services', 'search' ), true ) ) {
				return 'href="#" data-dsh-open="' . esc_attr( $a ) . '"';
			}
			return 'href="#"';
		}
		$ext = preg_match( '#^https?://#i', $u ) && false === strpos( $u, (string) wp_parse_url( home_url(), PHP_URL_HOST ) );
		return 'href="' . esc_url( $u ? $u : '#' ) . '"' . ( $ext ? ' target="_blank" rel="noopener"' : '' );
	}

	private function more_sections( $o ) {
		$sections = array();
		$cur      = null;
		foreach ( preg_split( '/\r\n|\n/', (string) $o['more_menu'] ) as $line ) {
			$line = trim( $line );
			if ( '' === $line ) {
				continue;
			}
			if ( '#' === $line[0] ) {
				$sections[] = array( 'title' => trim( ltrim( $line, '#' ) ), 'items' => array() );
				$cur        = count( $sections ) - 1;
				continue;
			}
			$p = array_map( 'trim', explode( '|', $line ) );
			if ( count( $p ) < 3 ) {
				continue;
			}
			if ( null === $cur ) {
				$sections[] = array( 'title' => '', 'items' => array() );
				$cur        = 0;
			}
			$sections[ $cur ]['items'][] = array( 'icon' => $p[0], 'label' => $p[1], 'url' => $p[2] );
		}
		return $sections;
	}


	/* =========================================================
	 * «المزيد» — gold badges, socials, quick links
	 * ======================================================= */

	/** Gradients shared by the badges (printed once inside «المزيد»). */
	private static function more_defs() {
		return '<svg class="dsm-defs" width="0" height="0" aria-hidden="true" focusable="false"><defs>'
			. '<linearGradient id="dsmRing" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#FFF3C9"/><stop offset=".45" stop-color="#E5B954"/><stop offset="1" stop-color="#9C6C17"/></linearGradient>'
			. '<radialGradient id="dsmIn" cx=".5" cy=".32" r=".75"><stop offset="0" stop-color="#2C7D52"/><stop offset=".55" stop-color="#0F4D2E"/><stop offset="1" stop-color="#062C19"/></radialGradient>'
			. '<linearGradient id="dsmGlyph" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#FFF1C2"/><stop offset=".5" stop-color="#E7BA52"/><stop offset="1" stop-color="#B9852A"/></linearGradient>'
			. '<linearGradient id="dsmPage" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#FFFDF4"/><stop offset="1" stop-color="#F3E6C2"/></linearGradient>'
			. '</defs></svg>';
	}

	private static function more_badge( $name ) {
		$base = '<circle cx="28" cy="28" r="26.5" fill="url(#dsmRing)"/><circle cx="28" cy="28" r="23" fill="url(#dsmIn)"/>'
			. '<circle cx="28" cy="28" r="23" fill="none" stroke="#000" stroke-opacity=".18" stroke-width=".8"/>'
			. '<path d="M9.5 23.5A19 19 0 0 1 24 9.4" fill="none" stroke="#fff" stroke-opacity=".16" stroke-width="3" stroke-linecap="round"/>';
		$g    = 'url(#dsmGlyph)';
		switch ( $name ) {
			case 'account':
				$in = $base . '<circle cx="28" cy="21.6" r="6.6" fill="' . $g . '"/>'
					. '<path d="M15.6 40.6c0-7.4 5.6-11.8 12.4-11.8s12.4 4.4 12.4 11.8v.6H15.6z" fill="' . $g . '"/>';
				break;
			case 'help':
				$in = $base . '<path d="M28 15.2a12.8 12.8 0 0 0-11.1 19.2L15.2 41l6.8-1.8A12.8 12.8 0 1 0 28 15.2z" fill="none" stroke="' . $g . '" stroke-width="2.5" stroke-linejoin="round"/>'
					. '<path d="M23.3 22.4c.5-.7 1.1-.8 1.6-.3l1.5 1.7c.4.4.4 1 0 1.4l-.8.9c1 2 2.6 3.6 4.6 4.6l.9-.8c.4-.4 1-.4 1.4 0l1.7 1.5c.5.5.4 1.1-.3 1.6-1 .8-2.3 1.2-3.4.8-3.6-1.3-6.4-4.1-7.7-7.7-.4-1.1 0-2.5.5-3.7z" fill="' . $g . '"/>';
				break;
			case 'privacy':
				return '<svg class="dsm-badge" viewBox="0 0 56 56" aria-hidden="true">'
					. '<path d="M28 2.5 50 10.4v16.2c0 13.6-9.4 23.6-22 27.9C15.4 50.2 6 40.2 6 26.6V10.4z" fill="url(#dsmRing)"/>'
					. '<path d="M28 7 45.6 13.4v13.2c0 11-7.5 19.2-17.6 22.8-10.1-3.6-17.6-11.8-17.6-22.8V13.4z" fill="url(#dsmIn)"/>'
					. '<path d="M14 15.5 28 10.4l9 3.3" fill="none" stroke="#fff" stroke-opacity=".16" stroke-width="2.4" stroke-linecap="round"/>'
					. '<path d="M22.6 26.2v-3.4a5.4 5.4 0 0 1 10.8 0v3.4" fill="none" stroke="' . $g . '" stroke-width="2.7" stroke-linecap="round"/>'
					. '<rect x="19.6" y="25.4" width="16.8" height="13.4" rx="2.8" fill="' . $g . '"/>'
					. '<circle cx="28" cy="30.8" r="1.9" fill="#0F4D2E"/><rect x="27.15" y="31.4" width="1.7" height="4" rx=".85" fill="#0F4D2E"/>'
					. '</svg>';
			case 'articles':
				return '<svg class="dsm-badge dsm-book" viewBox="0 0 56 56" aria-hidden="true">'
					. '<path d="M2.5 17.5v29.2c9-2.6 17.6-1.8 25.5 3.2 7.9-5 16.5-5.8 25.5-3.2V17.5" fill="url(#dsmIn)" stroke="url(#dsmRing)" stroke-width="1.6" stroke-linejoin="round"/>'
					. '<path d="M5.6 14.4c8-2.4 15.6-1.6 22.4 3v28.4c-6.8-4.4-14.4-5.2-22.4-3z" fill="url(#dsmPage)" stroke="url(#dsmRing)" stroke-width="1.5" stroke-linejoin="round"/>'
					. '<path d="M50.4 14.4c-8-2.4-15.6-1.6-22.4 3v28.4c6.8-4.4 14.4-5.2 22.4-3z" fill="url(#dsmPage)" stroke="url(#dsmRing)" stroke-width="1.5" stroke-linejoin="round"/>'
					. '<path d="M10 21.4c4.6-1 9.2-.6 13.6 1.2M10 26.6c4.6-1 9.2-.6 13.6 1.2M10 31.8c4.6-1 9.2-.6 13.6 1.2M10 37c4.6-1 9.2-.6 13.6 1.2M46 21.4c-4.6-1-9.2-.6-13.6 1.2M46 26.6c-4.6-1-9.2-.6-13.6 1.2M46 31.8c-4.6-1-9.2-.6-13.6 1.2M46 37c-4.6-1-9.2-.6-13.6 1.2" fill="none" stroke="#1B5E3B" stroke-opacity=".55" stroke-width="1.3" stroke-linecap="round"/>'
					. '<path d="M28 17.4v28.4" stroke="#B9852A" stroke-width="1.4"/>'
					. '</svg>';
			case 'invite':
				$in = $base . '<circle cx="33.4" cy="20.6" r="4.9" fill="' . $g . '" opacity=".78"/>'
					. '<path d="M26.2 34.8c.4-5.4 3.4-8.2 7.2-8.2 4 0 7.2 3 7.6 8.2z" fill="' . $g . '" opacity=".78"/>'
					. '<circle cx="23.4" cy="23" r="5.6" fill="' . $g . '" stroke="#0F4D2E" stroke-width="1.2"/>'
					. '<path d="M13.4 39.4c0-6 4.4-9.6 10-9.6s10 3.6 10 9.6v.8h-20z" fill="' . $g . '" stroke="#0F4D2E" stroke-width="1.2"/>'
					. '<circle cx="42.4" cy="42.4" r="8.6" fill="url(#dsmRing)"/><circle cx="42.4" cy="42.4" r="6.8" fill="url(#dsmIn)"/>'
					. '<path d="M42.4 38.8v7.2M38.8 42.4h7.2" stroke="' . $g . '" stroke-width="2.2" stroke-linecap="round"/>';
				break;
			default:
				$in = $base;
		}
		return '<svg class="dsm-badge" viewBox="0 0 56 56" aria-hidden="true">' . $in . '</svg>';
	}

	private static function more_chev() {
		return '<svg class="dsm-chev" viewBox="0 0 24 24" aria-hidden="true"><path d="M14.5 5.5 8 12l6.5 6.5" fill="none" stroke="currentColor" stroke-width="2.8" stroke-linecap="round" stroke-linejoin="round"/></svg>';
	}

	/** «تابعنا على» circles — managed in دلیل الزائر → «شبکه‌های اجتماعی (تابعنا)». */
	private static function socials( $o ) {
		return class_exists( 'DLZ_Socials' ) ? DLZ_Socials::items() : array();
	}

	/** «دعوة الأصدقاء»: opens the SMS app with the Arabic invitation and the site link under it. */
	private static function invite_sms( $o ) {
		$text = trim( (string) $o['invite_text'] );
		$body = ( '' !== $text ? $text . "\n" : '' ) . home_url( '/' );
		return 'sms:?&body=' . rawurlencode( $body );
	}

	/** Extra links from the «المزيد» menu setting, without the ones already shown as main cards. */
	private static function more_extra( $sections ) {
		$out  = array();
		$skip = array( '@privacy', '{articles}', '{profile}' );
		foreach ( $sections as $s ) {
			foreach ( $s['items'] as $it ) {
				$u = trim( $it['url'] );
				if ( in_array( $u, $skip, true ) || 'whatsapp' === $it['icon'] || preg_match( '#wa\.me|whatsapp#i', $u ) ) {
					continue;
				}
				$out[] = $it;
			}
		}
		return $out;
	}

	/* =========================================================
	 * Icons
	 * ======================================================= */

	public static function icon_paths() {
		return array(
			'headset'  => '<path d="M4 14v-2a8 8 0 0 1 16 0v2"/><path d="M4 14a2 2 0 0 1 2-2h1v6H6a2 2 0 0 1-2-2zM20 14a2 2 0 0 0-2-2h-1v6h1a2 2 0 0 0 2-2z"/><path d="M18 18v.5a2.5 2.5 0 0 1-2.5 2.5H12"/>',
			'heart'    => '<path fill="currentColor" stroke="none" d="M12 20.6s-7.6-4.6-9.4-9.3C1.3 7.9 3.6 4.4 7 4.4c2 0 3.5 1.1 5 3 1.5-1.9 3-3 5-3 3.4 0 5.7 3.5 4.4 6.9-1.8 4.7-9.4 9.3-9.4 9.3z"/>',
			'pin'      => '<path d="M12 21s-6.5-6.2-6.5-11a6.5 6.5 0 0 1 13 0c0 4.8-6.5 11-6.5 11z"/><circle cx="12" cy="10" r="2.3"/>',
			'pinfill'  => '<path fill="currentColor" stroke="none" d="M12 1.8A7.2 7.2 0 0 0 4.8 9c0 5.3 7.2 13.2 7.2 13.2S19.2 14.3 19.2 9A7.2 7.2 0 0 0 12 1.8zm0 10a2.8 2.8 0 1 1 0-5.6 2.8 2.8 0 0 1 0 5.6z"/>',
			'down'     => '<path d="m6 9 6 6 6-6"/>',
			'chev'     => '<path d="m15 6-6 6 6 6"/>',
			'back'     => '<path d="m9 6 6 6-6 6"/>',
			'search'   => '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.6-3.6"/>',
			'home'     => '<path fill="currentColor" stroke="none" d="M11.3 3.3a1.1 1.1 0 0 1 1.4 0l8.2 6.9c.4.3.1 1-.4 1H19V20a1 1 0 0 1-1 1h-3.6v-5.6H9.6V21H6a1 1 0 0 1-1-1v-8.8H3.5c-.5 0-.8-.7-.4-1z"/>',
			'cart'     => '<path fill="currentColor" stroke="none" d="M2.5 3.5h2.3c.5 0 .9.3 1 .8L6.2 6H20c.7 0 1.2.6 1 1.3l-1.7 7a1.6 1.6 0 0 1-1.6 1.2H8.6a1.6 1.6 0 0 1-1.6-1.3L5 5.5H2.5a1 1 0 0 1 0-2z"/><circle fill="currentColor" stroke="none" cx="9.5" cy="19.5" r="1.7"/><circle fill="currentColor" stroke="none" cx="17" cy="19.5" r="1.7"/>',
			'bookings' => '<path fill="currentColor" stroke="none" d="M4 6.5A2.5 2.5 0 0 1 6.5 4h11A2.5 2.5 0 0 1 20 6.5V9a3 3 0 0 0 0 6v2.5a2.5 2.5 0 0 1-2.5 2.5h-11A2.5 2.5 0 0 1 4 17.5V15a3 3 0 0 0 0-6z"/><path style="stroke:var(--dsh-gd)" stroke-dasharray="1.8 2.2" d="M14.5 7v10"/><path style="stroke:var(--dsh-gd)" d="M7.5 10h4M7.5 13.5h3"/>',
			'orders'   => '<path fill="currentColor" stroke="none" d="M9 2.5h6a1 1 0 0 1 1 1V4h1.5A2.5 2.5 0 0 1 20 6.5v13A2.5 2.5 0 0 1 17.5 22h-11A2.5 2.5 0 0 1 4 19.5v-13A2.5 2.5 0 0 1 6.5 4H8v-.5a1 1 0 0 1 1-1z"/><path style="stroke:var(--dsh-gd)" d="M8.5 10h7M8.5 13.5h7M8.5 17h4.5"/>',
			'dots'     => '<circle fill="currentColor" stroke="none" cx="5" cy="12" r="2"/><circle fill="currentColor" stroke="none" cx="12" cy="12" r="2"/><circle fill="currentColor" stroke="none" cx="19" cy="12" r="2"/>',
			'question' => '<circle cx="12" cy="12" r="8.5"/><path d="M9.6 9.6a2.5 2.5 0 1 1 3.4 2.3c-.6.3-1 .8-1 1.5v.5"/><circle fill="currentColor" stroke="none" cx="12" cy="16.6" r="1"/>',
			'book'     => '<path d="M12 6.8C10 5.3 7.4 4.8 3.5 4.8v13.6c3.9 0 6.5.5 8.5 2 2-1.5 4.6-2 8.5-2V4.8c-3.9 0-6.5.5-8.5 2zm0 0v13.6"/>',
			'bell'     => '<path d="M6 16v-5a6 6 0 0 1 12 0v5l1.6 2H4.4z"/><path d="M10 20.5a2 2 0 0 0 4 0"/>',
			'info'     => '<circle cx="12" cy="12" r="8.5"/><path d="M12 11v5.5"/><circle fill="currentColor" stroke="none" cx="12" cy="7.8" r="1"/>',
			'doc'      => '<rect x="5" y="3" width="14" height="18" rx="2.5"/><path d="M9 8h6M9 12h6M9 16h3.5"/>',
			'star'     => '<path d="m12 3 2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1-4.4-4.3 6.1-.9z"/>',
			'phone'    => '<path d="M5.5 3.5h3.3l1.7 4.3-2.2 1.4a11 11 0 0 0 5.5 5.5l1.4-2.2 4.3 1.7v3.3a2 2 0 0 1-2 2A15.5 15.5 0 0 1 3.5 5.5a2 2 0 0 1 2-2z"/>',
			'gift'     => '<rect x="3.5" y="8" width="17" height="4" rx="1"/><path d="M5 12v8h14v-8M12 8v12M12 8S10.5 4 8 4.5 7 8 12 8zm0 0s1.5-4 4-3.5S17 8 12 8z"/>',
			'map'      => '<path d="m3.5 6 5.5-2 6 2 5.5-2v14l-5.5 2-6-2-5.5 2z"/><path d="M9 4v14M15 6v14"/>',
			'edit'     => '<path d="M4 20h4L19 9l-4-4L4 16z"/><path d="m13.5 6.5 4 4"/>',
			'logout'   => '<path d="M14 4h3.5A2.5 2.5 0 0 1 20 6.5v11a2.5 2.5 0 0 1-2.5 2.5H14"/><path d="M10 8l-4 4 4 4M6 12h9"/>',
			'user'     => '<circle cx="12" cy="8.5" r="4"/><path d="M4.5 21a7.5 7.5 0 0 1 15 0"/>',
			'close'    => '<path d="M6 6l12 12M18 6 6 18"/>',
			'whatsapp' => '<path d="M12 3.5a8.5 8.5 0 0 0-7.3 12.8L3.5 20.5l4.3-1.1A8.5 8.5 0 1 0 12 3.5z"/><path d="M9 8.6c.3-.4.7-.4 1-.1l.8 1c.2.3.2.6 0 .9l-.5.6c.6 1.2 1.6 2.2 2.8 2.8l.6-.5c.3-.2.6-.2.9 0l1 .8c.3.3.3.7-.1 1-.5.5-1.3.8-2 .5a7 7 0 0 1-5-5c-.3-.7 0-1.5.5-2z"/>',
			'mail'     => '<rect x="3.5" y="5.5" width="17" height="13" rx="2.5"/><path d="m4.5 7.5 7.5 6 7.5-6"/>',
			'globe'    => '<circle cx="12" cy="12" r="8.5"/><path d="M3.5 12h17M12 3.5c2.3 2.4 3.5 5.2 3.5 8.5s-1.2 6.1-3.5 8.5c-2.3-2.4-3.5-5.2-3.5-8.5s1.2-6.1 3.5-8.5z"/>',
			'shield'   => '<path d="M12 3 5 6v5.5c0 4.4 3 8 7 9.5 4-1.5 7-5.1 7-9.5V6z"/><path d="m9 12 2 2 4-4"/>',
			'basket'   => '<path d="M4 9.5h16l-1.6 9a2 2 0 0 1-2 1.5H7.6a2 2 0 0 1-2-1.5z"/><path d="m8.5 9.5 3-5.5M15.5 9.5l-3-5.5M9.5 13.5v3M14.5 13.5v3"/>',
			'plane'    => '<path d="M21 15.5v-1.8l-7.5-4.6V4a1.5 1.5 0 0 0-3 0v5.1L3 13.7v1.8l7.5-2.3v4.9l-2 1.5v1.4l3.5-1 3.5 1v-1.4l-2-1.5v-4.9z"/>',
			'compass'  => '<circle cx="12" cy="12" r="8.5"/><path d="m15.5 8.5-2.1 4.9-4.9 2.1 2.1-4.9z"/>',
			'ticket'   => '<path d="M4 7.5A1.5 1.5 0 0 1 5.5 6h13A1.5 1.5 0 0 1 20 7.5V10a2 2 0 0 0 0 4v2.5a1.5 1.5 0 0 1-1.5 1.5h-13A1.5 1.5 0 0 1 4 16.5V14a2 2 0 0 0 0-4z"/><path d="M14 7v10" stroke-dasharray="2 2"/>',
			'car'      => '<path d="M5 11.5 6.8 7a2 2 0 0 1 1.9-1.3h6.6A2 2 0 0 1 17.2 7l1.8 4.5"/><rect x="3.5" y="11.5" width="17" height="5.5" rx="1.8"/><path d="M6 17v2M18 17v2"/><circle fill="currentColor" stroke="none" cx="7.5" cy="14.2" r="1.1"/><circle fill="currentColor" stroke="none" cx="16.5" cy="14.2" r="1.1"/>',
			'store'    => '<path d="M4 9.5 5.5 4h13L20 9.5"/><path d="M4 9.5a2.7 2.7 0 0 0 5.3 0 2.7 2.7 0 0 0 5.4 0 2.7 2.7 0 0 0 5.3 0"/><path d="M5.5 11.5V20h13v-8.5M10 20v-5h4v5"/>',
			'medical'  => '<rect x="3.5" y="3.5" width="17" height="17" rx="5"/><path d="M12 8v8M8 12h8"/>',
			'scale'    => '<path d="M12 4v16M7.5 20h9M5 7.5h14"/><path d="M5 7.5 2.8 13a2.3 2.3 0 0 0 4.4 0zM19 7.5 16.8 13a2.3 2.3 0 0 0 4.4 0z"/>',
			'coins'    => '<circle cx="12" cy="12" r="8.5"/><path d="M14.5 9.3c-.5-.8-1.4-1.3-2.5-1.3-1.4 0-2.5.8-2.5 2s1.1 1.6 2.5 2 2.5.8 2.5 2-1.1 2-2.5 2c-1.1 0-2-.5-2.5-1.3M12 6.5V8M12 16v1.5"/>',
			'grid'     => '<rect x="4" y="4" width="6.5" height="6.5" rx="2"/><rect x="13.5" y="4" width="6.5" height="6.5" rx="2"/><rect x="4" y="13.5" width="6.5" height="6.5" rx="2"/><rect x="13.5" y="13.5" width="6.5" height="6.5" rx="2"/>',
			'download' => '<path d="M12 4v11M7.5 10.5 12 15l4.5-4.5"/><path d="M5 19.5h14"/>',
			'clock'    => '<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/>',
			'external' => '<path d="M14 4h6v6M20 4l-9 9"/><path d="M18 14v4.5a1.5 1.5 0 0 1-1.5 1.5h-11A1.5 1.5 0 0 1 4 18.5v-11A1.5 1.5 0 0 1 5.5 6H10"/>',
		);
	}

	public static function icon( $name ) {
		$i = self::icon_paths();
		$p = isset( $i[ $name ] ) ? $i[ $name ] : $i['star'];
		return '<svg class="dsh-i" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . $p . '</svg>';
	}

	/* =========================================================
	 * Front-end
	 * ======================================================= */

	private function active() {
		$o = self::get();
		return $o['enabled'] && 'classic' !== $o['mode'] && ! is_admin() && ! is_customize_preview() && ! wp_doing_ajax();
	}

	public function body_class( $c ) {
		if ( $this->active() ) {
			$c[] = 'dsh-on';
			$c[] = 'dsh-mode-' . self::get()['mode'];
			if ( 'light' === self::get()['surface'] ) {
				$c[] = 'dsh-light';
			}
		}
		return $c;
	}

	private static function hard( $selectors ) {
		$out = array();
		foreach ( explode( ',', (string) $selectors ) as $sel ) {
			$sel = trim( $sel );
			if ( '' !== $sel ) {
				$out[] = 'html body ' . $sel;
			}
		}
		return implode( ',', $out );
	}

	public function front_assets() {
		if ( ! $this->active() ) {
			return;
		}
		$o     = self::get();
		$fonts = self::fonts();
		$ver   = defined( 'DASE_VERSION' ) ? DASE_VERSION : '14';
		if ( ! empty( $fonts[ $o['font'] ][1] ) ) {
			wp_enqueue_style( 'dsh-font', 'https://fonts.googleapis.com/css2?family=' . $fonts[ $o['font'] ][1] . '&display=swap', array(), null );
		}
		wp_enqueue_style( 'dsh', DASE_URL . 'assets/app-shell.css', array(), $ver );
		wp_enqueue_style( 'dsh-v15', DASE_URL . 'assets/app-shell-v15.css', array( 'dsh' ), $ver );
		if ( class_exists( 'DLZ_Countries' ) ) {
			DLZ_Countries::enqueue_style(); // waving flags + the «DlzDigits» English-digit font
		}
		$deps = array();
		if ( 'explore' === self::center_target( $o ) ) {
			DLZ_Nafahat::enqueue(); // «نفحات» lives in the center button
			$deps[] = 'dlz-nafahat';
		}
		wp_enqueue_script( 'dsh', DASE_URL . 'assets/app-shell.js', $deps, $ver, true );

		list( $labels, $cur ) = self::cities();
		$services             = array();
		foreach ( self::services() as $s ) {
			$services[] = array( 'label' => $s['label'], 'url' => $s['url'], 'icon' => $s['icon'], 'kw' => $s['kw'] );
		}
		wp_localize_script(
			'dsh',
			'DLZShell',
			array(
				'ajax'     => admin_url( 'admin-ajax.php' ),
				'nonce'    => wp_create_nonce( 'dlz_shell_search' ),
				'live'     => (int) $o['live_search'],
				'fontAuto' => 'site' === $o['font'],
				'digits'   => $o['latin_digits'] ? DASE_URL . 'assets/fonts/dlz-digits.woff' : '',
				'city'     => $cur,
				'cities'   => $labels,
				'services' => $services,
				'logged'   => is_user_logged_in(),
				'profile'  => self::links()['profile'],
				'icons'    => self::icon_paths(),
				'i18n'     => array(
					'recent'   => 'عمليات البحث الأخيرة',
					'services' => 'الخدمات',
					'empty'    => 'لا توجد نتائج مطابقة',
					'loading'  => 'جارٍ البحث...',
					'clear'    => 'مسح',
					'open'     => 'فتح الصفحة',
					'call'     => 'اتصال',
					'wa'       => 'واتساب',
					'map'      => 'الموقع',
					'all'      => 'عرض كل النتائج',
				),
			)
		);

		$bp  = (int) $o['breakpoint'];
		$css = ':root{--dsh-g:' . $o['color'] . ';--dsh-gd:' . $o['color_dark'] . ';--dsh-a:' . $o['accent'] . ';--dsh-font:' . ( $o['latin_digits'] ? '"DlzDigits",' : '' ) . self::font_stack( $o ) . '}';

		if ( 'custom' === $o['font'] && $o['font_reg_url'] ) {
			$fmt = function ( $u ) {
				$e = strtolower( pathinfo( (string) wp_parse_url( $u, PHP_URL_PATH ), PATHINFO_EXTENSION ) );
				return 'ttf' === $e ? 'truetype' : ( 'woff' === $e ? 'woff' : 'woff2' );
			};
			$css = "@font-face{font-family:'DalilFont';src:url('" . esc_url_raw( $o['font_reg_url'] ) . "') format('" . $fmt( $o['font_reg_url'] ) . "');font-weight:100 600;font-display:swap}"
				. ( $o['font_bold_url'] ? "@font-face{font-family:'DalilFont';src:url('" . esc_url_raw( $o['font_bold_url'] ) . "') format('" . $fmt( $o['font_bold_url'] ) . "');font-weight:700 900;font-display:swap}" : '' )
				. $css;
		}
		if ( $o['font_site'] && ! in_array( $o['font'], array( 'theme', 'site' ), true ) ) {
			$css .= 'body,h1,h2,h3,h4,h5,h6,p,a,li,td,th,label,button,input,select,textarea,blockquote,span:not([class*="icon"]):not(.dashicons):not([class*="fa-"]):not([class^="fa"]):not([class*="eicon"]){font-family:var(--dsh-font)!important}';
		}

		$hide = array( 'html body .dase-header', 'html body .dase-bottom', 'html body .dase-menu-overlay', 'html body .dase-city-panel' );
		if ( $o['hide_header'] && $o['header_selectors'] ) {
			$hide[] = self::hard( $o['header_selectors'] );
		}
		if ( $o['hide_footer'] && $o['footer_selectors'] ) {
			$hide[] = self::hard( $o['footer_selectors'] );
		}
		$show = '.dsh-header{display:block}.dsh-nav{display:block}html body.dsh-on{padding-bottom:calc(100px + env(safe-area-inset-bottom,0px))!important}'
			. implode( ',', array_filter( $hide ) ) . '{display:none!important}';
		$css .= 'hybrid' === $o['mode'] ? '@media (max-width:' . $bp . 'px){' . $show . '}' : $show;

		wp_add_inline_style( 'dsh', $css );
	}

	public function render_header() {
		if ( $this->header_done || ! $this->active() ) {
			return;
		}
		$this->header_done = true;
		if ( self::page_hidden( 'header' ) ) {
			return;
		}
		if ( class_exists( 'DLZ_Profile' ) && DLZ_Profile::is_page() ) {
			if ( 'site' === self::get()['font'] ) {
				echo self::font_probe_script(); // phpcs:ignore
			}
			return; // «الملف الشخصي» has its own title bar
		}

		$o                    = self::get();
		$l                    = self::links();
		$logo                 = $this->logo_url( $o );
		list( $labels, $cur ) = self::cities();
		$favs                 = self::fav_count();
		?>
<header class="dsh-header" id="dsh-header" dir="rtl">
	<div class="dsh-hbar">
		<button type="button" class="dsh-city" data-dsh-open="city" aria-haspopup="dialog" aria-label="تغيير المدينة">
			<?php echo self::icon( 'pinfill' ); ?>
			<span class="dsh-city-name"><?php echo esc_html( isset( $labels[ $cur ] ) ? $labels[ $cur ] : $cur ); ?></span>
			<?php echo self::icon( 'down' ); ?>
		</button>

		<a class="dsh-brand" href="<?php echo esc_url( $l['home'] ); ?>" aria-label="<?php echo esc_attr( $o['name_ar'] ); ?>">
			<span class="dsh-brand-mark"><?php echo $logo ? '<img src="' . esc_url( $logo ) . '" alt="">' : self::logo_svg(); // phpcs:ignore ?></span>
			<span class="dsh-brand-txt">
				<span class="dsh-brand-ar"><?php echo esc_html( $o['name_ar'] ); ?></span>
			</span>
		</a>

		<div class="dsh-hact">
			<a class="dsh-circ" href="<?php echo esc_url( $l['favorites'] ); ?>" data-tab="favorites">
				<span class="dsh-circ-i"><?php echo self::icon( 'heart' ); ?><span class="dsh-fav-badge"<?php echo $favs ? '' : ' hidden'; ?>><?php echo (int) $favs; ?></span></span>
				<span class="dsh-circ-l">المفضلة</span>
			</a>
			<?php if ( $l['support'] ) : ?>
			<a class="dsh-circ dsh-circ-gold" href="<?php echo esc_url( $l['support'] ); ?>">
			<?php else : ?>
			<a class="dsh-circ dsh-circ-gold" href="#" data-dlz-chat="1" role="button">
			<?php endif; ?>
				<span class="dsh-circ-i"><?php echo self::icon( 'headset' ); ?><span class="dsh-live-dot" aria-hidden="true"></span></span>
				<span class="dsh-circ-l">الدعم</span>
			</a>
		</div>
	</div>

	<form class="dsh-search" role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>">
		<input type="search" name="s" value="<?php echo esc_attr( get_search_query() ); ?>" placeholder="<?php echo esc_attr( $o['search_ph'] ); ?>" aria-label="<?php echo esc_attr( $o['search_ph'] ); ?>" autocomplete="off"<?php echo $o['live_search'] ? ' data-dsh-live="1"' : ''; ?>>
		<?php if ( $o['search_type'] ) : ?><input type="hidden" name="post_type" value="<?php echo esc_attr( $o['search_type'] ); ?>"><?php endif; ?>
		<button type="submit" aria-label="بحث"><?php echo self::icon( 'search' ); ?></button>
	</form>
</header>
		<?php
		if ( 'site' === $o['font'] ) {
			echo self::font_probe_script();
		}
	}

	/** Copies the site's own font (theme / Elementor kit) onto the app shell. */
	private static function font_probe_script() {
		// Elementor global font first (Site Settings → Global Fonts), then the font the body really uses.
		return '<script>(function(){try{var b=document.body,c=getComputedStyle(b),v="";["--e-global-typography-text-font-family","--e-global-typography-primary-font-family"].some(function(k){v=(c.getPropertyValue(k)||"").trim();return !!v;});var f=v?v+","+c.fontFamily:c.fontFamily;if(f)document.documentElement.style.setProperty("--dsh-font",' . ( self::get()['latin_digits'] ? '"\"DlzDigits\","+' : '' ) . 'f+",system-ui,sans-serif");}catch(e){}})();</script>';
	}

	public function render_footer() {
		if ( $this->footer_done || ! $this->active() ) {
			return;
		}
		$this->footer_done = true;
		if ( ! $this->header_done ) {
			echo '<div id="dsh-late" hidden>';
			$this->render_header();
			echo '</div>';
		}

		$o                    = self::get();
		$l                    = self::links();
		$logo                 = $this->logo_url( $o );
		$sections             = $this->more_sections( $o );
		$services             = self::services();
		list( $labels, $cur ) = self::cities();
		$cur_label            = isset( $labels[ $cur ] ) ? $labels[ $cur ] : $cur;
		$user                 = wp_get_current_user();
		$logged               = $user && $user->exists();
		$favs                 = self::fav_count();
		$hide_nav             = self::page_hidden( 'footer' );
		$ct                   = self::center_target( $o );

		if ( ! $hide_nav ) :
			?>
<nav class="dsh-nav" id="dsh-nav" dir="rtl" aria-label="القائمة الرئيسية">
	<svg class="dsh-nav-hump" viewBox="0 0 220 34" preserveAspectRatio="none" aria-hidden="true"><path class="dsh-hump-fill" d="M0 34C40 34 52 3 110 3s70 31 110 31Z"/><path class="dsh-hump-line" d="M0 33.4C40 33.4 52 2.6 110 2.6s70 30.8 110 30.8"/></svg>
	<div class="dsh-nav-in">
		<a class="dsh-tab" data-tab="home" href="<?php echo esc_url( $l['home'] ); ?>">
			<?php echo self::icon( 'home' ); ?><span>الرئيسية</span>
		</a>
		<a class="dsh-tab" data-tab="bookings" href="<?php echo esc_url( $l['bookings'] ); ?>">
			<?php echo self::icon( 'bookings' ); ?><span>حجوزاتي</span>
		</a>
		<?php $ct_panel = in_array( $ct, array( 'services', 'explore' ), true ); if ( ! $ct_panel ) : ?>
		<a class="dsh-center" data-tab="center" href="<?php echo esc_url( $ct ); ?>">
		<?php else : ?>
		<button type="button" class="dsh-center" data-tab="center" data-dsh-open="<?php echo esc_attr( $ct ); ?>" aria-haspopup="dialog" aria-controls="dsh-<?php echo esc_attr( $ct ); ?>">
		<?php endif; ?>
			<span class="dsh-halo" aria-hidden="true"><i class="dsh-halo-a"></i><i class="dsh-halo-b"></i></span>
			<span class="dsh-center-ring"><span class="dsh-center-core"><?php echo $logo ? '<img src="' . esc_url( $logo ) . '" alt="">' : self::logo_svg(); // phpcs:ignore ?></span></span>
			<span class="dsh-center-l"><?php echo esc_html( $o['center_label'] ); ?></span>
			<span class="dsh-center-orn" aria-hidden="true"><i></i><b></b><i></i></span>
		<?php echo $ct_panel ? '</button>' : '</a>'; ?>
		<a class="dsh-tab" data-tab="orders" href="<?php echo esc_url( $l['orders'] ? $l['orders'] : '#' ); ?>">
			<span class="dsh-tab-ic"><?php echo self::icon( 'orders' ); ?><span class="dsh-badge" hidden>0</span></span><span>طلباتي</span>
		</a>
		<button type="button" class="dsh-tab" data-tab="more" data-dsh-open="more" aria-haspopup="dialog" aria-controls="dsh-more">
			<?php echo self::icon( 'dots' ); ?><span><?php echo esc_html( $o['more_title'] ); ?></span>
		</button>
	</div>
</nav>
		<?php endif; ?>

<?php echo ( $logged && class_exists( 'DLZ_Countries' ) && ( $dlzf = DLZ_Countries::of_user( $user->ID ) ) ) ? DLZ_Countries::defs( array( $dlzf ) ) : ''; // phpcs:ignore — only the visitor's own flag ?>
<div class="dsh-more" id="dsh-more" dir="rtl" role="dialog" aria-modal="true" aria-labelledby="dsh-more-title" hidden>
	<div class="dsh-more-top">
		<h2 id="dsh-more-title"><?php echo esc_html( $o['more_title'] ); ?></h2>
		<span class="dsh-orn" aria-hidden="true"></span>
	</div>
	<div class="dsh-more-sheet dsm">
		<?php echo self::more_defs(); // phpcs:ignore ?>
		<?php $complete = $logged && function_exists( 'dlz_profile_is_complete' ) ? dlz_profile_is_complete( $user->ID ) : true; ?>
		<nav class="dsm-list" aria-label="<?php echo esc_attr( $o['more_title'] ); ?>">
			<a class="dsm-card" href="<?php echo esc_url( $l['profile'] ); ?>">
				<?php
				$ukey  = ( $logged && class_exists( 'DLZ_Countries' ) ) ? DLZ_Countries::of_user( $user->ID ) : '';
				$uav   = $logged ? (string) get_user_meta( $user->ID, 'mp_avatar', true ) : '';
				$uname = $logged ? trim( (string) get_user_meta( $user->ID, 'mp_full_name', true ) ) : '';
				if ( $logged && '' === $uname ) {
					$uname = trim( get_user_meta( $user->ID, 'first_name', true ) . ' ' . get_user_meta( $user->ID, 'last_name', true ) );
				}
				?>
				<span class="dsm-ic"><?php echo $uav ? '<span class="dsm-av"><img class="dsh-avatar" src="' . esc_url( $uav ) . '" alt=""></span>' : self::more_badge( 'account' ); // phpcs:ignore ?></span>
				<span class="dsm-l dsm-l-acc"><span class="dsm-acc-t"><span class="dsm-acc-n"><?php echo esc_html( '' !== $uname ? $uname : 'حسابي' ); ?></span><?php if ( '' !== $uname ) : ?><small>حسابي</small><?php endif; ?></span><span class="dsm-card-flag"><?php echo $ukey ? DLZ_Countries::flag( $ukey, true, 'dsm-flag' ) : ''; // phpcs:ignore ?></span></span>
				<?php if ( $logged && ! $complete ) : ?><span class="dsm-pill">أكمل ملفك</span><?php elseif ( ! $logged ) : ?><span class="dsm-pill dsm-pill-soft">تسجيل الدخول</span><?php endif; ?>
				<?php echo self::more_chev(); // phpcs:ignore ?>
			</a>
			<a class="dsm-card" <?php echo self::action_attrs( $o['help_url'] ? $o['help_url'] : '@chat' ); // phpcs:ignore ?>>
				<span class="dsm-ic"><?php echo self::more_badge( 'help' ); // phpcs:ignore ?></span>
				<span class="dsm-l">المساعدة</span>
				<?php echo self::more_chev(); // phpcs:ignore ?>
			</a>
			<a class="dsm-card" href="#" data-dlz-info="privacy">
				<span class="dsm-ic"><?php echo self::more_badge( 'privacy' ); // phpcs:ignore ?></span>
				<span class="dsm-l">سياسة الخصوصية</span>
				<?php echo self::more_chev(); // phpcs:ignore ?>
			</a>
			<a class="dsm-card" href="<?php echo esc_url( $l['articles'] ? $l['articles'] : home_url( '/' ) ); ?>">
				<span class="dsm-ic"><?php echo self::more_badge( 'articles' ); // phpcs:ignore ?></span>
				<span class="dsm-l">المقالات</span>
				<?php echo self::more_chev(); // phpcs:ignore ?>
			</a>
			<a class="dsm-card" href="<?php echo esc_attr( self::invite_sms( $o ) ); ?>" data-dsh-share="1" data-text="<?php echo esc_attr( trim( (string) $o['invite_text'] ) ); ?>" data-url="<?php echo esc_url( home_url( '/' ) ); ?>">
				<span class="dsm-ic"><?php echo self::more_badge( 'invite' ); // phpcs:ignore ?></span>
				<span class="dsm-l">دعوة الأصدقاء</span>
				<?php echo self::more_chev(); // phpcs:ignore ?>
			</a>
		</nav>



		<?php if ( $o['app_url'] ) : ?>
		<a class="dsh-app dsm-app" href="<?php echo esc_url( $o['app_url'] ); ?>" download>
			<span class="dsh-app-ic"><?php echo self::icon( 'download' ); ?></span>
			<span class="dsh-app-t"><b><?php echo esc_html( $o['app_title'] ); ?></b><small><?php echo esc_html( $o['app_sub'] ); ?></small></span>
			<span class="dsh-app-btn">تحميل</span>
		</a>
		<?php endif; ?>

		<?php $socials = self::socials( $o ); if ( $socials ) : ?>
		<div class="dsm-title dsm-follow"><i></i><b></b><span>تابعنا على:</span><b></b><i></i></div>
		<div class="dsm-social">
			<?php foreach ( $socials as $sc ) : ?>
				<?php if ( $sc['url'] ) : ?>
			<a class="dsm-soc" href="<?php echo esc_url( $sc['url'] ); ?>" <?php echo preg_match( '#^(tel|mailto):#', $sc['url'] ) ? '' : 'target="_blank" rel="noopener"'; ?> aria-label="<?php echo esc_attr( $sc['label'] ); ?>"><?php echo $sc['svg']; // phpcs:ignore ?></a>
				<?php else : ?>
			<span class="dsm-soc" role="img" aria-label="<?php echo esc_attr( $sc['label'] ); ?>"><?php echo $sc['svg']; // phpcs:ignore ?></span>
				<?php endif; ?>
			<?php endforeach; ?>
		</div>
		<?php endif; ?>
		<?php $site = home_url( '/' ); ?>
		<a class="dsm-site" href="<?php echo esc_url( $site ); ?>"><?php echo self::icon( 'globe' ); ?><span dir="ltr"><?php echo esc_html( preg_replace( '#^www\.#', '', (string) wp_parse_url( $site, PHP_URL_HOST ) ) ); ?></span></a>

		<?php if ( $logged ) : ?>
		<a class="dsh-logout dsm-logout" href="<?php echo esc_url( wp_logout_url( home_url( '/' ) ) ); ?>"><?php echo self::icon( 'logout' ); ?>تسجيل الخروج</a>
		<?php endif; ?>
		<p class="dsh-sign dsm-sign">«<?php echo esc_html( $o['name_ar'] ); ?>» – نرافقكم لتكون رحلتكم في أمان<br><small>v<?php echo esc_html( defined( 'DASE_VERSION' ) ? DASE_VERSION : '' ); ?></small></p>
	</div>
</div>

<?php $inv = trim( (string) $o['invite_text'] ); ?>
<div class="dsh-share" id="dsh-share" dir="rtl" role="dialog" aria-modal="true" aria-labelledby="dsh-share-t" hidden>
	<div class="dsh-share-bd" data-share-close></div>
	<div class="dsh-share-box">
		<span class="dsh-grip" aria-hidden="true"></span>
		<h3 id="dsh-share-t">ادعُ أصدقاءك</h3>
		<p class="dsh-share-sub">أرسل الدعوة عبر أيّ تطبيق تحبّه</p>
		<div class="dsh-share-msg"><span><?php echo esc_html( $inv ); ?></span><b dir="ltr"><?php echo esc_html( home_url( '/' ) ); ?></b></div>
		<div class="dsh-share-grid">
			<button type="button" data-share="wa" style="--c:#25D366"><span><?php echo class_exists( 'DLZ_Socials' ) ? DLZ_Socials::svg( 'whatsapp' ) : ''; // phpcs:ignore ?></span>واتساب</button>
			<button type="button" data-share="tg" style="--c:#229ED9"><span><?php echo class_exists( 'DLZ_Socials' ) ? DLZ_Socials::svg( 'telegram' ) : ''; // phpcs:ignore ?></span>تيليجرام</button>
			<button type="button" data-share="sms" style="--c:#0F4D2E"><span><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 5.5h16a1.5 1.5 0 0 1 1.5 1.5v9a1.5 1.5 0 0 1-1.5 1.5H10l-4.5 3.5V17.5H4A1.5 1.5 0 0 1 2.5 16V7A1.5 1.5 0 0 1 4 5.5z" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linejoin="round"/><circle cx="8" cy="11.5" r="1.2" fill="currentColor"/><circle cx="12" cy="11.5" r="1.2" fill="currentColor"/><circle cx="16" cy="11.5" r="1.2" fill="currentColor"/></svg></span>الرسائل SMS</button>
			<button type="button" data-share="fb" style="--c:#1877F2"><span><?php echo class_exists( 'DLZ_Socials' ) ? DLZ_Socials::svg( 'facebook' ) : ''; // phpcs:ignore ?></span>فيسبوك</button>
			<button type="button" data-share="mail" style="--c:#B8862B"><span><?php echo class_exists( 'DLZ_Socials' ) ? DLZ_Socials::svg( 'email' ) : ''; // phpcs:ignore ?></span>البريد</button>
			<button type="button" data-share="copy" style="--c:#4F5F57"><span><svg viewBox="0 0 24 24" aria-hidden="true"><rect x="8.5" y="8.5" width="11.5" height="11.5" rx="2.4" fill="none" stroke="currentColor" stroke-width="1.9"/><path d="M15.5 8.5V6A2 2 0 0 0 13.5 4H6a2 2 0 0 0-2 2v7.5a2 2 0 0 0 2 2h2.5" fill="none" stroke="currentColor" stroke-width="1.9"/></svg></span><em>نسخ الرسالة</em></button>
		</div>
		<button type="button" class="dsh-share-more" data-share="native" hidden><svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="18" cy="5.5" r="2.5" fill="none" stroke="currentColor" stroke-width="1.8"/><circle cx="6" cy="12" r="2.5" fill="none" stroke="currentColor" stroke-width="1.8"/><circle cx="18" cy="18.5" r="2.5" fill="none" stroke="currentColor" stroke-width="1.8"/><path d="m8.2 10.8 7.6-4M8.2 13.2l7.6 4" stroke="currentColor" stroke-width="1.8"/></svg>تطبيقات أخرى…</button>
	</div>
</div>

<div class="dsh-sheet" id="dsh-city" dir="rtl" role="dialog" aria-modal="true" aria-labelledby="dsh-city-title" hidden>
	<div class="dsh-sheet-box">
		<span class="dsh-grip" aria-hidden="true"></span>
		<h3 id="dsh-city-title">اختر المدينة</h3>
		<p class="dsh-sheet-sub">تُعرض الإعلانات والخدمات حسب المدينة المختارة</p>
		<ul>
			<?php foreach ( $labels as $key => $label ) : ?>
			<li><a href="#" data-city="<?php echo esc_attr( $key ); ?>" class="<?php echo $key === $cur ? 'is-current' : ''; ?>"><?php echo self::icon( 'pin' ); ?><span><?php echo esc_html( $label ); ?></span><i class="dsh-check" aria-hidden="true"></i></a></li>
			<?php endforeach; ?>
		</ul>
	</div>
</div>

<div class="dsh-sheet dsh-svc" id="dsh-services" dir="rtl" role="dialog" aria-modal="true" aria-labelledby="dsh-svc-title" hidden>
	<div class="dsh-sheet-box">
		<span class="dsh-grip" aria-hidden="true"></span>
		<div class="dsh-svc-head">
			<h3 id="dsh-svc-title">خدمات <?php echo esc_html( $o['name_ar'] ); ?></h3>
			<button type="button" class="dsh-svc-city" data-dsh-open="city"><?php echo self::icon( 'pinfill' ); ?><span class="dsh-city-name"><?php echo esc_html( $cur_label ); ?></span></button>
		</div>
		<?php if ( $services ) : ?>
		<div class="dsh-svc-grid">
			<?php foreach ( $services as $i => $sv ) : ?>
			<a class="dsh-svc-tile" href="<?php echo esc_url( $sv['url'] ); ?>" style="--i:<?php echo (int) $i; ?>">
				<span class="dsh-svc-ic"><?php echo self::icon( $sv['icon'] ); ?></span>
				<span class="dsh-svc-l"><?php echo esc_html( $sv['label'] ); ?></span>
			</a>
			<?php endforeach; ?>
		</div>
		<?php else : ?>
		<p class="dsh-sheet-sub">لم يتم العثور على صفحات الخدمات بعد.</p>
		<?php endif; ?>
		<button type="button" class="dsh-svc-search" data-dsh-open="search"><?php echo self::icon( 'search' ); ?><span><?php echo esc_html( $o['search_ph'] ); ?></span></button>
	</div>
</div>

		<?php if ( 'explore' === $ct ) : ?>
<div class="dsh-exp" id="dsh-explore" dir="rtl" role="dialog" aria-modal="true" aria-labelledby="dsh-exp-title" hidden>
	<div class="dsh-exp-top">
		<button type="button" class="dsh-find-back" data-dsh-close aria-label="رجوع"><?php echo self::icon( 'back' ); ?></button>
		<div class="dsh-exp-head">
			<h2 id="dsh-exp-title"><?php echo esc_html( $o['center_label'] ); ?></h2>
			<span class="dsh-exp-orn" aria-hidden="true"><i></i><b></b><i></i></span>
		</div>
		<span class="dsh-exp-sp" aria-hidden="true"></span>
	</div>
	<div class="dsh-exp-body">
		<?php echo DLZ_Nafahat::render( array( 'lazy' => 1, 'per' => 15, 'chips' => 1 ) ); // phpcs:ignore ?>
	</div>
</div>
		<?php endif; ?>

		<?php if ( $o['live_search'] ) : ?>
<div class="dsh-find" id="dsh-search" dir="rtl" role="dialog" aria-modal="true" aria-label="بحث" hidden>
	<div class="dsh-find-top">
		<button type="button" class="dsh-find-back" data-dsh-close aria-label="رجوع"><?php echo self::icon( 'back' ); ?></button>
		<form class="dsh-find-form" role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>">
			<?php echo self::icon( 'search' ); ?>
			<input type="search" name="s" placeholder="<?php echo esc_attr( $o['search_ph'] ); ?>" autocomplete="off" enterkeyhint="search" aria-label="<?php echo esc_attr( $o['search_ph'] ); ?>">
			<button type="button" class="dsh-find-clear" aria-label="مسح" hidden><?php echo self::icon( 'close' ); ?></button>
		</form>
	</div>
	<div class="dsh-find-body" aria-live="polite"></div>
</div>
		<?php endif; ?>
		<?php
	}

	/* =========================================================
	 * Live search (AJAX)
	 * ======================================================= */

	private static function trim_text( $t, $words = 22 ) {
		return wp_trim_words( wp_strip_all_tags( (string) $t ), $words, '…' );
	}

	public function ajax_search() {
		// Public, read-only search: no nonce so cached pages (page-cache plugins) never break it.
		$q = isset( $_REQUEST['q'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['q'] ) ) : '';
		$q = trim( $q );
		if ( function_exists( 'mb_strlen' ) ? mb_strlen( $q ) < 2 : strlen( $q ) < 2 ) {
			wp_send_json_success( array( 'groups' => array() ) );
		}
		$ckey = 'dlz_shs_' . md5( $q . '|' . ( function_exists( 'dlz_current_city' ) ? dlz_current_city() : '' ) );
		$hit  = get_transient( $ckey );
		if ( is_array( $hit ) ) {
			wp_send_json_success( $hit );
		}

		list( $labels, $cur ) = self::cities();
		$groups               = array();

		$cpt = array(
			'dbd_business'      => array( 'الفنادق والمطاعم والخدمات', 'directory', '_dbd_city', 'store' ),
			'dlz_daily_tour'    => array( 'الجولات اليومية', 'tours', '_dlz_tour_city', 'compass' ),
			'dlz_entertainment' => array( 'المراكز الترفيهية', 'entertainment', '_dlz_ent_city', 'ticket' ),
			'dalil_article'     => array( 'المقالات', 'articles', '', 'book' ),
		);
		foreach ( $cpt as $pt => $def ) {
			if ( ! post_type_exists( $pt ) ) {
				continue;
			}
			$query = new WP_Query(
				array(
					'post_type'           => $pt,
					'post_status'         => 'publish',
					's'                   => $q,
					'posts_per_page'      => 6,
					'no_found_rows'       => true,
					'ignore_sticky_posts' => true,
					'suppress_filters'    => false,
				)
			);
			$items = array();
			$base  = self::service_url( $def[1] );
			foreach ( $query->posts as $p ) {
				$city = $def[2] ? (string) get_post_meta( $p->ID, $def[2], true ) : '';
				$snap = function_exists( 'dlz_favorite_snapshot' ) && 'dalil_article' !== $pt ? dlz_favorite_snapshot( $pt, $p->ID ) : array();
				$img  = ! empty( $snap['image'] ) ? $snap['image'] : get_the_post_thumbnail_url( $p->ID, 'thumbnail' );
				$desc = ! empty( $snap['description'] ) ? $snap['description'] : ( $p->post_excerpt ? $p->post_excerpt : $p->post_content );
				$url  = 'dalil_article' === $pt ? get_permalink( $p ) : ( 'dlz_daily_tour' === $pt && ! $base ? get_permalink( $p ) : $base );
				$items[] = array(
					'id'    => $p->ID,
					'title' => get_the_title( $p ),
					'sub'   => $city && isset( $labels[ $city ] ) ? $labels[ $city ] : '',
					'here'  => $city && $city === $cur,
					'img'   => $img ? esc_url_raw( $img ) : '',
					'desc'  => self::trim_text( $desc ),
					'url'   => $url ? $url : '',
					'phone' => isset( $snap['phone'] ) ? (string) $snap['phone'] : '',
					'wa'    => isset( $snap['whatsapp'] ) ? preg_replace( '/\D+/', '', (string) $snap['whatsapp'] ) : '',
					'map'   => isset( $snap['map'] ) ? (string) $snap['map'] : '',
				);
			}
			// Current city first.
			usort( $items, function ( $a, $b ) {
				return (int) $b['here'] - (int) $a['here'];
			} );
			if ( $items ) {
				$groups[] = array( 'label' => $def[0], 'icon' => $def[3], 'items' => $items );
			}
		}

		// Supermarket products (custom table).
		global $wpdb;
		$tp = $wpdb->prefix . 'dlz_sm_products';
		if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $tp ) ) === $tp ) {
			$rows  = $wpdb->get_results( $wpdb->prepare( "SELECT id,name_ar,description_ar,image_id,base_price,sale_price FROM {$tp} WHERE active=1 AND name_ar LIKE %s ORDER BY sort_order ASC, id DESC LIMIT 6", '%' . $wpdb->esc_like( $q ) . '%' ) ); // phpcs:ignore
			$items = array();
			$base  = self::service_url( 'supermarket' );
			foreach ( (array) $rows as $r ) {
				$price   = ( null !== $r->sale_price && (float) $r->sale_price > 0 ) ? (float) $r->sale_price : (float) $r->base_price;
				$img     = $r->image_id ? wp_get_attachment_image_url( (int) $r->image_id, 'thumbnail' ) : '';
				$items[] = array(
					'id'    => (int) $r->id,
					'title' => $r->name_ar,
					'sub'   => $price ? ( class_exists( 'DLZ_Money' ) ? DLZ_Money::fmt( $price ) : number_format_i18n( $price ) ) : '',
					'img'   => $img ? $img : '',
					'desc'  => self::trim_text( $r->description_ar ),
					'url'   => $base,
				);
			}
			if ( $items ) {
				$groups[] = array( 'label' => 'منتجات السوبرماركت', 'icon' => 'basket', 'items' => $items );
			}
		}

		$data = array( 'groups' => $groups, 'all' => add_query_arg( 's', rawurlencode( $q ), home_url( '/' ) ) );
		set_transient( $ckey, $data, 5 * MINUTE_IN_SECONDS );
		wp_send_json_success( $data );
	}

	/* =========================================================
	 * Admin
	 * ======================================================= */

	public function admin_assets( $hook ) {
		if ( false === strpos( (string) $hook, 'dlz-app-shell' ) ) {
			return;
		}
		wp_enqueue_media();
		wp_enqueue_style( 'wp-color-picker' );
		wp_enqueue_script( 'wp-color-picker' );
		wp_add_inline_script(
			'wp-color-picker',
			"jQuery(function($){
	$('.dsh-color').wpColorPicker();
	$('#dsh-logo-pick').on('click', function(e){ e.preventDefault();
		var f = wp.media({ title: 'انتخاب لوگو', library: { type: 'image' }, button: { text: 'استفاده' }, multiple: false });
		f.on('select', function(){ var a = f.state().get('selection').first().toJSON(); $('#dsh-logo-id').val(a.id); $('#dsh-logo-url').val(a.url); $('#dsh-logo-prev').attr('src', a.url).show(); });
		f.open(); });
	$('#dsh-logo-rm').on('click', function(e){ e.preventDefault(); $('#dsh-logo-id,#dsh-logo-url').val(''); $('#dsh-logo-prev').hide(); });
	$('.dsh-fpick').on('click', function(e){ e.preventDefault(); var t = $($(this).data('target'));
		var f = wp.media({ title: 'انتخاب فایل', button: { text: 'استفاده' }, multiple: false });
		f.on('select', function(){ t.val(f.state().get('selection').first().toJSON().url); }); f.open(); });
	$('.dsh-preset').on('click', function(e){ e.preventDefault(); var p = $(this).data('p');
		['color','color_dark','accent'].forEach(function(k, i){ $('input[name=\"" . self::OPT . "['+k+']\"]').wpColorPicker('color', p[i]); }); });
	var gf = " . wp_json_encode( self::fonts() ) . ";
	function demo(){ var k = $('#dsh-font-sel').val(), f = gf[k]; $('.dsh-font-custom').toggle(k === 'custom');
		if (f && f[1]) { if (!$('#dsh-gf-' + k).length) $('head').append($('<link>', { id: 'dsh-gf-' + k, rel: 'stylesheet', href: 'https://fonts.googleapis.com/css2?family=' + f[1] + '&display=swap' }));
			$('#dsh-font-demo').css('font-family', JSON.stringify(f[0]) + ', sans-serif'); } else { $('#dsh-font-demo').css('font-family', 'inherit'); } }
	$('#dsh-font-sel').on('change', demo); demo();
	function cm(){ $('.dsh-center-link').toggle($('input[name=\"" . self::OPT . "[center_mode]\"]:checked').val() === 'link'); }
	$('input[name=\"" . self::OPT . "[center_mode]\"]').on('change', cm); cm();
});"
		);
	}

	public function settings_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$o = self::get();
		$n = self::OPT;

		$text  = function ( $key, $label, $help = '', $ltr = false, $cls = '' ) use ( $o, $n ) {
			printf(
				'<tr class="%s"><th>%s</th><td><input type="text" class="regular-text" %s name="%s[%s]" value="%s">%s</td></tr>',
				esc_attr( $cls ),
				esc_html( $label ),
				$ltr ? 'dir="ltr"' : '',
				esc_attr( $n ),
				esc_attr( $key ),
				esc_attr( $o[ $key ] ),
				$help ? '<p class="description">' . $help . '</p>' : ''
			);
		};
		$check = function ( $key, $label ) use ( $o, $n ) {
			printf( '<label style="display:block;margin:3px 0"><input type="checkbox" name="%s[%s]" value="1" %s> %s</label>', esc_attr( $n ), esc_attr( $key ), checked( $o[ $key ], 1, false ), esc_html( $label ) );
		};
		$radio = function ( $key, $val, $label, $help = '' ) use ( $o, $n ) {
			printf( '<label style="display:block;margin:6px 0"><input type="radio" name="%s[%s]" value="%s" %s> <b>%s</b>%s</label>', esc_attr( $n ), esc_attr( $key ), esc_attr( $val ), checked( $o[ $key ], $val, false ), esc_html( $label ), $help ? ' <span class="description">— ' . esc_html( $help ) . '</span>' : '' );
		};
		$all = self::services( true );
		?>
		<div class="wrap dsh-adm" dir="rtl">
			<h1>هدر و نوار اپ <span style="font-size:12px;background:#0c4a3a;color:#d9ae4a;border-radius:20px;padding:2px 10px;vertical-align:middle">ادغام‌شده در سیستم یکپارچه</span></h1>
			<p class="description" style="max-width:780px">هدر سبز/طلایی، نوار پایین، صفحه «المزيد»، منوی خدمات و جستجوی زنده — همه به داده‌های سیستم یکپارچه وصل‌اند: شهر انتخابی، چت پشتیبانی آنلاین، علاقه‌مندی‌ها، سبد سوپرمارکت و صفحه سفارش‌ها.</p>
			<style>.dsh-adm h2{border-bottom:1px solid #dcdcde;padding-bottom:8px;margin-top:30px}.dsh-adm .form-table th{width:210px}.dsh-svc-tbl td,.dsh-svc-tbl th{padding:8px 10px!important;vertical-align:middle}.dsh-svc-tbl code{font-size:11px}.dsh-preset{margin-left:6px!important}</style>
			<form method="post" action="options.php">
				<?php settings_fields( 'dalil_app_shell_group' ); ?>

				<h2>حالت نمایش</h2>
				<table class="form-table" role="presentation">
					<tr><th>وضعیت</th><td><?php $check( 'enabled', 'هدر و نوار اپ فعال باشد' ); ?></td></tr>
					<tr><th>زوم صفحه</th><td><?php $check( 'no_zoom', 'جلوگیری از زوم (دو انگشت یا دوبار ضربه) در همه صفحات سایت — مثل اپلیکیشن' ); ?></td></tr>
					<tr><th>اعداد</th><td><?php $check( 'latin_digits', 'همه‌ی اعداد سایت با ارقام انگلیسی نمایش داده شوند (0123456789) — حتی اگر فونت سایت ارقام فارسی داشته باشد' ); ?></td></tr>
					<tr><th>حالت</th><td>
						<?php
						$radio( 'mode', 'app', 'اپ در همه دستگاه‌ها', 'پیشنهادی؛ هدر قدیمی سفید و هدر قالب مخفی می‌شوند' );
						$radio( 'mode', 'hybrid', 'ترکیبی', 'موبایل و تبلت = اپ، دسکتاپ = هدر کلاسیک سفید/طلایی' );
						$radio( 'mode', 'classic', 'کلاسیک', 'فقط هدر و فوتر قدیمی سیستم یکپارچه' );
						?>
					</td></tr>
					<tr><th>عرض موبایل (حالت ترکیبی)</th><td><input type="number" class="small-text" name="<?php echo esc_attr( $n ); ?>[breakpoint]" value="<?php echo esc_attr( $o['breakpoint'] ); ?>"> px</td></tr>
					<tr><th>هدر قالب</th><td><?php $check( 'hide_header', 'هدر قالب / المنتور را مخفی کن' ); ?><input type="text" class="large-text" dir="ltr" name="<?php echo esc_attr( $n ); ?>[header_selectors]" value="<?php echo esc_attr( $o['header_selectors'] ); ?>"></td></tr>
					<tr><th>فوتر قالب</th><td><?php $check( 'hide_footer', 'فوتر قالب را مخفی کن' ); ?><input type="text" class="large-text" dir="ltr" name="<?php echo esc_attr( $n ); ?>[footer_selectors]" value="<?php echo esc_attr( $o['footer_selectors'] ); ?>"></td></tr>
				</table>
				<p class="description">صفحاتی که در «تنظیمات ظاهر سایت» برای مخفی‌کردن هدر/فوتر انتخاب شده‌اند، روی هدر و نوار اپ هم اعمال می‌شوند.</p>

				<h2>هدر</h2>
				<table class="form-table" role="presentation">
					<tr><th>لوگو</th><td>
						<input type="hidden" id="dsh-logo-id" name="<?php echo esc_attr( $n ); ?>[logo_id]" value="<?php echo esc_attr( $o['logo_id'] ); ?>">
						<input type="hidden" id="dsh-logo-url" name="<?php echo esc_attr( $n ); ?>[logo_url]" value="<?php echo esc_attr( $o['logo_url'] ); ?>">
						<img id="dsh-logo-prev" src="<?php echo esc_url( $o['logo_url'] ); ?>" style="width:70px;height:70px;object-fit:contain;background:#0c4a3a;border-radius:14px;padding:6px;<?php echo $o['logo_url'] ? '' : 'display:none'; ?>"><br>
						<button class="button button-primary" id="dsh-logo-pick">انتخاب لوگو</button> <button class="button" id="dsh-logo-rm">حذف</button>
						<p class="description">PNG طلایی با پس‌زمینه شفاف. خالی = لوگوی «تنظیمات ظاهر سایت».</p>
					</td></tr>
					<?php
					$text( 'name_ar', 'نام کنار لوگو', 'با خط کوفی مدرن (Reem Kufi) نمایش داده می‌شود.' );
					$text( 'search_ph', 'متن جستجو' );
					?>
					<tr><th>جستجوی زنده</th><td><?php $check( 'live_search', 'جستجوی فوری در آگهی‌ها، تورها، مراکز تفریحی، مقالات و محصولات سوپرمارکت' ); ?></td></tr>
					<?php
					$text( 'fav_url', 'لینک المفضلة (اختیاری)', 'خالی = صفحه علاقه‌مندی‌های پروفایل کاربر.', true );
					$text( 'support_url', 'لینک الدعم (اختیاری)', 'خالی = باز شدن چت پشتیبانی آنلاین (پیشنهادی).', true );
					?>
					<tr><th>شهرها</th><td><p class="description">شهرها از «تنظیمات ظاهر سایت» خوانده می‌شوند و با انتخاب شهر در هدر، همه بخش‌ها (آگهی‌ها، تورها، تفریحی…) فیلتر می‌شوند.</p></td></tr>
				</table>

				<h2>نوار پایین</h2>
				<table class="form-table" role="presentation">
					<?php
					$text( 'cart_url', 'لینک السلة (اختیاری)', 'خالی = صفحه سبد سوپرمارکت. شمارنده سبد خودکار است.', true );
					$text( 'orders_url', 'لینک طلباتي (اختیاری)', 'خالی = صفحه «طلباتي وحجوزاتي».', true );
					?>
					<tr><th>دکمه وسط</th><td>
						<?php
						$radio( 'center_mode', 'explore', 'اکسپلور (نفحات)', 'اکسپلور اینستاگرامی نفحات؛ با لمس هر پست، ریلز تمام‌صفحه با لایک و نظر باز می‌شود' );
						$radio( 'center_mode', 'services', 'منوی خدمات', 'یک برگه با همه بخش‌های سایت باز می‌شود' );
						$radio( 'center_mode', 'link', 'لینک', 'به یک صفحه دلخواه می‌رود' );
						?>
					</td></tr>
					<?php
					$text( 'center_label', 'متن دکمه وسط' );
					$text( 'center_url', 'لینک دکمه وسط (حالت لینک)', '', true, 'dsh-center-link' );
					?>
					<tr><th>محتوای نفحات</th><td><p class="description" style="max-width:640px">دکمه وسط «نفحات» اکسپلور اینستاگرامی را باز می‌کند (شبکه عکس و ویدیو، پخش ریلز، لایک، نظر و اشتراک‌گذاری).
						محتوا از منوی <a href="<?php echo esc_url( admin_url( 'edit.php?post_type=ige_photo' ) ); ?>"><b>نفحات</b></a> در پیشخوان اضافه می‌شود. همین اکسپلور را با ویجت المنتور «نفحات (اکسپلور اینستاگرامی)» یا شورت‌کد <code>[dlz_nafahat]</code> در هر صفحه‌ای هم می‌توانید بگذارید.</p></td></tr>
				</table>

				<h2>منوی خدمات</h2>
				<p class="description">صفحه هر بخش به‌صورت خودکار پیدا می‌شود (شورت‌کد یا ویجت المنتور). در صورت نیاز لینک را دستی وارد کنید.</p>
				<table class="widefat striped dsh-svc-tbl" style="max-width:900px">
					<thead><tr><th>بخش</th><th>صفحه پیدا شده</th><th>لینک دستی</th><th>مخفی</th></tr></thead>
					<tbody>
					<?php foreach ( $all as $sv ) : $row = isset( $o['services'][ $sv['key'] ] ) ? $o['services'][ $sv['key'] ] : array(); ?>
						<tr>
							<td><b><?php echo esc_html( $sv['label'] ); ?></b></td>
							<td><?php echo $sv['auto'] ? '<a href="' . esc_url( $sv['auto'] ) . '" target="_blank"><code>' . esc_html( rawurldecode( '/' . ltrim( str_replace( home_url(), '', $sv['auto'] ), '/' ) ) ) . '</code></a>' : '<span style="color:#b32d2e">پیدا نشد</span>'; ?></td>
							<td><input type="url" dir="ltr" style="width:100%" name="<?php echo esc_attr( $n ); ?>[services][<?php echo esc_attr( $sv['key'] ); ?>][url]" value="<?php echo esc_attr( isset( $row['url'] ) ? $row['url'] : '' ); ?>" placeholder="خودکار"></td>
							<td><input type="checkbox" name="<?php echo esc_attr( $n ); ?>[services][<?php echo esc_attr( $sv['key'] ); ?>][off]" value="1" <?php checked( ! empty( $row['off'] ) ); ?>></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
				<table class="form-table" role="presentation">
					<tr><th>خدمات اضافه</th><td><textarea class="large-text" rows="3" dir="rtl" name="<?php echo esc_attr( $n ); ?>[services_extra]"><?php echo esc_textarea( $o['services_extra'] ); ?></textarea>
						<p class="description">هر خط: <code>آیکون|متن|لینک</code> — مثلاً <code>gift|العروض|/offers</code></p></td></tr>
				</table>

				<h2>صفحه المزيد</h2>
				<table class="form-table" role="presentation">
					<?php
					$text( 'more_title', 'عنوان' );
					$text( 'help_url', 'لینک «المساعدة»', 'واتساپ پشتیبانی؛ مثلاً <code>https://wa.me/9647822719796</code>. خالی = چت آنلاین.', true );
					$text( 'invite_text', 'متن دعوت «دعوة الأصدقاء»', 'با زدن «دعوة الأصدقاء» پنجره‌ی اشتراک باز می‌شود (واتساپ، تلگرام، پیامک، فیسبوک، ایمیل، کپی و بقیه‌ی برنامه‌های گوشی) و همین متن با لینک سایت زیر آن ارسال می‌شود.' );
					?>
					<tr><th>تابعنا على</th><td><a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=dlz-socials' ) ); ?>">مدیریت شبکه‌های اجتماعی و شماره‌ها</a></td></tr>

					<?php
					$text( 'app_url', 'لینک دانلود اپلیکیشن (APK)', 'اگر پر شود، کارت طلایی «تحميل التطبيق» بالای منو نمایش داده می‌شود.', true );
					$text( 'app_title', 'عنوان کارت اپلیکیشن' );
					$text( 'app_sub', 'زیرعنوان کارت اپلیکیشن' );
					?>
				</table>

				<h2>رنگ و فونت</h2>
				<table class="form-table" role="presentation">
					<tr><th>پس‌زمینه هدر و نوار پایین</th><td>
						<?php
						$radio( 'surface', 'dark', 'سبز و طلایی (طرح اصلی اپ)', 'هدر و نوار پایین با رنگ اصلی، هاله‌ی طلایی چرخان دور «نفحات»' );
						$radio( 'surface', 'light', 'سفید', 'هدر، نوار پایین و صفحه المزيد سفید با جزئیات طلایی' );
						?>
					</td></tr>
					<tr><th>پالت آماده</th><td>
						<button class="button dsh-preset" data-p='["#0a4425","#032514","#d9ae4a"]'>سبز اپ (طرح اصلی)</button>
						<button class="button dsh-preset" data-p='["#0c4a3a","#07332a","#d9ae4a"]'>سبز زمردی</button>
						<button class="button dsh-preset" data-p='["#123b5e","#0a2238","#d7ad35"]'>سرمه‌ای سلطنتی (هماهنگ با سایت)</button>
						<button class="button dsh-preset" data-p='["#5a1f2b","#3b1119","#d9ae4a"]'>عنابی</button>
					</td></tr>
					<tr><th>رنگ اصلی</th><td><input type="text" class="dsh-color" name="<?php echo esc_attr( $n ); ?>[color]" value="<?php echo esc_attr( $o['color'] ); ?>"></td></tr>
					<tr><th>رنگ اصلی تیره</th><td><input type="text" class="dsh-color" name="<?php echo esc_attr( $n ); ?>[color_dark]" value="<?php echo esc_attr( $o['color_dark'] ); ?>"></td></tr>
					<tr><th>طلایی</th><td><input type="text" class="dsh-color" name="<?php echo esc_attr( $n ); ?>[accent]" value="<?php echo esc_attr( $o['accent'] ); ?>"></td></tr>
					<tr><th>فونت</th><td>
						<select name="<?php echo esc_attr( $n ); ?>[font]" id="dsh-font-sel">
							<?php foreach ( self::fonts() as $k => $f ) : ?>
								<option value="<?php echo esc_attr( $k ); ?>" <?php selected( $o['font'], $k ); ?>><?php echo esc_html( $f[0] ); ?></option>
							<?php endforeach; ?>
						</select>
						<p id="dsh-font-demo" style="margin-top:10px;padding:14px 18px;background:#0c4a3a;color:#d9ae4a;border-radius:12px;font-size:22px;font-weight:700;max-width:420px">المزيد — الدعم والتواصل<br><span style="color:#fff;font-size:16px;font-weight:500">ابحث عن فندق، مطعم، خدمة...</span></p>
					</td></tr>
					<tr class="dsh-font-custom"><th>فایل فونت معمولی</th><td>
						<input type="url" class="large-text" dir="ltr" id="dsh-freg" name="<?php echo esc_attr( $n ); ?>[font_reg_url]" value="<?php echo esc_attr( $o['font_reg_url'] ); ?>">
						<button class="button dsh-fpick" data-target="#dsh-freg">آپلود</button></td></tr>
					<tr class="dsh-font-custom"><th>فایل فونت بولد</th><td>
						<input type="url" class="large-text" dir="ltr" id="dsh-fbold" name="<?php echo esc_attr( $n ); ?>[font_bold_url]" value="<?php echo esc_attr( $o['font_bold_url'] ); ?>">
						<button class="button dsh-fpick" data-target="#dsh-fbold">آپلود</button></td></tr>
					<tr><th>محدوده فونت</th><td><?php $check( 'font_site', 'این فونت روی کل سایت اعمال شود' ); ?></td></tr>
				</table>

				<?php submit_button( 'ذخیره تنظیمات' ); ?>
			</form>
		</div>
		<?php
	}
}
