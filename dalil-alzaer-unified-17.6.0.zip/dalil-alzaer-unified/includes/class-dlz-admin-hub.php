<?php
/**
 * Dalil Al Zaer — every section of the plugin on the WordPress Dashboard.
 *
 * The plugin's menus (supermarket, taxi, tickets, tours, chat, Nafahat, settings …) are taken out of the
 * admin sidebar and shown as icon tiles in one Dashboard widget «دلیل الزائر — همه بخش‌ها»
 * (it can be switched off in «تنظیمات صفحه»). Nothing is lost: the tiles are built from the real
 * menu of the current user (same capabilities, every sub page as a chip) and every address appears once.
 * The pages themselves are untouched, so every link, bookmark and permission keeps working.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DLZ_Admin_Hub {

	const OPT = 'dlz_admin_hub';

	/** @var array captured sections [ ['slug','label','icon','url','count','subs'=>[[label,url,count]]] ] */
	private static $sections = array();

	/** @var array normalised URLs of every moved page (for the «back to the Dashboard» bar) */
	private static $urls = array();

	/** @var array post types of moved menus */
	private static $types = array();

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'collect' ), PHP_INT_MAX );
		add_action( 'wp_dashboard_setup', array( __CLASS__, 'widget' ) );
		add_action( 'admin_post_dlz_hub_mode', array( __CLASS__, 'save_mode' ) );
		add_action( 'in_admin_header', array( __CLASS__, 'back_bar' ) );
		add_action( 'admin_head', array( __CLASS__, 'styles' ) );
		// the hub can never stay folded: on a phone the fold arrow is hidden and a tap on the title folded it for good
		add_filter( 'get_user_option_closedpostboxes_dashboard', array( __CLASS__, 'never_closed' ) );
		add_filter( 'get_user_option_metaboxhidden_dashboard', array( __CLASS__, 'never_closed' ) );
	}

	public static function never_closed( $v ) {
		return is_array( $v ) ? array_values( array_diff( $v, array( 'dlz_hub' ) ) ) : $v;
	}

	/** «all»: WordPress' own menus and other plugins move to the Dashboard too (only «پیشخوان» stays). */
	public static function mode() {
		$o = get_option( self::OPT, array() );
		return ( is_array( $o ) && ! empty( $o['all'] ) ) ? 'all' : 'dalil';
	}

	/* ---------------------------------------------------------
	 * Which menus are ours
	 * ------------------------------------------------------- */

	private static function is_ours( $slug ) {
		if ( preg_match( '#^(?:edit\.php|post-new\.php)\?post_type=(dalil|dlz|dbd|ige|dase|mcr|lcr)_#', $slug ) ) {
			return true;
		}
		return (bool) preg_match( '#^(dlz|dalil|dase|dbd|ige|mcr|lcr)[-_]#', $slug );
	}

	/** Preferred order and group of the known sections. */
	private static function groups() {
		return array(
			'talk'    => array( 'ارتباط با زائران', array( 'dlz-inbox', 'dlz-support-chat', 'options-general.php?page=mp-sms-login' ) ),
			'safe'    => array( 'امنیت', array( 'dlz-security' ) ),
			'service' => array( 'خدمات، سفارش‌ها و رزروها', array( 'dlz-sm', 'dlz-taxi-panel', 'edit.php?post_type=dalil_ticket_trip', 'edit.php?post_type=dlz_daily_tour', 'dlz-entertainment', 'mcr-submissions', 'lcr-submissions', 'dalil-currency-rates' ) ),
			'content' => array( 'محتوا و آگهی‌ها', array( 'edit.php?post_type=dbd_business', 'edit.php?post_type=dbd_business&dbd_kind=venue', 'edit.php?post_type=dbd_business&dbd_kind=salon', 'edit.php?post_type=dbd_room', 'edit.php?post_type=ige_photo', 'dalil-articles', 'edit.php?post_type=dalil_article' ) ),
			'look'    => array( 'ظاهر اپ و تنظیمات', array( 'dlz-app-shell', 'dase-settings', 'dlz-money', 'dlz-socials', 'dlz-countries' ) ),
			'wp'      => array( 'وردپرس و افزونه‌های دیگر', array() ),
		);
	}

	/** Nicer names / icons for known sections. */
	private static function look( $slug ) {
		$m = array(
			'dlz-inbox'                              => array( 'درخواست‌های جدید', 'dashicons-bell', '#D63638' ),
			'dlz-security'                           => array( 'امنیت سایت', 'dashicons-shield', '#0F4D2E' ),
			'dlz-support-chat'                       => array( 'پشتیبانی آنلاین (چت)', 'dashicons-format-chat', '#0F8A5F' ),
			'options-general.php?page=mp-sms-login'  => array( 'ورود پیامکی و کاربران', 'dashicons-smartphone', '#2563EB' ),
			'dlz-sm'                                 => array( 'سوپرمارکت', 'dashicons-cart', '#16A34A' ),
			'dlz-taxi-panel'                         => array( 'تاکسی VIP', 'dashicons-car', '#D97706' ),
			'edit.php?post_type=dalil_ticket_trip'   => array( 'بلیط سفر', 'dashicons-tickets-alt', '#0284C7' ),
			'edit.php?post_type=dlz_daily_tour'      => array( 'تورهای روزانه', 'dashicons-location-alt', '#0D9488' ),
			'dlz-entertainment'                      => array( 'مراکز تفریحی', 'dashicons-palmtree', '#DB2777' ),
			'mcr-submissions'                        => array( 'مشاوره پزشکی', 'dashicons-heart', '#DC2626' ),
			'lcr-submissions'                        => array( 'مشاوره حقوقی', 'dashicons-businessperson', '#4F46E5' ),
			'dalil-currency-rates'                   => array( 'نرخ ارز و تبدیل', 'dashicons-money-alt', '#65A30D' ),
			'edit.php?post_type=dbd_business'        => array( 'آگهی‌ها و کسب‌وکارها', 'dashicons-store', '#B45309' ),
			'edit.php?post_type=dbd_business&dbd_kind=venue' => array( 'تالارها و باغ‌تالارها', 'dashicons-heart', '#BE185D' ),
			'edit.php?post_type=dbd_business&dbd_kind=salon' => array( 'سالن‌های زیبایی', 'dashicons-art', '#C026D3' ),
			'edit.php?post_type=dbd_room'            => array( 'Room ها (گروه آگهی‌ها)', 'dashicons-screenoptions', '#7C3AED' ),
			'edit.php?post_type=ige_photo'           => array( 'نفحات (اکسپلور)', 'dashicons-format-gallery', '#C026D3' ),
			'dalil-articles'                         => array( 'مقالات', 'dashicons-media-document', '#0369A1' ),
			'edit.php?post_type=dalil_article'       => array( 'مقالات', 'dashicons-media-document', '#0369A1' ),
			'dlz-app-shell'                          => array( 'هدر و نوار اپ', 'dashicons-smartphone', '#0F4D2E' ),
			'dase-settings'                          => array( 'تنظیمات ظاهر سایت', 'dashicons-admin-appearance', '#9A6B12' ),
			'dlz-socials'                            => array( 'شبکه‌های اجتماعی (تابعنا)', 'dashicons-share', '#0891B2' ),
			'dlz-countries'                          => array( 'کشورها و پرچم‌ها', 'dashicons-flag', '#B91C1C' ),
			'dlz-money'                              => array( 'ارز قیمت‌ها (تبدیل خودکار)', 'dashicons-money-alt', '#15803D' ),
		);
		return isset( $m[ $slug ] ) ? $m[ $slug ] : null;
	}

	/* ---------------------------------------------------------
	 * Menu → sections
	 * ------------------------------------------------------- */

	private static function is_core_file( $file ) {
		$f = strtok( (string) $file, '?' );
		return $f && 'admin.php' !== $f && preg_match( '/\.php$/', $f ) && file_exists( ABSPATH . 'wp-admin/' . $f );
	}

	private static function top_url( $slug ) {
		if ( get_plugin_page_hook( $slug, 'admin.php' ) || false === strpos( $slug, '.php' ) ) {
			return 'admin.php?page=' . $slug;
		}
		return $slug;
	}

	/** Same rules WordPress uses to print a sub menu link. */
	private static function sub_url( $parent, $slug ) {
		if ( get_plugin_page_hook( $slug, $parent ) ) {
			return self::is_core_file( $parent ) ? add_query_arg( 'page', $slug, $parent ) : 'admin.php?page=' . $slug;
		}
		if ( false === strpos( $slug, '.php' ) ) {
			return 'admin.php?page=' . $slug;
		}
		return $slug;
	}

	public static function norm( $u ) {
		$u    = preg_replace( '#^.*?/wp-admin/#', '', html_entity_decode( (string) $u ) );
		$u    = preg_replace( '/#.*$/', '', $u );
		$bits = explode( '?', $u, 2 );
		$args = array();
		if ( isset( $bits[1] ) ) {
			parse_str( $bits[1], $args );
			unset( $args['_wpnonce'], $args['settings-updated'], $args['message'], $args['paged'] );
		}
		ksort( $args );
		return ( '' === $bits[0] ? 'index.php' : $bits[0] ) . ( $args ? '?' . http_build_query( $args ) : '' );
	}

	/** Is admin.php?page=$slug a real page (some old links pointed to pages that no longer exist)? */
	private static function page_exists( $slug ) {
		if ( empty( $GLOBALS['_registered_pages'] ) ) {
			return true;
		}
		$end = '_page_' . $slug;
		foreach ( array_keys( $GLOBALS['_registered_pages'] ) as $h ) {
			if ( substr( $h, -strlen( $end ) ) === $end ) {
				return true;
			}
		}
		return false;
	}

	private static function clean( $title, &$count = null ) {
		$count = 0;
		if ( preg_match( '#class=["\'][^"\']*(?:awaiting-mod|update-plugins|count|pending)[^"\']*["\'][^>]*>.*?(\d+)#s', (string) $title, $m ) ) {
			$count = (int) $m[1];
		}
		$t = preg_replace( '#<span[^>]*class=["\'][^"\']*(?:awaiting-mod|update-plugins|count|pending|screen-reader)[^"\']*["\'][^>]*>.*?</span>(?:\s*</span>)?#s', '', (string) $title );
		return trim( preg_replace( '/\s+/u', ' ', wp_strip_all_tags( $t ) ) );
	}

	/** Runs last on «admin_menu»: copy the menus to the Dashboard, then take them out of the sidebar. */
	public static function collect() {
		global $menu, $submenu;
		if ( empty( $menu ) || ! is_array( $menu ) ) {
			return;
		}
		// the «دسترسی ادمین‌ها» page lists the sidebar menus: leave them there while it is open
		$keep_all = isset( $_GET['page'] ) && 'aam-settings' === $_GET['page']; // phpcs:ignore
		$all      = 'all' === self::mode();
		$seen     = array( self::norm( 'admin.php?page=dlz-unified' ) => 1 ); // the old hub page is this Dashboard now
		$found    = array();
		$move     = array();

		$ordered = $menu;
		ksort( $ordered, SORT_NUMERIC ); // the order the sidebar shows them
		foreach ( $ordered as $pos => $item ) {
			if ( empty( $item[2] ) || ( isset( $item[4] ) && false !== strpos( (string) $item[4], 'wp-menu-separator' ) ) ) {
				continue;
			}
			$slug = $item[2];
			if ( 'index.php' === $slug ) {
				continue; // «پیشخوان» always stays
			}
			$ours = self::is_ours( $slug );
			if ( ! $ours && ! $all ) {
				continue;
			}
			$move[ $pos ] = $slug;
			if ( ! current_user_can( $item[1] ) ) {
				continue;
			}
			$found[] = array( $slug, $item, $ours );
		}
		// settings page of the SMS login lives under «تنظیمات»: show it on the Dashboard too
		$sms = false;
		if ( isset( $submenu['options-general.php'] ) ) {
			foreach ( $submenu['options-general.php'] as $s ) {
				if ( 'mp-sms-login' === $s[2] && current_user_can( $s[1] ) ) {
					$sms = $s;
				}
			}
		}

		$secs = array();
		$add  = function ( $key, $label, $icon, $url, $count, $subs, $color = '', $group = '', $main_label = '' ) use ( &$secs, &$seen ) {
			$n = self::norm( $url );
			// two menus with the same name (e.g. the articles dashboard and the articles list) become one tile
			foreach ( $secs as &$same ) {
				if ( $same['label'] !== $label ) {
					continue;
				}
				foreach ( array_merge( array( array( $main_label ? $main_label : 'صفحه اصلی', $url, 0 ) ), $subs ) as $s ) {
					$sn = self::norm( $s[1] );
					if ( ! isset( $seen[ $sn ] ) ) {
						$seen[ $sn ]     = 1;
						$same['subs'][] = $s;
					}
				}
				return;
			}
			unset( $same );
			if ( isset( $seen[ $n ] ) ) {
				// main page already shown: keep its unseen sub pages as chips of the section that owns it
				$subs = array_values( array_filter( $subs, function ( $s ) use ( &$seen ) { return ! isset( $seen[ self::norm( $s[1] ) ] ); } ) );
				if ( ! $subs ) {
					return;
				}
				foreach ( $secs as &$sec ) {
					if ( self::norm( $sec['url'] ) === $n ) {
						foreach ( $subs as $s ) {
							$seen[ self::norm( $s[1] ) ] = 1;
							$sec['subs'][]               = $s;
						}
						return;
					}
				}
				unset( $sec );
				$url = $subs[0][1];
				$n   = self::norm( $url );
				array_shift( $subs );
			}
			$seen[ $n ] = 1;
			$keep       = array();
			foreach ( $subs as $s ) {
				$sn = self::norm( $s[1] );
				if ( isset( $seen[ $sn ] ) ) {
					continue;
				}
				$seen[ $sn ] = 1;
				$keep[]      = $s;
			}
			$secs[ $key ] = array(
				'key'   => $key,
				'label' => $label,
				'icon'  => $icon,
				'color' => $color,
				'url'   => $url,
				'count' => $count,
				'subs'  => $keep,
				'group' => $group,
			);
		};

		foreach ( $found as $f ) {
			list( $slug, $item, $ours ) = $f;
			if ( 'dlz-unified' === $slug ) {
				continue;
			}
			$subs  = array();
			$main  = '';
			$mlabe = '';
			if ( ! empty( $submenu[ $slug ] ) ) {
				foreach ( $submenu[ $slug ] as $s ) {
					if ( ! current_user_can( $s[1] ) ) {
						continue;
					}
					$u = self::sub_url( $slug, $s[2] );
					if ( '' === $main ) {
						$main  = $u;
						$mlabe = self::clean( $s[0] );
						continue;
					}
					$c      = 0;
					$label  = self::clean( $s[0], $c );
					$subs[] = array( $label, $u, $c );
				}
			}
			if ( '' === $main ) {
				$main = self::top_url( $slug );
			}
			$cnt   = 0;
			$label = self::clean( $item[0], $cnt );
			$icon  = isset( $item[6] ) ? (string) $item[6] : '';
			$lk    = self::look( $slug );
			if ( $lk ) {
				$label = $lk[0];
				$icon  = $lk[1];
			}
			if ( ! $cnt && preg_match( '#post_type=dbd_business&dbd_kind=([a-z]+)#', $slug, $km ) ) {
				$cnt = -1 * count( get_posts( array( 'post_type' => 'dbd_business', 'post_status' => 'publish', 'posts_per_page' => -1, 'fields' => 'ids', 'no_found_rows' => true, 'meta_key' => '_dbd_kind', 'meta_value' => $km[1] ) ) ); // phpcs:ignore
			} elseif ( ! $cnt && preg_match( '#post_type=([a-z0-9_]+)#', $slug, $pm ) && post_type_exists( $pm[1] ) ) {
				$c   = wp_count_posts( $pm[1] );
				$cnt = -1 * (int) ( isset( $c->publish ) ? $c->publish : 0 ); // negative = plain total, not an alert
			}
			$add( $slug, $label, $icon, $main, $cnt, $subs, $lk ? $lk[2] : '', $ours ? '' : 'wp', $mlabe );
		}

		// the plugin hub's own pages (chat, app header, settings …) become tiles of their own;
		// its links to other menus are already there, so they are skipped as duplicates
		foreach ( $found as $f ) {
			if ( 'dlz-unified' !== $f[0] || empty( $submenu['dlz-unified'] ) ) {
				continue;
			}
			foreach ( $submenu['dlz-unified'] as $s ) {
				if ( 'dlz-unified' === $s[2] || ! current_user_can( $s[1] ) ) {
					continue;
				}
				$url = self::sub_url( 'dlz-unified', $s[2] );
				if ( 0 === strpos( $url, 'admin.php?page=' ) && ! self::page_exists( substr( $url, 15 ) ) ) {
					continue; // dead link
				}
				$key = 0 === strpos( $url, 'admin.php?page=' ) ? substr( $url, 15 ) : $url;
				$lk  = self::look( $key );
				$lab = $lk ? $lk[0] : self::clean( $s[0] );
				$dup = false;
				foreach ( $secs as &$sec ) {
					if ( $sec['label'] === $lab && ! isset( $seen[ self::norm( $url ) ] ) ) {
						$sec['subs'][]            = array( 'فهرست کامل', $url, 0 ); // same section, another list page
						$seen[ self::norm( $url ) ] = 1;
						$dup                       = true;
					}
				}
				unset( $sec );
				if ( $dup ) {
					continue;
				}
				$sc = 0;
				self::clean( $s[0], $sc ); // e.g. «درخواست‌های جدید» carries its unseen number
				$add( $key, $lk ? $lk[0] : self::clean( $s[0] ), $lk ? $lk[1] : 'dashicons-admin-generic', $url, $sc, array(), $lk ? $lk[2] : '' );
			}
		}
		if ( $sms ) {
			$lk = self::look( 'options-general.php?page=mp-sms-login' );
			$add( 'options-general.php?page=mp-sms-login', $lk[0], $lk[1], 'options-general.php?page=mp-sms-login', 0, array(), $lk[2] );
		}

		// groups
		$order = array();
		foreach ( self::groups() as $gk => $g ) {
			foreach ( $g[1] as $i => $s ) {
				$order[ $s ] = array( $gk, $i );
			}
		}
		foreach ( $secs as $k => &$sec ) {
			if ( 'wp' === $sec['group'] ) {
				$sec['sort'] = 9000;
				continue;
			}
			if ( isset( $order[ $k ] ) ) {
				$sec['group'] = $order[ $k ][0];
				$sec['sort']  = $order[ $k ][1];
			} else {
				$sec['group'] = 'service';
				$sec['sort']  = 500;
			}
		}
		unset( $sec );
		self::$sections = $secs;

		foreach ( $secs as $sec ) {
			self::$urls[ self::norm( $sec['url'] ) ] = 1;
			foreach ( $sec['subs'] as $s ) {
				self::$urls[ self::norm( $s[1] ) ] = 1;
			}
		}
		foreach ( $move as $slug ) {
			if ( preg_match( '#post_type=([a-z0-9_]+)#', $slug, $pm ) ) {
				self::$types[] = $pm[1];
			}
		}

		if ( $keep_all ) {
			return;
		}
		foreach ( $move as $slug ) {
			remove_menu_page( $slug );
		}
	}

	/* ---------------------------------------------------------
	 * Dashboard widget
	 * ------------------------------------------------------- */

	public static function widget() {
		if ( ! self::$sections ) {
			return;
		}
		wp_add_dashboard_widget( 'dlz_hub', 'دلیل الزائر — همه بخش‌ها', array( __CLASS__, 'render' ) );
		// first in the first column; the script below lifts it above the columns at full width
		global $wp_meta_boxes;
		if ( isset( $wp_meta_boxes['dashboard']['normal']['core']['dlz_hub'] ) ) {
			$w = $wp_meta_boxes['dashboard']['normal']['core']['dlz_hub'];
			unset( $wp_meta_boxes['dashboard']['normal']['core']['dlz_hub'] );
			$wp_meta_boxes['dashboard']['normal']['high'] = array( 'dlz_hub' => $w ) + ( isset( $wp_meta_boxes['dashboard']['normal']['high'] ) ? $wp_meta_boxes['dashboard']['normal']['high'] : array() );
		}
	}

	private static function icon_html( $icon ) {
		if ( 0 === strpos( $icon, 'dashicons-' ) ) {
			return '<span class="dashicons ' . esc_attr( $icon ) . '"></span>';
		}
		if ( 0 === strpos( $icon, 'data:image' ) || preg_match( '#^https?://#', $icon ) ) {
			return '<img src="' . esc_attr( $icon ) . '" alt="">';
		}
		return '<span class="dashicons dashicons-admin-generic"></span>';
	}

	public static function render() {
		$secs   = self::$sections;
		$groups = self::groups();
		$by     = array();
		foreach ( $secs as $s ) {
			$by[ $s['group'] ][] = $s;
		}
		echo '<div class="dlz-hub" dir="rtl">';
		foreach ( $groups as $gk => $g ) {
			if ( empty( $by[ $gk ] ) ) {
				continue;
			}
			$list = $by[ $gk ];
			usort( $list, function ( $a, $b ) { return $a['sort'] - $b['sort']; } );
			echo '<h3 class="dlz-hub-h"><span>' . esc_html( $g[0] ) . '</span></h3><div class="dlz-hub-grid">';
			foreach ( $list as $s ) {
				$color = $s['color'] ? $s['color'] : '#0F4D2E';
				echo '<div class="dlz-hub-card" style="--c:' . esc_attr( $color ) . '">';
				echo '<a class="dlz-hub-main" href="' . esc_url( admin_url( $s['url'] ) ) . '"><span class="dlz-hub-ic">' . self::icon_html( $s['icon'] ) . '</span><b>' . esc_html( $s['label'] ) . '</b>'; // phpcs:ignore
				if ( $s['count'] > 0 ) {
					echo '<em class="dlz-hub-alert">' . esc_html( number_format_i18n( $s['count'] ) ) . '</em>';
				} elseif ( $s['count'] < 0 ) {
					echo '<em class="dlz-hub-num" title="تعداد منتشر شده">' . esc_html( number_format_i18n( -$s['count'] ) ) . '</em>';
				}
				echo '</a>';
				if ( $s['subs'] ) {
					echo '<div class="dlz-hub-subs">';
					foreach ( $s['subs'] as $sub ) {
						echo '<a href="' . esc_url( admin_url( $sub[1] ) ) . '">' . esc_html( $sub[0] ) . ( ! empty( $sub[2] ) ? ' <i>' . (int) $sub[2] . '</i>' : '' ) . '</a>';
					}
					echo '</div>';
				}
				echo '</div>';
			}
			echo '</div>';
		}
		if ( current_user_can( 'manage_options' ) ) {
			$all = 'all' === self::mode();
			$url = wp_nonce_url( admin_url( 'admin-post.php?action=dlz_hub_mode&all=' . ( $all ? '0' : '1' ) ), 'dlz_hub_mode' );
			echo '<p class="dlz-hub-foot">' . ( $all
				? 'همه‌ی منوهای وردپرس و افزونه‌ها اینجا هستند. <a href="' . esc_url( $url ) . '">برگرداندن منوهای وردپرس و افزونه‌های دیگر به منوی کناری</a>'
				: 'منوهای دلیل الزائر از منوی کناری به اینجا منتقل شده‌اند. <a href="' . esc_url( $url ) . '">منوهای خود وردپرس و افزونه‌های دیگر هم به اینجا منتقل شوند</a>' ) . '</p>';
		}
		echo '</div>';
		?>
<script>
(function () {
	var box = document.getElementById('dlz_hub'), wrap = document.getElementById('dashboard-widgets-wrap');
	if (!box || !wrap) return;
	var top = document.createElement('div'), welcome = document.getElementById('welcome-panel');
	top.id = 'dlz-hub-top';
	top.className = 'metabox-holder';
	var at = welcome && welcome.parentNode === wrap.parentNode ? welcome : wrap; // first thing on the Dashboard
	wrap.parentNode.insertBefore(top, at);
	top.appendChild(box);
	var ord = box.querySelector('.handle-actions');
	if (ord) ord.remove();
	box.classList.remove('closed', 'hide-if-js'); box.style.display = '';
	/* a tap on the green title must not fold the hub (WordPress folds boxes on a title click) */
	box.addEventListener('click', function (e) { if (e.target.closest('.postbox-header')) { e.stopPropagation(); e.preventDefault(); } }, true);
	var hd = box.querySelector('.hndle'); if (hd) hd.classList.remove('hndle', 'ui-sortable-handle');
})();
</script>
		<?php
	}

	public static function save_mode() {
		if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'dlz_hub_mode' ) ) {
			wp_die( 'دسترسی ندارید.' );
		}
		update_option( self::OPT, array( 'all' => ! empty( $_GET['all'] ) ? 1 : 0 ) ); // phpcs:ignore
		wp_safe_redirect( admin_url( 'index.php' ) );
		exit;
	}

	/* ---------------------------------------------------------
	 * «بازگشت به پیشخوان» on every moved page
	 * ------------------------------------------------------- */

	private static function on_moved_page() {
		global $pagenow;
		if ( 'index.php' === $pagenow ) {
			return false;
		}
		$scr = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( $scr && $scr->post_type && in_array( $scr->post_type, self::$types, true ) ) {
			return true;
		}
		$req = self::norm( isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '' ); // phpcs:ignore
		if ( isset( self::$urls[ $req ] ) ) {
			return true;
		}
		if ( isset( $_GET['page'] ) ) { // phpcs:ignore
			$pg = sanitize_key( wp_unslash( $_GET['page'] ) ); // phpcs:ignore
			foreach ( array_keys( self::$urls ) as $u ) {
				if ( false !== strpos( $u, 'page=' . $pg ) ) {
					return true;
				}
			}
			return 'dlz-unified' === $pg;
		}
		return false;
	}

	public static function back_bar() {
		if ( ! self::$sections || ! self::on_moved_page() ) {
			return;
		}
		echo '<div class="dlz-hub-back" dir="rtl"><a href="' . esc_url( admin_url( 'index.php' ) ) . '"><span class="dashicons dashicons-arrow-right-alt"></span>پیشخوان — همه بخش‌های دلیل الزائر</a></div>';
	}

	public static function styles() {
		global $pagenow;
		?>
<style>
.dlz-hub-back{margin:10px 20px 0 0}
.dlz-hub-back a{display:inline-flex;align-items:center;gap:6px;padding:6px 14px 6px 16px;border-radius:999px;background:#fff;border:1px solid #E3C98A;color:#0F4D2E;font-weight:600;text-decoration:none;box-shadow:0 1px 3px rgba(0,0,0,.05)}
.dlz-hub-back a:hover{background:#FFFBEF;color:#0F4D2E}
.dlz-hub-back .dashicons{font-size:18px;width:18px;height:18px}
<?php if ( 'index.php' === $pagenow ) : ?>
#dlz-hub-top{padding-top:0;margin:0 0 6px}
#dlz-hub-top #dlz_hub{margin:0}#dlz_hub.closed .inside{display:block!important}#dlz_hub .postbox-header{cursor:default}#dlz_hub .handle-actions{display:none!important}
#dlz_hub .postbox-header{background:linear-gradient(90deg,#0F4D2E,#0A3A22);border-bottom:2px solid #D9AE4A}
#dlz_hub .postbox-header h2{color:#F6DB8E;font-size:15px}
#dlz_hub .postbox-header .handle-actions button{color:#F6DB8E}
#dlz_hub .inside{margin:0;padding:6px 16px 14px}
.dlz-hub-h{display:flex;align-items:center;gap:10px;margin:14px 0 10px!important;font-size:13px!important;color:#6B4E12!important}
.dlz-hub-h::after{content:"";flex:1;height:1px;background:linear-gradient(to left,transparent,#E3C98A)}
.dlz-hub-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(210px,1fr));gap:12px}
.dlz-hub-card{display:flex;flex-direction:column;background:#fff;border:1px solid #ECE3CC;border-radius:14px;overflow:hidden;transition:box-shadow .15s,transform .15s,border-color .15s}
.dlz-hub-card:hover{border-color:var(--c);box-shadow:0 8px 20px -10px rgba(0,0,0,.25);transform:translateY(-1px)}
.dlz-hub-main{display:flex;align-items:center;gap:11px;padding:12px;text-decoration:none;color:#1d2327}
.dlz-hub-main:hover,.dlz-hub-main:focus{color:#1d2327}
.dlz-hub-ic{flex:0 0 44px;width:44px;height:44px;border-radius:13px;display:flex;align-items:center;justify-content:center;color:#fff;
	background:linear-gradient(145deg,color-mix(in srgb,var(--c) 78%,#fff),var(--c));box-shadow:0 6px 14px -6px var(--c)}
.dlz-hub-ic .dashicons{font-size:23px;width:23px;height:23px}
.dlz-hub-ic img{width:22px;height:22px;filter:brightness(0) invert(1)}
.dlz-hub-main b{flex:1;font-size:14px;line-height:1.5}
.dlz-hub-num{font-style:normal;font-size:12px;font-weight:700;color:#50575e;background:#F3F1EA;border-radius:999px;padding:2px 9px}
.dlz-hub-alert{font-style:normal;font-size:12px;font-weight:700;color:#fff;background:#d63638;border-radius:999px;padding:2px 9px}
.dlz-hub-subs{display:flex;flex-wrap:wrap;gap:6px;padding:0 12px 12px}
.dlz-hub-subs a{font-size:12px;line-height:1.4;padding:4px 10px;border-radius:999px;text-decoration:none;color:#3c434a;background:#F6F7F7;border:1px solid #E7E8E9}
.dlz-hub-subs a:hover{color:var(--c);border-color:var(--c);background:#fff}
.dlz-hub-subs a i{font-style:normal;color:#fff;background:#d63638;border-radius:999px;padding:0 6px;margin-right:2px}
.dlz-hub-foot{margin:16px 0 0!important;color:#646970;font-size:12px}
<?php endif; ?>
</style>
		<?php
	}
}

DLZ_Admin_Hub::init();
