<?php
/**
 * Dalil Al Zaer — «تابعنا على» links (shown at the bottom of «المزيد»).
 * Admin: دلیل الزائر → «شبکه‌های اجتماعی (تابعنا)». Add / remove / reorder any number of links or numbers.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DLZ_Socials {

	const OPT = 'dlz_socials';

	public static function init() {
		add_action( 'admin_init', array( __CLASS__, 'register' ) );
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 20 );
	}

	/** type => array( label (fa), placeholder, help ) */
	public static function types() {
		return array(
			'whatsapp'  => array( 'واتساپ', '9647822719796', 'شماره با کد کشور (بدون + و صفر) یا لینک wa.me' ),
			'instagram' => array( 'اینستاگرام', 'dalilalzaer', 'نام کاربری یا لینک کامل' ),
			'facebook'  => array( 'فیسبوک', 'dalilalzaer', 'نام صفحه یا لینک کامل' ),
			'linkedin'  => array( 'لینکدین', '', 'لینک کامل — خالی = فقط آیکن' ),
			'telegram'  => array( 'تلگرام', 'dalilalzaer', 'نام کاربری یا لینک t.me' ),
			'youtube'   => array( 'یوتیوب', '@dalilalzaer', 'هندل (@…) یا لینک کامل' ),
			'tiktok'    => array( 'تیک‌تاک', '@dalilalzaer', 'هندل (@…) یا لینک کامل' ),
			'x'         => array( 'ایکس (توییتر)', 'dalilalzaer', 'نام کاربری یا لینک کامل' ),
			'snapchat'  => array( 'اسنپ‌چت', 'dalilalzaer', 'نام کاربری یا لینک کامل' ),
			'phone'     => array( 'تلفن', '+989152082983', 'شماره برای تماس مستقیم' ),
			'email'     => array( 'ایمیل', 'info@dalilalzaer.com', 'آدرس ایمیل' ),
			'website'   => array( 'وب‌سایت', 'https://', 'لینک کامل' ),
		);
	}

	public static function defaults() {
		$o  = class_exists( 'DLZ_App_Shell' ) ? DLZ_App_Shell::get() : array();
		$wa = ! empty( $o['social_whatsapp'] ) ? $o['social_whatsapp'] : '9647822719796';
		return array(
			array( 'type' => 'whatsapp', 'value' => $wa ),
			array( 'type' => 'linkedin', 'value' => ! empty( $o['social_linkedin'] ) ? $o['social_linkedin'] : '' ),
			array( 'type' => 'instagram', 'value' => ! empty( $o['social_instagram'] ) ? $o['social_instagram'] : '' ),
			array( 'type' => 'facebook', 'value' => ! empty( $o['social_facebook'] ) ? $o['social_facebook'] : '' ),
		);
	}

	public static function rows() {
		$rows = get_option( self::OPT, null );
		return is_array( $rows ) ? $rows : self::defaults();
	}

	/** Turns what the admin typed (number, @handle, username or URL) into a link. '' = icon only. */
	public static function url( $type, $v ) {
		$v = trim( (string) $v );
		if ( '' === $v ) {
			return '';
		}
		$is_url = (bool) preg_match( '#^(https?:)?//#i', $v );
		$h      = ltrim( $v, '@/' );
		switch ( $type ) {
			case 'whatsapp':
				if ( $is_url ) {
					return $v;
				}
				$d = preg_replace( '/\D/', '', $v );
				$d = preg_replace( '/^00/', '', $d );
				return $d ? 'https://wa.me/' . $d : '';
			case 'phone':
				return 'tel:' . preg_replace( '/[^\d+]/', '', $v );
			case 'email':
				return is_email( $v ) ? 'mailto:' . $v : '';
			case 'instagram':
				return $is_url ? $v : 'https://instagram.com/' . rawurlencode( $h );
			case 'facebook':
				return $is_url ? $v : 'https://facebook.com/' . rawurlencode( $h );
			case 'telegram':
				return $is_url ? $v : 'https://t.me/' . rawurlencode( $h );
			case 'youtube':
				return $is_url ? $v : 'https://youtube.com/@' . rawurlencode( $h );
			case 'tiktok':
				return $is_url ? $v : 'https://tiktok.com/@' . rawurlencode( $h );
			case 'x':
				return $is_url ? $v : 'https://x.com/' . rawurlencode( $h );
			case 'snapchat':
				return $is_url ? $v : 'https://snapchat.com/add/' . rawurlencode( $h );
			default:
				return $is_url ? $v : 'https://' . $h;
		}
	}

	public static function label( $type ) {
		$l = array(
			'whatsapp' => 'واتساب', 'instagram' => 'إنستغرام', 'facebook' => 'فيسبوك', 'linkedin' => 'لينكدإن', 'telegram' => 'تيليغرام',
			'youtube' => 'يوتيوب', 'tiktok' => 'تيك توك', 'x' => 'إكس', 'snapchat' => 'سناب شات', 'phone' => 'اتصال', 'email' => 'البريد', 'website' => 'الموقع',
		);
		return isset( $l[ $type ] ) ? $l[ $type ] : $type;
	}

	public static function svg( $type ) {
		$s = array(
			'whatsapp'  => '<path d="M12 3.1a8.9 8.9 0 0 0-7.7 13.3L3.1 20.9l4.6-1.2A8.9 8.9 0 1 0 12 3.1z" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linejoin="round"/><path d="M8.9 8.1c.3-.5.8-.6 1.1-.2l1.1 1.2c.3.3.3.7 0 1l-.5.6c.7 1.4 1.8 2.5 3.2 3.2l.6-.5c.3-.3.7-.3 1 0l1.2 1.1c.4.3.3.8-.2 1.1-.7.6-1.6.9-2.4.6-2.5-.9-4.5-2.9-5.4-5.4-.3-.8 0-1.7.3-2.5z" fill="currentColor"/>',
			'linkedin'  => '<rect x="3.6" y="9" width="3.4" height="11.2" rx=".6" fill="currentColor"/><circle cx="5.3" cy="5.3" r="2" fill="currentColor"/><path d="M9.6 9h3.2v1.6c.6-1.1 2-1.9 3.6-1.9 2.8 0 3.8 1.8 3.8 4.6v6.9H17v-6.2c0-1.5-.3-2.6-1.8-2.6-1.6 0-2.2 1.1-2.2 2.6v6.2H9.6z" fill="currentColor"/>',
			'instagram' => '<rect x="3.4" y="3.4" width="17.2" height="17.2" rx="5" fill="none" stroke="currentColor" stroke-width="2"/><circle cx="12" cy="12" r="4" fill="none" stroke="currentColor" stroke-width="2"/><circle cx="17.3" cy="6.7" r="1.25" fill="currentColor"/>',
			'facebook'  => '<path d="M13.6 21v-7.6h2.6l.4-3.1h-3V8.4c0-.9.3-1.5 1.6-1.5h1.6V4.1c-.3 0-1.2-.1-2.4-.1-2.4 0-4 1.4-4 4.1v2.2H7.8v3.1h2.6V21z" fill="currentColor"/>',
			'telegram'  => '<path d="M20.6 4.3 3.4 11c-1 .4-1 1 0 1.3l4.3 1.4 1.6 5c.2.6.5.7 1 .3l2.4-2 4.6 3.4c.8.5 1.4.2 1.6-.8l2.9-13.6c.3-1.2-.4-1.7-1.2-1.4z" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/><path d="m7.8 13.7 9.4-6-7 7.2" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/>',
			'youtube'   => '<rect x="2.6" y="5.6" width="18.8" height="12.8" rx="4" fill="none" stroke="currentColor" stroke-width="1.9"/><path d="m10 9.2 5 2.8-5 2.8z" fill="currentColor"/>',
			'tiktok'    => '<path d="M14.2 3.2h3c.3 2.1 1.6 3.5 3.6 3.7v3c-1.4 0-2.6-.4-3.6-1.1v6.4a5.6 5.6 0 1 1-5.6-5.6c.3 0 .6 0 .9.1v3.1a2.6 2.6 0 1 0 1.7 2.4z" fill="currentColor"/>',
			'x'         => '<path d="M4 4h4.6l4 5.4L17.4 4H20l-6.2 7 6.8 9H16l-4.4-5.9L6.4 20H3.8l6.6-7.4z" fill="currentColor"/>',
			'snapchat'  => '<path d="M12 3.4c3 0 4.9 2.2 4.9 5v2.3l1.6-.5c.6-.2 1 .5.5.9l-1.8 1.2c.6 1.6 1.8 2.8 3.4 3.3.5.2.4.8 0 1-.9.3-1.7.4-2.1.6-.3.6-.3 1.3-.9 1.2-1-.2-1.8-.1-2.7.6-.9.7-1.8 1.2-2.9 1.2s-2-.5-2.9-1.2c-.9-.7-1.7-.8-2.7-.6-.6.1-.6-.6-.9-1.2-.4-.2-1.2-.3-2.1-.6-.4-.2-.5-.8 0-1 1.6-.5 2.8-1.7 3.4-3.3L4.1 11c-.5-.4-.1-1.1.5-.9l1.6.5V8.4c0-2.8 1.9-5 5.8-5z" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/>',
			'phone'     => '<path d="M5.6 3.6h3.1l1.6 4.1-2.1 1.3a10.4 10.4 0 0 0 5.2 5.2l1.3-2.1 4.1 1.6v3.1a1.9 1.9 0 0 1-1.9 1.9A14.6 14.6 0 0 1 3.7 5.5a1.9 1.9 0 0 1 1.9-1.9z" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linejoin="round"/>',
			'email'     => '<rect x="3.2" y="5.4" width="17.6" height="13.2" rx="2.6" fill="none" stroke="currentColor" stroke-width="1.9"/><path d="m4.2 7.4 7.8 6.2 7.8-6.2" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linejoin="round"/>',
			'website'   => '<circle cx="12" cy="12" r="8.6" fill="none" stroke="currentColor" stroke-width="1.9"/><path d="M3.6 12h16.8M12 3.4c2.4 2.4 3.6 5.3 3.6 8.6s-1.2 6.2-3.6 8.6c-2.4-2.4-3.6-5.3-3.6-8.6S9.6 5.8 12 3.4z" fill="none" stroke="currentColor" stroke-width="1.7"/>',
		);
		return '<svg viewBox="0 0 24 24" aria-hidden="true">' . ( isset( $s[ $type ] ) ? $s[ $type ] : $s['website'] ) . '</svg>';
	}

	/** Items ready for the front end: label, url ('' = icon only), svg. */
	public static function items() {
		$out = array();
		foreach ( self::rows() as $r ) {
			$t = isset( $r['type'] ) ? $r['type'] : '';
			if ( ! isset( self::types()[ $t ] ) ) {
				continue;
			}
			$out[] = array( 'type' => $t, 'label' => self::label( $t ), 'url' => self::url( $t, isset( $r['value'] ) ? $r['value'] : '' ), 'svg' => self::svg( $t ) );
		}
		return $out;
	}

	/* ---------------- admin ---------------- */

	public static function register() {
		register_setting( 'dlz_socials_group', self::OPT, array( 'sanitize_callback' => array( __CLASS__, 'sanitize' ) ) );
	}

	public static function sanitize( $in ) {
		$out = array();
		if ( ! is_array( $in ) ) {
			return $out;
		}
		$types = self::types();
		foreach ( $in as $r ) {
			$t = isset( $r['type'] ) ? sanitize_key( $r['type'] ) : '';
			if ( ! isset( $types[ $t ] ) ) {
				continue;
			}
			$v     = isset( $r['value'] ) ? sanitize_text_field( wp_unslash( $r['value'] ) ) : '';
			$out[] = array( 'type' => $t, 'value' => substr( $v, 0, 300 ) );
			if ( count( $out ) >= 12 ) {
				break;
			}
		}
		return $out;
	}

	public static function menu() {
		add_submenu_page( 'dlz-unified', 'تابعنا على — شبکه‌های اجتماعی', 'شبکه‌های اجتماعی (تابعنا)', 'manage_options', 'dlz-socials', array( __CLASS__, 'page' ) );
	}

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$rows  = self::rows();
		$types = self::types();
		$opt   = function ( $sel ) use ( $types ) {
			$h = '';
			foreach ( $types as $k => $t ) {
				$h .= '<option value="' . esc_attr( $k ) . '" data-ph="' . esc_attr( $t[1] ) . '" data-help="' . esc_attr( $t[2] ) . '"' . selected( $sel, $k, false ) . '>' . esc_html( $t[0] ) . '</option>';
			}
			return $h;
		};
		?>
		<div class="wrap dlz-soc-adm" dir="rtl">
			<h1>تابعنا على — شبکه‌های اجتماعی</h1>
			<p class="description" style="max-width:760px">این آیکن‌ها پایین صفحه «المزيد» در بخش «تابعنا على» نمایش داده می‌شوند (به همین ترتیب، از راست به چپ). برای هر مورد نوع را انتخاب و لینک، نام کاربری یا شماره را وارد کنید. اگر کادر خالی بماند، فقط آیکن بدون لینک نمایش داده می‌شود.</p>
			<style>
				.dlz-soc-adm table{max-width:860px;background:#fff;border:1px solid #dcdcde;border-radius:12px;border-collapse:separate;border-spacing:0;overflow:hidden}
				.dlz-soc-adm td,.dlz-soc-adm th{padding:10px 12px;vertical-align:middle;border-bottom:1px solid #f0f0f1}
				.dlz-soc-adm tr:last-child td{border-bottom:0}
				.dlz-soc-adm .soc-ic{width:42px;height:42px;border-radius:50%;display:flex;align-items:center;justify-content:center;color:#0F4D2E;box-shadow:inset 0 0 0 2px #D9B25A;background:#fffdf6}
				.dlz-soc-adm .soc-ic svg{width:22px;height:22px}
				.dlz-soc-adm input[type=text]{width:100%;direction:ltr;text-align:left}
				.dlz-soc-adm .soc-help{display:block;color:#787c82;font-size:12px;margin-top:4px}
				.dlz-soc-adm .soc-move{cursor:grab;color:#a7aaad;font-size:18px;user-select:none}
				.dlz-soc-adm .button-link-delete{color:#b32d2e}
			</style>
			<form method="post" action="options.php">
				<?php settings_fields( 'dlz_socials_group' ); ?>
				<table class="widefat" id="dlz-soc-table">
					<thead><tr><th style="width:30px"></th><th style="width:60px">آیکن</th><th style="width:180px">نوع</th><th>لینک / نام کاربری / شماره</th><th style="width:70px"></th></tr></thead>
					<tbody>
					<?php foreach ( $rows as $i => $r ) : $t = isset( $types[ $r['type'] ] ) ? $types[ $r['type'] ] : $types['website']; ?>
						<tr>
							<td class="soc-move" title="جابجایی">⋮⋮</td>
							<td><span class="soc-ic"><?php echo self::svg( $r['type'] ); // phpcs:ignore ?></span></td>
							<td><select class="soc-type" name="<?php echo esc_attr( self::OPT ); ?>[<?php echo (int) $i; ?>][type]"><?php echo $opt( $r['type'] ); // phpcs:ignore ?></select></td>
							<td><input type="text" class="soc-val" name="<?php echo esc_attr( self::OPT ); ?>[<?php echo (int) $i; ?>][value]" value="<?php echo esc_attr( $r['value'] ); ?>" placeholder="<?php echo esc_attr( $t[1] ); ?>"><span class="soc-help"><?php echo esc_html( $t[2] ); ?></span></td>
							<td><button type="button" class="button-link button-link-delete soc-del">حذف</button></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
				<p><button type="button" class="button" id="dlz-soc-add">+ افزودن شبکه یا شماره</button></p>
				<?php submit_button( 'ذخیره' ); ?>
			</form>
			<script type="text/template" id="dlz-soc-tpl"><tr><td class="soc-move" title="جابجایی">⋮⋮</td><td><span class="soc-ic"></span></td><td><select class="soc-type" name="<?php echo esc_attr( self::OPT ); ?>[__i__][type]"><?php echo $opt( 'instagram' ); // phpcs:ignore ?></select></td><td><input type="text" class="soc-val" name="<?php echo esc_attr( self::OPT ); ?>[__i__][value]" value=""><span class="soc-help"></span></td><td><button type="button" class="button-link button-link-delete soc-del">حذف</button></td></tr></script>
			<script>
			jQuery(function ($) {
				var icons = <?php echo wp_json_encode( array_combine( array_keys( $types ), array_map( array( __CLASS__, 'svg' ), array_keys( $types ) ) ) ); ?>;
				var $tb = $('#dlz-soc-table tbody');
				function renumber() {
					$tb.find('tr').each(function (i) {
						$(this).find('select,input').each(function () { this.name = this.name.replace(/\[\d+\]|\[__i__\]/, '[' + i + ']'); });
					});
				}
				function sync($tr) {
					var o = $tr.find('.soc-type option:selected');
					$tr.find('.soc-ic').html(icons[o.val()] || '');
					$tr.find('.soc-val').attr('placeholder', o.data('ph') || '');
					$tr.find('.soc-help').text(o.data('help') || '');
				}
				$tb.on('change', '.soc-type', function () { sync($(this).closest('tr')); });
				$tb.on('click', '.soc-del', function () { $(this).closest('tr').remove(); renumber(); });
				$('#dlz-soc-add').on('click', function () { var $tr = $($('#dlz-soc-tpl').html()); $tb.append($tr); sync($tr); renumber(); $tr.find('.soc-val').focus(); });
				if ($.fn.sortable) $tb.sortable({ handle: '.soc-move', axis: 'y', update: renumber });
			});
			</script>
		</div>
		<?php
	}
}

DLZ_Socials::init();
add_action( 'admin_enqueue_scripts', function ( $hook ) {
	if ( false !== strpos( (string) $hook, 'dlz-socials' ) ) {
		wp_enqueue_script( 'jquery-ui-sortable' );
	}
} );
