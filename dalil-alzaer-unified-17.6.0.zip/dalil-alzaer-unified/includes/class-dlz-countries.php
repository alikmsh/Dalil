<?php
/**
 * Dalil Al Zaer — the ten Arab countries of the visitors' profile:
 * names, taglines, dialling codes, waving SVG flags and a picture per country.
 *
 * Pictures and taglines can be changed in «دلیل الزائر → کشورها و پرچم‌ها».
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DLZ_Countries {

	const OPT = 'dlz_countries';


	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 21 );
		add_action( 'admin_init', array( __CLASS__, 'register' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'admin_assets' ) );
	}

	/** key => [official name, short name, tagline, dialling code] */
	public static function base() {
		return array(
			'iq' => array( 'جمهورية العراق', 'العراق', 'عاصمة الولاء وموئل العتبات', '+964' ),
			'lb' => array( 'الجمهورية اللبنانية', 'لبنان', 'جبل عامل مهد التشيع وعرين الصامدين', '+961' ),
			'bh' => array( 'مملكة البحرين', 'البحرين', 'أهل الولاء والفداء', '+973' ),
			'sa' => array( 'المملكة العربية السعودية', 'السعودية', 'أهل الولاء في الأحساء والقطيف والمدينة', '+966' ),
			'kw' => array( 'دولة الكويت', 'الكويت', 'محبو أهل البيت والحسينيات العامرة', '+965' ),
			'om' => array( 'سلطنة عمان', 'عُمان', 'أهل المودة وأخوة الصفاء', '+968' ),
			'ae' => array( 'دولة الإمارات العربية المتحدة', 'الإمارات', 'محبو العترة ورواد المجالس', '+971' ),
			'qa' => array( 'دولة قطر', 'قطر', 'أهل المحبة والولاء', '+974' ),
			'sy' => array( 'الجمهورية العربية السورية', 'سوريا', 'حماة العقيلة وجوار السيدة زينب', '+963' ),
			'ye' => array( 'الجمهورية اليمنية', 'اليمن', 'أنصار الولاية وأهل الإيمان والجهاد', '+967' ),
		);
	}

	/** Full list with the admin overrides applied. */
	public static function all() {
		static $all = null;
		if ( null !== $all ) {
			return $all;
		}
		$saved = get_option( self::OPT, array() );
		$saved = is_array( $saved ) ? $saved : array();
		$all   = array();
		foreach ( self::base() as $k => $c ) {
			$s         = isset( $saved[ $k ] ) && is_array( $saved[ $k ] ) ? $saved[ $k ] : array();
			$all[ $k ] = array(
				'key'   => $k,
				'name'  => $c[0],
				'short' => $c[1],
				'tag'   => ! empty( $s['tag'] ) ? $s['tag'] : $c[2],
				'dial'  => $c[3],
				'img'   => ! empty( $s['img'] ) ? $s['img'] : DASE_URL . 'assets/countries/' . $k . '.jpg',
			);
		}
		return $all;
	}

	public static function get( $key ) {
		$a = self::all();
		return isset( $a[ $key ] ) ? $a[ $key ] : null;
	}

	/** Old profiles stored an Arabic name (15.3 list) — map it to the new key. */
	public static function key_from( $value ) {
		$value = trim( (string) $value );
		if ( '' === $value ) {
			return '';
		}
		if ( isset( self::base()[ $value ] ) ) {
			return $value;
		}
		$map = array(
			'العراق'   => 'iq',
			'لبنان'    => 'lb',
			'البحرين'  => 'bh',
			'السعودية' => 'sa',
			'الكويت'   => 'kw',
			'عُمان'    => 'om',
			'عمان'     => 'om',
			'الإمارات' => 'ae',
			'قطر'      => 'qa',
			'سوريا'    => 'sy',
			'اليمن'    => 'ye',
		);
		if ( isset( $map[ $value ] ) ) {
			return $map[ $value ];
		}
		foreach ( self::base() as $k => $c ) {
			if ( $value === $c[0] ) {
				return $k;
			}
		}
		return '';
	}

	/** The visitor's country key (new meta first, then the old Arabic name). */
	public static function of_user( $uid ) {
		$k = (string) get_user_meta( $uid, 'mp_country_code', true );
		if ( $k && self::get( $k ) ) {
			return $k;
		}
		return self::key_from( get_user_meta( $uid, 'mp_country', true ) );
	}

	/* ---------------------------------------------------------
	 * Flags
	 * ------------------------------------------------------- */

	/** The SVG symbols of the flags a page needs (each symbol printed once per page). */
	private static $printed = array();
	public static function defs( $only = null ) {
		static $all = null;
		if ( null === $all ) {
			$all = array();
			$f   = DASE_PATH . 'assets/flag-symbols.svg';
			$raw = file_exists( $f ) ? (string) file_get_contents( $f ) : ''; // phpcs:ignore
			if ( preg_match_all( '#<symbol id="dlzf-([a-z]{2})".*?</symbol>#s', $raw, $m, PREG_SET_ORDER ) ) {
				foreach ( $m as $x ) {
					$all[ $x[1] ] = $x[0];
				}
			}
		}
		$keys = null === $only ? array_keys( $all ) : (array) $only;
		$out  = '';
		foreach ( $keys as $k ) {
			if ( isset( $all[ $k ] ) && ! isset( self::$printed[ $k ] ) ) {
				self::$printed[ $k ] = 1;
				$out                .= $all[ $k ];
			}
		}
		return '' === $out ? '' : '<svg class="dlzf-defs" width="0" height="0" style="position:absolute;width:0;height:0;overflow:hidden" aria-hidden="true" focusable="false"><defs>' . $out . '</defs></svg>';
	}

	/**
	 * A flag. Waving flags are cut into vertical strips that move on a delayed wave
	 * (GPU transforms only — light enough for a list of ten).
	 */
	public static function flag( $key, $wave = true, $cls = '' ) {
		if ( ! self::get( $key ) ) {
			return '';
		}
		$use = '<svg viewBox="0 0 300 200" preserveAspectRatio="none" focusable="false"><use href="#dlzf-' . esc_attr( $key ) . '"/></svg>';
		if ( ! $wave ) {
			return '<span class="dlzf is-still ' . esc_attr( $cls ) . '" data-flag="' . esc_attr( $key ) . '" aria-hidden="true">' . $use . '</span>';
		}
		$n = 12;
		$h = '<span class="dlzf ' . esc_attr( $cls ) . '" data-flag="' . esc_attr( $key ) . '" style="--n:' . $n . '" aria-hidden="true">';
		for ( $i = 0; $i < $n; $i++ ) {
			$h .= '<i style="--i:' . $i . ';--k:' . round( 0.25 + 0.75 * $i / ( $n - 1 ), 2 ) . '">' . $use . '</i>';
		}
		return $h . '</span>';
	}

	/** Data for the front-end scripts. */
	public static function js() {
		$out = array();
		foreach ( self::all() as $k => $c ) {
			$out[ $k ] = array( 'name' => $c['name'], 'short' => $c['short'], 'tag' => $c['tag'], 'dial' => $c['dial'] );
		}
		return $out;
	}

	public static function enqueue_style() {
		wp_enqueue_style( 'dlz-flags', DASE_URL . 'assets/flags.css', array(), defined( 'DASE_VERSION' ) ? DASE_VERSION : '15' );
	}

	/* ---------------------------------------------------------
	 * Admin: «کشورها و پرچم‌ها»
	 * ------------------------------------------------------- */

	public static function menu() {
		add_submenu_page( 'dlz-unified', 'کشورها و پرچم‌ها', 'کشورها و پرچم‌ها', 'manage_options', 'dlz-countries', array( __CLASS__, 'page' ) );
	}

	public static function register() {
		register_setting( 'dlz_countries_group', self::OPT, array( 'sanitize_callback' => array( __CLASS__, 'sanitize' ) ) );
	}

	public static function sanitize( $in ) {
		$out = array();
		if ( ! is_array( $in ) ) {
			return $out;
		}
		foreach ( self::base() as $k => $c ) {
			if ( empty( $in[ $k ] ) || ! is_array( $in[ $k ] ) ) {
				continue;
			}
			$tag = trim( sanitize_text_field( isset( $in[ $k ]['tag'] ) ? $in[ $k ]['tag'] : '' ) );
			$img = trim( esc_url_raw( isset( $in[ $k ]['img'] ) ? $in[ $k ]['img'] : '' ) );
			$row = array();
			if ( '' !== $tag && $tag !== $c[2] ) {
				$row['tag'] = $tag;
			}
			if ( '' !== $img && false === strpos( $img, 'assets/countries/' . $k . '.jpg' ) ) {
				$row['img'] = $img;
			}
			if ( $row ) {
				$out[ $k ] = $row;
			}
		}
		return $out;
	}

	public static function admin_assets( $hook ) {
		if ( false === strpos( (string) $hook, 'dlz-countries' ) ) {
			return;
		}
		wp_enqueue_media();
		self::enqueue_style();
	}

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$saved = get_option( self::OPT, array() );
		echo self::defs(); // phpcs:ignore
		?>
<div class="wrap" dir="rtl">
	<h1>کشورها و پرچم‌ها</h1>
	<p style="max-width:760px;font-size:13px;line-height:2">این ده کشور در صفحه‌ی «الملف الشخصي» (انتخاب کشور و پیش‌شماره‌ی تلفن بین‌المللی) نمایش داده می‌شوند. برای هر کشور می‌توانید عکس دلخواه از کتابخانه‌ی رسانه انتخاب کنید (بهتر است افقی و حداقل ۶۴۰×۴۰۰ پیکسل و در فضای شب باشد) و جمله‌ی زیر نام کشور را تغییر دهید. خالی گذاشتن هر فیلد یعنی همان پیش‌فرض افزونه.</p>
	<form method="post" action="options.php">
		<?php settings_fields( 'dlz_countries_group' ); ?>
		<table class="widefat striped" style="max-width:1000px">
			<thead><tr><th style="width:70px">پرچم</th><th style="width:190px">کشور</th><th>جمله‌ی زیر نام</th><th style="width:330px">عکس کشور</th></tr></thead>
			<tbody>
			<?php
			foreach ( self::all() as $k => $c ) :
				$s   = isset( $saved[ $k ] ) ? $saved[ $k ] : array();
				$img = isset( $s['img'] ) ? $s['img'] : '';
				?>
				<tr>
					<td><?php echo self::flag( $k, true, 'dlzf-admin' ); // phpcs:ignore ?></td>
					<td><b><?php echo esc_html( $c['name'] ); ?></b><br><code dir="ltr"><?php echo esc_html( $c['dial'] ); ?></code></td>
					<td><input type="text" class="large-text" name="<?php echo esc_attr( self::OPT . '[' . $k . '][tag]' ); ?>" value="<?php echo esc_attr( isset( $s['tag'] ) ? $s['tag'] : '' ); ?>" placeholder="<?php echo esc_attr( self::base()[ $k ][2] ); ?>"></td>
					<td>
						<div style="display:flex;gap:8px;align-items:center">
							<img class="dlzc-prev" src="<?php echo esc_url( $c['img'] ); ?>" alt="" style="width:110px;height:64px;object-fit:cover;border-radius:8px;background:#0b1712">
							<input type="hidden" class="dlzc-img" name="<?php echo esc_attr( self::OPT . '[' . $k . '][img]' ); ?>" value="<?php echo esc_attr( $img ); ?>" data-def="<?php echo esc_url( DASE_URL . 'assets/countries/' . $k . '.jpg' ); ?>">
							<button type="button" class="button dlzc-pick">انتخاب عکس</button>
							<button type="button" class="button-link-delete dlzc-reset"<?php echo $img ? '' : ' hidden'; ?>>پیش‌فرض</button>
						</div>
					</td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<?php submit_button( 'ذخیره' ); ?>
	</form>
</div>
<style>.dlzf-admin{--w:54px;--h:36px}</style>
<script>
jQuery(function ($) {
	$('.dlzc-pick').on('click', function () {
		var $td = $(this).closest('td'), fr = wp.media({ title: 'عکس کشور', library: { type: 'image' }, multiple: false, button: { text: 'انتخاب' } });
		fr.on('select', function () {
			var a = fr.state().get('selection').first().toJSON(), u = (a.sizes && a.sizes.large ? a.sizes.large.url : a.url);
			$td.find('.dlzc-img').val(u); $td.find('.dlzc-prev').attr('src', u); $td.find('.dlzc-reset').prop('hidden', false);
		});
		fr.open();
	});
	$('.dlzc-reset').on('click', function () {
		var $td = $(this).closest('td'), $i = $td.find('.dlzc-img');
		$i.val(''); $td.find('.dlzc-prev').attr('src', $i.data('def')); $(this).prop('hidden', true);
	});
});
</script>
		<?php
	}
}

DLZ_Countries::init();
