<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

define( 'MCR_VERSION', '2.0.0' );
define( 'MCR_PATH', plugin_dir_path( __FILE__ ) );
define( 'MCR_URL', plugin_dir_url( __FILE__ ) );
define( 'MCR_TABLE', 'mcr_submissions' );

require_once MCR_PATH . 'includes/class-mcr-data.php';
require_once MCR_PATH . 'includes/class-mcr-db.php';
require_once MCR_PATH . 'includes/class-mcr-admin-menu.php';
require_once MCR_PATH . 'includes/class-mcr-admin-submissions.php';
require_once MCR_PATH . 'includes/class-mcr-settings.php';
require_once MCR_PATH . 'includes/class-mcr-ajax.php';
require_once MCR_PATH . 'includes/class-mcr-elementor.php';

register_activation_hook( __FILE__, array( 'MCR_DB', 'install' ) );
add_action( 'admin_init', array( 'MCR_DB', 'maybe_upgrade' ) );
add_action( 'wp_ajax_mcr_submit', array( 'MCR_DB', 'maybe_upgrade' ), 1 );
add_action( 'wp_ajax_nopriv_mcr_submit', array( 'MCR_DB', 'maybe_upgrade' ), 1 );

/**
 * Front-end assets — only loaded when the widget is actually on the page,
 * so it never conflicts with the active theme's own styles/scripts.
 */
function mcr_register_frontend_assets() {
	wp_register_style( 'mcr-frontend', MCR_URL . 'assets/css/mcr-frontend.css', array(), MCR_VERSION );
	wp_register_script( 'mcr-frontend', MCR_URL . 'assets/js/mcr-frontend.js', array( 'jquery' ), MCR_VERSION, true );
	wp_localize_script( 'mcr-frontend', 'MCR_AJAX', array(
		'url'   => admin_url( 'admin-ajax.php' ),
		'nonce' => wp_create_nonce( 'mcr_submit_nonce' ),
	) );
}
add_action( 'wp_enqueue_scripts', 'mcr_register_frontend_assets' );

/**
 * Admin assets — only on our own admin pages.
 */
function mcr_admin_assets( $hook ) {
	if ( strpos( $hook, 'mcr' ) === false ) {
		return;
	}
	wp_enqueue_style( 'mcr-admin', MCR_URL . 'assets/css/mcr-admin.css', array(), MCR_VERSION );
}
add_action( 'admin_enqueue_scripts', 'mcr_admin_assets' );
