(function ($) {
	'use strict';

	function closeAllPanels() {
		$('.mcr-cat-dropdown.open').removeClass('open').find('.mcr-cat-toggle').attr('aria-expanded', 'false');
	}

	$(document).on('click', '.mcr-cat-toggle', function (e) {
		e.stopPropagation();
		var $dropdown = $(this).closest('.mcr-cat-dropdown');
		var isOpen = $dropdown.hasClass('open');
		closeAllPanels();
		if (!isOpen) {
			$dropdown.addClass('open');
			$(this).attr('aria-expanded', 'true');
		}
	});

	$(document).on('click', '.mcr-cat-option', function () {
		var $dropdown = $(this).closest('.mcr-cat-dropdown');
		var value = $(this).data('value');
		var text = $(this).find('.mcr-cat-text').text();

		$dropdown.find('.mcr-cat-value').val(value);
		$dropdown.find('.mcr-cat-toggle-text').text(text);
		$dropdown.find('.mcr-cat-toggle').addClass('mcr-has-value');
		$dropdown.find('.mcr-cat-option').removeClass('active');
		$(this).addClass('active');
		// the city label follows the chosen service: treatment or cosmetic surgery
		var $lb = $(this).closest('form, .mcr-form, .mcr-wrap').find('.mcr-city-label').first();
		if ($lb.length) { var cos = String($lb.data('cos-keys') || '').split(',').indexOf(String(value)) > -1; $lb.text(cos ? $lb.data('cos') : $lb.data('med')); }
		closeAllPanels();
	});

	$(document).on('click', function () {
		closeAllPanels();
	});

	// upload label preview
	$(document).on('change', '.mcr-upload input[type=file]', function () {
		var name = this.files && this.files[0] ? this.files[0].name : '';
		if (name) {
			$(this).closest('.mcr-upload').find('.mcr-upload-text').text(name);
		}
	});

	$(document).on('submit', '.mcr-form', function (e) {
		e.preventDefault();
		var $form = $(this);
		var $widget = $form.closest('.mcr-widget');
		var $box = $form.find('.mcr-message-box');
		var $btn = $form.find('.mcr-submit');

		var catValue = $form.find('.mcr-cat-value').val();
		if (!catValue) {
			$box.attr('class', 'mcr-message-box error').text('يرجى اختيار القسم الطبي.').show();
			$widget.get(0).scrollIntoView({ behavior: 'smooth', block: 'center' });
			return;
		}

		var formData = new FormData(this);
		formData.append('action', 'mcr_submit');
		formData.append('nonce', MCR_AJAX.nonce);

		$btn.prop('disabled', true);
		var originalText = $btn.find('.mcr-submit-text').text();
		$btn.find('.mcr-submit-text').text('...جارٍ الإرسال');

		$.ajax({
			url: MCR_AJAX.url,
			type: 'POST',
			data: formData,
			processData: false,
			contentType: false,
			success: function (res) {
				if (res.success) {
					$box.attr('class', 'mcr-message-box success').text(res.data.message).show();
					var $catValueInput = $form.find('.mcr-cat-value');
					var lockedCategory = $catValueInput.closest('.mcr-cat-dropdown').length === 0 ? $catValueInput.val() : '';
					$form[0].reset();
					if (lockedCategory) {
						// locked forms keep their fixed category after reset
						$catValueInput.val(lockedCategory);
					} else {
						$catValueInput.val('');
						$form.find('.mcr-cat-toggle-text').text('اختر القسم الطبي');
						$form.find('.mcr-cat-toggle').removeClass('mcr-has-value');
						$form.find('.mcr-cat-option').removeClass('active');
					}
					$form.find('.mcr-upload-text').text('إرفاق صورة الجواز أو التقرير الطبي (اختياري)');
				} else {
					$box.attr('class', 'mcr-message-box error').text((res.data && res.data.message) || 'حدث خطأ، يرجى المحاولة مرة أخرى.').show();
				}
			},
			error: function () {
				$box.attr('class', 'mcr-message-box error').text('تعذر إرسال الطلب، يرجى المحاولة مرة أخرى.').show();
			},
			complete: function () {
				$btn.prop('disabled', false);
				$btn.find('.mcr-submit-text').text(originalText);
			}
		});
	});

}(jQuery));
