<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Shortcode fallback (works even without Elementor) — [mcr_form default="dentistry" lock="yes"] */
add_shortcode( 'mcr_form', function( $atts ) {
	$atts = shortcode_atts( array( 'default' => '', 'lock' => '' ), $atts );
	ob_start();
	mcr_render_form( '', '', $atts['default'], ( 'yes' === $atts['lock'] || '1' === $atts['lock'] ) );
	return ob_get_clean();
} );

/**
 * Shared render function used by both the shortcode and the Elementor widget.
 *
 * @param string $gold_color       Optional accent color override.
 * @param string $navy_color       Optional background color override.
 * @param string $default_category Category key to pre-select (optional).
 * @param bool   $lock_category    If true and a default is set, the picker is hidden/locked to that category.
 */
function mcr_render_form( $gold_color = '', $navy_color = '', $default_category = '', $lock_category = false ) {
	wp_enqueue_style( 'mcr-frontend' );
	wp_enqueue_script( 'mcr-frontend' );

	$all_cats  = MCR_Data::categories();
	$countries = MCR_Data::countries();
	$cities    = MCR_Data::iran_cities();
	$uid       = 'mcr_' . wp_generate_uuid4();

	$style_parts = array();
	if ( $gold_color ) { $style_parts[] = '--mcr-gold:' . esc_attr( $gold_color ); }
	if ( $navy_color ) { $style_parts[] = '--mcr-navy:' . esc_attr( $navy_color ); }
	$style = $style_parts ? ' style="' . implode( ';', $style_parts ) . ';"' : '';

	$has_default = $default_category && isset( $all_cats[ $default_category ] );
	$is_locked   = $has_default && $lock_category;
	?>
	<div class="mcr-widget" id="<?php echo esc_attr( $uid ); ?>"<?php echo $style; ?> dir="rtl">
		<form class="mcr-form" method="post" enctype="multipart/form-data" novalidate>

			<!-- Category bar: closed nav that opens a list of medical departments -->
			<div class="mcr-field">
				<label class="mcr-label">القسم الطبي <span class="mcr-req">*</span></label>

				<?php if ( $is_locked ) : ?>
					<div class="mcr-cat-locked">
						<span class="mcr-cat-text"><?php echo esc_html( $all_cats[ $default_category ]['ar'] ); ?></span>
					</div>
					<input type="hidden" class="mcr-cat-value" name="category_key" value="<?php echo esc_attr( $default_category ); ?>" required />
				<?php else : ?>
					<div class="mcr-cat-dropdown">
						<button type="button" class="mcr-cat-toggle <?php echo $has_default ? 'mcr-has-value' : ''; ?>" aria-expanded="false">
							<span class="mcr-cat-toggle-text"><?php echo $has_default ? esc_html( $all_cats[ $default_category ]['ar'] ) : 'اختر القسم الطبي'; ?></span>
							<span class="mcr-cat-arrow">⌄</span>
						</button>
						<div class="mcr-cat-panel">
							<?php foreach ( $all_cats as $key => $cat ) : ?>
								<button type="button" class="mcr-cat-option <?php echo ( $has_default && $key === $default_category ) ? 'active' : ''; ?>" data-value="<?php echo esc_attr( $key ); ?>">
									<span class="mcr-cat-text"><?php echo esc_html( $cat['ar'] ); ?></span>
								</button>
							<?php endforeach; ?>
						</div>
						<input type="hidden" class="mcr-cat-value" name="category_key" value="<?php echo $has_default ? esc_attr( $default_category ) : ''; ?>" required />
					</div>
				<?php endif; ?>
			</div>

			<div class="mcr-field">
				<label class="mcr-label" for="<?php echo esc_attr($uid);?>_name">الاسم <span class="mcr-req">*</span></label>
				<div class="mcr-input-wrap">
					<input type="text" id="<?php echo esc_attr($uid);?>_name" name="name" required />
				</div>
			</div>

			<div class="mcr-field">
				<label class="mcr-label">رقم الهاتف / واتساب <span class="mcr-req">*</span></label>
				<div class="mcr-input-wrap">
					<input type="tel" name="phone" required dir="ltr" />
				</div>
			</div>

			<div class="mcr-field mcr-field-row">
				<div class="mcr-field-half">
					<label class="mcr-label">الجنس <span class="mcr-req">*</span></label>
					<div class="mcr-input-wrap">
						<select name="gender" required>
							<option value="male">ذكر</option>
							<option value="female">أنثى</option>
						</select>
					</div>
				</div>
				<div class="mcr-field-half">
					<label class="mcr-label">الجنسية <span class="mcr-req">*</span></label>
					<div class="mcr-input-wrap">
						<select name="nationality" required>
							<?php foreach ( $countries as $c ) : ?>
								<option value="<?php echo esc_attr( $c ); ?>"><?php echo esc_html( $c ); ?></option>
							<?php endforeach; ?>
						</select>
					</div>
				</div>
			</div>

			<div class="mcr-field">
				<?php $mcr_cos = $has_default && in_array( $default_category, array( 'rhinoplasty', 'hair_transplant', 'body_contouring', 'eyelid', 'cosmetic_dental', 'facelift', 'lip_filler', 'necklift', 'other_surgery' ), true ); ?>
				<label class="mcr-label"><span class="mcr-city-label" data-med="المدينة المطلوبة للعلاج" data-cos="المدينة المطلوبة للتجميل" data-cos-keys="rhinoplasty,hair_transplant,body_contouring,eyelid,cosmetic_dental,facelift,lip_filler,necklift,other_surgery"><?php echo $mcr_cos ? 'المدينة المطلوبة للتجميل' : 'المدينة المطلوبة للعلاج'; ?></span> <span class="mcr-req">*</span></label>
				<div class="mcr-input-wrap">
					<select name="city" required>
						<?php foreach ( $cities as $c ) : ?>
							<option value="<?php echo esc_attr( $c ); ?>"><?php echo esc_html( $c ); ?></option>
						<?php endforeach; ?>
					</select>
				</div>
			</div>

			<div class="mcr-field">
				<label class="mcr-label">شرح الحالة <span class="mcr-req">*</span></label>
				<div class="mcr-input-wrap mcr-textarea-wrap">
					<textarea name="message" rows="4" required></textarea>
				</div>
			</div>

			<div class="mcr-field">
				<label class="mcr-upload">
					<input type="file" name="attachment" accept=".jpg,.jpeg,.png,.webp,.pdf" />
					<span class="mcr-upload-text">إرفاق صورة الجواز أو التقرير الطبي (اختياري)</span>
					<span class="mcr-upload-hint">بإمكانك إرفاق صورة أو ملف PDF</span>
				</label>
			</div>

			<button type="submit" class="mcr-submit">
				<span class="mcr-submit-text">إرسال الطلب</span>
			</button>

			<div class="mcr-message-box" style="display:none;"></div>
		</form>
	</div>
	<?php
}

/** Register the Elementor widget once Elementor has loaded. */
add_action( 'elementor/widgets/register', function( $widgets_manager ) {
	if ( ! class_exists( '\Elementor\Widget_Base' ) ) { return; }
	require_once MCR_PATH . 'includes/class-mcr-elementor-widget.php';
	$widgets_manager->register( new \MCR_Elementor_Widget() );
} );

add_action( 'elementor/elements/categories_registered', function( $elements_manager ) {
	$elements_manager->add_category( 'mcr-category', array(
		'title' => 'مشاوره پزشکی',
		'icon'  => 'eicon-form-horizontal',
	) );
} );
