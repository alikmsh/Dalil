<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class MCR_Data {

	/**
	 * The 24 medical departments / disease types.
	 * Shown to the visitor in Arabic, shown to the admin in Persian.
	 */
	public static function categories() {
		return array(
			'infertility'      => array( 'ar' => 'علاج العقم',                  'fa' => 'درمان ناباروری' ),
			'ophthalmology'    => array( 'ar' => 'طب العيون',                    'fa' => 'چشم‌پزشکی' ),
			'dentistry'        => array( 'ar' => 'طب الأسنان',                   'fa' => 'دندان‌پزشکی' ),
			'cardiology'       => array( 'ar' => 'أمراض القلب',                  'fa' => 'بیماری‌های قلب' ),
			'orthopedics'      => array( 'ar' => 'العظام والمفاصل',              'fa' => 'ارتوپدی و مفاصل' ),
			'neurology'        => array( 'ar' => 'أمراض الدماغ والأعصاب',        'fa' => 'مغز و اعصاب' ),
			'gastro'           => array( 'ar' => 'أمراض الجهاز الهضمي',          'fa' => 'گوارش' ),
			'pulmonology'      => array( 'ar' => 'أمراض الصدر والتنفس',          'fa' => 'ریه و تنفس' ),
			'oncology'         => array( 'ar' => 'أمراض السرطان',                'fa' => 'سرطان (انکولوژی)' ),
			'urology'          => array( 'ar' => 'أمراض الكلى والمجاري البولية', 'fa' => 'کلیه و مجاری ادراری' ),
			'gynecology'       => array( 'ar' => 'أمراض النساء والولادة',        'fa' => 'زنان و زایمان' ),
			'andrology'        => array( 'ar' => 'أمراض الذكورة والتناسل',       'fa' => 'مردان و ناباروری مردان' ),
			'dermatology'      => array( 'ar' => 'أمراض الجلدية',                'fa' => 'پوست' ),
			'pediatrics'       => array( 'ar' => 'طب الأطفال',                   'fa' => 'اطفال' ),
			'other_disease'    => array( 'ar' => 'أخرى الأمراض',                 'fa' => 'سایر بیماری‌ها' ),
			'rhinoplasty'      => array( 'ar' => 'تجميل الأنف',                  'fa' => 'جراحی زیبایی بینی' ),
			'hair_transplant'  => array( 'ar' => 'زراعة الشعر',                  'fa' => 'کاشت مو' ),
			'body_contouring'  => array( 'ar' => 'نحت الجسم',                    'fa' => 'لیزر و لاغری موضعی' ),
			'eyelid'           => array( 'ar' => 'تجميل الجفون',                 'fa' => 'زیبایی پلک' ),
			'cosmetic_dental'  => array( 'ar' => 'تجميل الأسنان',                'fa' => 'زیبایی دندان' ),
			'facelift'         => array( 'ar' => 'شد الوجه',                     'fa' => 'لیفت صورت' ),
			'lip_filler'       => array( 'ar' => 'تكبير الشفاه',                 'fa' => 'افزایش حجم لب' ),
			'necklift'         => array( 'ar' => 'شد الرقبة',                    'fa' => 'لیفت گردن' ),
			'other_surgery'    => array( 'ar' => 'عمليات أخرى',                  'fa' => 'سایر اعمال جراحی' ),
		);
	}

	public static function category_label( $key, $lang = 'ar' ) {
		$cats = self::categories();
		if ( isset( $cats[ $key ] ) ) {
			return $cats[ $key ][ $lang ];
		}
		return '';
	}

	/** Nationality list shown to the visitor. */
	public static function countries() {
		return array(
			'السعودية', 'الإمارات العربية المتحدة', 'الكويت', 'قطر', 'البحرين', 'عمان',
			'العراق', 'سوريا', 'لبنان', 'الأردن', 'فلسطين', 'اليمن', 'مصر',
		);
	}

	/** Destination cities in Iran, shown to the visitor. */
	public static function iran_cities() {
		return array(
			'مشهد المقدسة', 'قم المقدسة', 'طهران', 'شيراز',
		);
	}
}
