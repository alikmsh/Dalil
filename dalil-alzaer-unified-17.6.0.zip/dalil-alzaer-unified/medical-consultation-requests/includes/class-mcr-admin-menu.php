<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class MCR_Admin_Menu {

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'register_menu' ) );
	}

	public static function register_menu() {
		$new_count = MCR_DB::count_new();
		$badge     = $new_count > 0 ? ' <span class="mcr-badge">' . $new_count . '</span>' : '';

		add_menu_page(
			'مشاوره پزشکی',
			'مشاوره پزشکی' . $badge,
			'manage_options',
			'mcr-submissions',
			array( 'MCR_Admin_Submissions', 'render_list_page' ),
			'dashicons-heart',
			27
		);

		add_submenu_page( 'mcr-submissions', 'درخواست‌ها', 'درخواست‌ها' . $badge, 'manage_options', 'mcr-submissions', array( 'MCR_Admin_Submissions', 'render_list_page' ) );

		add_submenu_page( 'mcr-submissions', 'تنظیمات', 'تنظیمات', 'manage_options', 'mcr-settings', array( 'MCR_Settings', 'render_page' ) );
	}
}
MCR_Admin_Menu::init();
