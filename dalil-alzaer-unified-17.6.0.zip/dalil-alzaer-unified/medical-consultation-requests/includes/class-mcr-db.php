<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class MCR_DB {

	public static function table() {
		global $wpdb;
		return $wpdb->prefix . MCR_TABLE;
	}

	public static function install() {
		global $wpdb;
		$table_name      = self::table();
		$charset_collate = $wpdb->get_charset_collate();

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$sql = "CREATE TABLE {$table_name} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			user_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			category_key VARCHAR(50) NOT NULL DEFAULT '',
			name VARCHAR(191) NOT NULL DEFAULT '',
			phone VARCHAR(60) NOT NULL DEFAULT '',
			gender VARCHAR(20) NOT NULL DEFAULT '',
			nationality VARCHAR(120) NOT NULL DEFAULT '',
			city VARCHAR(120) NOT NULL DEFAULT '',
			message TEXT NULL,
			attachment_url VARCHAR(500) NOT NULL DEFAULT '',
			status VARCHAR(20) NOT NULL DEFAULT 'new',
			created_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY status (status),
			KEY user_id (user_id)
		) {$charset_collate};";

		dbDelta( $sql );
		update_option( 'mcr_db_version', 2 );

		if ( false === get_option( 'mcr_settings' ) ) {
			add_option( 'mcr_settings', array(
				'email_notify'    => 0,
				'notify_email'    => get_option( 'admin_email' ),
				'success_message' => 'تم إرسال طلبك بنجاح، سيقوم فريقنا الطبي بالتواصل معك في أقرب وقت.',
			) );
		}
	}

	/** Adds the user_id column on old installs (requests now show in «طلباتي»). */
	public static function maybe_upgrade() {
		if ( (int) get_option( 'mcr_db_version', 0 ) < 2 ) {
			self::install();
		}
	}

	/** Requests of one visitor: by account, or by phone for requests sent before logging in. */
	public static function for_user( $uid, $phone = '' ) {
		global $wpdb;
		$t    = self::table();
		$tail = substr( preg_replace( '/\D/', '', (string) $phone ), -10 );
		if ( strlen( $tail ) >= 9 ) {
			return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$t} WHERE user_id = %d OR phone LIKE %s ORDER BY id DESC LIMIT 100", $uid, '%' . $wpdb->esc_like( $tail ) . '%' ) );
		}
		return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$t} WHERE user_id = %d ORDER BY id DESC LIMIT 100", $uid ) );
	}

	public static function insert( $data ) {
		global $wpdb;
		$data['user_id']    = get_current_user_id();
		$data['created_at'] = current_time( 'mysql' );
		$data['status']     = 'new';
		$wpdb->insert( self::table(), $data );
		return $wpdb->insert_id;
	}

	public static function get_all( $args = array() ) {
		global $wpdb;
		$table = self::table();

		$where  = array( '1=1' );
		$params = array();

		if ( ! empty( $args['category_key'] ) ) {
			$where[]  = 'category_key = %s';
			$params[] = $args['category_key'];
		}
		if ( ! empty( $args['status'] ) ) {
			$where[]  = 'status = %s';
			$params[] = $args['status'];
		}
		if ( ! empty( $args['search'] ) ) {
			$where[]  = '(name LIKE %s OR phone LIKE %s OR message LIKE %s)';
			$like     = '%' . $wpdb->esc_like( $args['search'] ) . '%';
			$params[] = $like;
			$params[] = $like;
			$params[] = $like;
		}

		$sql = "SELECT * FROM {$table} WHERE " . implode( ' AND ', $where ) . ' ORDER BY id DESC';

		if ( ! empty( $params ) ) {
			$sql = $wpdb->prepare( $sql, $params );
		}

		return $wpdb->get_results( $sql );
	}

	public static function get( $id ) {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM " . self::table() . " WHERE id = %d", $id ) );
	}

	public static function mark_read( $id ) {
		global $wpdb;
		$wpdb->update( self::table(), array( 'status' => 'read' ), array( 'id' => $id ) );
	}

	public static function delete( $id ) {
		global $wpdb;
		$wpdb->delete( self::table(), array( 'id' => $id ) );
	}

	public static function count_new() {
		global $wpdb;
		return (int) $wpdb->get_var( "SELECT COUNT(*) FROM " . self::table() . " WHERE status = 'new'" );
	}
}
