<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class MCR_Admin_Submissions {

	public static function render_list_page() {
		if ( ! current_user_can( 'manage_options' ) ) { return; }

		if ( isset( $_GET['mcr_action'], $_GET['id'] ) && isset( $_GET['_wpnonce'] ) && wp_verify_nonce( $_GET['_wpnonce'], 'mcr_row_action' ) ) {
			$id = (int) $_GET['id'];
			if ( 'delete' === $_GET['mcr_action'] ) {
				MCR_DB::delete( $id );
				echo '<div class="notice notice-success"><p>درخواست حذف شد.</p></div>';
			} elseif ( 'read' === $_GET['mcr_action'] ) {
				MCR_DB::mark_read( $id );
			}
		}

		if ( isset( $_GET['view'] ) ) {
			self::render_detail( (int) $_GET['view'] );
			return;
		}

		$args = array(
			'category_key' => isset( $_GET['category_key'] ) ? sanitize_text_field( $_GET['category_key'] ) : '',
			'status'       => isset( $_GET['status'] ) ? sanitize_text_field( $_GET['status'] ) : '',
			'search'       => isset( $_GET['s'] ) ? sanitize_text_field( $_GET['s'] ) : '',
		);

		$rows = MCR_DB::get_all( $args );
		$cats = MCR_Data::categories();
		?>
		<div class="wrap mcr-wrap">
			<h1>درخواست‌های مشاوره پزشکی</h1>

			<form method="get" class="mcr-filters">
				<input type="hidden" name="page" value="mcr-submissions" />
				<input type="text" name="s" placeholder="جستجو در نام، تلفن، متن پیام..." value="<?php echo esc_attr( $args['search'] ); ?>" />

				<select name="category_key">
					<option value="">همه بخش‌ها</option>
					<?php foreach ( $cats as $key => $cat ) : ?>
						<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $args['category_key'], $key ); ?>><?php echo esc_html( $cat['fa'] ); ?></option>
					<?php endforeach; ?>
				</select>

				<select name="status">
					<option value="">همه وضعیت‌ها</option>
					<option value="new" <?php selected( $args['status'], 'new' ); ?>>خوانده‌نشده</option>
					<option value="read" <?php selected( $args['status'], 'read' ); ?>>خوانده‌شده</option>
				</select>

				<button class="button button-primary">فیلتر</button>
				<?php if ( $args['category_key'] || $args['status'] || $args['search'] ) : ?>
					<a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=mcr-submissions' ) ); ?>">پاک کردن فیلتر</a>
				<?php endif; ?>
			</form>

			<table class="widefat striped mcr-table">
				<thead>
					<tr>
						<th>وضعیت</th>
						<th>نام</th>
						<th>تلفن / واتساب</th>
						<th>جنسیت</th>
						<th>ملیت</th>
						<th>شهر</th>
						<th>نوع بیماری</th>
						<th>تاریخ</th>
						<th>عملیات</th>
					</tr>
				</thead>
				<tbody>
					<?php if ( empty( $rows ) ) : ?>
						<tr><td colspan="9">هنوز درخواستی ثبت نشده است.</td></tr>
					<?php else : ?>
						<?php foreach ( $rows as $row ) :
							$view_url   = admin_url( 'admin.php?page=mcr-submissions&view=' . $row->id );
							$delete_url = wp_nonce_url( admin_url( 'admin.php?page=mcr-submissions&mcr_action=delete&id=' . $row->id ), 'mcr_row_action' );
							$cat_fa     = MCR_Data::category_label( $row->category_key, 'fa' );
							$gender_fa  = 'male' === $row->gender ? 'مرد' : ( 'female' === $row->gender ? 'زن' : '—' );
						?>
						<tr class="<?php echo 'new' === $row->status ? 'mcr-row-new' : ''; ?>">
							<td><?php echo 'new' === $row->status ? '<span class="mcr-dot"></span> جدید' : 'خوانده‌شده'; ?></td>
							<td><a href="<?php echo esc_url( $view_url ); ?>"><strong><?php echo esc_html( $row->name ); ?></strong></a></td>
							<td dir="ltr"><?php echo esc_html( $row->phone ); ?></td>
							<td><?php echo esc_html( $gender_fa ); ?></td>
							<td><?php echo esc_html( $row->nationality ); ?></td>
							<td><?php echo esc_html( $row->city ); ?></td>
							<td><?php echo esc_html( $cat_fa ?: '—' ); ?></td>
							<td><?php echo esc_html( date_i18n( 'Y/m/d H:i', strtotime( $row->created_at ) ) ); ?></td>
							<td>
								<a class="button button-small" href="<?php echo esc_url( $view_url ); ?>">مشاهده</a>
								<a class="button button-small mcr-danger" href="<?php echo esc_url( $delete_url ); ?>" onclick="return confirm('حذف این درخواست انجام شود؟');">حذف</a>
							</td>
						</tr>
						<?php endforeach; ?>
					<?php endif; ?>
				</tbody>
			</table>
		</div>
		<?php
	}

	private static function render_detail( $id ) {
		$row = MCR_DB::get( $id );
		if ( ! $row ) {
			echo '<div class="wrap"><p>درخواست یافت نشد.</p></div>';
			return;
		}
		MCR_DB::mark_read( $id );
		$cat       = MCR_Data::categories();
		$cat_info  = isset( $cat[ $row->category_key ] ) ? $cat[ $row->category_key ] : null;
		$gender_fa = 'male' === $row->gender ? 'مرد' : ( 'female' === $row->gender ? 'زن' : '—' );
		$back_url  = admin_url( 'admin.php?page=mcr-submissions' );
		$wa_number = preg_replace( '/[^0-9]/', '', $row->phone );
		?>
		<div class="wrap mcr-wrap">
			<a href="<?php echo esc_url( $back_url ); ?>" class="button">&rarr; بازگشت به لیست</a>
			<h1>جزئیات درخواست #<?php echo (int) $row->id; ?></h1>

			<div class="mcr-detail-card">
				<table class="widefat mcr-detail-table">
					<tr><th>نام</th><td><?php echo esc_html( $row->name ); ?></td></tr>
					<tr><th>تلفن / واتساب</th><td dir="ltr">
						<?php echo esc_html( $row->phone ); ?>
						&nbsp; <a target="_blank" href="https://wa.me/<?php echo esc_attr( $wa_number ); ?>" class="button button-small">باز کردن در واتساب</a>
					</td></tr>
					<tr><th>جنسیت</th><td><?php echo esc_html( $gender_fa ); ?></td></tr>
					<tr><th>ملیت</th><td><?php echo esc_html( $row->nationality ); ?></td></tr>
					<tr><th>شهر (ایران)</th><td><?php echo esc_html( $row->city ); ?></td></tr>
					<tr><th>نوع بیماری (بخش مربوطه)</th><td>
						<?php if ( $cat_info ) : ?>
							<?php echo esc_html( $cat_info['fa'] ); ?>
							<span class="mcr-muted">(عربی: <?php echo esc_html( $cat_info['ar'] ); ?>)</span>
						<?php else : ?>—<?php endif; ?>
					</td></tr>
					<tr><th>تاریخ ارسال</th><td><?php echo esc_html( date_i18n( 'Y/m/d H:i', strtotime( $row->created_at ) ) ); ?></td></tr>
					<tr><th>شرح مشکل</th><td class="mcr-message"><?php echo nl2br( esc_html( $row->message ) ); ?></td></tr>
					<tr><th>پیوست</th><td>
						<?php if ( $row->attachment_url ) : ?>
							<a href="<?php echo esc_url( class_exists( 'DLZ_Security' ) ? DLZ_Security::file_url( $row->attachment_url ) : $row->attachment_url ); ?>" target="_blank" rel="noopener">مشاهده / دانلود فایل پیوست</a>
						<?php else : ?>
							بدون پیوست
						<?php endif; ?>
					</td></tr>
				</table>
			</div>
		</div>
		<?php
	}
}
