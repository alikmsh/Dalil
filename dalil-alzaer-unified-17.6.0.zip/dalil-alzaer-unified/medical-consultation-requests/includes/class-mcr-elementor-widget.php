<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Core\Kits\Documents\Tabs\Global_Colors;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;

class MCR_Elementor_Widget extends Widget_Base {

	public function get_name() { return 'mcr_consultation_form'; }
	public function get_title() { return 'درخواست مشاوره پزشکی'; }
	public function get_icon() { return 'eicon-form-horizontal'; }
	public function get_categories() { return array( 'dalil-alzaer' ); }
	public function get_keywords() { return array( 'مشاوره', 'پزشکی', 'فرم', 'medical', 'consultation', 'form' ); }

	protected function register_controls() {

		// ===== CONTENT TAB =====
		$this->start_controls_section( 'content_section', array(
			'label' => 'محتوا',
			'tab'   => Controls_Manager::TAB_CONTENT,
		) );

		$options = array( '' => 'بدون پیش‌فرض (کاربر خودش انتخاب کند)' );
		foreach ( MCR_Data::categories() as $key => $cat ) {
			$options[ $key ] = $cat['fa'];
		}

		$this->add_control( 'default_category', array(
			'label'       => 'بیماری / بخش پیش‌فرض',
			'type'        => Controls_Manager::SELECT,
			'options'     => $options,
			'default'     => '',
			'description' => 'اگر انتخاب کنید، این گزینه از قبل در فرم انتخاب‌شده نمایش داده می‌شود (مثلاً برای صفحه‌ی اختصاصی یک بخش).',
		) );

		$this->add_control( 'lock_category', array(
			'label'        => 'قفل شدن روی این بخش (کاربر نتواند تغییر دهد)',
			'type'         => Controls_Manager::SWITCHER,
			'default'      => '',
			'condition'    => array( 'default_category!' => '' ),
			'description'  => 'در صورت فعال بودن، نوار انتخاب بخش پزشکی مخفی می‌شود و فقط همین بخش برای کاربر ثبت می‌شود.',
		) );

		$this->end_controls_section();

		// ===== STYLE TAB =====
		$this->start_controls_section( 'style_section', array(
			'label' => 'ظاهر (سرمه‌ای و طلایی)',
			'tab'   => Controls_Manager::TAB_STYLE,
		) );

		$this->add_control( 'gold_color', array(
			'label'       => 'رنگ طلایی (اصلی)',
			'type'        => Controls_Manager::COLOR,
			'default'     => '#D4AF37',
			'global'      => array(
				'default' => Global_Colors::COLOR_PRIMARY,
			),
			'description' => 'رنگ دکمه‌ها، آیکون‌ها و برجسته‌ها.',
			'selectors'   => array(
				'{{WRAPPER}} .mcr-widget' => '--mcr-gold: {{VALUE}};',
			),
		) );

		$this->add_control( 'navy_color', array(
			'label'       => 'رنگ سرمه‌ای (پس‌زمینه)',
			'type'        => Controls_Manager::COLOR,
			'default'     => '#0B1B33',
			'global'      => array(
				'default' => Global_Colors::COLOR_SECONDARY,
			),
			'description' => 'رنگ پس‌زمینه‌ی کارت فرم.',
			'selectors'   => array(
				'{{WRAPPER}} .mcr-widget' => '--mcr-navy: {{VALUE}};',
			),
		) );

		$this->add_control( 'radius', array(
			'label'     => 'گردی گوشه‌ها (px)',
			'type'      => Controls_Manager::SLIDER,
			'range'     => array( 'px' => array( 'min' => 0, 'max' => 40 ) ),
			'default'   => array( 'size' => 16, 'unit' => 'px' ),
			'selectors' => array(
				'{{WRAPPER}} .mcr-widget' => '--mcr-radius: {{SIZE}}{{UNIT}};',
			),
		) );

		$this->add_group_control( Group_Control_Typography::get_type(), array(
			'name'     => 'body_typography',
			'label'    => 'فونت',
			'global'   => array( 'default' => Global_Typography::TYPOGRAPHY_TEXT ),
			'selector' => '{{WRAPPER}} .mcr-widget',
		) );

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		mcr_render_form(
			$settings['gold_color'],
			$settings['navy_color'],
			$settings['default_category'],
			'yes' === $settings['lock_category']
		);
	}
}
