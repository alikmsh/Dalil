<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class MCR_Settings {

	public static function get() {
		$defaults = array(
			'email_notify'    => 0,
			'notify_email'    => get_option( 'admin_email' ),
			'success_message' => 'تم إرسال طلبك بنجاح، سيقوم فريقنا الطبي بالتواصل معك في أقرب وقت.',
		);
		return wp_parse_args( get_option( 'mcr_settings', array() ), $defaults );
	}

	public static function render_page() {
		if ( ! current_user_can( 'manage_options' ) ) { return; }

		if ( isset( $_POST['mcr_settings_nonce'] ) && wp_verify_nonce( $_POST['mcr_settings_nonce'], 'mcr_save_settings' ) ) {
			$settings = array(
				'email_notify'    => isset( $_POST['email_notify'] ) ? 1 : 0,
				'notify_email'    => sanitize_email( $_POST['notify_email'] ),
				'success_message' => sanitize_textarea_field( $_POST['success_message'] ),
			);
			update_option( 'mcr_settings', $settings );
			echo '<div class="notice notice-success"><p>تنظیمات ذخیره شد.</p></div>';
		}

		$s = self::get();
		?>
		<div class="wrap mcr-wrap">
			<h1>تنظیمات فرم مشاوره پزشکی</h1>
			<form method="post">
				<?php wp_nonce_field( 'mcr_save_settings', 'mcr_settings_nonce' ); ?>

				<table class="form-table">
					<tr>
						<th scope="row">اطلاع‌رسانی ایمیلی</th>
						<td>
							<label>
								<input type="checkbox" name="email_notify" value="1" <?php checked( $s['email_notify'], 1 ); ?> />
								علاوه بر نمایش در پنل، هنگام دریافت درخواست جدید به ادمین ایمیل هم ارسال شود
							</label>
							<p class="description">پیش‌فرض غیرفعال است — همه‌ی درخواست‌ها در هر صورت در قسمت «درخواست‌ها» نمایش داده می‌شوند و نیازی به ایمیل نیست.</p>
						</td>
					</tr>
					<tr>
						<th scope="row">ایمیل دریافت‌کننده</th>
						<td>
							<input type="email" name="notify_email" class="regular-text" value="<?php echo esc_attr( $s['notify_email'] ); ?>" />
							<p class="description">فقط در صورت فعال بودن گزینه‌ی بالا استفاده می‌شود.</p>
						</td>
					</tr>
					<tr>
						<th scope="row">پیام موفقیت به کاربر (عربی)</th>
						<td>
							<textarea name="success_message" class="large-text" rows="3" dir="rtl"><?php echo esc_textarea( $s['success_message'] ); ?></textarea>
							<p class="description">این پیام بعد از ارسال موفق فرم به کاربر عرب‌زبان نمایش داده می‌شود.</p>
						</td>
					</tr>
				</table>

				<?php submit_button( 'ذخیره تنظیمات' ); ?>
			</form>
		</div>
		<?php
	}
}
