<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class MCR_Ajax {

	public static function init() {
		add_action( 'wp_ajax_mcr_submit', array( __CLASS__, 'handle_submit' ) );
		add_action( 'wp_ajax_nopriv_mcr_submit', array( __CLASS__, 'handle_submit' ) );
	}

	public static function handle_submit() {
		check_ajax_referer( 'mcr_submit_nonce', 'nonce' );

		// at most 5 requests per visitor in 10 minutes
		$ip  = isset( $_SERVER['REMOTE_ADDR'] ) ? preg_replace( '/[^0-9a-f:.]/i', '', (string) $_SERVER['REMOTE_ADDR'] ) : '';
		$rlk = 'mcr_rl_' . md5( $ip . '|' . get_current_user_id() );
		$hit = (int) get_transient( $rlk );
		if ( $hit >= 5 ) {
			wp_send_json_error( array( 'message' => 'تم إرسال عدة طلبات، يرجى المحاولة بعد قليل.' ) );
		}
		set_transient( $rlk, $hit + 1, 10 * MINUTE_IN_SECONDS );
		$digits = array( '۰' => '0', '۱' => '1', '۲' => '2', '۳' => '3', '۴' => '4', '۵' => '5', '۶' => '6', '۷' => '7', '۸' => '8', '۹' => '9', '٠' => '0', '١' => '1', '٢' => '2', '٣' => '3', '٤' => '4', '٥' => '5', '٦' => '6', '٧' => '7', '٨' => '8', '٩' => '9' );

		$name         = isset( $_POST['name'] ) ? mb_substr( sanitize_text_field( wp_unslash( $_POST['name'] ) ), 0, 120 ) : '';
		$phone        = isset( $_POST['phone'] ) ? preg_replace( '/[^0-9+ ]/', '', strtr( sanitize_text_field( wp_unslash( $_POST['phone'] ) ), $digits ) ) : '';
		$gender       = isset( $_POST['gender'] ) ? sanitize_text_field( wp_unslash( $_POST['gender'] ) ) : '';
		$nationality  = isset( $_POST['nationality'] ) ? sanitize_text_field( wp_unslash( $_POST['nationality'] ) ) : '';
		$city         = isset( $_POST['city'] ) ? sanitize_text_field( wp_unslash( $_POST['city'] ) ) : '';
		$category_key = isset( $_POST['category_key'] ) ? sanitize_text_field( wp_unslash( $_POST['category_key'] ) ) : '';
		$message      = isset( $_POST['message'] ) ? sanitize_textarea_field( wp_unslash( $_POST['message'] ) ) : '';

		// server-side limits: whatever the browser sends, only sane values are stored
		$phone       = substr( $phone, 0, 30 );
		$gender      = mb_substr( $gender, 0, 20 );
		$nationality = mb_substr( $nationality, 0, 60 );
		$city        = mb_substr( $city, 0, 80 );
		$message     = mb_substr( $message, 0, 4000 );
		if ( strlen( preg_replace( '/\D/', '', $phone ) ) < 7 ) {
			$phone = '';
		}
		if ( ! $name || ! $phone || ! $gender || ! $nationality || ! $city || ! $category_key || ! $message ) {
			wp_send_json_error( array( 'message' => 'يرجى تعبئة جميع الحقول المطلوبة.' ) );
		}

		$valid_categories = array_keys( MCR_Data::categories() );
		if ( ! in_array( $category_key, $valid_categories, true ) ) {
			wp_send_json_error( array( 'message' => 'خطأ في تحديد القسم الطبي.' ) );
		}

		$attachment_url = '';
		if ( ! empty( $_FILES['attachment']['name'] ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
			require_once ABSPATH . 'wp-admin/includes/image.php';
			require_once ABSPATH . 'wp-admin/includes/media.php';

			$allowed_types = array( 'jpg', 'jpeg', 'png', 'webp', 'pdf' );
			$filename      = sanitize_file_name( $_FILES['attachment']['name'] );
			$ext           = strtolower( pathinfo( $filename, PATHINFO_EXTENSION ) );

			if ( ! in_array( $ext, $allowed_types, true ) ) {
				wp_send_json_error( array( 'message' => 'صيغة الملف غير مدعومة (JPG, PNG, PDF فقط).' ) );
			}
			if ( $_FILES['attachment']['size'] > 5 * 1024 * 1024 ) {
				wp_send_json_error( array( 'message' => 'حجم الملف يجب أن يكون أقل من 5 ميغابايت.' ) );
			}

			if ( ! empty( $_FILES['attachment']['error'] ) || ! is_uploaded_file( $_FILES['attachment']['tmp_name'] ) ) {
				wp_send_json_error( array( 'message' => 'تعذّر رفع الملف، حاول مرة أخرى.' ) );
			}
			$chk = wp_check_filetype_and_ext( $_FILES['attachment']['tmp_name'], $filename, array( 'jpg|jpeg' => 'image/jpeg', 'png' => 'image/png', 'webp' => 'image/webp', 'pdf' => 'application/pdf' ) );
			if ( empty( $chk['type'] ) || ( 'application/pdf' !== $chk['type'] && ! @getimagesize( $_FILES['attachment']['tmp_name'] ) ) || ( 'application/pdf' === $chk['type'] && '%PDF' !== (string) file_get_contents( $_FILES['attachment']['tmp_name'], false, null, 0, 4 ) ) ) { // phpcs:ignore
				wp_send_json_error( array( 'message' => 'صيغة الملف غير مدعومة (JPG, PNG, PDF فقط).' ) );
			}
			if ( class_exists( 'DLZ_Security' ) ) {
				DLZ_Security::private_uploads( true );
			}
			$upload = wp_handle_upload( $_FILES['attachment'], array( 'test_form' => false, 'unique_filename_callback' => function ( $dir, $name, $ext ) { return 'doc-' . wp_generate_password( 24, false ) . strtolower( $ext ); }, 'mimes' => array( 'jpg|jpeg' => 'image/jpeg', 'png' => 'image/png', 'webp' => 'image/webp', 'pdf' => 'application/pdf' ) ) );
			if ( class_exists( 'DLZ_Security' ) ) {
				DLZ_Security::private_uploads( false );
			}
			if ( isset( $upload['url'] ) && empty( $upload['error'] ) ) {
				$attachment_url = $upload['url'];
			}
		}

		$id = MCR_DB::insert( array(
			'category_key'   => $category_key,
			'name'           => $name,
			'phone'          => $phone,
			'gender'         => $gender,
			'nationality'    => $nationality,
			'city'           => $city,
			'message'        => $message,
			'attachment_url' => $attachment_url,
		) );
		if ( $id && class_exists( 'DLZ_Inbox' ) ) {
			DLZ_Inbox::add( 'medical', MCR_Data::category_label( $category_key, 'fa' ) . ' — ' . $name, $phone . ( $city ? ' · ' . $city : '' ), admin_url( 'admin.php?page=mcr-submissions&view=' . $id ) );
		}

		// Optional email notification (off by default, per settings)
		$settings = MCR_Settings::get();
		if ( ! empty( $settings['email_notify'] ) && ! empty( $settings['notify_email'] ) ) {
			$subject = 'درخواست مشاوره پزشکی جدید - ' . $name;
			$body    = "نام: {$name}\nتلفن: {$phone}\nنوع بیماری: " . MCR_Data::category_label( $category_key, 'fa' ) . "\nپیام: {$message}\n\nمشاهده در پنل: " . admin_url( 'admin.php?page=mcr-submissions&view=' . $id );
			wp_mail( $settings['notify_email'], $subject, $body );
		}

		wp_send_json_success( array( 'message' => $settings['success_message'] ) );
	}
}
MCR_Ajax::init();
