/* Dalil Al Zaer — SMS login (phone → code boxes → done) + the legacy profile setup / dashboard. No jQuery. */
(function () {
	'use strict';
	var d = document, cfg = window.MPSMSLogin || {};
	/* pull the block up under the app header when only empty theme / Elementor spacing sits above it */
	var lift = window.DLZLift || (window.DLZLift = function (root) {
		if (!root || root.__lift) return;
		root.__lift = 1;
		var pt = d.querySelector('.dlz-ptitle'), hd = pt && pt.offsetHeight ? pt : d.getElementById('dsh-header'), ab = d.getElementById('wpadminbar'); // under the page title when there is one
		var y = window.scrollY || 0, ref = 0;
		if (hd && hd.offsetHeight) ref = getComputedStyle(hd).position === 'fixed' ? hd.offsetHeight : hd.getBoundingClientRect().bottom + y;
		else if (ab && getComputedStyle(ab).position === 'fixed') ref = ab.offsetHeight;
		var gap = root.getBoundingClientRect().top + y - ref - 10;
		if (gap < 6 || gap > 420) return;
		var w = d.createTreeWalker(d.body, NodeFilter.SHOW_ELEMENT), el;
		while ((el = w.nextNode())) {
			if (el === root) break;
			if (el.contains(root) || (hd && (el === hd || hd.contains(el))) || /^(SCRIPT|STYLE|LINK|META|NOSCRIPT|TEMPLATE)$/.test(el.tagName)) continue;
			var r = el.getBoundingClientRect();
			if (r.width < 2 || r.height < 2 || r.bottom + y <= ref) continue;
			var cs = getComputedStyle(el);
			if (cs.visibility === 'hidden' || cs.position === 'fixed' || cs.position === 'absolute' || +cs.opacity === 0) continue;
			if (/^(IMG|SVG|svg|VIDEO|IFRAME|INPUT|BUTTON|CANVAS|SELECT|TEXTAREA)$/.test(el.tagName) || [].some.call(el.childNodes, function (n) { return n.nodeType === 3 && n.textContent.trim(); })) return;
		}
		root.style.marginTop = (-gap) + 'px';
	});
	function digits(v) { return String(v || '').replace(/[۰-۹]/g, function (c) { return '۰۱۲۳۴۵۶۷۸۹'.indexOf(c); }).replace(/[٠-٩]/g, function (c) { return '٠١٢٣٤٥٦٧٨٩'.indexOf(c); }).replace(/\D/g, ''); }
	function phone(v) { v = digits(v); if (v.indexOf('0098') === 0) v = '0' + v.slice(4); else if (v.indexOf('98') === 0 && v.length === 12) v = '0' + v.slice(2); if (v.indexOf('9') === 0 && v.length === 10) v = '0' + v; return v; }
	function post(data) {
		var f = new FormData();
		Object.keys(data).forEach(function (k) { f.append(k, data[k]); });
		f.append('nonce', cfg.nonce || '');
		return fetch(cfg.ajax, { method: 'POST', body: f, credentials: 'same-origin' }).then(function (r) { return r.json().catch(function () { return { success: false, data: { message: 'تعذّر الاتصال بالخادم.' } }; }); });
	}
	function pretty(p) { return p.length === 11 ? p.slice(0, 4) + ' ' + p.slice(4, 7) + ' ' + p.slice(7) : p; }

	function initLogin(root) {
		if (root.__mpl) return; root.__mpl = 1;
		var steps = root.querySelectorAll('.mpl-step'), msg = root.querySelector('.mpl-msg');
		var fPhone = root.querySelector('.mpl-f-phone'), fOtp = root.querySelector('.mpl-f-otp');
		var inPhone = root.querySelector('.mpl-phone'), boxes = [].slice.call(root.querySelectorAll('.mpl-otp input'));
		var wait = root.querySelector('.mpl-wait'), again = root.querySelector('.mpl-again');
		var token = '', cur = '', timer = 0, busy = false, otpAbort = null;
		/* ---------- country ---------- */
		var cc = root.querySelector('.mpl-cc'), pick = root.querySelector('.mpl-pick'), opts = [].slice.call(root.querySelectorAll('.mpl-opt'));
		/* the sheet lives at the end of <body>, so no theme / Elementor wrapper can trap it inside the card */
		if (pick) { var portal = d.createElement('div'); portal.className = 'mpl mpl-portal'; portal.setAttribute('dir', 'rtl'); portal.appendChild(pick); d.body.appendChild(portal); }
		var ctry = 'ir', dial = '+98', lens = [10];
		function setCountry(k, quiet) {
			var o = opts.filter(function (x) { return x.getAttribute('data-k') === k; })[0];
			if (!o) return;
			ctry = k; dial = o.getAttribute('data-dial'); lens = o.getAttribute('data-len').split(',').map(Number);
			opts.forEach(function (x) { var on = x === o; x.classList.toggle('is-on', on); x.setAttribute('aria-selected', on ? 'true' : 'false'); });
			cc.querySelector('.mpl-cc-f').innerHTML = o.querySelector('.mpl-opt-f').innerHTML;
			cc.querySelector('b').textContent = dial;
			inPhone.placeholder = o.getAttribute('data-ex') || '';
			root.setAttribute('data-ctry', k);
			try { localStorage.setItem('mpl_ctry', k); } catch (e) {}
			if (!quiet) { cc.classList.remove('is-pop'); void cc.offsetWidth; cc.classList.add('is-pop'); }
		}
		/* the country list slides up from the bottom of the screen */
		var pickT = 0;
		function openPick(on) {
			if (!pick) return;
			clearTimeout(pickT);
			cc.setAttribute('aria-expanded', on ? 'true' : 'false');
			root.classList.toggle('is-picking', on);
			d.documentElement.classList.toggle('mpl-lock', on);
			if (on) {
				pick.hidden = false;
				requestAnimationFrame(function () { requestAnimationFrame(function () { pick.classList.add('is-open'); }); });
				var cur0 = pick.querySelector('.mpl-opt.is-on'); if (cur0) setTimeout(function () { cur0.scrollIntoView({ block: 'nearest' }); }, 60);
			} else {
				pick.classList.remove('is-open');
				pickT = setTimeout(function () { pick.hidden = true; }, 260);
			}
		}
		if (cc && pick) {
			cc.addEventListener('click', function () { openPick(!pick.classList.contains('is-open')); });
			pick.querySelector('.mpl-pick-x').addEventListener('click', function () { openPick(false); cc.focus(); });
			pick.querySelector('.mpl-pick-bd').addEventListener('click', function () { openPick(false); });
			opts.forEach(function (o) { o.addEventListener('click', function () { setCountry(o.getAttribute('data-k')); openPick(false); say(''); root.querySelector('.mpl-in').classList.remove('is-bad'); inPhone.focus(); }); });
			root.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !pick.hidden) { openPick(false); cc.focus(); } });
			d.addEventListener('click', function (e) { if (!pick.hidden && !e.target.closest('.mpl-pick,.mpl-cc')) openPick(false); });
			var saved = ''; try { saved = localStorage.getItem('mpl_ctry') || ''; } catch (e) {}
			if (saved) setCountry(saved, true);
		}
		/* «+964…» / «00964…» typed or pasted → switch the country by itself */
		function sniff() {
			var raw = String(inPhone.value || '').replace(/[۰-۹]/g, function (c) { return '۰۱۲۳۴۵۶۷۸۹'.indexOf(c); }).replace(/[٠-٩]/g, function (c) { return '٠١٢٣٤٥٦٧٨٩'.indexOf(c); }).replace(/[^\d+]/g, '');
			if (raw.indexOf('00') === 0) raw = '+' + raw.slice(2);
			if (raw.charAt(0) !== '+') return false;
			var best = null;
			opts.forEach(function (o) { var dl = o.getAttribute('data-dial'); if (raw.indexOf(dl) === 0 && (!best || dl.length > best.getAttribute('data-dial').length)) best = o; });
			if (!best) return false;
			setCountry(best.getAttribute('data-k'));
			inPhone.value = raw.slice(best.getAttribute('data-dial').length);
			return true;
		}
		function national() { var v = digits(inPhone.value); return ctry === 'ir' ? phone(v) : v.replace(/^0+/, ''); }
		function valid(v) { return ctry === 'ir' ? /^09\d{9}$/.test(v) : lens.indexOf(v.length) > -1; }
		function badMsg() { var o = pick && pick.querySelector('.mpl-opt.is-on'); return ctry === 'ir' ? 'يُرجى إدخال رقم هاتف إيراني صحيح يبدأ بـ 09 (11 رقماً).' : 'يُرجى إدخال رقم هاتف صحيح في ' + (o ? o.querySelector('.mpl-opt-n').textContent : 'هذه الدولة') + '. مثال: ' + (inPhone.placeholder || ''); }
		function show(name) {
			steps.forEach(function (s) { s.hidden = s.getAttribute('data-step') !== name; });
			root.setAttribute('data-step', name);
		}
		function say(t, bad) { msg.textContent = t || ''; msg.hidden = !t; msg.classList.toggle('is-err', !!bad); }
		function load(btn, on, label) {
			busy = on; btn.disabled = on; btn.classList.toggle('is-busy', on);
			if (label) btn.querySelector('span').textContent = label;
		}
		function countdown(sec) {
			clearInterval(timer);
			var n = sec;
			again.hidden = true; wait.hidden = false;
			function tick() { var m = Math.floor(n / 60), s = n % 60; wait.querySelector('b').textContent = m + ':' + (s < 10 ? '0' : '') + s; }
			tick();
			timer = setInterval(function () { n--; if (n <= 0) { clearInterval(timer); wait.hidden = true; again.hidden = false; } else tick(); }, 1000);
		}
		function code() { return boxes.map(function (b) { return digits(b.value); }).join(''); }
		function fill(v) { v = digits(v).slice(0, boxes.length); boxes.forEach(function (b, i) { b.value = v.charAt(i) || ''; b.classList.toggle('is-on', !!b.value); }); var nx = boxes[Math.min(v.length, boxes.length - 1)]; if (nx) nx.focus(); if (v.length === boxes.length) submitOtp(); }
		function webotp() {
			if (!('OTPCredential' in window) || !navigator.credentials) return;
			try { otpAbort = new AbortController(); } catch (e) { return; }
			navigator.credentials.get({ otp: { transport: ['sms'] }, signal: otpAbort.signal }).then(function (o) { if (o && o.code) fill(o.code); }).catch(function () {});
		}
		function send(btn) {
			if (busy) return;
			sniff();
			cur = national();
			inPhone.value = cur;
			if (!valid(cur)) { say(badMsg(), true); inPhone.focus(); root.querySelector('.mpl-in').classList.add('is-bad'); return; }
			root.querySelector('.mpl-in').classList.remove('is-bad');
			say('');
			var label = btn.querySelector('span') ? btn.querySelector('span').textContent : '';
			load(btn, true, 'جارٍ الإرسال…');
			post({ action: 'mp_send_otp', phone: cur, country: ctry, website: (fPhone.website || {}).value || '' }).then(function (r) {
				load(btn, false, label);
				if (!r || !r.success) { say((r && r.data && r.data.message) || 'تعذّر إرسال الرمز.', true); return; }
				token = r.data.token;
				root.querySelector('.mpl-num').textContent = r.data.show || (ctry === 'ir' ? pretty(cur) : dial + ' ' + cur);
				show('otp');
				fill('');
				countdown(parseInt(r.data.wait, 10) || 60);
				say('');
				webotp();
				setTimeout(function () { boxes[0].focus(); }, 60);
			}).catch(function () { load(btn, false, label); say('تعذّر الاتصال بالخادم، حاول مرة أخرى.', true); });
		}
		function submitOtp() {
			var c = code(), btn = root.querySelector('.mpl-verify');
			if (busy) return;
			if (c.length !== boxes.length) { say('يُرجى إدخال الرمز كاملاً (' + boxes.length + ' أرقام).', true); return; }
			say('');
			load(btn, true, 'جارٍ التحقق…');
			post({ action: 'mp_verify_otp', phone: cur, country: ctry, otp: c, token: token }).then(function (r) {
				if (r && r.success) {
					if (otpAbort) try { otpAbort.abort(); } catch (e) {}
					clearInterval(timer);
					show('done'); say('');
					setTimeout(function () { location.reload(); }, 650);
					return;
				}
				load(btn, false, 'تأكيد وتسجيل الدخول');
				var dt = (r && r.data) || {};
				say(dt.message || 'الرمز غير صحيح.', true);
				root.querySelector('.mpl-otp').classList.remove('is-shake'); void root.offsetWidth; root.querySelector('.mpl-otp').classList.add('is-shake');
				if (dt.code === 'expired') { token = ''; clearInterval(timer); wait.hidden = true; again.hidden = false; }
				fill('');
			}).catch(function () { load(btn, false, 'تأكيد وتسجيل الدخول'); say('تعذّر الاتصال بالخادم، حاول مرة أخرى.', true); });
		}
		fPhone.addEventListener('submit', function (e) { e.preventDefault(); send(fPhone.querySelector('.mpl-send')); });
		inPhone.addEventListener('input', function () { if (!sniff()) { var raw = String(inPhone.value || ''), v = (/^\s*(\+|00)/.test(raw) ? '+' : '') + digits(raw.replace(/^\s*00/, '')); if (v !== inPhone.value) inPhone.value = v; } root.querySelector('.mpl-in').classList.remove('is-bad'); });
		fOtp.addEventListener('submit', function (e) { e.preventDefault(); submitOtp(); });
		boxes.forEach(function (b, i) {
			b.addEventListener('input', function () {
				var v = digits(b.value);
				if (v.length > 1) { fill(code().slice(0, i) + v); return; }
				b.value = v; b.classList.toggle('is-on', !!v);
				if (v && i < boxes.length - 1) boxes[i + 1].focus();
				if (code().length === boxes.length) submitOtp();
			});
			b.addEventListener('keydown', function (e) {
				if (e.key === 'Backspace' && !b.value && i > 0) { boxes[i - 1].value = ''; boxes[i - 1].classList.remove('is-on'); boxes[i - 1].focus(); e.preventDefault(); }
				if (e.key === 'ArrowLeft' && i < boxes.length - 1) boxes[i + 1].focus();
				if (e.key === 'ArrowRight' && i > 0) boxes[i - 1].focus();
			});
			b.addEventListener('paste', function (e) { var t = (e.clipboardData || window.clipboardData).getData('text'); if (t) { e.preventDefault(); fill(t); } });
			b.addEventListener('focus', function () { b.select(); });
		});
		again.addEventListener('click', function () { send(again); });
		root.querySelector('.mpl-change').addEventListener('click', function () { clearInterval(timer); token = ''; if (otpAbort) try { otpAbort.abort(); } catch (e) {} show('phone'); say(''); inPhone.focus(); });
		show('phone');
	}

	/* ---------- legacy: profile setup + dashboard (only when the app account page is not active) ---------- */
	function msgEl(scope) { return scope.querySelector('.mp-msg') || scope.querySelector('.mp-dashboard-msg'); }
	function say2(scope, t, bad) { var m = msgEl(scope); if (!m) return; m.textContent = t || ''; m.classList.toggle('error', !!bad); }
	function upload(file) { var f = new FormData(); f.append('action', 'mp_upload_avatar'); f.append('nonce', cfg.nonce || ''); f.append('avatar', file); return fetch(cfg.ajax, { method: 'POST', body: f, credentials: 'same-origin' }).then(function (r) { return r.json(); }); }
	function initSetup(s) {
		var gender = '';
		s.querySelectorAll('.mp-gender button').forEach(function (b) { b.addEventListener('click', function () { gender = b.getAttribute('data-g'); s.querySelectorAll('.mp-gender button').forEach(function (x) { x.classList.toggle('active', x === b); }); }); });
		var btn = s.querySelector('.mp-complete'); if (!btn) return;
		btn.addEventListener('click', function () {
			if (!gender) { say2(s, 'يرجى اختيار الجنس.', true); return; }
			btn.disabled = true;
			post({ action: 'mp_complete_profile', first_name: s.querySelector('.mp-first').value, last_name: s.querySelector('.mp-last').value, gender: gender }).then(function (r) {
				if (!r.success) { say2(s, r.data.message, true); btn.disabled = false; return; }
				var file = s.querySelector('.mp-avatar-setup').files[0];
				if (!file) { location.reload(); return; }
				upload(file).then(function () { location.reload(); }).catch(function () { location.reload(); });
			}).catch(function () { btn.disabled = false; say2(s, 'حدث خطأ.', true); });
		});
	}
	function initDash(dd) {
		var act = dd.querySelector('.mp-edit-gender button.active'), gender = act ? act.getAttribute('data-g') : '';
		var modal = dd.querySelector('.mp-modal');
		dd.querySelectorAll('.mp-settings,.mp-settings-trigger').forEach(function (b) { b.addEventListener('click', function () { modal.style.display = 'flex'; }); });
		var close = dd.querySelector('.mp-close'); if (close) close.addEventListener('click', function () { modal.style.display = 'none'; });
		if (modal) modal.addEventListener('click', function (e) { if (e.target === modal) modal.style.display = 'none'; });
		dd.querySelectorAll('.mp-edit-gender button').forEach(function (b) { b.addEventListener('click', function () { gender = b.getAttribute('data-g'); dd.querySelectorAll('.mp-edit-gender button').forEach(function (x) { x.classList.toggle('active', x === b); }); }); });
		var save = dd.querySelector('.mp-save-profile');
		if (save) save.addEventListener('click', function () {
			save.disabled = true;
			post({ action: 'mp_update_profile', first_name: dd.querySelector('.mp-edit-first').value, last_name: dd.querySelector('.mp-edit-last').value, gender: gender }).then(function (r) { if (r.success) location.reload(); else { save.disabled = false; say2(dd, r.data.message, true); } });
		});
		var cam = dd.querySelector('.mp-camera'), inp = dd.querySelector('.mp-avatar-input');
		if (cam && inp) { cam.addEventListener('click', function () { inp.click(); }); inp.addEventListener('change', function () { if (inp.files[0]) upload(inp.files[0]).then(function (r) { if (r.success) location.reload(); else say2(dd, r.data.message, true); }); }); }
	}
	function boot() {
		d.querySelectorAll('.mpl').forEach(function (m) { initLogin(m); setTimeout(function () { lift(m); }, 0); });
		d.querySelectorAll('.mp-profile-setup').forEach(initSetup);
		d.querySelectorAll('.mp-dashboard').forEach(initDash);
	}
	if (d.readyState === 'loading') d.addEventListener('DOMContentLoaded', boot); else boot();
	window.addEventListener('elementor/frontend/init', function () { setTimeout(boot, 300); });
})();
