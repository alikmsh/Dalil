<?php
if (!defined('ABSPATH')) exit;

final class MP_SMS_User_Panel {
    const OPT='mp_sms_login_options';
    const NONCE='mp_sms_login_nonce';

    public function __construct(){
        add_action('admin_menu',[$this,'admin_menu']);
        add_action('admin_init',[$this,'register_settings']);
        add_action('wp_enqueue_scripts',[$this,'enqueue']);
        add_filter('show_admin_bar',[$this,'show_admin_bar']);
        add_action('wp_ajax_nopriv_mp_send_otp',[$this,'send_otp']);
        add_action('wp_ajax_mp_send_otp',[$this,'send_otp']);
        add_action('wp_ajax_nopriv_mp_verify_otp',[$this,'verify_otp']);
        add_action('wp_ajax_mp_verify_otp',[$this,'verify_otp']);
        add_action('wp_ajax_mp_complete_profile',[$this,'complete_profile']);
        add_action('wp_ajax_mp_update_profile',[$this,'update_profile']);
        add_action('wp_ajax_mp_upload_avatar',[$this,'upload_avatar']);
        add_shortcode('mp_sms_login',[$this,'shortcode']);
        add_shortcode('mp_user_panel',[$this,'panel_shortcode']);
        add_action('elementor/widgets/register',[$this,'elementor_widget']);
        add_action('admin_post_mp_sms_test',[$this,'sms_test']);
    }

    public static function defaults(){return [
        'username'=>'','password'=>'','body_id'=>'','otp_length'=>6,'otp_expire'=>120,
        'resend_wait'=>60,'max_per_hour'=>5,'max_ip_per_hour'=>20,
        'intl_format'=>'00'
    ];}

    public function opts(){$o=wp_parse_args(get_option(self::OPT,[]),self::defaults());if(class_exists('DLZ_Security'))$o['password']=DLZ_Security::unseal($o['password']);return $o;}

    public function admin_menu(){
        add_options_page('ورود پیامکی','ورود پیامکی','manage_options','mp-sms-login',[$this,'settings_page']);
    }

    public function register_settings(){
        register_setting('mp_sms_login_group',self::OPT,[
            'sanitize_callback'=>function($in){
                $d=self::defaults();
                return [
                    'username'=>sanitize_text_field($in['username']??''),
                    // the panel password is kept encrypted; an empty field keeps the saved one
                    'password'=>(function($v){$old=(array)get_option(self::OPT,[]);$v=trim((string)$v);if($v==='')return $old['password']??'';return class_exists('DLZ_Security')?DLZ_Security::seal($v):$v;})(wp_unslash($in['password']??'')),
                    'body_id'=>absint($in['body_id']??0),
                    'otp_length'=>max(4,min(8,absint($in['otp_length']??$d['otp_length']))),
                    'otp_expire'=>max(30,min(900,absint($in['otp_expire']??$d['otp_expire']))),
                    'resend_wait'=>max(20,min(600,absint($in['resend_wait']??$d['resend_wait']))),
                    'max_per_hour'=>max(1,min(50,absint($in['max_per_hour']??$d['max_per_hour']))),
                    'max_ip_per_hour'=>max(1,min(100,absint($in['max_ip_per_hour']??$d['max_ip_per_hour']))),
                    'intl_format'=>in_array($in['intl_format']??'00',['00','+','plain'],true)?$in['intl_format']:'00',
                ];
            }
        ]);
    }

    public function settings_page(){
        $o=$this->opts(); ?>
        <div class="wrap" dir="rtl">
            <h1>ورود پیامکی و پنل کاربری</h1>
            <form method="post" action="options.php">
                <?php settings_fields('mp_sms_login_group'); ?>
                <table class="form-table">
                    <tr><th>نام کاربری ملی پیامک</th><td><input class="regular-text" name="<?php echo esc_attr(self::OPT); ?>[username]" value="<?php echo esc_attr($o['username']); ?>"></td></tr>
                    <tr><th>رمز عبور ملی پیامک</th><td><input type="password" class="regular-text" name="<?php echo esc_attr(self::OPT); ?>[password]" value="" autocomplete="new-password" placeholder="<?php echo $o['password']!==''?'•••••••• (ذخیره شده — برای تغییر، رمز جدید را بنویسید)':''; ?>"></td></tr>
                    <tr><th>شناسه الگوی OTP (bodyId)</th><td><input type="number" class="small-text" name="<?php echo esc_attr(self::OPT); ?>[body_id]" value="<?php echo esc_attr($o['body_id']); ?>"></td></tr>
                    <tr><th>طول کد</th><td><input type="number" min="4" max="8" name="<?php echo esc_attr(self::OPT); ?>[otp_length]" value="<?php echo esc_attr($o['otp_length']); ?>"></td></tr>
                    <tr><th>اعتبار کد (ثانیه)</th><td><input type="number" min="30" max="900" name="<?php echo esc_attr(self::OPT); ?>[otp_expire]" value="<?php echo esc_attr($o['otp_expire']); ?>"></td></tr>
                    <tr><th>فاصله ارسال مجدد</th><td><input type="number" min="20" max="600" name="<?php echo esc_attr(self::OPT); ?>[resend_wait]" value="<?php echo esc_attr($o['resend_wait']); ?>"></td></tr>
                    <tr><th>حداکثر SMS هر شماره در ساعت</th><td><input type="number" min="1" max="50" name="<?php echo esc_attr(self::OPT); ?>[max_per_hour]" value="<?php echo esc_attr($o['max_per_hour']); ?>"></td></tr>
                    <tr><th>حداکثر SMS هر IP در ساعت</th><td><input type="number" min="1" max="100" name="<?php echo esc_attr(self::OPT); ?>[max_ip_per_hour]" value="<?php echo esc_attr($o['max_ip_per_hour']); ?>"></td></tr>
                </table>
                <h2 style="margin-top:28px">شماره‌های خارجی</h2>
                <p style="max-width:760px;line-height:2">در صفحه‌ی ورود، کاربر می‌تواند علاوه بر ایران، کشور خود را انتخاب کند (عراق، لبنان، بحرین، عربستان، کویت، عمان، امارات، قطر، سوریه، یمن). کد این شماره‌ها هم با همین الگوی ملی پیامک ارسال می‌شود؛ برای رسیدن پیامک به شماره‌های خارجی، <b>ارسال بین‌المللی</b> باید در پنل ملی پیامک شما فعال باشد.</p>
                <table class="form-table">
                    <tr><th>شکل ارسال شماره‌ی خارجی به ملی پیامک</th><td><select name="<?php echo esc_attr(self::OPT); ?>[intl_format]">
                        <?php foreach(['00'=>'00964xxxxxxxxxx','+'=>'+964xxxxxxxxxx','plain'=>'964xxxxxxxxxx'] as $k=>$l): ?><option value="<?php echo esc_attr($k); ?>" <?php selected($o['intl_format'],$k); ?> dir="ltr"><?php echo esc_html($l); ?></option><?php endforeach; ?>
                    </select> <span class="description">اگر پیامک به شماره‌ی خارجی نرسید، شکل دیگر را امتحان کنید یا از پشتیبانی ملی پیامک بپرسید.</span></td></tr>
                </table>
                <?php submit_button('ذخیره تنظیمات'); ?>
            </form>
            <h2 style="margin-top:28px">ارسال کد آزمایشی</h2>
            <?php if(isset($_GET['sms_test'])): $ok=$_GET['sms_test']==='ok'; // phpcs:ignore ?>
            <div class="notice <?php echo $ok?'notice-success':'notice-error'; ?> inline"><p><?php echo $ok?'پیامک با کد 123456 به ملی پیامک تحویل شد.':'ارسال نشد: '.esc_html((string)get_transient('mp_sms_test_err')); ?></p></div>
            <?php endif; ?>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">
                <input type="hidden" name="action" value="mp_sms_test"><?php wp_nonce_field('mp_sms_test'); ?>
                <input class="regular-text" dir="ltr" name="phone" placeholder="09121234567 / +9647701234567" required>
                <?php submit_button('ارسال','secondary','submit',false); ?>
                <span class="description">برای امتحان یک شماره‌ی ایرانی یا خارجی (با + و کد کشور).</span>
            </form>
            <hr>
            <h2>شورت‌کد</h2>
            <p><code>[mp_sms_login]</code> ورود را نمایش می‌دهد و بعد از ورود، پنل کاربری را نمایش خواهد داد.</p>
            <p><code>[mp_user_panel]</code> فقط پنل کاربری را نمایش می‌دهد.</p>
        </div><?php
    }

    private function normalize_phone($p){
        $p=strtr(trim((string)$p),['۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9','٠'=>'0','١'=>'1','٢'=>'2','٣'=>'3','٤'=>'4','٥'=>'5','٦'=>'6','٧'=>'7','٨'=>'8','٩'=>'9']);
        $p=preg_replace('/[^0-9+]/','',$p);
        if(strpos($p,'+98')===0)$p='0'.substr($p,3);
        if(strpos($p,'0098')===0)$p='0'.substr($p,4);
        if(strpos($p,'98')===0&&strlen($p)===12)$p='0'.substr($p,2);
        if(strpos($p,'9')===0&&strlen($p)===10)$p='0'.$p;
        return $p;
    }
    private function valid_phone($p){return (bool)preg_match('/^09\d{9}$/',$p);}
    private function ip(){return isset($_SERVER['REMOTE_ADDR'])?sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])):'unknown';}
    private function rkey($t,$v){return 'mp_sms_rl_'.$t.'_'.md5($v);}
    private function inc($k){$n=(int)get_transient($k);set_transient($k,$n+1,3600);return $n+1;}

    private function latin($s){return strtr((string)$s,['۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9','٠'=>'0','١'=>'1','٢'=>'2','٣'=>'3','٤'=>'4','٥'=>'5','٦'=>'6','٧'=>'7','٨'=>'8','٩'=>'9']);}

    /** key => [short name, dial code, national lengths, example] — Iran first, then the visitors' countries. */
    public static function countries(){
        static $m=null; if($m!==null) return $m;
        $m=['ir'=>['إيران','+98',[10],'912 345 6789']];
        $len=['iq'=>[10],'lb'=>[7,8],'bh'=>[8],'sa'=>[9],'kw'=>[8],'om'=>[8],'ae'=>[9],'qa'=>[8],'sy'=>[9],'ye'=>[9]];
        $ex=['iq'=>'770 123 4567','lb'=>'71 123 456','bh'=>'3600 1234','sa'=>'50 123 4567','kw'=>'5000 1234','om'=>'9212 3456','ae'=>'50 123 4567','qa'=>'3312 3456','sy'=>'944 567 890','ye'=>'712 345 678'];
        if(class_exists('DLZ_Countries')) foreach(DLZ_Countries::all() as $k=>$c) $m[$k]=[$c['short'],$c['dial'],$len[$k]??[7,8,9,10],$ex[$k]??''];
        return $m;
    }

    /** 7701234567 → «770 123 4567», 501234567 → «50 123 4567», 50001234 → «5000 1234» */
    public static function group($n){
        $sizes=[10=>[3,3,4],9=>[2,3,4],8=>[4,4],7=>[1,3,3]];
        if(!isset($sizes[strlen($n)])) return $n;
        $out=[];$i=0; foreach($sizes[strlen($n)] as $z){$out[]=substr($n,$i,$z);$i+=$z;}
        return implode(' ',$out);
    }

    /** (raw phone, country key) → ['id'=>stored phone,'ch'=>'sms'|'intl','show'=>pretty,'ctry'=>key] or WP_Error */
    private function resolve($raw,$ctry){
        $all=self::countries();
        $p=preg_replace('/[^0-9+]/','',$this->latin(trim((string)$raw)));
        if(strpos($p,'00')===0) $p='+'.substr($p,2);
        if(strpos($p,'+')===0){
            $best='';
            foreach($all as $k=>$c) if(strpos($p,$c[1])===0&&strlen($c[1])>strlen($best?$all[$best][1]:'')) $best=$k;
            if(!$best) return new WP_Error('ctry','هذه الدولة غير مدعومة حالياً.');
            $ctry=$best; $nat=substr($p,strlen($all[$best][1]));
        } else $nat=$p;
        if(!isset($all[$ctry])) $ctry='ir';
        if($ctry==='ir'){
            $ph=$this->normalize_phone($p);
            if(!$this->valid_phone($ph)) return new WP_Error('phone','رقم الهاتف غير صالح. اكتب رقماً إيرانياً يبدأ بـ 09.');
            return ['id'=>$ph,'ch'=>'sms','show'=>'+98 '.substr($ph,1,3).' '.substr($ph,4,3).' '.substr($ph,7),'ctry'=>'ir'];
        }
        $nat=ltrim(preg_replace('/\D/','',$nat),'0');
        if(!in_array(strlen($nat),$all[$ctry][2],true)) return new WP_Error('phone','يُرجى إدخال رقم هاتف صحيح في '.$all[$ctry][0].'. مثال: '.$all[$ctry][3]);
        return ['id'=>$all[$ctry][1].$nat,'ch'=>'intl','show'=>$all[$ctry][1].' '.self::group($nat),'ctry'=>$ctry];
    }

    /** The number as Melipayamak expects it: 09… for Iran, 00964… / +964… / 964… abroad (setting). */
    private function sms_to($id){
        if(strpos($id,'+')!==0) return $id;
        $f=$this->opts()['intl_format'];
        return $f==='+'?$id:($f==='plain'?substr($id,1):'00'.substr($id,1));
    }

    public function sms_test(){
        if(!current_user_can('manage_options')) wp_die('دسترسی ندارید.');
        check_admin_referer('mp_sms_test');
        $who=$this->resolve(wp_unslash($_POST['phone']??''),'ir');
        $r=is_wp_error($who)?$who:$this->send_melipayamak($this->sms_to($who['id']),'123456');
        if(is_wp_error($r)) set_transient('mp_sms_test_err',$r->get_error_message().($r->get_error_data()?' — '.$r->get_error_data():''),300);
        wp_safe_redirect(add_query_arg('sms_test',is_wp_error($r)?'fail':'ok',admin_url('options-general.php?page=mp-sms-login'))); exit;
    }

    private function send_melipayamak($phone,$otp){
        $o=$this->opts();
        if(!$o['username']||!$o['password']||!$o['body_id']) return new WP_Error('config','خدمة الرسائل غير مهيأة حالياً، يرجى التواصل مع الدعم.');
        $res=wp_remote_post('https://rest.payamak-panel.com/api/SendSMS/BaseServiceNumber',[
            'timeout'=>20,'body'=>[
                'username'=>$o['username'],'password'=>$o['password'],'text'=>(string)$otp,
                'to'=>$phone,'bodyId'=>(string)$o['body_id']
            ]
        ]);
        if(is_wp_error($res)) return new WP_Error('api','تعذّر الاتصال بخدمة الرسائل، حاول بعد قليل.');
        $code=wp_remote_retrieve_response_code($res);
        $body=json_decode(wp_remote_retrieve_body($res),true);
        if($code<200||$code>=300||!is_array($body)) return new WP_Error('api','تعذّر إرسال الرسالة، حاول بعد قليل.');
        if(isset($body['RetStatus'])&&(int)$body['RetStatus']!==1){
            return new WP_Error('sms','تعذّر إرسال الرسالة، حاول بعد قليل.','RetStatus '.(int)$body['RetStatus'].(isset($body['StrRetStatus'])?' '.sanitize_text_field($body['StrRetStatus']):'').(isset($body['Value'])?' / '.sanitize_text_field((string)$body['Value']):''));
        }
        return $body;
    }

    /** Too many wrong codes for this number → it is locked for 30 minutes (send and verify). */
    private function locked($phone){ return (int)get_transient($this->rkey('fail',$phone))>=8; }

    public function send_otp(){
        if(!check_ajax_referer(self::NONCE,'nonce',false)) wp_send_json_error(['message'=>'انتهت صلاحية الصفحة، يرجى تحديثها.'],403);
        if(!empty($_POST['website'])) wp_send_json_error(['message'=>'تعذر الإرسال.'],400); // honeypot
        $who=$this->resolve(wp_unslash($_POST['phone']??''),sanitize_key(wp_unslash($_POST['country']??'ir')));
        if(is_wp_error($who)) wp_send_json_error(['message'=>$who->get_error_message()],400);
        $phone=$who['id'];
        if($this->locked($phone)) wp_send_json_error(['message'=>'تم إيقاف هذا الرقم مؤقتاً بسبب محاولات خاطئة كثيرة. حاول بعد 30 دقيقة.'],429);
        $o=$this->opts(); $pk=$this->rkey('phone',$phone); $ik=$this->rkey('ip',$this->ip()); $lk=$this->rkey('last',$phone);
        $dk=$this->rkey('ipday',$this->ip());
        if((int)get_transient($dk)>=max(30,(int)$o['max_ip_per_hour']*4)) wp_send_json_error(['message'=>'تم تجاوز الحد اليومي للطلبات من هذا الاتصال.'],429);
        if(get_transient($lk)) wp_send_json_error(['message'=>'يرجى الانتظار قليلًا ثم المحاولة مرة أخرى.'],429);
        if((int)get_transient($pk)>=(int)$o['max_per_hour']) wp_send_json_error(['message'=>'تم تجاوز الحد المسموح لطلبات هذا الرقم.'],429);
        if((int)get_transient($ik)>=(int)$o['max_ip_per_hour']) wp_send_json_error(['message'=>'تم تجاوز الحد المسموح للطلبات من هذا الاتصال.'],429);
        $otp='';
        for($i=0;$i<(int)$o['otp_length'];$i++)$otp.=wp_rand(0,9);
        $r=$this->send_melipayamak($this->sms_to($phone),$otp);
        if(is_wp_error($r)) wp_send_json_error(['message'=>$r->get_error_message()],500);
        $token=wp_generate_password(32,false,false);
        set_transient('mp_sms_otp_'.$token,[
            'phone'=>$phone,'hash'=>wp_hash($otp.'|'.$token),'attempts'=>0
        ],(int)$o['otp_expire']);
        set_transient($lk,1,(int)$o['resend_wait']); $this->inc($pk);$this->inc($ik);
        set_transient($dk,(int)get_transient($dk)+1,DAY_IN_SECONDS);
        wp_send_json_success(['token'=>$token,'message'=>'تم إرسال رمز التحقق.','wait'=>(int)$o['resend_wait'],'length'=>(int)$o['otp_length'],'expire'=>(int)$o['otp_expire'],'channel'=>$who['ch'],'show'=>$who['show']]);
    }

    private function user_by_phone($phone){
        $u=get_users(['meta_key'=>'mp_sms_phone','meta_value'=>$phone,'number'=>1,'count_total'=>false]);
        return $u?$u[0]:false;
    }

    private function create_user($phone,$ctry='ir'){
        $login='mp_'.substr(md5($phone),0,16);
        $id=wp_create_user($login,wp_generate_password(32,true,true),$login.'@local.invalid');
        if(is_wp_error($id))return $id;
        update_user_meta($id,'mp_sms_phone',$phone);
        update_user_meta($id,'mp_profile_complete',0);
        if($ctry!=='ir'&&class_exists('DLZ_Countries')&&($c=DLZ_Countries::get($ctry))){
            // a visitor who signed in with his own country's number: the profile starts filled in
            update_user_meta($id,'mp_country_code',$ctry); update_user_meta($id,'mp_country',$c['short']);
            update_user_meta($id,'mp_intl_dial',$ctry); update_user_meta($id,'mp_intl_phone',substr($phone,strlen($c['dial'])));
        }
        return get_user_by('id',$id);
    }

    public function verify_otp(){
        if(!check_ajax_referer(self::NONCE,'nonce',false)) wp_send_json_error(['message'=>'انتهت صلاحية الصفحة، يرجى تحديثها.'],403);
        $who=$this->resolve(wp_unslash($_POST['phone']??''),sanitize_key(wp_unslash($_POST['country']??'ir')));
        $phone=is_wp_error($who)?'':$who['id'];
        $otp=preg_replace('/\D/','',strtr((string)wp_unslash($_POST['otp']??''),['۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9','٠'=>'0','١'=>'1','٢'=>'2','٣'=>'3','٤'=>'4','٥'=>'5','٦'=>'6','٧'=>'7','٨'=>'8','٩'=>'9']));
        $token=preg_replace('/[^A-Za-z0-9]/','',(string)wp_unslash($_POST['token']??''));
        if($phone&&$this->locked($phone)) wp_send_json_error(['message'=>'تم إيقاف هذا الرقم مؤقتاً بسبب محاولات خاطئة كثيرة. حاول بعد 30 دقيقة.'],429);
        $data=$token?get_transient('mp_sms_otp_'.$token):false;
        if(!$phone||!$token||!is_array($data)||$data['phone']!==$phone) wp_send_json_error(['message'=>'انتهت صلاحية الرمز، اطلب رمزاً جديداً.','code'=>'expired'],400);
        $data['attempts']++;
        if($data['attempts']>5){delete_transient('mp_sms_otp_'.$token);wp_send_json_error(['message'=>'تم تجاوز عدد المحاولات، اطلب رمزاً جديداً.','code'=>'expired'],429);}
        set_transient('mp_sms_otp_'.$token,$data,max(30,(int)$this->opts()['otp_expire']));
        if(!hash_equals($data['hash'],wp_hash($otp.'|'.$token))){
            $fk=$this->rkey('fail',$phone); set_transient($fk,(int)get_transient($fk)+1,30*MINUTE_IN_SECONDS);
            wp_send_json_error(['message'=>'الرمز الذي أدخلته غير صحيح.','left'=>max(0,5-(int)$data['attempts'])],400);
        }
        delete_transient('mp_sms_otp_'.$token);
        delete_transient($this->rkey('fail',$phone));
        $user=$this->user_by_phone($phone);$new=false;
        if(!$user){$user=$this->create_user($phone,$who['ctry']);$new=true;}
        if(is_wp_error($user))wp_send_json_error(['message'=>'تعذر إنشاء الحساب.'],500);
        wp_set_current_user($user->ID);wp_set_auth_cookie($user->ID,true,is_ssl());
        wp_send_json_success([
            'message'=>'تم تسجيل الدخول بنجاح.',
            'new_user'=>$new,
            'profile_complete'=>(bool)get_user_meta($user->ID,'mp_profile_complete',true),
            'redirect'=>apply_filters('mp_sms_login_redirect',home_url('/'),$user)
        ]);
    }

    private function current_profile(){
        $u=wp_get_current_user();
        return [
            'id'=>$u->ID,
            'first_name'=>get_user_meta($u->ID,'first_name',true),
            'last_name'=>get_user_meta($u->ID,'last_name',true),
            'gender'=>get_user_meta($u->ID,'mp_gender',true),
            'phone'=>get_user_meta($u->ID,'mp_sms_phone',true),
            'avatar'=>get_user_meta($u->ID,'mp_avatar',true),
            'complete'=>(bool)get_user_meta($u->ID,'mp_profile_complete',true)
        ];
    }

    private function validate_profile_input($first,$last,$gender){
        if(mb_strlen($first)<2||mb_strlen($last)<2) return 'يرجى إدخال الاسم واسم العائلة بالكامل.';
        if(!in_array($gender,['male','female'],true)) return 'يرجى اختيار الجنس.';
        return '';
    }

    public function complete_profile(){
        check_ajax_referer(self::NONCE,'nonce');
        if(!is_user_logged_in())wp_send_json_error(['message'=>'يرجى تسجيل الدخول أولاً.'],401);
        $first=sanitize_text_field($_POST['first_name']??'');$last=sanitize_text_field($_POST['last_name']??'');$gender=sanitize_key($_POST['gender']??'');
        if($e=$this->validate_profile_input($first,$last,$gender))wp_send_json_error(['message'=>$e],400);
        $id=get_current_user_id();
        update_user_meta($id,'first_name',$first);update_user_meta($id,'last_name',$last);update_user_meta($id,'display_name',trim($first.' '.$last));
        update_user_meta($id,'mp_gender',$gender);update_user_meta($id,'mp_profile_complete',1);
        wp_send_json_success(['message'=>'تم حفظ معلوماتك.','redirect'=>home_url('/')]);
    }

    public function update_profile(){
        check_ajax_referer(self::NONCE,'nonce');
        if(!is_user_logged_in())wp_send_json_error(['message'=>'يرجى تسجيل الدخول أولاً.'],401);
        $first=sanitize_text_field($_POST['first_name']??'');$last=sanitize_text_field($_POST['last_name']??'');$gender=sanitize_key($_POST['gender']??'');
        if($e=$this->validate_profile_input($first,$last,$gender))wp_send_json_error(['message'=>$e],400);
        $id=get_current_user_id();update_user_meta($id,'first_name',$first);update_user_meta($id,'last_name',$last);
        update_user_meta($id,'display_name',trim($first.' '.$last));update_user_meta($id,'mp_gender',$gender);
        wp_send_json_success(['message'=>'تم تحديث المعلومات بنجاح.']);
    }

    public function upload_avatar(){
        check_ajax_referer(self::NONCE,'nonce');
        if(!is_user_logged_in())wp_send_json_error(['message'=>'يرجى تسجيل الدخول أولاً.'],401);
        if(empty($_FILES['avatar']))wp_send_json_error(['message'=>'لم يتم اختيار صورة.'],400);
        $file=$_FILES['avatar'];
        if(!empty($file['error']))wp_send_json_error(['message'=>'تعذر رفع الصورة.'],400);
        if($file['size']>3*1024*1024)wp_send_json_error(['message'=>'يجب ألا يتجاوز حجم الصورة 3 ميغابايت.'],400);
        $type=wp_check_filetype_and_ext($file['tmp_name'],$file['name'],['jpg|jpeg|jpe'=>'image/jpeg','png'=>'image/png','webp'=>'image/webp']);
        if(empty($type['type'])||strpos($type['type'],'image/')!==0||!is_uploaded_file($file['tmp_name'])||!@getimagesize($file['tmp_name']))wp_send_json_error(['message'=>'يسمح بملفات الصور فقط.'],400);
        require_once ABSPATH.'wp-admin/includes/file.php';
        $uploaded=wp_handle_upload($file,['test_form'=>false,'mimes'=>[
            'jpg'=>'image/jpeg','jpeg'=>'image/jpeg','png'=>'image/png','webp'=>'image/webp'
        ]]);
        if(isset($uploaded['error']))wp_send_json_error(['message'=>'تعذر حفظ الصورة.'],500);
        update_user_meta(get_current_user_id(),'mp_avatar',esc_url_raw($uploaded['url']));
        wp_send_json_success(['message'=>'تم حفظ صورة الملف الشخصي.','url'=>esc_url_raw($uploaded['url'])]);
    }

    public function show_admin_bar($show){
        // فقط مدیران واقعی نوار مدیریت وردپرس را ببینند؛ کاربران عادی نباید آن را ببینند.
        return current_user_can('manage_options') ? $show : false;
    }

    /** Registered everywhere, loaded only on the page that shows the login (or the old dashboard). */
    public function enqueue(){
        wp_register_style('mp-user-panel',plugins_url('assets/style.css',__FILE__),[],defined('DASE_VERSION')?DASE_VERSION:'2.1');
        wp_register_script('mp-user-panel',plugins_url('assets/app.js',__FILE__),[],defined('DASE_VERSION')?DASE_VERSION:'2.1',true);
        wp_localize_script('mp-user-panel','MPSMSLogin',['ajax'=>admin_url('admin-ajax.php'),'nonce'=>wp_create_nonce(self::NONCE),'len'=>(int)$this->opts()['otp_length']]);
        if(is_singular()){
            $p=get_queried_object(); $c=$p&&isset($p->post_content)?(string)$p->post_content:'';
            $el=get_post_meta(get_queried_object_id(),'_elementor_data',true);
            if(false!==strpos($c,'[mp_')||(is_string($el)&&false!==strpos($el,'mp_sms'))){ wp_enqueue_style('mp-user-panel'); wp_enqueue_script('mp-user-panel'); }
        }
    }
    private function assets(){
        wp_enqueue_script('mp-user-panel');
        if(!did_action('wp_head')){ wp_enqueue_style('mp-user-panel'); return ''; }
        if(wp_style_is('mp-user-panel','done')) return '';
        return function_exists('dlz_inline_css') ? dlz_inline_css('mp-user-panel',plugin_dir_path(__FILE__).'assets/style.css') : '<link rel="stylesheet" href="'.esc_url(plugins_url('assets/style.css',__FILE__).'?ver='.(defined('DASE_VERSION')?DASE_VERSION:'2.1').'.'.filemtime(plugin_dir_path(__FILE__).'assets/style.css')).'">';
    }

    private function login_markup(){
        $o=$this->opts(); $len=(int)$o['otp_length'];
        // the site's own logo (the one in the app header); the drawn mark only when none is uploaded
        $lu=class_exists('DLZ_App_Shell')?DLZ_App_Shell::logo():'';
        if(!$lu) $lu=get_site_icon_url(192);
        $logo=$lu?'<img src="'.esc_url($lu).'" alt="دليل الزائر">':(class_exists('DLZ_App_Shell')?DLZ_App_Shell::logo_svg():'');
        $ic=function($p){return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'.$p.'</svg>';};
        $cs=self::countries(); $fl=class_exists('DLZ_Countries');
        $flag=function($k) use($fl){
            if($k==='ir') return '<span class="dlzf is-still mpl-fl" data-flag="ir" aria-hidden="true"><svg viewBox="0 0 300 200" preserveAspectRatio="none" focusable="false"><use href="#dlzf-ir"/></svg></span>'; // with the emblem
            return $fl?DLZ_Countries::flag($k,false,'mpl-fl'):'';
        };
        ob_start(); echo $this->assets(); // phpcs:ignore ?>
        <div class="mpl" dir="rtl">
          <div class="mpl-card">
            <header class="mpl-h">
              <span class="mpl-logo<?php echo $lu?' has-img':''; ?>"><?php echo $logo; // phpcs:ignore ?></span>
              <?php if(!$lu): ?><b class="mpl-brand">دليل الزائر</b><?php endif; ?>
            </header>
            <div class="mpl-body">
              <section class="mpl-step" data-step="phone">
                <h2>أهلاً وسهلاً بكم</h2>
                <p class="mpl-sub">يُرجى إدخال رقم هاتفكم المحمول لتسجيل الدخول أو إنشاء حساب جديد، وسيُرسَل إليكم رمز التحقق برسالة نصية.</p>
                <?php echo $fl?DLZ_Countries::defs(array_keys($cs)):''; // phpcs:ignore ?>
                <form class="mpl-f mpl-f-phone" novalidate>
                  <label class="mpl-l" for="mpl-phone">رقم الهاتف المحمول</label>
                  <div class="mpl-in"><button type="button" class="mpl-cc" aria-haspopup="listbox" aria-expanded="false" aria-label="اختر الدولة"><span class="mpl-cc-f"><?php echo $flag('ir'); // phpcs:ignore ?></span><b dir="ltr">+98</b><?php echo $ic('<path d="m7 10 5 5 5-5"/>'); // phpcs:ignore ?></button><input id="mpl-phone" class="mpl-phone" type="tel" inputmode="tel" autocomplete="tel" dir="ltr" maxlength="18" placeholder="912 345 6789" aria-describedby="mpl-hint"></div>
                  <div class="mpl-pick" hidden>
                    <div class="mpl-pick-bd"></div>
                    <div class="mpl-pick-box" role="dialog" aria-modal="true" aria-label="اختر دولتك">
                    <span class="mpl-pick-grip" aria-hidden="true"></span>
                    <div class="mpl-pick-h"><b>اختر دولتك</b><button type="button" class="mpl-pick-x" aria-label="إغلاق"><?php echo $ic('<path d="M6 6l12 12M18 6 6 18"/>'); // phpcs:ignore ?></button></div>
                    <ul class="mpl-pick-l" role="listbox" aria-label="الدولة">
                      <?php foreach($cs as $k=>$c): ?><li><button type="button" role="option" class="mpl-opt<?php echo $k==='ir'?' is-on':''; ?>" data-k="<?php echo esc_attr($k); ?>" data-dial="<?php echo esc_attr($c[1]); ?>" data-len="<?php echo esc_attr(implode(',',$c[2])); ?>" data-ex="<?php echo esc_attr($c[3]); ?>" aria-selected="<?php echo $k==='ir'?'true':'false'; ?>"><span class="mpl-opt-f"><?php echo $flag($k); // phpcs:ignore ?></span><span class="mpl-opt-n"><?php echo esc_html($c[0]); ?></span><b dir="ltr"><?php echo esc_html($c[1]); ?></b><i class="mpl-opt-ck"><?php echo $ic('<path d="m5 12.5 4.5 4.5L19 7.5"/>'); // phpcs:ignore ?></i></button></li><?php endforeach; ?>
                    </ul>
                    </div>
                  </div>
                  <input type="text" name="website" class="mpl-hp" tabindex="-1" autocomplete="off" aria-hidden="true">
                  <button class="mpl-btn mpl-send" type="submit"><span>إرسال رمز التحقق</span><?php echo $ic('<path d="m14.5 6-6 6 6 6"/>'); // phpcs:ignore ?></button>
                </form>
                <p class="mpl-note" id="mpl-hint"><?php echo $ic('<path d="M12 3.5 5 6.2v5.3c0 4.4 3 7.7 7 9 4-1.3 7-4.6 7-9V6.2z"/><path d="m9 12 2.2 2.2L15.2 10"/>'); // phpcs:ignore ?><span>نحافظ على خصوصية بياناتكم ولا نشاركها مع أي جهة.</span></p>
              </section>
              <section class="mpl-step" data-step="otp" hidden>
                <h2>رمز التحقق</h2>
                <p class="mpl-sub">أُرسل رمز مكوّن من <?php echo (int)$len; ?> أرقام إلى الرقم <b class="mpl-num" dir="ltr"></b> <button type="button" class="mpl-link mpl-change">تعديل الرقم</button></p>
                <form class="mpl-f mpl-f-otp" novalidate>
                  <div class="mpl-otp" dir="ltr" role="group" aria-label="رمز التحقق">
                    <?php for($k=0;$k<$len;$k++): ?><input type="text" inputmode="numeric" maxlength="1" pattern="[0-9]*" aria-label="<?php echo esc_attr('الرقم '.($k+1)); ?>" <?php echo $k?'autocomplete="off"':'autocomplete="one-time-code"'; ?>><?php endfor; ?>
                  </div>
                  <button class="mpl-btn mpl-verify" type="submit"><span>تأكيد وتسجيل الدخول</span></button>
                </form>
                <div class="mpl-resend"><span class="mpl-wait">يمكنك طلب رمز جديد بعد <b dir="ltr">0:60</b></span><button type="button" class="mpl-link mpl-again" hidden>إعادة إرسال الرمز</button></div>
              </section>
              <section class="mpl-step mpl-done" data-step="done" hidden>
                <span class="mpl-ok"><?php echo $ic('<path d="m5 12.5 4.5 4.5L19 7.5"/>'); // phpcs:ignore ?></span>
                <h2>تم تسجيل الدخول بنجاح</h2>
                <p class="mpl-sub">جارٍ فتح حسابكم…</p>
              </section>
              <p class="mpl-msg" role="alert" aria-live="polite" hidden></p>
            </div>
          </div>
        </div>
        <?php return ob_get_clean();
    }

    private function profile_setup_markup(){
        $p=$this->current_profile();ob_start();?>
        <div class="mp-profile-setup" dir="rtl">
            <div class="mp-setup-icon">✦</div>
            <h2>إكمال الملف الشخصي</h2>
            <p>لإنشاء ملفك الشخصي، أدخل المعلومات التالية.</p>
            <label>الاسم</label><input class="mp-first" type="text" placeholder="الاسم">
            <label>اسم العائلة</label><input class="mp-last" type="text" placeholder="اسم العائلة">
            <label>الجنس</label>
            <div class="mp-gender">
                <button type="button" data-g="male">ذكر</button>
                <button type="button" data-g="female">أنثى</button>
            </div>
            <label>صورة الملف الشخصي <span>(اختياري)</span></label>
            <input class="mp-avatar-setup" type="file" accept="image/jpeg,image/png,image/webp">
            <small>يمكنك إضافة الصورة لاحقًا من الملف الشخصي.</small>
            <button class="mp-complete" type="button">متابعة والدخول إلى الملف الشخصي</button>
            <div class="mp-msg"></div>
        </div><?php return ob_get_clean();
    }

    public function panel_shortcode(){
        if(!is_user_logged_in()) return $this->login_markup();
        if(class_exists('DLZ_Profile')) return DLZ_Profile::render(); // Dalil Al Zaer app-style account page
        $p=$this->current_profile();
        if(!$p['complete']) return $this->assets().$this->profile_setup_markup();
        return $this->assets().$this->panel_markup();
    }

    public function panel_markup(){
        $p=$this->current_profile();$name=trim($p['first_name'].' '.$p['last_name']);
        $avatar=$p['avatar'];
        $initial=mb_substr($p['first_name']?:'ز',0,1);
        ob_start();?>
        <div class="mp-dashboard" dir="rtl">
            <div class="mp-cover">
                <div class="mp-topbar"><button class="mp-back" type="button">‹</button><div class="mp-dashboard-title">حسابی</div><button class="mp-settings" type="button" aria-label="الإعدادات">⚙</button></div>
                <div class="mp-avatar-wrap">
                    <div class="mp-avatar">
                        <?php if($avatar): ?><img src="<?php echo esc_url($avatar); ?>" alt=""><?php else: ?><span><?php echo esc_html($initial); ?></span><?php endif; ?>
                    </div>
                    <button class="mp-camera" type="button" title="تغيير الصورة">📷</button>
                    <input class="mp-avatar-input" type="file" accept="image/jpeg,image/png,image/webp" hidden>
                </div>
                <div class="mp-user-card">
                    <h2><?php echo esc_html($name?:'مستخدم'); ?></h2>
                    <div class="mp-role"><?php echo $p['gender']==='female'?'زائر كريم':'زائر كريم'; ?></div>
                    <div class="mp-contact">📞 <?php echo esc_html($p['phone']); ?></div>
                </div>
                <div class="mp-city-section"><?php echo do_shortcode('[dlz_cities_profile]'); ?></div>
                <div class="mp-profile-shortcuts mp-profile-actions">
                    <a class="mp-profile-action-favorite" href="<?php echo esc_url(function_exists('dlz_profile_url') ? add_query_arg('dlz_view','favorites',dlz_profile_url()) : home_url('/')); ?>"><b>♥</b><span>المفضلة</span></a>
                    <button type="button" class="mp-profile-action-settings mp-settings-trigger"><b>⚙</b><span>الإعدادات</span></button>
                </div>
            </div>
            <div class="mp-dashboard-msg"></div>
            <div class="mp-modal" style="display:none">
                <div class="mp-modal-box">
                    <button class="mp-close" type="button">×</button>
                    <h3>معلومات الحساب</h3>
                    <label>الاسم</label><input class="mp-edit-first" value="<?php echo esc_attr($p['first_name']); ?>">
                    <label>اسم العائلة</label><input class="mp-edit-last" value="<?php echo esc_attr($p['last_name']); ?>">
                    <label>الجنس</label>
                    <div class="mp-gender mp-edit-gender">
                        <button type="button" data-g="male" class="<?php echo $p['gender']==='male'?'active':''; ?>">ذكر</button>
                        <button type="button" data-g="female" class="<?php echo $p['gender']==='female'?'active':''; ?>">أنثى</button>
                    </div>
                    <button class="mp-save-profile" type="button">حفظ التغييرات</button>
                </div>
            </div>
        </div><?php return ob_get_clean();
    }

    public function shortcode(){
        if(is_user_logged_in()) return $this->panel_shortcode();
        return $this->login_markup();
    }

    public function elementor_widget($widgets_manager){
        if(!class_exists('\Elementor\Widget_Base'))return;
        $widgets_manager->register(new class extends \Elementor\Widget_Base{
            public function get_name(){return 'mp_sms_user_panel';}
            public function get_title(){return 'ورود پیامکی و پنل مستخدمی';}
            public function get_icon(){return 'eicon-user-circle-o';}
            public function get_categories(){return ['dalil-alzaer'];}
            protected function render(){echo do_shortcode('[mp_sms_login]');}
        });
    }
}
new MP_SMS_User_Panel();
