/* Dalil Al Zaer — «نفحات»: Instagram-style Explore grid + Reels viewer + comments */
(function () {
	'use strict';
	var d = document, w = window, html = d.documentElement;
	var C = w.DLZNafahatCfg || {}, T = C.i18n || {};
	var nonce = C.nonce || '';

	/* ---------------- helpers ---------------- */
	function esc(v) { var x = d.createElement('div'); x.textContent = v == null ? '' : String(v); return x.innerHTML.replace(/"/g, '&quot;').replace(/'/g, '&#39;'); }
	function attr(v) { return esc(v).replace(/"/g, '&quot;'); }
	function num(n) {
		n = +n || 0;
		if (n >= 1e6) return (n / 1e6).toFixed(n >= 1e7 ? 0 : 1).replace(/\.0$/, '') + 'M';
		if (n >= 1e4) return Math.round(n / 1e3) + 'K';
		if (n >= 1e3) return (n / 1e3).toFixed(1).replace(/\.0$/, '') + 'K';
		return String(n);
	}
	var I = {
		heart: '<svg viewBox="0 0 24 24" aria-hidden="true"><path class="o" d="M12 20.6s-7.6-4.6-9.4-9.3C1.4 8.2 3.4 4.6 7 4.6c2 0 3.6 1.2 5 3 1.4-1.8 3-3 5-3 3.6 0 5.6 3.6 4.4 6.7-1.8 4.7-9.4 9.3-9.4 9.3Z"/></svg>',
		comment: '<svg viewBox="0 0 24 24" aria-hidden="true"><path class="o" d="M20.7 16.9A9.1 9.1 0 1 0 17 20.2l4.3 1.1Z"/></svg>',
		send: '<svg viewBox="0 0 24 24" aria-hidden="true"><path class="o" d="M21.5 2.8 10.2 13.6M21.5 2.8l-6.9 18.6-4.4-7.8-7.8-4.4Z"/></svg>',
		back: '<svg viewBox="0 0 24 24" aria-hidden="true"><path class="o" d="M14.5 5 21 12l-6.5 7M20.5 12H3.5"/></svg>',
		close: '<svg viewBox="0 0 24 24" aria-hidden="true"><path class="o" d="M6 6l12 12M18 6 6 18"/></svg>',
		reel: '<svg viewBox="0 0 24 24" aria-hidden="true"><rect class="o" x="3" y="3" width="18" height="18" rx="5"/><path class="o" d="M3.5 8.5h17M9 3.5l2.6 5M14.4 3.5 17 8.5"/><path class="f" d="m10 12.2 4.6 2.6L10 17.4Z"/></svg>',
		muted: '<svg viewBox="0 0 24 24" aria-hidden="true"><path class="f" d="M4 9h3.5L12 5v14l-4.5-4H4Z"/><path class="o" d="m16 9.5 5 5m0-5-5 5"/></svg>',
		sound: '<svg viewBox="0 0 24 24" aria-hidden="true"><path class="f" d="M4 9h3.5L12 5v14l-4.5-4H4Z"/><path class="o" d="M15.5 8.8a4.6 4.6 0 0 1 0 6.4M18.2 6.2a8.3 8.3 0 0 1 0 11.6"/></svg>',
		play: '<svg viewBox="0 0 24 24" aria-hidden="true"><path class="f" d="M8 5.5v13l10.5-6.5Z"/></svg>',
		grid: '<svg viewBox="0 0 24 24" aria-hidden="true"><rect class="o" x="3.5" y="3.5" width="17" height="17" rx="3.5"/><path class="o" d="M9.2 3.5v17M14.8 3.5v17M3.5 9.2h17M3.5 14.8h17"/></svg>'
	};
	function ico(n) { return I[n] || ''; }

	function request(action, params) {
		var body = new FormData();
		body.append('action', action);
		for (var k in params) if (params[k] !== undefined && params[k] !== null) body.append(k, params[k]);
		return fetch(C.ajax, { method: 'POST', body: body, credentials: 'same-origin' }).then(function (r) {
			return r.json().catch(function () { return { success: false, data: { code: 'http_' + r.status } }; });
		});
	}
	/* writes: nonce + one silent retry when the page came from a cache with an expired nonce */
	function write(action, params, retried) {
		params.nonce = nonce;
		return request(action, params).then(function (r) {
			if (!r.success && r.data && r.data.code === 'bad_nonce' && !retried) {
				return request('dnf_nonce', {}).then(function (n) {
					if (n && n.success) { nonce = n.data.nonce; C.logged = n.data.logged; }
					return write(action, params, true);
				});
			}
			return r;
		});
	}
	function goLogin() { if (C.login) w.location.href = C.login; }

	/* ---------------- toast ---------------- */
	var toastEl, toastT;
	function toast(msg, action) {
		if (!toastEl) {
			toastEl = d.createElement('div');
			toastEl.className = 'dnf-toast';
			toastEl.setAttribute('role', 'status');
			d.body.appendChild(toastEl);
		}
		toastEl.innerHTML = '<span>' + esc(msg) + '</span>' + (action ? '<button type="button">' + esc(action.label) + '</button>' : '');
		if (action) toastEl.querySelector('button').onclick = action.fn;
		toastEl.classList.add('is-on');
		clearTimeout(toastT);
		toastT = setTimeout(function () { toastEl.classList.remove('is-on'); }, action ? 4200 : 2200);
	}
	function loginToast(msg) { toast(msg, { label: 'تسجيل الدخول', fn: goLogin }); }

	/* ---------------- layers + history (back button closes the viewer / comments) ---------------- */
	var layers = [], skipPop = 0;
	var API = w.DLZNafahat = w.DLZNafahat || {};
	API.lastBack = 0;
	API.isOpen = function () { return layers.length > 0; };
	function lock(on) { html.classList.toggle('dnf-lock', !!on); }
	/* keep keys other scripts put in history.state (e.g. the WordPress Interactivity router) */
	function withState(extra) {
		var st = {}, cur = history.state;
		if (cur && typeof cur === 'object') for (var k in cur) if (k !== 'dnf' && k !== 'dsh') st[k] = cur[k];
		for (var j in extra) st[j] = extra[j];
		return st;
	}
	function pushLayer(name, closeFn) {
		layers.push({ name: name, close: closeFn });
		lock(true);
		try { history.pushState(withState({ dnf: name }), ''); } catch (e) {}
	}
	function popLayer(fromHistory) {
		var l = layers.pop();
		if (!l) return;
		l.close();
		if (!layers.length) lock(false);
		if (!fromHistory && history.state && history.state.dnf === l.name) {
			API.lastBack = Date.now() + 600;
			skipPop++;
			try { history.back(); } catch (e) { skipPop--; }
		}
	}
	function closeLayer(name) {
		if (layers.length && layers[layers.length - 1].name === name) popLayer(false);
	}
	w.addEventListener('popstate', function () {
		if (skipPop) { skipPop--; API.lastBack = Date.now(); return; }
		if (!layers.length) return;
		API.lastBack = Date.now();
		popLayer(true);
	});
	w.addEventListener('keydown', function (e) {
		if (e.key === 'Escape' && layers.length) { e.stopPropagation(); e.preventDefault(); popLayer(false); }
	}, true);

	/* ---------------- data source (one feed, shared by the grid and the viewer) ---------------- */
	function Source(conf) {
		this.conf = conf || {};
		this.items = [];
		this.page = 0;
		this.more = true;
		this.busy = null;
		this.listeners = [];
	}
	Source.prototype.reset = function (cat) {
		this.conf.cat = cat;
		this.items = [];
		this.page = 0;
		this.more = true;
		this.busy = null;
		this.gen = (this.gen || 0) + 1;
	};
	Source.prototype.add = function (data) {
		var self = this, seen = {}, fresh = [];
		self.items.forEach(function (it) { seen[it.id] = 1; });
		(data.items || []).forEach(function (it) { if (!seen[it.id]) { seen[it.id] = 1; fresh.push(it); } });
		self.items = self.items.concat(fresh);
		self.page++;
		self.more = !!data.more;
		self.listeners.forEach(function (fn) { fn(fresh); });
		return fresh;
	};
	Source.prototype.load = function () {
		var self = this;
		if (self.busy) return self.busy;
		if (!self.more) return Promise.resolve([]);
		var gen = self.gen;
		self.busy = request('dnf_feed', {
			page: self.page + 1, per: self.conf.per || 15, orderby: self.conf.orderby || 'date',
			cat: self.conf.cat || 0, seed: self.conf.seed || 0, first: self.conf.first || 0
		}).then(function (r) {
			if (gen !== self.gen) return [];
			self.busy = null;
			if (!r || !r.success) throw new Error('feed');
			return self.add(r.data);
		}, function (err) { if (gen === self.gen) self.busy = null; throw err; });
		return self.busy;
	};
	Source.prototype.find = function (id) {
		for (var i = 0; i < this.items.length; i++) if (this.items[i].id === id) return this.items[i];
		return null;
	};
	/* every open copy of an item (grid tile, slide) shows the same counts */
	var registry = {};
	function reg(it) {
		var list = registry[it.id] || (registry[it.id] = []);
		if (list.indexOf(it) < 0) list.push(it);
	}
	function syncItem(id, patch) {
		(registry[id] || []).forEach(function (it) { for (var k in patch) it[k] = patch[k]; });
		d.querySelectorAll('[data-dnf-id="' + id + '"]').forEach(function (el) {
			if ('likes' in patch) el.querySelectorAll('.dnf-n-likes').forEach(function (n) { n.textContent = num(patch.likes); });
			if ('comments' in patch) el.querySelectorAll('.dnf-n-comments').forEach(function (n) { n.textContent = num(patch.comments); });
			if ('liked' in patch) el.querySelectorAll('.dnf-like').forEach(function (b) { b.classList.toggle('is-on', !!patch.liked); b.setAttribute('aria-pressed', patch.liked ? 'true' : 'false'); });
		});
	}

	/* ---------------- Explore grid ---------------- */
	var AREAS = [['a', 'b', 't', 'c', 'd'], ['t', 'a', 'b', 'c', 'd']];

	function tile(it, i) {
		reg(it);
		var media = it.thumb
			? '<img src="' + attr(it.thumb) + '" alt="" loading="lazy" decoding="async">'
			: (it.type === 'video' ? '<video src="' + attr(it.src) + '#t=0.1" muted playsinline preload="metadata" tabindex="-1"></video>' : '');
		return '<button type="button" class="dnf-tile' + (it.type === 'video' ? ' is-video' : '') + '" data-i="' + i + '" data-dnf-id="' + it.id + '" style="--d:' + ((i % 15) * 35) + 'ms" aria-label="' + attr((it.caption || T.more || '').slice(0, 80)) + '">'
			+ media
			+ (it.type === 'video' ? '<span class="dnf-badge">' + ico('reel') + '</span>' : '')
			+ '<span class="dnf-hov"><span>' + ico('heart') + '<b class="dnf-n-likes">' + num(it.likes) + '</b></span><span>' + ico('comment') + '<b class="dnf-n-comments">' + num(it.comments) + '</b></span></span>'
			+ '</button>';
	}
	function group(items, start) {
		var g = Math.floor(start / 5), full = items.length === 5, areas = AREAS[g % 2], out = '';
		items.forEach(function (it, k) {
			var t = tile(it, start + k);
			if (full) t = t.replace('style="', 'style="grid-area:' + areas[k] + ';');
			if (full && areas[k] === 't') t = t.replace('class="dnf-tile', 'class="dnf-tile is-tall');
			out += t;
		});
		return '<div class="dnf-grp' + (full ? (g % 2 ? ' is-b' : ' is-a') : ' is-plain') + '" data-g="' + g + '">' + out + '</div>';
	}
	function skeleton() {
		var s = '<div class="dnf-grp is-a is-sk">';
		['a', 'b', 't', 'c', 'd'].forEach(function (a) { s += '<span class="dnf-tile is-sk' + (a === 't' ? ' is-tall' : '') + '" style="grid-area:' + a + '"></span>'; });
		return s + '</div>';
	}

	function Explore(root) {
		var self = this, conf = {};
		try { conf = JSON.parse(root.getAttribute('data-dnf') || '{}'); } catch (e) {}
		self.root = root;
		self.grid = root.querySelector('.dnf-grid');
		self.foot = root.querySelector('.dnf-foot');
		self.src = new Source(conf);
		self.baseCat = conf.cat || 0;
		self.src.listeners.push(function () { self.paint(); });
		root.__dnf = self;

		self.grid.addEventListener('click', function (e) {
			var t = e.target.closest('.dnf-tile:not(.is-sk)');
			if (t) { e.preventDefault(); Viewer.open(self.src, +t.getAttribute('data-i')); return; }
			if (e.target.closest('.dnf-retry')) self.more();
		});
		root.querySelectorAll('.dnf-chip').forEach(function (c) {
			c.addEventListener('click', function () {
				if (c.classList.contains('is-on')) return;
				root.querySelectorAll('.dnf-chip').forEach(function (x) { var on = x === c; x.classList.toggle('is-on', on); x.setAttribute('aria-selected', on ? 'true' : 'false'); });
				try { c.scrollIntoView({ inline: 'center', block: 'nearest', behavior: 'smooth' }); } catch (e) {}
				self.src.reset(+c.getAttribute('data-cat') || self.baseCat);
				self.painted = 0;
				self.grid.innerHTML = skeleton() + skeleton();
				self.more();
			});
		});

		var seed = root.querySelector('script.dnf-seed');
		if (seed) {
			try { self.src.add(JSON.parse(seed.textContent)); } catch (e) { self.more(); }
			seed.remove();
		} else {
			self.grid.innerHTML = skeleton() + skeleton();
			self.more();
		}
		if ('IntersectionObserver' in w) {
			self.io = new IntersectionObserver(function (en) { if (en[0].isIntersecting && self.src.more) self.more(); }, { rootMargin: '900px 0px' });
			self.io.observe(self.foot);
		} else {
			w.addEventListener('scroll', function () { if (self.src.more && self.foot.getBoundingClientRect().top < innerHeight + 900) self.more(); }, { passive: true });
		}
	}
	Explore.prototype.more = function () {
		var self = this;
		if (!self.src.more || self.src.busy) return;
		self.foot.innerHTML = '<span class="dnf-spin"></span>';
		self.src.load().then(function () {
			self.foot.innerHTML = '';
			// the sentinel may still be on screen: keep filling until it is pushed away
			if (self.src.more && self.foot.getBoundingClientRect().top < (w.innerHeight || 800) + 300) setTimeout(function () { self.more(); }, 60);
		}, function () {
			self.foot.innerHTML = '<button type="button" class="dnf-retry">' + esc(T.retry || 'إعادة المحاولة') + '</button>';
			self.foot.querySelector('.dnf-retry').onclick = function () { self.more(); };
		});
	};
	/* re-renders from the last partial group so the Instagram rhythm (5 tiles = 2 rows) never breaks */
	Explore.prototype.paint = function () {
		var self = this, items = self.src.items, from = self.painted || 0;
		if (!items.length) {
			self.grid.innerHTML = self.src.more ? skeleton() : '<div class="dnf-empty"><span class="dnf-empty-ic">' + ico('grid') + '</span><b>' + esc(T.empty) + '</b><small>' + esc(T.emptySub) + '</small></div>';
			self.painted = 0;
			return;
		}
		self.grid.querySelectorAll('.is-sk,.dnf-empty').forEach(function (n) { n.remove(); });
		var start = Math.floor(from / 5) * 5;
		if (start < from) {
			var last = self.grid.querySelector('.dnf-grp[data-g="' + Math.floor(from / 5) + '"]');
			if (last) last.remove();
		}
		var buf = '';
		for (var i = start; i < items.length; i += 5) buf += group(items.slice(i, i + 5), i);
		self.grid.insertAdjacentHTML('beforeend', buf);
		self.painted = items.length;
	};

	/* ---------------- Reels viewer ---------------- */
	var Viewer = (function () {
		var el, trk, src, io, active = -1, muted = true, open = false, unsub = null;

		function build() {
			if (el) return;
			var b = C.brand || {};
			el = d.createElement('div');
			el.className = 'dnf-viewer';
			el.setAttribute('role', 'dialog');
			el.setAttribute('aria-modal', 'true');
			el.setAttribute('aria-label', C.title || 'نفحات');
			el.setAttribute('dir', 'rtl');
			el.hidden = true;
			el.innerHTML = '<div class="dnf-v-top"><button type="button" class="dnf-v-btn dnf-v-back" aria-label="' + attr(T.back) + '">' + ico('back') + '</button>'
				+ '<b class="dnf-v-title">' + esc(C.title || 'نفحات') + '</b>'
				+ '<button type="button" class="dnf-v-btn dnf-v-mute" aria-label="' + attr(T.sound) + '" hidden>' + ico('muted') + '</button></div>'
				+ '<div class="dnf-v-trk"></div>';
			d.body.appendChild(el);
			trk = el.querySelector('.dnf-v-trk');
			el.querySelector('.dnf-v-back').addEventListener('click', function () { closeLayer('viewer'); });
			el.querySelector('.dnf-v-mute').addEventListener('click', function () { setMuted(!muted); });
			trk.addEventListener('click', onClick);
			trk.addEventListener('scroll', function () {
				if (src && src.more && !src.busy && trk.scrollTop + trk.clientHeight * 3 > trk.scrollHeight) src.load().catch(function () {});
			}, { passive: true });
			b.logo = b.logo || '';
		}

		function slide(it, i) {
			reg(it);
			var b = C.brand || {}, media, bg = it.cover || it.thumb || '';
			if (it.type === 'video') {
				media = '<video class="dnf-s-m" data-src="' + attr(it.src) + '"' + (it.cover ? ' poster="' + attr(it.cover) + '"' : '') + ' muted loop playsinline preload="none"></video>'
					+ '<span class="dnf-s-state" aria-hidden="true"></span>';
			} else {
				media = '<img class="dnf-s-m" src="' + attr(it.src) + '" alt="" loading="' + (Math.abs(i - active) < 2 ? 'eager' : 'lazy') + '" decoding="async">';
			}
			var cap = (it.caption || '').trim();
			var tall = it.w && it.h && it.h / it.w >= 1.6; // 9:16 reels fill the screen, other ratios stay whole
			return '<section class="dnf-slide' + (it.type === 'video' ? ' is-video' : '') + (tall ? ' is-tall' : '') + '" data-i="' + i + '" data-dnf-id="' + it.id + '">'
				+ (bg ? '<span class="dnf-s-bg" style="background-image:url(&quot;' + attr(bg) + '&quot;)"></span>' : '')
				+ '<div class="dnf-s-media">' + media + '<span class="dnf-pop" aria-hidden="true">' + ico('heart') + '</span></div>'
				+ '<div class="dnf-s-side">'
				+ '<button type="button" class="dnf-act dnf-like' + (it.liked ? ' is-on' : '') + '" aria-pressed="' + (it.liked ? 'true' : 'false') + '" aria-label="' + attr(T.like) + '">' + ico('heart') + '<b class="dnf-n-likes">' + num(it.likes) + '</b></button>'
				+ '<button type="button" class="dnf-act dnf-cmt" aria-label="' + attr(T.comments) + '">' + ico('comment') + '<b class="dnf-n-comments">' + num(it.comments) + '</b></button>'
				+ '<button type="button" class="dnf-act dnf-share" aria-label="' + attr(T.share) + '">' + ico('send') + '<b>' + esc(T.share) + '</b></button>'
				+ '</div>'
				+ '<div class="dnf-s-info">'
				+ '<div class="dnf-s-who"><span class="dnf-s-av">' + (b.logo ? '<img src="' + attr(b.logo) + '" alt="">' : (b.svg ? '<i class="dnf-s-svg">' + b.svg + '</i>' : '<i>' + esc((b.name || 'د').charAt(0)) + '</i>')) + '</span>'
				+ '<b>' + esc(b.name || '') + '</b>' + (it.cat ? '<span class="dnf-s-cat">' + esc(it.cat) + '</span>' : '') + '<time>' + esc(it.ago || '') + '</time></div>'
				+ (cap ? '<p class="dnf-s-cap is-clamp">' + esc(cap) + '</p><button type="button" class="dnf-s-more" hidden>' + esc(T.more) + '</button>' : '')
				+ '</div>'
				+ '</section>';
		}

		function render(from) {
			var out = '';
			for (var i = from; i < src.items.length; i++) out += slide(src.items[i], i);
			trk.insertAdjacentHTML('beforeend', out);
			trk.querySelectorAll('.dnf-slide:not([data-o])').forEach(function (s) {
				s.setAttribute('data-o', '1');
				io.observe(s);
				var cap = s.querySelector('.dnf-s-cap'), more = s.querySelector('.dnf-s-more');
				if (cap && more) requestAnimationFrame(function () { if (cap.scrollHeight > cap.clientHeight + 2) more.hidden = false; });
			});
		}

		function setActive(i) {
			if (i === active) return;
			active = i;
			trk.querySelectorAll('.dnf-slide').forEach(function (s) {
				var k = +s.getAttribute('data-i'), v = s.querySelector('video');
				s.classList.toggle('is-active', k === i);
				if (!v) return;
				if (Math.abs(k - i) <= 1 && !v.getAttribute('src')) { v.src = v.getAttribute('data-src'); v.preload = k === i ? 'auto' : 'metadata'; }
				if (k === i) { v.muted = muted; var p = v.play(); if (p && p.catch) p.catch(function () { s.classList.add('is-paused'); }); }
				else { try { v.pause(); } catch (e) {} }
			});
			var cur = src.items[i];
			el.querySelector('.dnf-v-mute').hidden = !(cur && cur.type === 'video');
			if (src.more && i >= src.items.length - 3) src.load().catch(function () {});
		}

		function setMuted(m) {
			muted = m;
			var btn = el.querySelector('.dnf-v-mute');
			btn.innerHTML = ico(m ? 'muted' : 'sound');
			btn.classList.add('is-pulse');
			setTimeout(function () { btn.classList.remove('is-pulse'); }, 400);
			trk.querySelectorAll('video').forEach(function (v) { v.muted = m; });
		}

		var lastTap = 0, tapT = null;
		function onClick(e) {
			var s = e.target.closest('.dnf-slide');
			if (!s) return;
			var i = +s.getAttribute('data-i'), it = src.items[i];
			if (!it) return;
			if (e.target.closest('.dnf-like')) { like(it, s, null); return; }
			if (e.target.closest('.dnf-cmt')) { Sheet.open(it); return; }
			if (e.target.closest('.dnf-share')) { share(it); return; }
			if (e.target.closest('.dnf-s-more')) {
				var cap = s.querySelector('.dnf-s-cap'), mb = e.target.closest('.dnf-s-more');
				var clamp = cap.classList.toggle('is-clamp');
				s.classList.toggle('is-expanded', !clamp);
				mb.textContent = clamp ? T.more : T.less;
				return;
			}
			if (!e.target.closest('.dnf-s-media')) return;
			var now = Date.now();
			if (now - lastTap < 320) {
				clearTimeout(tapT);
				lastTap = 0;
				like(it, s, true);
				pop(s, e);
				return;
			}
			lastTap = now;
			if (it.type === 'video') {
				tapT = setTimeout(function () {
					var v = s.querySelector('video');
					if (!v) return;
					if (v.paused) { var p = v.play(); if (p && p.catch) p.catch(function () {}); s.classList.remove('is-paused'); }
					else if (muted) { setMuted(false); }
					else { v.pause(); s.classList.add('is-paused'); }
				}, 330);
			}
		}

		function pop(s, e) {
			var h = s.querySelector('.dnf-pop'), r = s.querySelector('.dnf-s-media').getBoundingClientRect();
			h.style.left = ((e.clientX || r.left + r.width / 2) - r.left) + 'px';
			h.style.top = ((e.clientY || r.top + r.height / 2) - r.top) + 'px';
			h.classList.remove('is-on'); void h.offsetWidth; h.classList.add('is-on');
		}

		function like(it, s, force) {
			if (!+C.logged) { loginToast(T.loginLike); return; }
			var want = force === null ? !it.liked : force;
			if (want === !!it.liked) return;
			var before = { liked: it.liked, likes: it.likes };
			syncItem(it.id, { liked: want ? 1 : 0, likes: Math.max(0, (+it.likes || 0) + (want ? 1 : -1)) });
			var b = s && s.querySelector('.dnf-like');
			if (b && want) { b.classList.remove('is-burst'); void b.offsetWidth; b.classList.add('is-burst'); }
			write('dnf_like', { post_id: it.id, state: want ? 1 : 0 }).then(function (r) {
				if (r && r.success) syncItem(it.id, { liked: r.data.liked, likes: r.data.count });
				else {
					syncItem(it.id, before);
					if (r && r.data && r.data.code === 'login_required') loginToast(T.loginLike); else toast(T.failed);
				}
			}, function () { syncItem(it.id, before); toast(T.failed); });
		}

		function share(it) {
			var cap = (it.caption || '').replace(/\s+/g, ' ').trim();
			if (cap.length > 110) cap = cap.slice(0, 110) + '…';
			// the app's share sheet: WhatsApp, Telegram, SMS, Facebook, e-mail, copy and the phone's other apps
			if (w.DLZShare) {
				w.DLZShare({ text: (cap ? cap + '\n' : '') + 'شاهد هذه النفحة على «دليل الزائر»:', url: it.url, title: 'مشاركة النفحة', sub: 'أرسل رابط هذا المنشور عبر أيّ تطبيق تحبّه' });
				return;
			}
			var data = { title: C.title || 'نفحات', text: (it.caption || '').slice(0, 120), url: it.url };
			if (navigator.share) { navigator.share(data).catch(function () {}); return; }
			var done = function () { toast(T.copied); };
			if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(it.url).then(done, function () { prompt('', it.url); });
			else { prompt('', it.url); }
		}

		function show(source, index) {
			build();
			if (open) return;
			src = source;
			active = -1;
			trk.innerHTML = '';
			io = new IntersectionObserver(function (en) {
				en.forEach(function (x) { if (x.isIntersecting && x.intersectionRatio > 0.6) setActive(+x.target.getAttribute('data-i')); });
			}, { root: trk, threshold: [0.6] });
			unsub = function (fresh) { if (open && fresh.length) render(trk.querySelectorAll('.dnf-slide').length); };
			src.listeners.push(unsub);
			active = index;
			render(0);
			active = -1;
			el.hidden = false;
			open = true;
			pushLayer('viewer', close);
			var target = trk.querySelector('.dnf-slide[data-i="' + index + '"]');
			if (target) trk.scrollTop = target.offsetTop;
			requestAnimationFrame(function () {
				el.classList.add('is-open');
				if (target) trk.scrollTop = target.offsetTop;
				setActive(index);
			});
			try { el.querySelector('.dnf-v-back').focus({ preventScroll: true }); } catch (e) {}
		}

		function close() {
			if (!open) return;
			open = false;
			el.classList.remove('is-open');
			trk.querySelectorAll('video').forEach(function (v) { try { v.pause(); } catch (e) {} v.removeAttribute('src'); try { v.load(); } catch (e) {} });
			if (io) io.disconnect();
			if (src && unsub) { var k = src.listeners.indexOf(unsub); if (k >= 0) src.listeners.splice(k, 1); }
			setTimeout(function () { if (!open) { el.hidden = true; trk.innerHTML = ''; } }, 260);
		}

		return {
			open: function (source, index) {
				if (!source || !source.items[index]) return;
				show(source, index);
			},
			like: like
		};
	})();

	/* ---------------- Comments sheet ---------------- */
	var Sheet = (function () {
		var el, list, form, cur = null;
		function build() {
			if (el) return;
			el = d.createElement('div');
			el.className = 'dnf-sheet';
			el.setAttribute('role', 'dialog');
			el.setAttribute('aria-modal', 'true');
			el.setAttribute('aria-label', T.comments);
			el.setAttribute('dir', 'rtl');
			el.hidden = true;
			el.innerHTML = '<div class="dnf-sheet-bd"></div><div class="dnf-sheet-box"><span class="dnf-grip" aria-hidden="true"></span>'
				+ '<div class="dnf-sheet-head"><b>' + esc(T.comments) + ' <span class="dnf-n-comments"></span></b><button type="button" class="dnf-v-btn dnf-sheet-x" aria-label="' + attr(T.close) + '">' + ico('close') + '</button></div>'
				+ '<div class="dnf-sheet-list"></div>'
				+ (+C.logged
					? '<form class="dnf-sheet-form"><span class="dnf-me">' + (C.avatar ? '<img src="' + attr(C.avatar) + '" alt="" onerror="this.remove()">' : '') + '</span><textarea rows="1" maxlength="600" placeholder="' + attr(T.addComm) + '" aria-label="' + attr(T.addComm) + '"></textarea><button type="submit" disabled>' + esc(T.post) + '</button></form>'
					: '<a class="dnf-sheet-login" href="' + attr(C.login || '#') + '">' + esc(T.loginComm) + '</a>')
				+ '</div>';
			d.body.appendChild(el);
			list = el.querySelector('.dnf-sheet-list');
			form = el.querySelector('.dnf-sheet-form');
			el.querySelector('.dnf-sheet-bd').addEventListener('click', function () { closeLayer('sheet'); });
			el.querySelector('.dnf-sheet-x').addEventListener('click', function () { closeLayer('sheet'); });
			if (form) {
				var ta = form.querySelector('textarea'), btn = form.querySelector('button');
				ta.addEventListener('input', function () {
					btn.disabled = !ta.value.trim();
					ta.style.height = 'auto';
					ta.style.height = Math.min(110, ta.scrollHeight) + 'px';
				});
				ta.addEventListener('keydown', function (e) { if (e.key === 'Enter' && !e.shiftKey && !('ontouchstart' in w)) { e.preventDefault(); if (!btn.disabled) form.requestSubmit ? form.requestSubmit() : form.dispatchEvent(new Event('submit', { cancelable: true })); } });
				form.addEventListener('submit', function (e) {
					e.preventDefault();
					var text = ta.value.trim();
					if (!text || !cur) return;
					btn.disabled = true;
					var it = cur;
					write('dnf_comment', { post_id: it.id, content: text }).then(function (r) {
						if (r && r.success) {
							ta.value = ''; ta.style.height = '';
							list.querySelectorAll('.dnf-c-empty').forEach(function (n) { n.remove(); });
							list.insertAdjacentHTML('beforeend', row(r.data.comment, true));
							list.scrollTop = list.scrollHeight;
							syncItem(it.id, { comments: r.data.count });
							el.querySelector('.dnf-sheet-head .dnf-n-comments').textContent = num(r.data.count);
						} else {
							var c = r && r.data && r.data.code;
							if (c === 'login_required') loginToast(T.loginComm);
							else toast(c === 'too_fast' ? T.tooFast : T.failed);
							btn.disabled = false;
						}
					}, function () { toast(T.failed); btn.disabled = false; });
				});
			}
		}
		function row(c, fresh) {
			return '<div class="dnf-c' + (fresh ? ' is-new' : '') + '"><span class="dnf-c-av">' + esc((c.name || 'ز').trim().charAt(0)) + '<img src="' + attr(c.avatar) + '" alt="" loading="lazy" onerror="this.remove()"></span><div><p><b>' + esc(c.name) + '</b> ' + esc(c.text) + '</p><time>' + esc(c.ago) + '</time></div></div>';
		}
		function open(it) {
			build();
			cur = it;
			el.querySelector('.dnf-sheet-head .dnf-n-comments').textContent = it.comments ? num(it.comments) : '';
			list.innerHTML = '<span class="dnf-spin"></span>';
			el.hidden = false;
			requestAnimationFrame(function () { requestAnimationFrame(function () { el.classList.add('is-open'); }); });
			pushLayer('sheet', close);
			request('dnf_comments', { post_id: it.id }).then(function (r) {
				if (cur !== it) return;
				if (!r || !r.success) { list.innerHTML = '<p class="dnf-c-empty">' + esc(T.failed) + '</p>'; return; }
				var rows = r.data.comments || [];
				list.innerHTML = rows.length ? rows.map(function (c) { return row(c); }).join('') : '<p class="dnf-c-empty">' + esc(T.noComm) + '</p>';
				list.scrollTop = list.scrollHeight;
				syncItem(it.id, { comments: r.data.count });
			}, function () { list.innerHTML = '<p class="dnf-c-empty">' + esc(T.failed) + '</p>'; });
		}
		function close() {
			if (!el) return;
			el.classList.remove('is-open');
			cur = null;
			setTimeout(function () { if (!el.classList.contains('is-open')) el.hidden = true; }, 280);
		}
		return { open: open };
	})();

	/* ---------------- public API + boot ---------------- */
	function mount(scope) {
		if (!scope) return;
		var list = scope.classList && scope.classList.contains('dnf') ? [scope] : [].slice.call(scope.querySelectorAll('.dnf'));
		list.forEach(function (root) { if (!root.__dnf && root.querySelector('.dnf-grid')) new Explore(root); });
	}
	API.mount = mount;
	API.openPost = function (id) {
		id = +id;
		if (!id) return;
		var s = new Source({ per: 15, orderby: 'date', first: id });
		s.load().then(function () { if (s.items.length) Viewer.open(s, 0); }).catch(function () {});
	};

	function boot() {
		d.querySelectorAll('.dnf:not(.dnf-lazy)').forEach(function (r) { mount(r); });
		// shared link: ?nafha=123 opens that post in the viewer
		try {
			var u = new URL(w.location.href), id = u.searchParams.get('nafha');
			if (id) {
				u.searchParams.delete('nafha');
				history.replaceState(history.state, '', u.pathname + u.search + u.hash);
				setTimeout(function () { API.openPost(id); }, 250);
			}
		} catch (e) {}
	}
	if (d.readyState === 'loading') d.addEventListener('DOMContentLoaded', boot); else boot();

	// Elementor editor preview / popups render the widget after load
	var hooked = false;
	function hookElementor() {
		if (hooked || !w.elementorFrontend || !w.elementorFrontend.hooks) return;
		hooked = true;
		w.elementorFrontend.hooks.addAction('frontend/element_ready/ig_social_posts.default', function ($s) { mount($s && $s[0] ? $s[0] : $s); });
	}
	if (w.jQuery) w.jQuery(w).on('elementor/frontend/init', hookElementor);
	w.addEventListener('elementor/frontend/init', hookElementor);
	hookElementor();
})();
