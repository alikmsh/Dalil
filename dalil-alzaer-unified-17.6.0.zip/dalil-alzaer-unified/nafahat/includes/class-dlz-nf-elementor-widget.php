<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

/**
 * «نفحات» — Instagram-style Explore for Elementor.
 * Keeps the old widget name (ig_social_posts) so pages built with the standalone plugin keep working.
 */
class DLZ_NF_Elementor_Widget extends Widget_Base {

	public function get_name() {
		return 'ig_social_posts';
	}

	public function get_title() {
		return 'نفحات (اکسپلور اینستاگرامی)';
	}

	public function get_icon() {
		return 'eicon-gallery-grid';
	}

	public function get_categories() {
		return array( 'dlz-nafahat' );
	}

	public function get_keywords() {
		return array( 'nafahat', 'explore', 'instagram', 'reels', 'نفحات', 'اکسپلور', 'اینستاگرام', 'پست' );
	}

	public function get_style_depends() {
		return array( 'dlz-nafahat' );
	}

	public function get_script_depends() {
		return array( 'dlz-nafahat' );
	}

	private static function cats() {
		$out   = array( '0' => 'همه دسته‌ها' );
		$terms = get_terms( array( 'taxonomy' => DLZ_Nafahat::TAX, 'hide_empty' => false ) );
		if ( ! is_wp_error( $terms ) ) {
			foreach ( $terms as $t ) {
				$out[ (string) $t->term_id ] = $t->name;
			}
		}
		return $out;
	}

	protected function register_controls() {
		$this->start_controls_section( 'content', array( 'label' => 'نفحات' ) );
		$this->add_control(
			'title',
			array(
				'label'       => 'عنوان بالای اکسپلور',
				'type'        => Controls_Manager::TEXT,
				'default'     => '',
				'placeholder' => 'مثلاً: نفحات',
			)
		);
		$this->add_control(
			'limit',
			array(
				'label'       => 'تعداد در هر بار بارگذاری',
				'type'        => Controls_Manager::NUMBER,
				'default'     => 15,
				'min'         => 5,
				'max'         => 30,
				'step'        => 5,
				'description' => 'با اسکرول، ادامه‌ی نفحات خودکار بارگذاری می‌شود.',
			)
		);
		$this->add_control(
			'orderby',
			array(
				'label'   => 'ترتیب',
				'type'    => Controls_Manager::SELECT,
				'default' => 'date',
				'options' => array(
					'date'       => 'جدیدترین',
					'menu_order' => 'ترتیب دستی (ویژگی‌ها ← ترتیب)',
					'random'     => 'تصادفی',
				),
			)
		);
		$this->add_control(
			'category',
			array(
				'label'   => 'فقط این دسته',
				'type'    => Controls_Manager::SELECT,
				'default' => '0',
				'options' => self::cats(),
			)
		);
		$this->add_control(
			'chips',
			array(
				'label'        => 'نوار دسته‌ها (چیپ‌ها)',
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => 'نمایش',
				'label_off'    => 'مخفی',
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);
		$this->end_controls_section();
	}

	protected function render() {
		$s = $this->get_settings_for_display();
		echo DLZ_Nafahat::render( // phpcs:ignore
			array(
				'per'     => isset( $s['limit'] ) ? (int) $s['limit'] : 15,
				'orderby' => isset( $s['orderby'] ) ? ( 'random' === $s['orderby'] || 'rand' === $s['orderby'] ? 'random' : $s['orderby'] ) : 'date',
				'cat'     => isset( $s['category'] ) ? (int) $s['category'] : 0,
				'chips'   => isset( $s['chips'] ) && 'yes' === $s['chips'],
				'title'   => isset( $s['title'] ) ? $s['title'] : '',
			)
		);
	}
}
