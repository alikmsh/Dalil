<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Read helpers shared by the renderer, AJAX and the admin list. */
class DLZ_NF_Data {

	/** Media of a post: type image|video, full src, tile thumb, cover (poster) and size. */
	public static function media( $post_id ) {
		$id = absint( get_post_meta( $post_id, '_ige_media_id', true ) );
		if ( ! $id && has_post_thumbnail( $post_id ) ) {
			$id = (int) get_post_thumbnail_id( $post_id );
		}
		$out = array( 'type' => 'image', 'src' => '', 'thumb' => '', 'cover' => '', 'w' => 0, 'h' => 0 );
		if ( ! $id ) {
			return $out;
		}
		$mime = (string) get_post_mime_type( $id );
		if ( 0 === strpos( $mime, 'video/' ) ) {
			$out['type'] = 'video';
			$out['src']  = (string) wp_get_attachment_url( $id );
			$meta        = wp_get_attachment_metadata( $id );
			$out['w']    = isset( $meta['width'] ) ? (int) $meta['width'] : 0;
			$out['h']    = isset( $meta['height'] ) ? (int) $meta['height'] : 0;
			$cover       = has_post_thumbnail( $post_id ) ? (int) get_post_thumbnail_id( $post_id ) : 0;
			if ( $cover && $cover !== $id ) {
				$out['cover'] = (string) wp_get_attachment_image_url( $cover, 'large' );
				$out['thumb'] = (string) wp_get_attachment_image_url( $cover, 'medium_large' );
			}
			return $out;
		}
		$full = wp_get_attachment_image_src( $id, 'large' );
		if ( $full ) {
			$out['src'] = (string) $full[0];
			$out['w']   = (int) $full[1];
			$out['h']   = (int) $full[2];
		} else {
			$out['src'] = (string) wp_get_attachment_url( $id );
		}
		$thumb        = wp_get_attachment_image_url( $id, 'medium_large' );
		$out['thumb'] = $thumb ? (string) $thumb : $out['src'];
		$out['cover'] = $out['src'];
		return $out;
	}

	public static function liked_users( $post_id ) {
		$likes = get_post_meta( $post_id, '_ige_liked_users', true );
		return is_array( $likes ) ? array_values( array_unique( array_map( 'intval', $likes ) ) ) : array();
	}

	public static function likes( $post_id ) {
		$n = get_post_meta( $post_id, '_ige_like_count', true );
		return '' === $n ? count( self::liked_users( $post_id ) ) : (int) $n;
	}

	public static function liked( $post_id, $user_id = 0 ) {
		$user_id = (int) ( $user_id ? $user_id : get_current_user_id() );
		return $user_id && in_array( $user_id, self::liked_users( $post_id ), true );
	}

	public static function user_label( $user_id ) {
		$user = get_userdata( (int) $user_id );
		if ( ! $user ) {
			return 'زائر';
		}
		$name = trim( $user->first_name . ' ' . $user->last_name );
		return $name ? $name : $user->display_name;
	}

	public static function avatar( $user_id ) {
		$user_id = (int) $user_id;
		if ( $user_id ) {
			$custom = get_user_meta( $user_id, 'mp_avatar', true );
			if ( $custom ) {
				return esc_url_raw( $custom );
			}
		}
		return (string) get_avatar_url( $user_id, array( 'size' => 96 ) );
	}

	/** «منذ ٣ ساعات» style relative time in Arabic. */
	public static function ago( $gmt_ts ) {
		$diff = max( 0, time() - (int) $gmt_ts );
		if ( $diff < 60 ) {
			return 'الآن';
		}
		$units = array(
			array( 31536000, 'سنة', 'سنتين', 'سنوات' ),
			array( 2592000, 'شهر', 'شهرين', 'أشهر' ),
			array( 604800, 'أسبوع', 'أسبوعين', 'أسابيع' ),
			array( 86400, 'يوم', 'يومين', 'أيام' ),
			array( 3600, 'ساعة', 'ساعتين', 'ساعات' ),
			array( 60, 'دقيقة', 'دقيقتين', 'دقائق' ),
		);
		foreach ( $units as $u ) {
			$n = (int) floor( $diff / $u[0] );
			if ( $n < 1 ) {
				continue;
			}
			if ( 1 === $n ) {
				return 'منذ ' . $u[1];
			}
			if ( 2 === $n ) {
				return 'منذ ' . $u[2];
			}
			return 'منذ ' . $n . ' ' . ( $n <= 10 ? $u[3] : $u[1] );
		}
		return 'الآن';
	}

	public static function share_url( $post_id ) {
		return add_query_arg( 'nafha', (int) $post_id, home_url( '/' ) );
	}

	public static function item( $p ) {
		$p = get_post( $p );
		if ( ! $p ) {
			return null;
		}
		$m = self::media( $p->ID );
		if ( ! $m['src'] ) {
			return null; // a post without a photo / video has nothing to show in Explore
		}
		$terms = get_the_terms( $p, DLZ_Nafahat::TAX );
		return array(
			'id'       => (int) $p->ID,
			'type'     => $m['type'],
			'src'      => $m['src'],
			'thumb'    => $m['thumb'],
			'cover'    => $m['cover'],
			'w'        => $m['w'],
			'h'        => $m['h'],
			'caption'  => (string) get_post_meta( $p->ID, '_ige_caption', true ),
			'likes'    => self::likes( $p->ID ),
			'liked'    => self::liked( $p->ID ) ? 1 : 0,
			'comments' => (int) get_comments_number( $p->ID ),
			'ago'      => self::ago( get_post_time( 'U', true, $p ) ),
			'cat'      => ( $terms && ! is_wp_error( $terms ) ) ? $terms[0]->name : '',
			'url'      => self::share_url( $p->ID ),
		);
	}

	/**
	 * One page of the feed. $a: page, per, orderby (date|menu_order|random), cat, seed, first (post id shown first).
	 * Returns array( items => [], more => bool ).
	 */
	public static function feed( $a ) {
		$per     = max( 1, min( 30, (int) $a['per'] ) );
		$page    = max( 1, (int) $a['page'] );
		$orderby = isset( $a['orderby'] ) ? $a['orderby'] : 'date';
		$args    = array(
			'post_type'              => DLZ_Nafahat::CPT,
			'post_status'            => 'publish',
			'posts_per_page'         => $per,
			'paged'                  => $page,
			'ignore_sticky_posts'    => true,
			'no_found_rows'          => false,
			'update_post_term_cache' => true,
			'suppress_filters'       => false,
		);
		if ( 'menu_order' === $orderby ) {
			$args['orderby'] = array( 'menu_order' => 'ASC', 'date' => 'DESC' );
		} elseif ( 'random' === $orderby ) {
			$args['orderby'] = 'rand(' . max( 1, (int) ( isset( $a['seed'] ) ? $a['seed'] : 1 ) ) . ')'; // seeded: stable across pages
		} else {
			$args['orderby'] = array( 'date' => 'DESC', 'ID' => 'DESC' );
		}
		if ( ! empty( $a['cat'] ) ) {
			$args['tax_query'] = array( array( 'taxonomy' => DLZ_Nafahat::TAX, 'field' => 'term_id', 'terms' => array( (int) $a['cat'] ) ) ); // phpcs:ignore
		}
		$first = ! empty( $a['first'] ) ? (int) $a['first'] : 0;
		if ( $first ) {
			$args['post__not_in'] = array( $first ); // phpcs:ignore
		}
		$q     = new WP_Query( $args );
		$items = array();
		if ( $first && 1 === $page ) {
			$fp = get_post( $first );
			if ( $fp && DLZ_Nafahat::CPT === $fp->post_type && 'publish' === $fp->post_status ) {
				$it = self::item( $fp );
				if ( $it ) {
					$items[] = $it;
				}
			}
		}
		foreach ( $q->posts as $p ) {
			$it = self::item( $p );
			if ( $it ) {
				$items[] = $it;
			}
		}
		return array( 'items' => $items, 'more' => $page < (int) $q->max_num_pages );
	}

	public static function comment_row( $c ) {
		$uid = (int) $c->user_id;
		return array(
			'id'     => (int) $c->comment_ID,
			'name'   => $uid ? self::user_label( $uid ) : ( $c->comment_author ? $c->comment_author : 'زائر' ),
			'avatar' => self::avatar( $uid ),
			'text'   => wp_strip_all_tags( (string) $c->comment_content ),
			'ago'    => self::ago( strtotime( $c->comment_date_gmt . ' UTC' ) ),
			'mine'   => $uid && get_current_user_id() === $uid ? 1 : 0,
		);
	}
}
