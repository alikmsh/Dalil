<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Feed, likes and comments over admin-ajax. Read endpoints are public; writes need a login + nonce. */
class DLZ_NF_Ajax {

	public static function init() {
		foreach ( array( 'feed', 'comments', 'nonce' ) as $a ) {
			add_action( 'wp_ajax_dnf_' . $a, array( __CLASS__, $a ) );
			add_action( 'wp_ajax_nopriv_dnf_' . $a, array( __CLASS__, $a ) );
		}
		add_action( 'wp_ajax_dnf_like', array( __CLASS__, 'like' ) );
		add_action( 'wp_ajax_dnf_comment', array( __CLASS__, 'comment' ) );
		add_action( 'wp_ajax_nopriv_dnf_like', array( __CLASS__, 'need_login' ) );
		add_action( 'wp_ajax_nopriv_dnf_comment', array( __CLASS__, 'need_login' ) );
		// Older front-ends (cached pages of the standalone plugin) keep working.
		add_action( 'wp_ajax_ige_toggle_like', array( __CLASS__, 'legacy_like' ) );
		add_action( 'wp_ajax_ige_add_comment', array( __CLASS__, 'legacy_comment' ) );
	}

	private static function req( $k, $default = '' ) {
		return isset( $_REQUEST[ $k ] ) ? wp_unslash( $_REQUEST[ $k ] ) : $default; // phpcs:ignore
	}

	/** Cached pages carry stale nonces: answer with a clear code so the browser can refresh and retry. */
	private static function check_nonce() {
		$n = sanitize_text_field( (string) self::req( 'nonce' ) );
		if ( ! wp_verify_nonce( $n, DLZ_Nafahat::NONCE ) ) {
			wp_send_json_error( array( 'code' => 'bad_nonce' ), 403 );
		}
	}

	private static function post_or_fail( $id ) {
		$p = get_post( absint( $id ) );
		if ( ! $p || DLZ_Nafahat::CPT !== $p->post_type || 'publish' !== $p->post_status ) {
			wp_send_json_error( array( 'code' => 'invalid_post' ), 404 );
		}
		return $p;
	}

	public static function need_login() {
		wp_send_json_error( array( 'code' => 'login_required', 'login' => DLZ_Nafahat::login_url() ), 401 );
	}

	public static function nonce() {
		nocache_headers();
		wp_send_json_success( array( 'nonce' => wp_create_nonce( DLZ_Nafahat::NONCE ), 'logged' => is_user_logged_in() ? 1 : 0 ) );
	}

	public static function feed() {
		nocache_headers();
		$orderby = sanitize_key( (string) self::req( 'orderby', 'date' ) );
		$data    = DLZ_NF_Data::feed(
			array(
				'page'    => absint( self::req( 'page', 1 ) ),
				'per'     => absint( self::req( 'per', 15 ) ),
				'orderby' => in_array( $orderby, array( 'date', 'menu_order', 'random' ), true ) ? $orderby : 'date',
				'cat'     => absint( self::req( 'cat', 0 ) ),
				'seed'    => absint( self::req( 'seed', 0 ) ),
				'first'   => absint( self::req( 'first', 0 ) ),
			)
		);
		wp_send_json_success( $data );
	}

	public static function comments() {
		nocache_headers();
		$p    = self::post_or_fail( self::req( 'post_id' ) );
		$list = get_comments(
			array(
				'post_id' => $p->ID,
				'status'  => 'approve',
				'type'    => 'comment',
				'number'  => 100,
				'orderby' => 'comment_date_gmt',
				'order'   => 'DESC',
			)
		);
		$rows = array();
		foreach ( array_reverse( $list ) as $c ) {
			$rows[] = DLZ_NF_Data::comment_row( $c );
		}
		wp_send_json_success( array( 'comments' => $rows, 'count' => (int) get_comments_number( $p->ID ) ) );
	}

	public static function like() {
		self::check_nonce();
		$p   = self::post_or_fail( self::req( 'post_id' ) );
		$uid = get_current_user_id();
		wp_send_json_success( self::toggle( $p->ID, $uid ) );
	}

	private static function toggle( $post_id, $uid ) {
		$likes = DLZ_NF_Data::liked_users( $post_id );
		$want  = self::req( 'state', '' );
		$has   = in_array( $uid, $likes, true );
		$liked = '' === $want ? ! $has : ( '1' === (string) $want );
		if ( $liked && ! $has ) {
			$likes[] = $uid;
		} elseif ( ! $liked && $has ) {
			$likes = array_values( array_diff( $likes, array( $uid ) ) );
		}
		update_post_meta( $post_id, '_ige_liked_users', $likes );
		update_post_meta( $post_id, '_ige_like_count', count( $likes ) );
		return array( 'liked' => $liked ? 1 : 0, 'count' => count( $likes ) );
	}

	public static function comment() {
		self::check_nonce();
		$p    = self::post_or_fail( self::req( 'post_id' ) );
		$text = trim( sanitize_textarea_field( (string) self::req( 'content' ) ) );
		if ( '' === $text ) {
			wp_send_json_error( array( 'code' => 'empty' ), 400 );
		}
		if ( function_exists( 'mb_substr' ) ) {
			$text = mb_substr( $text, 0, 600 );
		}
		$user = wp_get_current_user();
		$key  = 'dnf_cmt_' . $user->ID;
		if ( get_transient( $key ) ) {
			wp_send_json_error( array( 'code' => 'too_fast' ), 429 );
		}
		set_transient( $key, 1, 8 );

		$id = wp_insert_comment(
			wp_slash(
				array(
					'comment_post_ID'      => $p->ID,
					'comment_content'      => $text,
					'user_id'              => $user->ID,
					'comment_author'       => DLZ_NF_Data::user_label( $user->ID ),
					'comment_author_email' => $user->user_email,
					'comment_author_IP'    => isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '',
					'comment_approved'     => 1,
					'comment_type'         => 'comment',
				)
			)
		);
		if ( ! $id ) {
			wp_send_json_error( array( 'code' => 'failed' ), 500 );
		}
		wp_send_json_success(
			array(
				'comment' => DLZ_NF_Data::comment_row( get_comment( $id ) ),
				'count'   => (int) get_comments_number( $p->ID ),
			)
		);
	}

	/* Old action names used by the standalone plugin's script. */
	public static function legacy_like() {
		check_ajax_referer( 'ige_social_nonce', 'nonce' );
		$p = self::post_or_fail( self::req( 'post_id' ) );
		wp_send_json_success( self::toggle( $p->ID, get_current_user_id() ) );
	}

	public static function legacy_comment() {
		check_ajax_referer( 'ige_social_nonce', 'nonce' );
		$_REQUEST['nonce'] = wp_create_nonce( DLZ_Nafahat::NONCE );
		self::comment();
	}
}
