<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** «نفحات» post type + categories + admin list (keeps the old ige_photo / ige_category names). */
class DLZ_NF_CPT {

	public static function init() {
		add_action( 'init', array( __CLASS__, 'register' ) );
		add_filter( 'manage_' . DLZ_Nafahat::CPT . '_posts_columns', array( __CLASS__, 'columns' ) );
		add_action( 'manage_' . DLZ_Nafahat::CPT . '_posts_custom_column', array( __CLASS__, 'column' ), 10, 2 );
		add_action( 'pre_get_posts', array( __CLASS__, 'admin_order' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'admin_css' ) );
		add_filter( 'enter_title_here', array( __CLASS__, 'title_ph' ), 10, 2 );
		add_filter( 'post_updated_messages', array( __CLASS__, 'messages' ) );
	}

	/** Gold-friendly menu icon (WordPress recolors it to match the admin scheme). */
	public static function menu_icon() {
		$svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path fill="black" d="M5 2h10a3 3 0 0 1 3 3v10a3 3 0 0 1-3 3H5a3 3 0 0 1-3-3V5a3 3 0 0 1 3-3zm0 1.6A1.4 1.4 0 0 0 3.6 5v1h12.8V5A1.4 1.4 0 0 0 15 3.6h-1.3l-1.7 2.4h-1.8l1.7-2.4H9.4L7.7 6H5.9l1.7-2.4zM3.6 7.6V15A1.4 1.4 0 0 0 5 16.4h10a1.4 1.4 0 0 0 1.4-1.4V7.6zm4.6 1.6 5 2.9-5 2.9z"/></svg>';
		return 'data:image/svg+xml;base64,' . base64_encode( $svg ); // phpcs:ignore
	}

	public static function register() {
		if ( post_type_exists( DLZ_Nafahat::CPT ) ) {
			return;
		}
		register_post_type(
			DLZ_Nafahat::CPT,
			array(
				'labels'              => array(
					'name'                  => 'نفحات',
					'singular_name'         => 'نفحه',
					'menu_name'             => 'نفحات',
					'all_items'             => 'همه نفحات',
					'add_new'               => 'افزودن نفحه',
					'add_new_item'          => 'افزودن نفحه جدید',
					'edit_item'             => 'ویرایش نفحه',
					'new_item'              => 'نفحه جدید',
					'view_item'             => 'مشاهده',
					'search_items'          => 'جستجوی نفحات',
					'not_found'             => 'هنوز نفحه‌ای منتشر نشده است',
					'not_found_in_trash'    => 'در زباله‌دان چیزی نیست',
					'featured_image'        => 'کاور (تصویر شاخص)',
					'set_featured_image'    => 'انتخاب کاور',
					'remove_featured_image' => 'حذف کاور',
					'use_featured_image'    => 'استفاده به‌عنوان کاور',
				),
				'public'              => false,
				'publicly_queryable'  => false,
				'exclude_from_search' => true,
				'show_ui'             => true,
				'show_in_menu'        => true,
				'show_in_admin_bar'   => true,
				'menu_position'       => 26,
				'menu_icon'           => self::menu_icon(),
				'capability_type'     => 'post',
				'map_meta_cap'        => true,
				'hierarchical'        => false,
				'supports'            => array( 'title', 'thumbnail', 'comments', 'page-attributes' ),
				'has_archive'         => false,
				'rewrite'             => false,
				'query_var'           => false,
				'show_in_rest'        => true,
			)
		);
		if ( ! taxonomy_exists( DLZ_Nafahat::TAX ) ) {
			register_taxonomy(
				DLZ_Nafahat::TAX,
				DLZ_Nafahat::CPT,
				array(
					'labels'            => array(
						'name'          => 'دسته‌های نفحات',
						'singular_name' => 'دسته',
						'all_items'     => 'همه دسته‌ها',
						'edit_item'     => 'ویرایش دسته',
						'add_new_item'  => 'افزودن دسته جدید',
						'menu_name'     => 'دسته‌بندی‌ها',
					),
					'hierarchical'      => true,
					'public'            => false,
					'show_ui'           => true,
					'show_admin_column' => true,
					'show_in_rest'      => true,
					'rewrite'           => false,
				)
			);
		}
	}

	public static function columns( $columns ) {
		$out = array();
		if ( isset( $columns['cb'] ) ) {
			$out['cb'] = $columns['cb'];
		}
		$out['dnf_thumb'] = 'نفحه';
		$out['title']     = 'عنوان / کپشن';
		$out['dnf_type']  = 'نوع';
		$out['dnf_likes'] = 'لایک';
		$out['dnf_comm']  = 'نظر';
		$tax              = 'taxonomy-' . DLZ_Nafahat::TAX;
		if ( isset( $columns[ $tax ] ) ) {
			$out[ $tax ] = $columns[ $tax ];
		}
		$out['date'] = isset( $columns['date'] ) ? $columns['date'] : 'تاریخ';
		return $out;
	}

	public static function column( $column, $post_id ) {
		$m = DLZ_NF_Data::media( $post_id );
		if ( 'dnf_thumb' === $column ) {
			if ( $m['thumb'] ) {
				echo '<img src="' . esc_url( $m['thumb'] ) . '" alt="" style="width:64px;height:64px;object-fit:cover;border-radius:10px;display:block">';
			} elseif ( 'video' === $m['type'] && $m['src'] ) {
				echo '<video src="' . esc_url( $m['src'] ) . '#t=0.1" muted preload="metadata" style="width:64px;height:64px;object-fit:cover;border-radius:10px;display:block;background:#111"></video>';
			} else {
				echo '<span style="display:inline-block;width:64px;height:64px;border-radius:10px;background:#f0ece2"></span>';
			}
		}
		if ( 'dnf_type' === $column ) {
			echo 'video' === $m['type'] ? '🎬 ویدیو' : ( $m['src'] ? '🖼️ عکس' : '—' );
		}
		if ( 'dnf_likes' === $column ) {
			echo esc_html( number_format_i18n( DLZ_NF_Data::likes( $post_id ) ) );
		}
		if ( 'dnf_comm' === $column ) {
			echo esc_html( number_format_i18n( (int) get_comments_number( $post_id ) ) );
		}
	}

	public static function admin_order( $q ) {
		if ( is_admin() && $q->is_main_query() && DLZ_Nafahat::CPT === $q->get( 'post_type' ) && ! $q->get( 'orderby' ) ) {
			$q->set( 'orderby', 'date' );
			$q->set( 'order', 'DESC' );
		}
	}

	public static function admin_css() {
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( $screen && DLZ_Nafahat::CPT === $screen->post_type ) {
			wp_enqueue_style( 'dlz-nafahat-admin', DLZ_NF_URL . 'assets/admin.css', array(), DLZ_NF_VERSION );
		}
	}

	public static function title_ph( $text, $post ) {
		return ( $post && DLZ_Nafahat::CPT === $post->post_type ) ? 'عنوان داخلی (اختیاری – در سایت نمایش داده نمی‌شود)' : $text;
	}

	public static function messages( $m ) {
		$m[ DLZ_Nafahat::CPT ] = array_fill( 0, 11, '' );
		$m[ DLZ_Nafahat::CPT ][1] = 'نفحه به‌روزرسانی شد.';
		$m[ DLZ_Nafahat::CPT ][4] = 'نفحه به‌روزرسانی شد.';
		$m[ DLZ_Nafahat::CPT ][6] = 'نفحه منتشر شد و در «نفحات» نمایش داده می‌شود.';
		$m[ DLZ_Nafahat::CPT ][7] = 'ذخیره شد.';
		$m[ DLZ_Nafahat::CPT ][8] = 'ارسال شد.';
		$m[ DLZ_Nafahat::CPT ][9] = 'زمان‌بندی شد.';
		$m[ DLZ_Nafahat::CPT ][10] = 'پیش‌نویس به‌روزرسانی شد.';
		return $m;
	}
}
