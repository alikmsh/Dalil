<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Media + caption box for a «نفحه» (same meta keys as the old plugin: _ige_media_id, _ige_caption). */
class DLZ_NF_Metabox {

	public static function init() {
		add_action( 'add_meta_boxes', array( __CLASS__, 'add' ) );
		add_action( 'save_post_' . DLZ_Nafahat::CPT, array( __CLASS__, 'save' ), 10, 2 );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'media' ) );
	}

	public static function media( $hook ) {
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( $screen && DLZ_Nafahat::CPT === $screen->post_type && in_array( $hook, array( 'post.php', 'post-new.php' ), true ) ) {
			wp_enqueue_media();
		}
	}

	public static function add() {
		add_meta_box( 'dnf_box', 'محتوای نفحه (عکس یا ویدیو + کپشن)', array( __CLASS__, 'box' ), DLZ_Nafahat::CPT, 'normal', 'high' );
	}

	public static function box( $post ) {
		wp_nonce_field( 'dnf_save', 'dnf_nonce' );
		$id      = absint( get_post_meta( $post->ID, '_ige_media_id', true ) );
		$caption = (string) get_post_meta( $post->ID, '_ige_caption', true );
		$url     = $id ? wp_get_attachment_url( $id ) : '';
		$mime    = $id ? (string) get_post_mime_type( $id ) : '';
		?>
		<div class="dnf-admin" dir="rtl">
			<input type="hidden" id="dnf_media_id" name="dnf_media_id" value="<?php echo esc_attr( $id ); ?>">
			<div class="dnf-admin-stage">
				<div id="dnf_media_preview" class="dnf-admin-prev<?php echo $url ? ' has-media' : ''; ?>">
					<?php if ( $url && 0 === strpos( $mime, 'video/' ) ) : ?>
						<video src="<?php echo esc_url( $url ); ?>" controls playsinline></video>
					<?php elseif ( $url ) : ?>
						<img src="<?php echo esc_url( $url ); ?>" alt="">
					<?php else : ?>
						<span class="dnf-admin-empty">هنوز عکس یا ویدیویی انتخاب نشده</span>
					<?php endif; ?>
				</div>
				<div class="dnf-admin-side">
					<button type="button" class="button button-primary button-hero" id="dnf_pick">انتخاب عکس یا ویدیو</button>
					<button type="button" class="button" id="dnf_remove" <?php disabled( ! $id ); ?>>حذف فایل</button>
					<p class="description">بهترین نسبت: عمودی ۹:۱۶ یا مربع. ویدیو در نفحات خودکار و بی‌صدا پخش می‌شود و کاربر با یک ضربه صدا را روشن می‌کند.<br>برای ویدیو می‌توانید از کادر «کاور» یک تصویر به‌عنوان کاور انتخاب کنید.</p>
				</div>
			</div>
			<p><label for="dnf_caption"><strong>کپشن</strong> <span class="description">(به عربی؛ هر خط جدا نمایش داده می‌شود)</span></label></p>
			<textarea id="dnf_caption" name="dnf_caption" rows="5" placeholder="اكتب وصفاً قصيراً لهذه النفحة…"><?php echo esc_textarea( $caption ); ?></textarea>
		</div>
		<script>
		jQuery(function ($) {
			var frame;
			function prev(a) {
				var h = (a.mime || '').indexOf('video/') === 0
					? '<video src="' + a.url + '" controls playsinline></video>'
					: '<img src="' + a.url + '" alt="">';
				$('#dnf_media_preview').addClass('has-media').html(h);
			}
			$('#dnf_pick').on('click', function (e) {
				e.preventDefault();
				if (frame) { frame.open(); return; }
				frame = wp.media({ title: 'انتخاب عکس یا ویدیو', button: { text: 'استفاده در نفحه' }, library: { type: ['image', 'video'] }, multiple: false });
				frame.on('select', function () {
					var a = frame.state().get('selection').first().toJSON();
					$('#dnf_media_id').val(a.id); prev(a); $('#dnf_remove').prop('disabled', false);
				});
				frame.open();
			});
			$('#dnf_remove').on('click', function (e) {
				e.preventDefault();
				$('#dnf_media_id').val('');
				$('#dnf_media_preview').removeClass('has-media').html('<span class="dnf-admin-empty">هنوز عکس یا ویدیویی انتخاب نشده</span>');
				$(this).prop('disabled', true);
			});
		});
		</script>
		<?php
	}

	public static function save( $post_id, $post ) {
		if ( ! isset( $_POST['dnf_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['dnf_nonce'] ) ), 'dnf_save' ) ) {
			return;
		}
		if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || wp_is_post_revision( $post_id ) ) {
			return;
		}
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}
		$media = isset( $_POST['dnf_media_id'] ) ? absint( $_POST['dnf_media_id'] ) : 0;
		if ( $media && get_post( $media ) && 'attachment' === get_post_type( $media ) ) {
			update_post_meta( $post_id, '_ige_media_id', $media );
			$mime = (string) get_post_mime_type( $media );
			// A photo is its own cover; a video keeps the cover the editor picked (if any).
			if ( 0 === strpos( $mime, 'image/' ) ) {
				set_post_thumbnail( $post_id, $media );
			}
		} else {
			delete_post_meta( $post_id, '_ige_media_id' );
		}
		$caption = isset( $_POST['dnf_caption'] ) ? sanitize_textarea_field( wp_unslash( $_POST['dnf_caption'] ) ) : '';
		update_post_meta( $post_id, '_ige_caption', $caption );

		// WordPress wants a title; the feed never shows it, so derive a harmless one from the caption.
		if ( '' === trim( (string) $post->post_title ) ) {
			$title = $caption ? wp_trim_words( $caption, 8, '…' ) : 'نفحه ' . $post_id;
			remove_action( 'save_post_' . DLZ_Nafahat::CPT, array( __CLASS__, 'save' ), 10 );
			wp_update_post( array( 'ID' => $post_id, 'post_title' => $title ) );
			add_action( 'save_post_' . DLZ_Nafahat::CPT, array( __CLASS__, 'save' ), 10, 2 );
		}
	}
}
