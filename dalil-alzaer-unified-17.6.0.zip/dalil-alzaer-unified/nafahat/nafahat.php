<?php
/**
 * Dalil Al Zaer — «نفحات» (merged from the standalone "IG Social Posts / ig-explore-grid" plugin).
 *
 * Instagram-style Explore grid + Reels viewer for short photo / video posts, with likes,
 * comments and sharing. Same post type, taxonomy and meta keys as the old plugin, so every
 * post, like and comment that already exists keeps working after the switch.
 *
 * Admin: Persian — Front: Arabic.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'DLZ_NF_VERSION', '15.0.0' );
define( 'DLZ_NF_PATH', plugin_dir_path( __FILE__ ) );
define( 'DLZ_NF_URL', plugin_dir_url( __FILE__ ) );

require_once DLZ_NF_PATH . 'includes/class-dlz-nf-cpt.php';
require_once DLZ_NF_PATH . 'includes/class-dlz-nf-metabox.php';
require_once DLZ_NF_PATH . 'includes/class-dlz-nf-data.php';
require_once DLZ_NF_PATH . 'includes/class-dlz-nf-ajax.php';

final class DLZ_Nafahat {

	const CPT   = 'ige_photo';
	const TAX   = 'ige_category';
	const NONCE = 'dlz_nafahat';

	private static $on       = false;
	private static $enqueued = false;

	/** Runs on plugins_loaded, after every plugin file is included. */
	public static function boot() {
		if ( self::$on ) {
			return;
		}
		// The old standalone plugin is still active: let it run alone and ask the admin to remove it.
		if ( defined( 'IGE_VERSION' ) || class_exists( 'IGE_Renderer', false ) ) {
			add_action( 'admin_notices', array( __CLASS__, 'standalone_notice' ) );
			return;
		}
		self::$on = true;

		DLZ_NF_CPT::init();
		DLZ_NF_Metabox::init();
		DLZ_NF_Ajax::init();

		foreach ( array( 'dlz_nafahat', 'ig_social_posts', 'ig_explore_grid' ) as $tag ) {
			add_shortcode( $tag, array( __CLASS__, 'shortcode' ) );
		}
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'register_assets' ), 5 );
		add_action( 'elementor/elements/categories_registered', array( __CLASS__, 'elementor_category' ) );
		add_action( 'elementor/widgets/register', array( __CLASS__, 'elementor_widget' ) );
		add_action( 'elementor/frontend/after_register_scripts', array( __CLASS__, 'register_assets' ) );
		add_action( 'elementor/frontend/after_register_styles', array( __CLASS__, 'register_assets' ) );
	}

	public static function active() {
		return self::$on;
	}

	public static function standalone_notice() {
		if ( ! current_user_can( 'activate_plugins' ) ) {
			return;
		}
		echo '<div class="notice notice-warning" dir="rtl"><p><b>دلیل الزائر:</b> «نفحات» (پست‌های اجتماعی) اکنون داخل «سیستم یکپارچه» است. لطفاً افزونه‌ی جداگانه‌ی <b>IG Social Posts</b> را غیرفعال و حذف کنید؛ همه پست‌ها، لایک‌ها و نظرات حفظ می‌شوند.</p></div>';
	}

	/* ---------------------------------------------------------
	 * Assets
	 * ------------------------------------------------------- */

	public static function register_assets() {
		if ( wp_script_is( 'dlz-nafahat', 'registered' ) ) {
			return;
		}
		wp_register_style( 'dlz-nafahat', DLZ_NF_URL . 'assets/nafahat.css', array(), DLZ_NF_VERSION );
		wp_register_script( 'dlz-nafahat', DLZ_NF_URL . 'assets/nafahat.js', array(), DLZ_NF_VERSION, true );
		wp_localize_script( 'dlz-nafahat', 'DLZNafahatCfg', self::js_config() );
	}

	/** Loads the explore assets (from the shortcode, the widget or the app shell's center button). */
	public static function enqueue() {
		self::register_assets();
		wp_enqueue_style( 'dlz-nafahat' );
		wp_enqueue_script( 'dlz-nafahat' );
		self::$enqueued = true;
	}

	public static function brand() {
		$name = get_bloginfo( 'name' );
		$logo = '';
		if ( class_exists( 'DLZ_App_Shell' ) ) {
			$o = DLZ_App_Shell::get();
			if ( ! empty( $o['name_ar'] ) ) {
				$name = $o['name_ar'];
			}
			$logo = DLZ_App_Shell::logo();
		}
		if ( ! $logo ) {
			$logo = get_site_icon_url( 128 );
		}
		return array( 'name' => $name, 'logo' => $logo, 'svg' => ( ! $logo && class_exists( 'DLZ_App_Shell' ) ) ? DLZ_App_Shell::logo_svg() : '' );
	}

	public static function login_url() {
		return function_exists( 'dlz_profile_url' ) ? dlz_profile_url() : wp_login_url();
	}

	private static function js_config() {
		$uid = get_current_user_id();
		return array(
			'ajax'   => admin_url( 'admin-ajax.php' ),
			'nonce'  => wp_create_nonce( self::NONCE ),
			'logged' => $uid ? 1 : 0,
			'login'  => self::login_url(),
			'avatar' => $uid ? DLZ_NF_Data::avatar( $uid ) : '',
			'brand'  => self::brand(),
			'title'  => self::center_label(),
			'i18n'   => array(
				'all'       => 'الكل',
				'empty'     => 'لا توجد نفحات بعد',
				'emptySub'  => 'تابعونا، ستُنشر هنا قريباً لحظات من رحاب الزيارة',
				'error'     => 'تعذّر التحميل، اسحب للمحاولة مرة أخرى',
				'retry'     => 'إعادة المحاولة',
				'comments'  => 'التعليقات',
				'noComm'    => 'لا توجد تعليقات بعد. كن أول من يعلّق',
				'addComm'   => 'أضف تعليقاً…',
				'post'      => 'نشر',
				'loginComm' => 'سجّل الدخول لإضافة تعليق',
				'loginLike' => 'سجّل الدخول للإعجاب',
				'more'      => 'المزيد',
				'less'      => 'عرض أقل',
				'copied'    => 'تم نسخ الرابط',
				'share'     => 'مشاركة',
				'like'      => 'إعجاب',
				'close'     => 'إغلاق',
				'back'      => 'رجوع',
				'sound'     => 'الصوت',
				'failed'    => 'حدث خطأ، حاول مرة أخرى',
				'tooFast'   => 'انتظر قليلاً قبل التعليق مرة أخرى',
			),
		);
	}

	public static function center_label() {
		if ( class_exists( 'DLZ_App_Shell' ) ) {
			$o = DLZ_App_Shell::get();
			if ( ! empty( $o['center_label'] ) ) {
				return $o['center_label'];
			}
		}
		return 'نفحات';
	}

	/* ---------------------------------------------------------
	 * Output
	 * ------------------------------------------------------- */

	/**
	 * Explore markup. $a: per (5–30), orderby (date|menu_order|random), cat (term id), chips (bool), lazy (bool).
	 * The first page is printed as JSON so the grid paints instantly, without an extra request.
	 */
	public static function render( $a = array() ) {
		if ( ! self::$on ) {
			return '';
		}
		self::enqueue();
		$a = wp_parse_args(
			$a,
			array( 'per' => 15, 'orderby' => 'date', 'cat' => 0, 'chips' => 1, 'lazy' => 0, 'title' => '' )
		);
		$per     = max( 5, min( 30, (int) $a['per'] ) );
		$per     = (int) ( ceil( $per / 5 ) * 5 ); // full Instagram groups (5 tiles = 3 columns x 2 rows)
		$orderby = in_array( $a['orderby'], array( 'date', 'menu_order', 'random' ), true ) ? $a['orderby'] : 'date';
		$cat     = absint( $a['cat'] );
		$seed    = 'random' === $orderby ? wp_rand( 1, 999999 ) : 0;
		$conf    = array( 'per' => $per, 'orderby' => $orderby, 'cat' => $cat, 'seed' => $seed );

		$chips = array();
		if ( ! empty( $a['chips'] ) && ! $cat ) {
			$terms = get_terms( array( 'taxonomy' => self::TAX, 'hide_empty' => true, 'number' => 20, 'orderby' => 'count', 'order' => 'DESC' ) );
			if ( ! is_wp_error( $terms ) ) {
				$chips = $terms;
			}
		}

		ob_start();
		?>
<div class="dnf<?php echo $a['lazy'] ? ' dnf-lazy' : ''; ?>" dir="rtl" data-dnf="<?php echo esc_attr( wp_json_encode( $conf ) ); ?>">
	<?php if ( '' !== (string) $a['title'] ) : ?>
	<div class="dnf-title"><span class="dnf-title-orn" aria-hidden="true"></span><h2><?php echo esc_html( $a['title'] ); ?></h2><span class="dnf-title-orn" aria-hidden="true"></span></div>
	<?php endif; ?>
	<?php if ( $chips ) : ?>
	<div class="dnf-chips" role="tablist" aria-label="التصنيفات">
		<button type="button" class="dnf-chip is-on" data-cat="0" role="tab" aria-selected="true">الكل</button>
		<?php foreach ( $chips as $t ) : ?>
		<button type="button" class="dnf-chip" data-cat="<?php echo (int) $t->term_id; ?>" role="tab" aria-selected="false"><?php echo esc_html( $t->name ); ?></button>
		<?php endforeach; ?>
	</div>
	<?php endif; ?>
	<div class="dnf-grid" aria-live="polite"><?php echo self::skeleton(); // phpcs:ignore ?></div>
	<div class="dnf-foot" aria-hidden="true"></div>
	<?php
	if ( ! $a['lazy'] ) {
		$first = DLZ_NF_Data::feed( array( 'page' => 1, 'per' => $per, 'orderby' => $orderby, 'cat' => $cat, 'seed' => $seed ) );
		echo '<script type="application/json" class="dnf-seed">' . wp_json_encode( $first, JSON_HEX_TAG | JSON_HEX_AMP | JSON_UNESCAPED_UNICODE ) . '</script>';
	}
	?>
</div>
		<?php
		return ob_get_clean();
	}

	private static function skeleton() {
		$out = '<div class="dnf-grp is-sk">';
		for ( $i = 0; $i < 5; $i++ ) {
			$out .= '<span class="dnf-tile is-sk"></span>';
		}
		return $out . '</div>';
	}

	public static function shortcode( $atts ) {
		$atts = shortcode_atts(
			array( 'limit' => 15, 'per' => 0, 'orderby' => 'date', 'category' => '', 'cat' => 0, 'chips' => 1, 'title' => '' ),
			$atts
		);
		return self::render(
			array(
				'per'     => $atts['per'] ? $atts['per'] : $atts['limit'],
				'orderby' => 'rand' === $atts['orderby'] ? 'random' : $atts['orderby'],
				'cat'     => $atts['cat'] ? $atts['cat'] : (int) $atts['category'],
				'chips'   => ! in_array( strtolower( (string) $atts['chips'] ), array( '0', 'no', 'false' ), true ),
				'title'   => $atts['title'],
			)
		);
	}

	/* ---------------------------------------------------------
	 * Elementor
	 * ------------------------------------------------------- */

	public static function elementor_category( $manager ) {
		$manager->add_category( 'dlz-nafahat', array( 'title' => 'دليل الزائر – نفحات', 'icon' => 'eicon-gallery-grid' ) );
	}

	public static function elementor_widget( $manager ) {
		if ( ! class_exists( '\Elementor\Widget_Base' ) ) {
			return;
		}
		require_once DLZ_NF_PATH . 'includes/class-dlz-nf-elementor-widget.php';
		$manager->register( new DLZ_NF_Elementor_Widget() );
	}
}

add_action( 'plugins_loaded', array( 'DLZ_Nafahat', 'boot' ), 2 );
