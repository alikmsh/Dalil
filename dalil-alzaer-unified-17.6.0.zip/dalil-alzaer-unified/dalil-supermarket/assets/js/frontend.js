(function($){'use strict';
 const key='dlz_sm_cart'; let cart=[];
 try{cart=JSON.parse(localStorage.getItem(key)||'[]');if(!Array.isArray(cart))cart=[];}catch(e){cart=[];}
 cart=cart.map(x=>({type:x.type||'product',id:+x.id||0,qty:Math.max(1,+x.qty||1),price:x.price,name:x.name,image:x.image})).filter(x=>x.id);
 const money=n=>window.DLZM&&DLZM.n?DLZM.n(n):new Intl.NumberFormat().format(Math.round(Number(n)||0));
 const save=()=>localStorage.setItem(key,JSON.stringify(cart));
 const esc=s=>$('<div>').text(s==null?'':String(s)).html();
 const openModal=id=>{$('#'+id).attr('aria-hidden','false').addClass('is-open');document.body.classList.add('dlz-sm-lock');};
 const closeModals=()=>{$('.dlz-sm-modal').attr('aria-hidden','true').removeClass('is-open');document.body.classList.remove('dlz-sm-lock');};
 function renderCart(data){
  let total=0,count=0,html='';(data&&data.items?data.items:cart).forEach(it=>{let q=+it.qty||0,p=+it.price||0;total+=q*p;count+=q;let type=it.type||'product';html+='<div class="dlz-sm-cart-row" data-type="'+esc(type)+'" data-id="'+it.id+'">'+(it.image?'<img src="'+esc(it.image)+'" alt="">':'')+'<span>'+esc(it.name||'')+'</span><div class="dlz-sm-cart-qty"><button class="dlz-sm-qminus" type="button">−</button><b>'+q+'</b><button class="dlz-sm-qplus" type="button">+</button></div><strong>'+money(q*p)+' '+esc(DLZSM.currency)+'</strong></div>';});
  $('.dlz-sm-cart-count-badge').text(count);$('.dlz-sm-cart-count-text').text(count);$('.dlz-sm-cart-total').text(money(total)+' '+DLZSM.currency);$('.dlz-sm-modal-total').text(money(total));$('.dlz-sm-checkout-total strong').text(money(total));$('.dlz-sm-cart-list').html(html||'<div class="dlz-sm-empty">السلة فارغة</div>');return{total,count};
 }
 function validate(serverCart,cb){$.post(DLZSM.ajax,{action:'dlz_sm_cart_validate',nonce:DLZSM.nonce,cart:JSON.stringify(serverCart||cart)},function(r){if(r.success){cart=(r.data.items||[]).map(x=>({type:x.type||'product',id:+x.id,qty:+x.qty,price:x.price,name:x.name,image:x.image}));save();renderCart(r.data);if(r.data.issues&&r.data.issues.length)toast('تم تحديث بعض الكميات في السلة.');}if(cb)cb(r);});}
 function addProduct(id,qty,name,image){let f=cart.find(x=>x.type==='product'&&x.id==id);if(f){f.qty=Math.min(99,f.qty+(qty||1));if(name)f.name=name;if(image)f.image=image;}else cart.push({type:'product',id:+id,qty:qty||1,name:name||'',image:image||''});save();validate(cart);toast('تمت إضافة المنتج إلى السلة.');}
 function addPackage(pkg){let f=cart.find(x=>x.type==='package'&&x.id==pkg.id);if(f)f.qty=Math.min(99,f.qty+1);else cart.push({type:'package',id:+pkg.id,qty:1,price:+pkg.price||0,name:pkg.name,image:pkg.image||''});save();validate(cart);toast('تمت إضافة الباقة إلى السلة.');}
 function change(type,id,d){let f=cart.find(x=>x.type===type&&x.id==id);if(!f)return;f.qty+=d;if(f.qty<1)cart=cart.filter(x=>!(x.type===type&&x.id==id));save();validate(cart);}
 function toast(msg){let x=$('<div class="dlz-sm-toast">'+esc(msg)+'</div>').appendTo('body');setTimeout(()=>x.addClass('show'),20);setTimeout(()=>x.removeClass('show'),2800);setTimeout(()=>x.remove(),3300);}
 function loadCategory(cat,title){openModal('dlz-sm-category-modal');$('.dlz-sm-category-popup-title').text(title||'المنتجات');$('.dlz-sm-category-popup-products').html('<div class="dlz-sm-loading">جارٍ تحميل المنتجات...</div>');$.post(DLZSM.ajax,{action:'dlz_sm_products',nonce:DLZSM.nonce,category:cat},function(r){if(r.success){$('.dlz-sm-category-popup-products').html(r.data.html);}else $('.dlz-sm-category-popup-products').html('<div class="dlz-sm-empty">لا توجد منتجات متاحة حالياً</div>');});}
 function loadProduct(id){openModal('dlz-sm-product-modal');$('.dlz-sm-product-popup-content').html('<div class="dlz-sm-loading">جارٍ تحميل المنتج...</div>');$.post(DLZSM.ajax,{action:'dlz_sm_product',nonce:DLZSM.nonce,product_id:id},function(r){if(!r.success){$('.dlz-sm-product-popup-content').html('<div class="dlz-sm-empty">المنتج غير متوفر حالياً</div>');return;}let p=r.data.product||{};let old=(Number(p.old_price)||0)>Number(p.price||0)?'<del>'+money(p.old_price)+' '+esc(p.currency)+'</del>':'';let h='<div class="dlz-sm-detail-image-wrap">'+(p.image?'<img class="dlz-sm-detail-image" src="'+esc(p.image)+'" alt="'+esc(p.name)+'">':'<div class="dlz-sm-detail-noimg"></div>')+'</div><div class="dlz-sm-detail-info"><span class="dlz-sm-detail-category">'+esc(p.category||'منتج')+'</span><h2>'+esc(p.name)+'</h2>'+(p.description?'<p class="dlz-sm-detail-description">'+esc(p.description)+'</p>':'')+'<div class="dlz-sm-detail-price">'+money(p.price)+' '+esc(p.currency)+' '+old+'</div><div class="dlz-sm-detail-delivery">التوصيل خلال '+esc(p.delivery||'30-60 دقيقة')+'</div>'+(p.available?'<button type="button" class="dlz-sm-detail-add dlz-sm-primary" data-id="'+p.id+'">أضف إلى السلة</button>':'<div class="dlz-sm-detail-unavailable">غير متوفر حالياً</div>')+'</div>';$('.dlz-sm-product-popup-content').html(h);});}
 function search(q){q=$.trim(q||'');if(!q){openModal('dlz-sm-search-modal');$('.dlz-sm-search-popup-title').text('نتائج البحث');$('.dlz-sm-search-results').html('<div class="dlz-sm-empty">اكتب اسم المنتج للبحث.</div>');return;}openModal('dlz-sm-search-modal');$('.dlz-sm-search-popup-title').text('نتائج البحث عن: '+q);$('.dlz-sm-search-results').html('<div class="dlz-sm-loading">جارٍ البحث...</div>');$.post(DLZSM.ajax,{action:'dlz_sm_search',nonce:DLZSM.nonce,search:q},function(r){if(r.success)$('.dlz-sm-search-results').html(r.data.html);else $('.dlz-sm-search-results').html('<div class="dlz-sm-empty">لا توجد نتائج.</div>');});}
 function getSavedOrders(){try{let a=JSON.parse(localStorage.getItem('dlz_sm_orders')||'[]');return Array.isArray(a)?a.filter(Boolean).slice(-30):[];}catch(e){return[];}}
 function saveOrderNumber(num){if(!num)return;let a=getSavedOrders().filter(x=>x!==num);a.push(num);localStorage.setItem('dlz_sm_orders',JSON.stringify(a.slice(-30)));}
 function deliveryProgress(o){
  let eta=Math.max(1,Number(o.estimated_minutes)||60);
  if(o.status==='delivered') return 100;
  if(o.status==='cancelled') return 0;
  let start=String(o.created_at||'').replace(' ','T');
  let t=Date.parse(start);
  if(!isFinite(t)) return 0;
  return Math.max(0,Math.min(100,((Date.now()-t)/(eta*60000))*100));
 }
 function deliveryCard(o){
  let active=!['delivered','cancelled'].includes(o.status);
  let eta=Math.max(1,Number(o.estimated_minutes)||60);
  let status=active?'قيد التنفيذ':(o.status==='delivered'?'مكتملة':'ملغاة');
  let progress=deliveryProgress(o);
  let items=(o.items||[]).map(it=>'<div class="dlz-sm-delivery-item">'+(it.image?'<img src="'+esc(it.image)+'" alt="">':'<span class="dlz-sm-delivery-item-placeholder"></span>')+'<div><strong>'+esc(it.name||'')+'</strong><span>'+esc(String(it.qty||0))+' × '+money(it.price||0)+' '+esc(DLZSM.currency)+'</span></div><b>'+money(it.line||0)+' '+esc(DLZSM.currency)+'</b></div>').join('');
  return '<article class="dlz-sm-delivery-order '+(active?'is-active':'is-complete')+'" data-delivery-start="'+esc(o.created_at||'')+'" data-delivery-minutes="'+eta+'" data-delivery-status="'+esc(o.status||'')+'"><button type="button" class="dlz-sm-delivery-order-toggle"><div class="dlz-sm-delivery-order-head"><div><span class="dlz-sm-delivery-status">'+esc(status)+'</span><h3>سوبر ماركت</h3><small>طلب '+esc(o.order_number)+' · '+esc(o.created_at||'')+(o.city_name?' · '+esc(o.city_name):'')+'</small></div><strong>'+money(o.total||0)+' '+esc(DLZSM.currency)+'</strong></div></button><div class="dlz-sm-delivery-track"><div class="dlz-sm-delivery-track-line"><span class="dlz-sm-delivery-track-fill" style="width:'+progress+'%"></span><span class="dlz-sm-delivery-bike" aria-hidden="true" style="--dlz-bike-pos:'+progress+'%"></span></div><div class="dlz-sm-delivery-track-labels"><span>تحضير الطلب</span><span>في الطريق</span><span>تم التسليم</span></div></div>'+(active?'<div class="dlz-sm-delivery-estimate">التوصيل المتوقع <b>خلال حوالي '+eta+' دقيقة</b></div>':'<div class="dlz-sm-delivery-estimate completed">تم إكمال الطلب بنجاح</div>')+'<div class="dlz-sm-delivery-items">'+items+'</div></article>';
 }
 function updateDeliveryProgress(){
  $('.dlz-sm-delivery-order.is-active').each(function(){
   let el=$(this), start=String(el.attr('data-delivery-start')||'').replace(' ','T'), t=Date.parse(start), eta=Math.max(1,Number(el.attr('data-delivery-minutes'))||60);
   if(!isFinite(t)) return;
   let pct=Math.max(0,Math.min(100,((Date.now()-t)/(eta*60000))*100));
   el.find('.dlz-sm-delivery-track-fill').css('width',pct+'%');
   el.find('.dlz-sm-delivery-bike').css('--dlz-bike-pos',pct+'%');
  });
 }
 function loadDeliveryOrders(){if(!$('.dlz-sm-delivery-app').length)return;let saved=getSavedOrders();try{let q=new URLSearchParams(window.location.search).get('order');if(q&&!saved.includes(q)){saved.push(q);saveOrderNumber(q);}}catch(e){}let box=$('.dlz-sm-delivery-list');if(!saved.length){box.html('<div class="dlz-sm-delivery-empty"><strong>لا توجد طلبات بعد</strong><span>عند إتمام طلبك سيظهر هنا لمتابعة حالة التوصيل.</span></div>');return;}box.html('<div class="dlz-sm-loading">جارٍ تحديث حالة الطلبات...</div>');$.post(DLZSM.ajax,{action:'dlz_sm_delivery_orders',nonce:DLZSM.nonce,order_numbers:JSON.stringify(saved)},function(r){if(!r.success){box.html('<div class="dlz-sm-delivery-empty">تعذر تحميل الطلبات حالياً.</div>');return;}let orders=r.data.orders||[];let active=orders.filter(o=>!['delivered','cancelled'].includes(o.status));let completed=orders.filter(o=>['delivered','cancelled'].includes(o.status));let tab=$('.dlz-sm-delivery-tabs button.is-active').data('delivery-tab')||'active';let list=tab==='completed'?completed:active;box.html(list.length?list.map(deliveryCard).join(''):'<div class="dlz-sm-delivery-empty"><strong>'+ (tab==='completed'?'لا توجد طلبات مكتملة':'لا توجد طلبات قيد التنفيذ') +'</strong><span>ستظهر طلباتك هنا تلقائياً.</span></div>');$('.dlz-sm-delivery-count-active').text(active.length);$('.dlz-sm-delivery-count-completed').text(completed.length);});}
 setInterval(updateDeliveryProgress,1000);
 function reloadStore(){ $.post(DLZSM.ajax,{action:'dlz_sm_load_store',nonce:DLZSM.nonce},function(r){if(!r.success)return;$('.dlz-sm-products-wrap').html(r.data.products);$('.dlz-sm-categories').replaceWith($(r.data.cats).filter('.dlz-sm-categories'));let packs=$(r.data.packages).filter('.dlz-sm-packages');if(packs.length)$('.dlz-sm-packages').replaceWith(packs);else $('.dlz-sm-packages').replaceWith('<div class="dlz-sm-packages"></div>');validate(cart);}); }
 $(document).on('click','.dlz-sm-delivery-request-banner',function(e){e.preventDefault();toast('قريباً');});
 $(document).on('click','.dlz-sm-mini-store-trigger',function(){let id=$(this).data('mini-store-target');$('#'+id).attr('aria-hidden','false').addClass('is-open');document.body.classList.add('dlz-sm-lock');});
 $(document).on('click','.dlz-sm-mini-store-close,.dlz-sm-mini-store-backdrop',function(){let m=$(this).closest('.dlz-sm-mini-store-modal');m.attr('aria-hidden','true').removeClass('is-open');document.body.classList.remove('dlz-sm-lock');});
 $(document).on('click','.dlz-sm-add',function(e){e.preventDefault();e.stopPropagation();var b=$(this),card=b.closest('.dlz-sm-product');addProduct(b.data('id'),1,card.find('.dlz-sm-product-title').text(),card.find('.dlz-sm-product-img').attr('src')||'');});
 $(document).on('click','.dlz-sm-detail-add',function(){addProduct($(this).data('id'),1);closeModals();});
 $(document).on('click','.dlz-sm-product',function(e){if($(e.target).closest('.dlz-sm-add').length)return;loadProduct($(this).data('product'));});
 $(document).on('click','.dlz-sm-package-add',function(){let btn=$(this).prop('disabled',true),id=$(this).data('id');$.post(DLZSM.ajax,{action:'dlz_sm_add_package',nonce:DLZSM.nonce,package_id:id},r=>{if(r.success&&r.data.package){addPackage(r.data.package);}else toast(r.data&&r.data.message?r.data.message:'تعذر إضافة الباقة.');btn.prop('disabled',false);});});
 $(document).on('click','.dlz-sm-qplus',function(){let row=$(this).closest('[data-id]');change(row.data('type')||'product',row.data('id'),1);});
 $(document).on('click','.dlz-sm-qminus',function(){let row=$(this).closest('[data-id]');change(row.data('type')||'product',row.data('id'),-1);});
 $(document).on('click','.dlz-sm-cart-open',function(){openModal('dlz-sm-cart-modal');renderCart();});
 $(document).on('click','.dlz-sm-checkout-open,.dlz-sm-checkout-open-inner',function(){if(!cart.length){toast('السلة فارغة');return;}closeModals();openModal('dlz-sm-checkout-modal');renderCart();});
 $(document).on('click','.dlz-sm-modal-close,.dlz-sm-modal-backdrop',closeModals);
  $(document).on('click','.dlz-sm-delivery-order-toggle',function(){ $(this).closest('.dlz-sm-delivery-order').toggleClass('is-expanded'); });
 $(document).on('click','.dlz-sm-delivery-tabs button',function(){ $('.dlz-sm-delivery-tabs button').removeClass('is-active');$(this).addClass('is-active');loadDeliveryOrders(); });
 $(document).on('click','.dlz-sm-category',function(){loadCategory($(this).data('category'),$(this).attr('aria-label'));});
 $(document).on('submit','.dlz-sm-search',function(e){e.preventDefault();search($('.dlz-sm-search-input').val());});
 $(document).on('click','.dlz-sm-search-submit',function(){search($('.dlz-sm-search-input').val());});
 $(document).on('keydown','.dlz-sm-search-input',function(e){if(e.key==='Enter'){e.preventDefault();search($(this).val());}});
 $(document).on('input','.dlz-sm-search-input',function(){let q=$(this).val();clearTimeout(this._t);if($.trim(q).length>=2)this._t=setTimeout(()=>search(q),450);});
 $(document).on('click','.dlz-sm-quick button',function(){$('.dlz-sm-search-input').val($(this).data('search'));search($(this).data('search'));});
 $(document).on('click','.dlz-sm-see-all',function(){$('.dlz-sm-search-input').val('');document.querySelector('.dlz-sm-products-section')?.scrollIntoView({behavior:'smooth',block:'start'});});
 $(document).on('submit','.dlz-sm-checkout-form',function(e){e.preventDefault();let form=this;if(!cart.length){toast('السلة فارغة');return;}let data={action:'dlz_sm_place_order',nonce:DLZSM.nonce,cart:JSON.stringify(cart)};$(form).serializeArray().forEach(x=>data[x.name]=x.value);let btn=$(form).find('button[type=submit]').prop('disabled',true);$('.dlz-sm-form-message').text('جارٍ تسجيل الطلب...');$.post(DLZSM.ajax,data,r=>{if(r.success){saveOrderNumber(r.data.order_number);cart=[];save();renderCart();if(r.data.delivery_url){let url=r.data.delivery_url+(r.data.delivery_url.indexOf('?')>=0?'&':'?')+'order='+encodeURIComponent(r.data.order_number);window.location.href=url;}else{$('.dlz-sm-form-message').text('تم تسجيل الطلب بنجاح: '+r.data.order_number);setTimeout(closeModals,1800);}}else $('.dlz-sm-form-message').text(r.data&&r.data.message?r.data.message:'تعذر تسجيل الطلب.');btn.prop('disabled',false);});});
 $(function(){renderCart();loadDeliveryOrders();setInterval(loadDeliveryOrders,60000);$(document).on('dase:cityChanged',function(){reloadStore();});});
})(jQuery);
