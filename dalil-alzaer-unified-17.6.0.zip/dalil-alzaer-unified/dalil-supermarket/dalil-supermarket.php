<?php
if (!defined('ABSPATH')) exit;

define('DLZ_SM_VERSION','1.4.2');
define('DLZ_SM_FILE',__FILE__);
define('DLZ_SM_DIR',plugin_dir_path(__FILE__));
define('DLZ_SM_URL',plugin_dir_url(__FILE__));

require_once DLZ_SM_DIR.'includes/class-dlz-sm.php';

register_activation_hook(__FILE__, ['DLZ_SM','activate']);
add_action('plugins_loaded', ['DLZ_SM','init']);
