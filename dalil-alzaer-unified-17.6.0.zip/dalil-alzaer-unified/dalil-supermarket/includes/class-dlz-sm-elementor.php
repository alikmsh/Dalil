<?php
if (!defined('ABSPATH')) exit;

/**
 * Elementor integration. The Widget_Base class is loaded only after Elementor
 * itself has fired its loaded hook. This prevents fatal errors during editor
 * bootstrap when plugin load order differs.
 */
class DLZ_SM_Elementor {
    private static $booted = false;

    public static function init() {
        add_action('elementor/loaded', [__CLASS__, 'boot'], 20);
        // Elementor may already be loaded when this plugin reaches init().
        if (did_action('elementor/loaded')) {
            self::boot();
        }
    }

    public static function boot() {
        if (self::$booted || !class_exists('\Elementor\Plugin')) return;
        self::$booted = true;
        add_action('elementor/widgets/register', [__CLASS__, 'register'], 20);
        add_action('elementor/elements/categories_registered', [__CLASS__, 'category'], 20);
    }

    public static function category($elements_manager) {
        if (!is_object($elements_manager) || !method_exists($elements_manager, 'add_category')) return;
        $elements_manager->add_category('dalil-alzaer', [
            'title' => 'دلیل الزائر',
            'icon'  => 'fa fa-map-marker'
        ]);
    }

    public static function register($widgets_manager) {
        if (!class_exists('\Elementor\Widget_Base')) return;
        if (!class_exists('DLZ_SM_Elementor_Widget')) {
            require_once DLZ_SM_DIR . 'includes/class-dlz-sm-elementor-widget.php';
        }
        if (!class_exists('DLZ_SM_Elementor_Widget')) return;

        $types = ['store','categories','bestsellers','discounts','ads','packages','quick','cart','city','mini_supermarket'];
        foreach ($types as $type) {
            $widgets_manager->register(new DLZ_SM_Elementor_Widget($type));
        }

        // Register delivery as a completely separate widget class.
        // This prevents Elementor from ever falling back to the store widget.
        if (!class_exists('DLZ_SM_Delivery_Widget')) {
            require_once DLZ_SM_DIR . 'includes/class-dlz-sm-delivery-widget.php';
        }
        if (class_exists('DLZ_SM_Delivery_Widget')) {
            $widgets_manager->register(new DLZ_SM_Delivery_Widget());
        }
    }
}
