<?php
if (!defined('ABSPATH')) exit;
class DLZ_SM_Ajax {
 public static function init(){
  foreach(['load_store','search','products','product','cities','cart_validate','place_order','add_package','delivery_orders'] as $a){add_action('wp_ajax_dlz_sm_'.$a,[__CLASS__,$a]);add_action('wp_ajax_nopriv_dlz_sm_'.$a,[__CLASS__,$a]);}
 }
 private static function ok(){check_ajax_referer('dlz_sm','nonce');}
 private static function cart_from_request(){
  $raw=isset($_POST['cart'])?wp_unslash($_POST['cart']):'[]';$a=json_decode($raw,true);return is_array($a)?$a:[];
 }
 public static function cities(){self::ok();global $wpdb;$rows=$wpdb->get_results("SELECT id,name,slug FROM ".DLZ_SM::$tables['cities']." WHERE active=1 ORDER BY sort_order,id");wp_send_json_success(['cities'=>$rows,'current'=>DLZ_SM::city_id()]);}
 public static function load_store(){self::ok();wp_send_json_success(self::payload());}
 private static function payload(){global $wpdb;$city=DLZ_SM::city_id();$cats=DLZ_SM_Frontend::render_categories();$products=DLZ_SM_Frontend::render_products();$ads='';$packages=DLZ_SM_Frontend::render_packages();$cityname=DLZ_SM::city_name($city);return compact('city','cityname','cats','products','ads','packages');}
 public static function products(){self::ok();$search=isset($_POST['search'])?sanitize_text_field(wp_unslash($_POST['search'])):'';$cat=isset($_POST['category'])?(int)$_POST['category']:0;wp_send_json_success(['html'=>DLZ_SM_Frontend::render_products(['search'=>$search,'category'=>$cat,'limit'=>24])]);}
 public static function product(){self::ok();$id=absint($_POST['product_id']??0);$p=DLZ_SM::product($id,DLZ_SM::city_id());if(!$p)wp_send_json_error(['message'=>'المنتج غير موجود حالياً.'],404);$data=DLZ_SM::product_json($p);$data['description']=$p->description_ar?:'';$data['currency']=DLZ_SM::cur();$data['delivery']=DLZ_SM::setting('delivery_time','30-60 دقيقة');wp_send_json_success(['product'=>$data]);}
 public static function search(){self::products();}
 public static function cart_validate(){self::ok();$cart=self::cart_from_request();$city=DLZ_SM::city_id();$validated=self::validate_cart($cart,$city);wp_send_json_success(['items'=>$validated['items'],'subtotal'=>$validated['subtotal'],'currency'=>DLZ_SM::cur(),'issues'=>$validated['issues']]);}

 public static function add_package(){
  self::ok(); global $wpdb; $id=absint($_POST['package_id']??0); $city=DLZ_SM::city_id();
  $p=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".DLZ_SM::$tables['packages']." WHERE id=%d AND active=1 AND stock_qty>0 AND city_id=%d",$id,$city));
  if(!$p)wp_send_json_error(['message'=>'هذه الباقة غير متاحة حالياً.'],404);
  wp_send_json_success(['package'=>['id'=>(int)$p->id,'name'=>$p->name_ar,'description'=>$p->description_ar,'image'=>$p->image_id?wp_get_attachment_image_url($p->image_id,'medium'):'','price'=>(float)$p->price,'old_price'=>(float)$p->old_price,'stock_qty'=>(int)$p->stock_qty],'currency'=>DLZ_SM::cur()]);
 }
 public static function delivery_orders(){
  self::ok(); global $wpdb;
  $raw=isset($_POST['order_numbers'])?wp_unslash($_POST['order_numbers']):'[]';
  $nums=json_decode($raw,true); if(!is_array($nums)) $nums=[];
  $nums=array_values(array_unique(array_filter(array_map(function($n){return sanitize_text_field($n);},$nums))));
  if(!$nums){wp_send_json_success(['orders'=>[]]);}
  $placeholders=implode(',',array_fill(0,count($nums),'%s'));
  $sql="SELECT o.order_number,o.status,o.created_at,o.total,o.estimated_minutes,o.items,c.name city_name FROM ".DLZ_SM::$tables['orders']." o LEFT JOIN ".DLZ_SM::$tables['cities']." c ON c.id=o.city_id WHERE o.order_number IN ($placeholders) ORDER BY o.id DESC LIMIT 50";
  $rows=$wpdb->get_results($wpdb->prepare($sql,$nums)); $out=[];
  foreach($rows as $o){$items=json_decode($o->items,true);if(!is_array($items))$items=[];$clean=[];foreach($items as $it){$clean[]=['type'=>($it['type']??'product')==='package'?'package':'product','name'=>sanitize_text_field($it['name']??''),'qty'=>(int)($it['qty']??0),'price'=>(float)($it['price']??0),'line'=>(float)($it['line']??0),'image'=>!empty($it['image'])?esc_url_raw($it['image']):''];} $out[]=['order_number'=>$o->order_number,'status'=>$o->status,'created_at'=>$o->created_at,'total'=>(float)$o->total,'estimated_minutes'=>(int)($o->estimated_minutes?:60),'city_name'=>$o->city_name,'items'=>$clean];}
  wp_send_json_success(['orders'=>$out,'currency'=>DLZ_SM::cur(),'delivery_time'=>'حوالي ساعة واحدة']);
 }
 public static function place_order(){
  self::ok();global $wpdb;
  $name=sanitize_text_field(wp_unslash($_POST['name']??''));$phone=sanitize_text_field(wp_unslash($_POST['phone']??''));$accommodation=sanitize_text_field(wp_unslash($_POST['accommodation']??''));$address=sanitize_textarea_field(wp_unslash($_POST['address']??''));$notes=sanitize_textarea_field(wp_unslash($_POST['notes']??''));$city=DLZ_SM::city_id();
  if(!$name||!$phone)wp_send_json_error(['message'=>'يرجى إكمال الاسم ورقم الهاتف.'],422);
  $validated=self::validate_cart(self::cart_from_request(),$city);if(!$validated['items'])wp_send_json_error(['message'=>'السلة فارغة أو المنتجات غير متاحة حالياً.'],422);
  $shipping=(float)DLZ_SM::setting('shipping_hotel',0);$subtotal=$validated['subtotal'];$total=$subtotal+$shipping;$order='DLZ-'.strtoupper(wp_generate_password(8,false,false));$items=wp_json_encode($validated['items'],JSON_UNESCAPED_UNICODE);
  $ok=$wpdb->insert(DLZ_SM::$tables['orders'],['order_number'=>$order,'customer_name'=>$name,'phone'=>$phone,'whatsapp'=>'','city_id'=>$city,'accommodation'=>$accommodation,'address'=>$address,'delivery_method'=>'hotel','notes'=>$notes,'items'=>$items,'subtotal'=>$subtotal,'shipping'=>$shipping,'discount'=>0,'total'=>$total,'estimated_minutes'=>60,'status'=>'pending','payment_status'=>'pending','created_at'=>current_time('mysql')],['%s','%s','%s','%s','%d','%s','%s','%s','%s','%s','%f','%f','%f','%f','%d','%s','%s','%s']);
  if(!$ok)wp_send_json_error(['message'=>'تعذر تسجيل الطلب. حاول مرة أخرى.'],500);
  if(class_exists('DLZ_Inbox'))DLZ_Inbox::add('market',$order.' — '.$name,count($validated['items']).' منتجات · '.number_format_i18n((float)$total).' د.ع',admin_url('admin.php?page=dlz-sm-orders'));
  foreach($validated['items'] as $it){if(($it['type']??'product')==='package'){$wpdb->query($wpdb->prepare("UPDATE {$wpdb->prefix}dlz_sm_packages SET stock_qty=GREATEST(stock_qty-%d,0) WHERE id=%d AND city_id=%d AND stock_qty>=%d",$it['qty'],$it['id'],$city,$it['qty']));}else{$wpdb->query($wpdb->prepare("UPDATE {$wpdb->prefix}dlz_sm_stock SET qty=GREATEST(qty-%d,0) WHERE product_id=%d AND city_id=%d",$it['qty'],$it['id'],$city));}}
  $page_id=(int)DLZ_SM::setting('delivery_page_id',0);
  $page_url=$page_id?get_permalink($page_id):'';
  if(!$page_url){$page=get_page_by_path('delivery');if($page)$page_url=get_permalink($page->ID);}
  if(!$page_url){$page=get_page_by_path('التوصيل');if($page)$page_url=get_permalink($page->ID);}
  wp_send_json_success(['order_number'=>$order,'total'=>$total,'currency'=>DLZ_SM::cur(),'delivery_url'=>$page_url,'message'=>'تم تسجيل طلبك بنجاح.']);
 }
 private static function validate_cart($cart,$city){
  global $wpdb;$items=[];$issues=[];$subtotal=0;
  foreach($cart as $it){$type=sanitize_key($it['type']??'product');$id=absint($it['id']??0);$q=max(1,min(99,absint($it['qty']??1)));
   if($type==='package'){
    $p=$wpdb->get_row($wpdb->prepare("SELECT id,name_ar,price,old_price,stock_qty,image_id FROM ".DLZ_SM::$tables['packages']." WHERE id=%d AND active=1 AND city_id=%d",$id,$city));
    if(!$p||$p->stock_qty<1){$issues[]=$id;continue;}$q=min($q,(int)$p->stock_qty);$line=$q*(float)$p->price;$subtotal+=$line;$items[]=['type'=>'package','id'=>$id,'qty'=>$q,'price'=>(float)$p->price,'name'=>$p->name_ar,'image'=>$p->image_id?wp_get_attachment_image_url($p->image_id,'thumbnail'):'','line'=>$line];continue;
   }
   $p=DLZ_SM::product($id,$city);if(!$p||!$p->city_active||$p->qty<1){$issues[]=$id;continue;}$q=min($q,$p->qty);$line=$q*$p->effective_price;$subtotal+=$line;$items[]=['type'=>'product','id'=>$id,'qty'=>$q,'price'=>$p->effective_price,'name'=>$p->name_ar,'image'=>$p->image_id?wp_get_attachment_image_url($p->image_id,'thumbnail'):'','line'=>$line];
  }
  return compact('items','issues','subtotal');
 }

}
