<?php
if (!defined('ABSPATH')) exit;

class DLZ_SM {
    /** Currency symbol of the visitor (DLZ_Money: country of the profile) — prices are stored in dinars. */
    public static function cur(){ return class_exists('DLZ_Money')?DLZ_Money::sym():self::setting('currency','د.ع'); }
    public static function money($v){ return class_exists('DLZ_Money')?DLZ_Money::fmt($v):number_format_i18n((float)$v).' '.self::setting('currency','د.ع'); }

    const DB_VERSION = '1.4.2';
    public static $tables = [];

    public static function init() {
        global $wpdb;
        self::$tables = [
            'cities'       => $wpdb->prefix.'dlz_sm_cities',
            'categories'   => $wpdb->prefix.'dlz_sm_categories',
            'products'     => $wpdb->prefix.'dlz_sm_products',
            'stock'        => $wpdb->prefix.'dlz_sm_stock',
            'ads'          => $wpdb->prefix.'dlz_sm_ads',
            'packages'     => $wpdb->prefix.'dlz_sm_packages',
            'package_items'=> $wpdb->prefix.'dlz_sm_package_items',
            'orders'       => $wpdb->prefix.'dlz_sm_orders',
        ];
        require_once DLZ_SM_DIR.'includes/class-dlz-sm-admin.php';
        require_once DLZ_SM_DIR.'includes/class-dlz-sm-ajax.php';
        require_once DLZ_SM_DIR.'includes/class-dlz-sm-elementor.php';
        require_once DLZ_SM_DIR.'includes/class-dlz-sm-frontend.php';
        DLZ_SM_Admin::init();
        DLZ_SM_Ajax::init();
        DLZ_SM_Elementor::init();
        DLZ_SM_Frontend::init();
        self::maybe_upgrade();
    }

    public static function activate() {
        global $wpdb;
        require_once ABSPATH.'wp-admin/includes/upgrade.php';
        $charset = $wpdb->get_charset_collate();
        $t = [
            'cities' => $wpdb->prefix.'dlz_sm_cities',
            'categories' => $wpdb->prefix.'dlz_sm_categories',
            'products' => $wpdb->prefix.'dlz_sm_products',
            'stock' => $wpdb->prefix.'dlz_sm_stock',
            'ads' => $wpdb->prefix.'dlz_sm_ads',
            'packages' => $wpdb->prefix.'dlz_sm_packages',
            'package_items' => $wpdb->prefix.'dlz_sm_package_items',
            'orders' => $wpdb->prefix.'dlz_sm_orders',
        ];
        dbDelta("CREATE TABLE {$t['cities']} (
            id bigint unsigned NOT NULL AUTO_INCREMENT, name varchar(190) NOT NULL, slug varchar(190) NOT NULL,
            active tinyint(1) NOT NULL DEFAULT 1, sort_order int NOT NULL DEFAULT 0, created_at datetime NOT NULL,
            PRIMARY KEY(id), UNIQUE KEY slug(slug), KEY active(active)
        ) $charset;");
        dbDelta("CREATE TABLE {$t['categories']} (
            id bigint unsigned NOT NULL AUTO_INCREMENT, name_ar varchar(190) NOT NULL, image_id bigint unsigned NOT NULL DEFAULT 0,
            city_id bigint unsigned NOT NULL DEFAULT 0, active tinyint(1) NOT NULL DEFAULT 1, sort_order int NOT NULL DEFAULT 0,
            created_at datetime NOT NULL, PRIMARY KEY(id), KEY city(city_id), KEY active(active)
        ) $charset;");
        dbDelta("CREATE TABLE {$t['products']} (
            id bigint unsigned NOT NULL AUTO_INCREMENT, name_ar varchar(190) NOT NULL, description_ar text NULL,
            image_id bigint unsigned NOT NULL DEFAULT 0, category_id bigint unsigned NOT NULL DEFAULT 0,
            base_price decimal(18,2) NOT NULL DEFAULT 0, sale_price decimal(18,2) NULL, active tinyint(1) NOT NULL DEFAULT 1,
            sort_order int NOT NULL DEFAULT 0, created_at datetime NOT NULL, updated_at datetime NOT NULL,
            PRIMARY KEY(id), KEY category(category_id), KEY active(active)
        ) $charset;");
        dbDelta("CREATE TABLE {$t['stock']} (
            id bigint unsigned NOT NULL AUTO_INCREMENT, product_id bigint unsigned NOT NULL, city_id bigint unsigned NOT NULL,
            qty int NOT NULL DEFAULT 0, price decimal(18,2) NULL, active tinyint(1) NOT NULL DEFAULT 1,
            PRIMARY KEY(id), UNIQUE KEY product_city(product_id,city_id), KEY city(city_id)
        ) $charset;");
        dbDelta("CREATE TABLE {$t['ads']} (
            id bigint unsigned NOT NULL AUTO_INCREMENT, title_ar varchar(190) NOT NULL, text_ar text NULL, image_id bigint unsigned NOT NULL DEFAULT 0,
            link_url text NULL, city_id bigint unsigned NOT NULL DEFAULT 0, placement varchar(30) NOT NULL DEFAULT 'top',
            start_at datetime NULL, end_at datetime NULL, active tinyint(1) NOT NULL DEFAULT 1, sort_order int NOT NULL DEFAULT 0,
            created_at datetime NOT NULL, PRIMARY KEY(id), KEY city(city_id), KEY placement(placement), KEY active(active)
        ) $charset;");
        dbDelta("CREATE TABLE {$t['packages']} (
            id bigint unsigned NOT NULL AUTO_INCREMENT, name_ar varchar(190) NOT NULL, description_ar text NULL,
            image_id bigint unsigned NOT NULL DEFAULT 0, city_id bigint unsigned NOT NULL DEFAULT 0, price decimal(18,2) NOT NULL DEFAULT 0,
            old_price decimal(18,2) NULL, stock_qty int NOT NULL DEFAULT 0, active tinyint(1) NOT NULL DEFAULT 1, sort_order int NOT NULL DEFAULT 0,
            created_at datetime NOT NULL, PRIMARY KEY(id), KEY city(city_id), KEY active(active)
        ) $charset;");
        dbDelta("CREATE TABLE {$t['package_items']} (
            id bigint unsigned NOT NULL AUTO_INCREMENT, package_id bigint unsigned NOT NULL, product_id bigint unsigned NOT NULL,
            qty int NOT NULL DEFAULT 1, PRIMARY KEY(id), KEY package(package_id)
        ) $charset;");
        dbDelta("CREATE TABLE {$t['orders']} (
            id bigint unsigned NOT NULL AUTO_INCREMENT, order_number varchar(40) NOT NULL, customer_name varchar(190) NOT NULL,
            phone varchar(60) NOT NULL, whatsapp varchar(60) NULL, city_id bigint unsigned NOT NULL, accommodation varchar(190) NULL,
            address text NULL, delivery_method varchar(30) NOT NULL DEFAULT 'hotel', notes text NULL, items longtext NOT NULL,
            subtotal decimal(18,2) NOT NULL DEFAULT 0, shipping decimal(18,2) NOT NULL DEFAULT 0, discount decimal(18,2) NOT NULL DEFAULT 0,
            total decimal(18,2) NOT NULL DEFAULT 0, estimated_minutes int NOT NULL DEFAULT 60, status varchar(30) NOT NULL DEFAULT 'pending', payment_status varchar(30) NOT NULL DEFAULT 'pending',
            created_at datetime NOT NULL, PRIMARY KEY(id), UNIQUE KEY order_number(order_number), KEY city(city_id), KEY status(status), KEY created_at(created_at)
        ) $charset;");
        $now = current_time('mysql');
        $cities = [
            ['مشهد','mashhad'], ['قم','qom'], ['شیراز','shiraz']
        ];
        foreach ($cities as $i=>$c) {
            $exists = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$t['cities']} WHERE slug=%s",$c[1]));
            if (!$exists) $wpdb->insert($t['cities'],['name'=>$c[0],'slug'=>$c[1],'active'=>1,'sort_order'=>$i,'created_at'=>$now]);
        }
        update_option('dlz_sm_db_version', self::DB_VERSION);
        $defaults = [
            'shipping_hotel'=>0,'shipping_apartment'=>0,'shipping_pickup'=>0,
            'currency'=>'د.ع','delivery_time'=>'30-60 دقيقة','store_title'=>'سوبر ماركت',
            'store_subtitle'=>'توصيل سريع إلى الفندق أو الشقة','logo_id'=>0,'banner_id'=>0,
            'primary'=>'#071A33','gold'=>'#C89B2C','delivery_page_id'=>0,'delivery_request_banner_id'=>0
        ];
        $current = get_option('dlz_sm_settings',[]);
        update_option('dlz_sm_settings', wp_parse_args(is_array($current)?$current:[], $defaults));
    }

    private static function maybe_upgrade() {
        $v = get_option('dlz_sm_db_version','0');
        if (version_compare($v, self::DB_VERSION, '>=')) return;
        global $wpdb;
        $table = self::$tables['packages'];
        $col = $wpdb->get_var("SHOW COLUMNS FROM $table LIKE 'stock_qty'");
        if (!$col) { $wpdb->query("ALTER TABLE $table ADD stock_qty int NOT NULL DEFAULT 0 AFTER old_price"); $wpdb->query("UPDATE $table SET stock_qty=9999 WHERE stock_qty=0"); }
        $orders = self::$tables['orders'];
        $eta_col = $wpdb->get_var("SHOW COLUMNS FROM $orders LIKE 'estimated_minutes'");
        if (!$eta_col) { $wpdb->query("ALTER TABLE $orders ADD estimated_minutes int NOT NULL DEFAULT 60 AFTER total"); }
        $settings = get_option('dlz_sm_settings',[]);
        if (!is_array($settings)) $settings=[];
        if (!isset($settings['banner_id'])) $settings['banner_id']=0;
        if (!isset($settings['delivery_page_id'])) $settings['delivery_page_id']=0;
        if (!isset($settings['delivery_request_banner_id'])) $settings['delivery_request_banner_id']=0;
        update_option('dlz_sm_settings',$settings);
        update_option('dlz_sm_db_version',self::DB_VERSION);
    }

    public static function setting($key,$default='') {
        $s=get_option('dlz_sm_settings',[]); return isset($s[$key])?$s[$key]:$default;
    }
    public static function city_id() {
        $raw = isset($_COOKIE['dase_city']) ? sanitize_text_field(wp_unslash($_COOKIE['dase_city'])) : '';
        if (!$raw && isset($_COOKIE['dlz_city'])) $raw=sanitize_text_field(wp_unslash($_COOKIE['dlz_city']));
        if (!$raw && isset($_GET['city'])) $raw=sanitize_text_field(wp_unslash($_GET['city']));
        $slug = sanitize_title($raw ?: 'mashhad');
        global $wpdb;
        $id=$wpdb->get_var($wpdb->prepare("SELECT id FROM ".self::$tables['cities']." WHERE slug=%s AND active=1",$slug));
        if (!$id && $raw) $id=$wpdb->get_var($wpdb->prepare("SELECT id FROM ".self::$tables['cities']." WHERE name=%s AND active=1",$raw));
        if (!$id) $id=$wpdb->get_var("SELECT id FROM ".self::$tables['cities']." WHERE slug='mashhad' AND active=1");
        return (int)$id;
    }
    public static function city_name($id) { global $wpdb; return (string)$wpdb->get_var($wpdb->prepare("SELECT name FROM ".self::$tables['cities']." WHERE id=%d",$id)); }
    public static function product($id,$city_id) {
        global $wpdb; $p=$wpdb->get_row($wpdb->prepare("SELECT p.*, c.name_ar category_name FROM ".self::$tables['products']." p LEFT JOIN ".self::$tables['categories']." c ON c.id=p.category_id WHERE p.id=%d AND p.active=1",$id));
        if (!$p) return null;
        $s=$wpdb->get_row($wpdb->prepare("SELECT qty,price,active FROM ".self::$tables['stock']." WHERE product_id=%d AND city_id=%d",$id,$city_id));
        if (!$s) { $p->qty=0; $p->city_active=0; $p->city_price=null; } else { $p->qty=(int)$s->qty; $p->city_active=(int)$s->active; $p->city_price=$s->price; }
        $p->effective_price = ($p->city_price!==null && $p->city_price!=='') ? (float)$p->city_price : (float)(($p->sale_price!==null && $p->sale_price!=='')?$p->sale_price:$p->base_price);
        return $p;
    }
    public static function product_json($p) {
        $img=$p->image_id?wp_get_attachment_image_url($p->image_id,'medium'):'';
        return ['id'=>(int)$p->id,'name'=>$p->name_ar,'image'=>$img,'price'=>(float)$p->effective_price,'old_price'=>(float)$p->base_price,'qty'=>(int)$p->qty,'available'=>(bool)($p->city_active && $p->qty>0),'category'=>$p->category_name];
    }
}
