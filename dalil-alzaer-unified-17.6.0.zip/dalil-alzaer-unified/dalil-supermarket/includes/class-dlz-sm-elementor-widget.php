<?php
if (!defined('ABSPATH')) exit;
if (!class_exists('\Elementor\Widget_Base')) return;

class DLZ_SM_Elementor_Widget extends \Elementor\Widget_Base {
    private $type = 'store';

    public function __construct($data = [], $args = null) {
        if (is_string($data)) {
            $this->type = sanitize_key($data);
            $data = [];
        } elseif (is_array($data) && isset($data['dlz_type'])) {
            $this->type = sanitize_key($data['dlz_type']);
            unset($data['dlz_type']);
        }
        parent::__construct($data, $args);
    }

    public function get_name() {
        return 'dlz_sm_' . $this->type;
    }

    public function get_title() {
        $titles = [
            'store'       => 'سوبر ماركت',
            'mini_supermarket' => 'سوبر ماركت',
            'categories'  => 'دسته‌بندی محصولات',
            'bestsellers' => 'محصولات پرفروش',
            'discounts'   => 'محصولات تخفیف‌دار',
            'ads'         => 'تبلیغات',
            'packages'    => 'بسته‌های آماده',
            'quick'       => 'احتياجات سريعة',
            'cart'        => 'سبد خرید',
            'city'        => 'انتخاب شهر',
            'delivery'   => 'صفحه التوصيل'
        ];
        return 'دلیل الزائر - ' . ($titles[$this->type] ?? 'سوپرمارکت');
    }

    public function get_icon() { return 'eicon-shop'; }
    public function get_categories() { return ['dalil-alzaer']; }

    protected function render() {
        switch ($this->type) {
            case 'store': echo do_shortcode('[dalil_supermarket]'); break;
            case 'mini_supermarket': echo DLZ_SM_Frontend::render_mini_supermarket_widget(); break;
            case 'categories': echo do_shortcode('[dalil_sm_categories]'); break;
            case 'bestsellers': echo DLZ_SM_Frontend::render_products(['limit'=>12,'order'=>'popular']); break;
            case 'discounts': echo DLZ_SM_Frontend::render_products(['limit'=>12,'discounted'=>1]); break;
            case 'ads': echo DLZ_SM_Frontend::render_ads('top'); break;
            case 'packages': echo DLZ_SM_Frontend::render_packages(); break;
            case 'quick': echo DLZ_SM_Frontend::render_quick(); break;
            case 'cart': echo do_shortcode('[dalil_sm_cart]'); break;
            case 'city': echo do_shortcode('[dalil_sm_city]'); break;
            case 'delivery': echo do_shortcode('[dalil_sm_delivery]'); break;
        }
    }
}
