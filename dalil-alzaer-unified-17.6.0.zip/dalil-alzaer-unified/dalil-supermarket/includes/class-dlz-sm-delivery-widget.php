<?php
if (!defined('ABSPATH')) exit;
if (!class_exists('\\Elementor\\Widget_Base')) return;

/**
 * Dedicated Elementor widget for the delivery/orders page.
 * Kept separate from the store widget so Elementor can never reuse
 * the supermarket renderer for the delivery page.
 */
class DLZ_SM_Delivery_Widget extends \Elementor\Widget_Base {
    public function get_name() { return 'dlz_sm_delivery'; }
    public function get_title() { return 'دلیل الزائر - توصيلات'; }
    public function get_icon() { return 'eicon-delivery'; }
    public function get_categories() { return ['dalil-alzaer']; }
    public function get_keywords() { return ['توصيل','طلبات','طلباتي','delivery','orders']; }

    protected function render() {
        if (class_exists('DLZ_SM_Frontend')) {
            echo DLZ_SM_Frontend::delivery_shortcode();
        }
    }
}
