<?php
if (!defined('ABSPATH')) exit;
class DLZ_SM_Frontend {
 public static function init(){
  add_action('wp_enqueue_scripts',[__CLASS__,'assets']);
  add_shortcode('dalil_supermarket',[__CLASS__,'main_shortcode']);
  add_shortcode('dalil_sm_categories',[__CLASS__,'categories_shortcode']);
  add_shortcode('dalil_sm_products',[__CLASS__,'products_shortcode']);
  add_shortcode('dalil_sm_ads',[__CLASS__,'ads_shortcode']);
  add_shortcode('dalil_sm_packages',[__CLASS__,'packages_shortcode']);
  add_shortcode('dalil_sm_quick',[__CLASS__,'quick_shortcode']);
  add_shortcode('dalil_sm_cart',[__CLASS__,'cart_shortcode']);
  add_shortcode('dalil_sm_city',[__CLASS__,'city_shortcode']);
  add_shortcode('dalil_sm_delivery',[__CLASS__,'delivery_shortcode']);
 }
 public static function assets(){
  wp_register_style('dlz-sm',DLZ_SM_URL.'assets/css/frontend.css',[],DLZ_SM_VERSION);
  wp_register_script('dlz-sm',DLZ_SM_URL.'assets/js/frontend.js',['jquery'],DLZ_SM_VERSION,true);
  wp_localize_script('dlz-sm','DLZSM',['ajax'=>admin_url('admin-ajax.php'),'nonce'=>wp_create_nonce('dlz_sm'),'currency'=>DLZ_SM::cur(),'city'=>DLZ_SM::city_id(),'delivery'=>DLZ_SM::setting('delivery_time','30-60 دقيقة')]);
 }
 public static function enqueue(){wp_enqueue_style('dlz-sm');wp_enqueue_script('dlz-sm');}
 public static function main_shortcode(){ self::enqueue(); ob_start(); include DLZ_SM_DIR.'templates/store.php'; return ob_get_clean(); }
 public static function categories_shortcode(){self::enqueue();return self::render_categories();}
 public static function products_shortcode(){self::enqueue();return self::render_products();}
 public static function ads_shortcode(){self::enqueue();return '';}
 public static function packages_shortcode(){self::enqueue();return self::render_packages();}
 public static function quick_shortcode(){self::enqueue();return self::render_quick();}
 public static function cart_shortcode(){
  self::enqueue();
  ob_start();
  echo '<div class="dlz-sm-app dlz-sm-cart-app" dir="rtl">';
  echo '<div class="dlz-sm-cart-page">';
  echo '<div class="dlz-sm-section-head"><h1>السلة</h1><span class="dlz-sm-cart-count-text">0</span></div>';
  echo '<div class="dlz-sm-cart-page-card"><div class="dlz-sm-cart-list"></div><div class="dlz-sm-cart-page-summary"><span>المجموع</span><strong class="dlz-sm-cart-total">0 '.esc_html(DLZ_SM::cur()).'</strong></div><button type="button" class="dlz-sm-primary dlz-sm-checkout-open">إتمام الطلب</button></div>';
  echo '</div>';
  echo '<div class="dlz-sm-modal" id="dlz-sm-checkout-modal" aria-hidden="true"><div class="dlz-sm-modal-backdrop"></div><div class="dlz-sm-modal-card dlz-sm-checkout"><button type="button" class="dlz-sm-modal-close" aria-label="إغلاق">×</button><h2>إتمام الطلب</h2><form class="dlz-sm-checkout-form"><label>الاسم<input name="name" required></label><label>رقم الهاتف<input name="phone" type="tel" required></label><label>الفندق / الشقة<input name="accommodation"></label><label>العنوان<textarea name="address"></textarea></label><label>ملاحظات الطلب<textarea name="notes"></textarea></label><div class="dlz-sm-checkout-total">المبلغ النهائي: <strong>0</strong> '.esc_html(DLZ_SM::cur()).'</div><button class="dlz-sm-primary" type="submit">تأكيد الطلب</button><div class="dlz-sm-form-message"></div></form></div></div>';
  echo '</div>';
  return ob_get_clean();
 }
 public static function city_shortcode(){self::enqueue();return '<div class="dlz-sm-city-select"><select class="dlz-sm-city-select-input"></select></div>';}
 public static function delivery_shortcode(){self::enqueue(); return '<div class="dlz-sm-delivery-app" dir="rtl"><div class="dlz-sm-delivery-hero"><div><span class="dlz-sm-delivery-kicker">توصيلات</span><h1>طلباتي</h1><p>تابع طلباتك حتى تصل إليك بأمان.</p></div><div class="dlz-sm-delivery-time"><span>وقت التوصيل المتوقع</span><strong>حوالي ساعة واحدة</strong></div></div>'.self::render_delivery_request_banner().'<div class="dlz-sm-delivery-tabs" role="tablist"><button class="is-active" data-delivery-tab="active"><span>النشطة</span><b class="dlz-sm-delivery-count-active">0</b></button><button data-delivery-tab="completed"><span>المكتملة</span><b class="dlz-sm-delivery-count-completed">0</b></button></div><div class="dlz-sm-delivery-list"><div class="dlz-sm-loading">جارٍ تحميل طلباتك...</div></div></div>';}

 public static function render_banner(){
  $id=(int)DLZ_SM::setting('banner_id',0);
  $url=$id?wp_get_attachment_image_url($id,'full'):'';
  if(!$url && file_exists(DLZ_SM_DIR.'assets/banner.jpg')) $url=DLZ_SM_URL.'assets/banner.jpg';
  return $url?'<div class="dlz-sm-banner"><img loading="eager" src="'.esc_url($url).'" alt="متجر دليل الزائر"></div>':'';
 }
 public static function render_mini_supermarket_widget(){
  self::enqueue();
  $id='dlz-sm-mini-supermarket-'.wp_rand(1000,99999);
  $products=wp_strip_all_tags(self::render_products(['limit'=>24]));
  // Render a dedicated popup using the same product renderer; the full HTML is kept hidden until click.
  ob_start();
  echo '<div class="dlz-sm-mini-store-widget" dir="rtl">';
  echo '<button type="button" class="dlz-sm-mini-store-trigger" data-mini-store-target="'.esc_attr($id).'"><span class="dlz-sm-mini-store-icon"><svg viewBox="0 0 48 48" aria-hidden="true"><path d="M7 9h5l4 23h21l4-16H14"/><circle cx="20" cy="39" r="3"/><circle cx="35" cy="39" r="3"/></svg></span><span>سوبر ماركت</span><span class="dlz-sm-mini-store-arrow">‹</span></button>';
  echo '<div id="'.esc_attr($id).'" class="dlz-sm-mini-store-modal" aria-hidden="true"><div class="dlz-sm-mini-store-backdrop"></div><div class="dlz-sm-mini-store-card"><button type="button" class="dlz-sm-mini-store-close" aria-label="إغلاق">×</button><div class="dlz-sm-popup-kicker">سوبر ماركت</div><h2>منتجات السوبر ماركت</h2><p class="dlz-sm-mini-store-subtitle">المنتجات المتاحة في مدينتك</p><div class="dlz-sm-mini-store-products">'.self::render_products(['limit'=>24]).'</div></div></div>';
  echo '</div>';
  return ob_get_clean();
 }
 public static function render_delivery_request_banner(){
  // Prefer the dedicated delivery banner; fall back to the store banner so an uploaded banner is never silently lost.
  $id=(int)DLZ_SM::setting('delivery_request_banner_id',0);
  if(!$id) $id=(int)DLZ_SM::setting('banner_id',0);
  if(!$id) {
   $fallback=DLZ_SM_DIR.'assets/banner.jpg';
   if(file_exists($fallback)) $url=DLZ_SM_URL.'assets/banner.jpg'; else return '';
  } else { $url=wp_get_attachment_image_url($id,'full'); if(!$url) { $fallback=DLZ_SM_DIR.'assets/banner.jpg'; $url=file_exists($fallback)?DLZ_SM_URL.'assets/banner.jpg':''; } }
  if(!$url) return '';
  return '<div id="dlz-sm-fixed-delivery-banner" class="dlz-sm-delivery-request-wrap"><button type="button" class="dlz-sm-delivery-request-banner" data-coming-soon="1" aria-label="طلب التوصيل"><img loading="eager" decoding="async" src="'.esc_url($url).'" alt="طلب التوصيل"><span class="dlz-sm-coming-soon">قريباً</span></button></div>';
 }
 public static function render_ads($placement='top'){return ''; }
 public static function render_categories(){
  global $wpdb; $city=DLZ_SM::city_id(); $t=DLZ_SM::$tables['categories'];
  $rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM $t WHERE active=1 AND (city_id=0 OR city_id=%d) ORDER BY sort_order ASC,id ASC LIMIT 12",$city));
  if(!$rows){ $items=[['خبز وفطور','01-bread.png'],['حلويات وبسكويت','02-sweets.png'],['ألبان وأجبان','03-dairy.png'],['شيبس ووجبات خفيفة','04-snacks.png'],['ماء ومشروبات','05-drinks.png'],['شاي وقهوة','06-tea-coffee.png'],['معلبات','07-canned.png'],['أطفال وحفاضات','08-baby.png'],['مناديل ونظافة','09-cleaning.png'],['احتياجات الفندق','10-hotel.png'],['فواكه','11-fruits.jpg'],['سجائر','12-cigarettes.png']]; foreach($items as $i=>$it){$wpdb->insert($t,['name_ar'=>$it[0],'image_id'=>0,'city_id'=>0,'active'=>1,'sort_order'=>$i,'created_at'=>current_time('mysql')]);} $rows=$wpdb->get_results("SELECT * FROM $t WHERE active=1 AND city_id=0 ORDER BY sort_order ASC,id ASC LIMIT 12"); }
  $map=['خبز وفطور'=>'01-bread.png','حلويات وبسكويت'=>'02-sweets.png','ألبان وأجبان'=>'03-dairy.png','شيبس ووجبات خفيفة'=>'04-snacks.png','ماء ومشروبات'=>'05-drinks.png','شاي وقهوة'=>'06-tea-coffee.png','معلبات'=>'07-canned.png','أطفال وحفاضات'=>'08-baby.png','مناديل ونظافة'=>'09-cleaning.png','احتياجات الفندق'=>'10-hotel.png','فواكه'=>'11-fruits.jpg','سجائر'=>'12-cigarettes.png'];
  ob_start(); echo '<div class="dlz-sm-section-head dlz-sm-category-head"><h2>التصنيفات</h2></div><div class="dlz-sm-categories">'; foreach($rows as $r){$img=$r->image_id?wp_get_attachment_image_url($r->image_id,'large'):''; if(!$img && isset($map[$r->name_ar])) $img=DLZ_SM_URL.'assets/category-images/'.$map[$r->name_ar]; echo '<button type="button" class="dlz-sm-category" data-category="'.(int)$r->id.'" aria-label="'.esc_attr($r->name_ar).'">'.($img?'<img loading="lazy" src="'.esc_url($img).'" alt="'.esc_attr($r->name_ar).'">':'<span class="dlz-sm-cat-placeholder"></span>').'</button>'; } echo '</div>'; return ob_get_clean();
 }
 public static function render_quick(){return '<div class="dlz-sm-quick"><button data-search="ماء">ماء</button><button data-search="خبز">خبز</button><button data-search="حليب">حليب</button><button data-search="حفاضات">حفاضات</button><button data-search="مناديل">مناديل</button><button data-search="شاي">شاي</button></div>';}
 public static function render_products($args=[]){
  global $wpdb;$city=DLZ_SM::city_id();$limit=isset($args['limit'])?(int)$args['limit']:12;$cat=isset($args['category'])?(int)$args['category']:0;$search=isset($args['search'])?sanitize_text_field($args['search']):'';$discounted=!empty($args['discounted']);$where='p.active=1';$params=[]; if($cat){$where.=' AND p.category_id=%d';$params[]=$cat;} if($discounted)$where.=' AND p.sale_price IS NOT NULL AND p.sale_price>0 AND p.sale_price<p.base_price '; if($search){$where.=' AND (p.name_ar LIKE %s OR p.description_ar LIKE %s)';$like='%'.$wpdb->esc_like($search).'%';$params[]=$like;$params[]=$like;}
  $sql="SELECT p.*, c.name_ar category_name, s.qty, s.price city_price, s.active city_active FROM {$wpdb->prefix}dlz_sm_products p LEFT JOIN {$wpdb->prefix}dlz_sm_categories c ON c.id=p.category_id LEFT JOIN {$wpdb->prefix}dlz_sm_stock s ON s.product_id=p.id AND s.city_id=%d WHERE $where ORDER BY p.sort_order ASC,p.id DESC LIMIT %d";
  array_unshift($params,$city);$params[]=$limit;$rows=$wpdb->get_results($wpdb->prepare($sql,$params)); ob_start(); echo '<div class="dlz-sm-products">'; foreach($rows as $p){$price=($p->city_price!==null)?(float)$p->city_price:(float)(($p->sale_price!==null)?$p->sale_price:$p->base_price);$available=(bool)($p->city_active && (int)$p->qty>0);$img=$p->image_id?wp_get_attachment_image_url($p->image_id,'medium'):'';$discount=($p->base_price>0&&$price<$p->base_price)?round((1-$price/$p->base_price)*100):0; echo '<article class="dlz-sm-product" data-product="'.(int)$p->id.'">'.($img?'<img class="dlz-sm-product-img" loading="lazy" src="'.esc_url($img).'" alt="">':'<div class="dlz-sm-product-img dlz-sm-noimg"></div>').'<div class="dlz-sm-product-body"><div class="dlz-sm-product-title">'.esc_html($p->name_ar).'</div><div class="dlz-sm-price">'.esc_html(DLZ_SM::money($price)).'</div>'.($discount?'<div class="dlz-sm-discount">-'.$discount.'%</div>':'').($available?'<button class="dlz-sm-add" data-id="'.(int)$p->id.'">أضف <b>+</b></button>':'<span class="dlz-sm-out">غير متوفر حالياً</span>').'</div></article>'; } if(!$rows)echo '<div class="dlz-sm-empty">لا توجد منتجات متاحة حالياً</div>';echo '</div>';return ob_get_clean();
 }
 public static function render_packages(){
  global $wpdb;$city=DLZ_SM::city_id();$rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM {$wpdb->prefix}dlz_sm_packages WHERE active=1 AND stock_qty>0 AND (city_id=0 OR city_id=%d) ORDER BY sort_order ASC,id DESC",$city));ob_start();echo '<div class="dlz-sm-section-head"><h2>باقات جاهزة</h2></div><div class="dlz-sm-packages">';foreach($rows as $p){$img=$p->image_id?wp_get_attachment_image_url($p->image_id,'medium'):'';$price=(float)$p->price;echo '<article class="dlz-sm-package">'.($img?'<img loading="lazy" src="'.esc_url($img).'" alt="">':'').'<div><span class="dlz-sm-package-stock">متوفر: '.(int)$p->stock_qty.'</span><h3>'.esc_html($p->name_ar).'</h3><p>'.esc_html($p->description_ar).'</p><strong>'.esc_html(DLZ_SM::money($price)).'</strong><button class="dlz-sm-package-add" data-id="'.(int)$p->id.'">أضف إلى السلة</button></div></article>'; }if(!$rows)echo '<div class="dlz-sm-empty">لا توجد باقات متاحة حالياً</div>';echo '</div>';return ob_get_clean();
 }
}
