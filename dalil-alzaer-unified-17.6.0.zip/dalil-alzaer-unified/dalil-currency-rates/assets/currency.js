/* Dalil Al Zaer — currency rates & exchange */
(function () {
	'use strict';
	var d = document;
	/* pull the block up under the app header when only empty theme / Elementor spacing sits above it */
	var lift = window.DLZLift || (window.DLZLift = function (root) {
		if (!root || root.__lift) return;
		root.__lift = 1;
		var pt = d.querySelector('.dlz-ptitle'), hd = pt && pt.offsetHeight ? pt : d.getElementById('dsh-header'), ab = d.getElementById('wpadminbar'); // under the page title when there is one
		var y = window.scrollY || 0, ref = 0;
		if (hd && hd.offsetHeight) ref = getComputedStyle(hd).position === 'fixed' ? hd.offsetHeight : hd.getBoundingClientRect().bottom + y;
		else if (ab && getComputedStyle(ab).position === 'fixed') ref = ab.offsetHeight;
		var gap = root.getBoundingClientRect().top + y - ref - 10;
		if (gap < 6 || gap > 420) return;
		var w = d.createTreeWalker(d.body, NodeFilter.SHOW_ELEMENT), el;
		while ((el = w.nextNode())) {
			if (el === root) break;
			if (el.contains(root) || (hd && (el === hd || hd.contains(el))) || /^(SCRIPT|STYLE|LINK|META|NOSCRIPT|TEMPLATE)$/.test(el.tagName)) continue;
			var r = el.getBoundingClientRect();
			if (r.width < 2 || r.height < 2 || r.bottom + y <= ref) continue;
			var cs = getComputedStyle(el);
			if (cs.visibility === 'hidden' || cs.position === 'fixed' || cs.position === 'absolute' || +cs.opacity === 0) continue;
			if (/^(IMG|SVG|svg|VIDEO|IFRAME|INPUT|BUTTON|CANVAS|SELECT|TEXTAREA)$/.test(el.tagName) || [].some.call(el.childNodes, function (n) { return n.nodeType === 3 && n.textContent.trim(); })) return;
		}
		root.style.marginTop = (-gap) + 'px';
	});

	function latin(s) {
		return String(s || '').replace(/[۰-۹]/g, function (c) { return c.charCodeAt(0) - 0x06F0; })
			.replace(/[٠-٩]/g, function (c) { return c.charCodeAt(0) - 0x0660; })
			.replace(/[٫،]/g, '.');
	}
	function num(v) { return parseFloat(latin(v).replace(/[^\d.]/g, '')) || 0; }
	function fmt(n, max) {
		try { return new Intl.NumberFormat('en-US', { maximumFractionDigits: max == null ? 2 : max }).format(n); }
		catch (e) { return String(Math.round(n * 100) / 100); }
	}
	/* 1234567.5 typed → «1,234,567.5» while keeping the caret near the same digit */
	function liveFormat(inp) {
		var raw = latin(inp.value).replace(/[^\d.]/g, ''), dot = raw.indexOf('.');
		if (dot > -1) raw = raw.slice(0, dot + 1) + raw.slice(dot + 1).replace(/\./g, '').slice(0, 2);
		var parts = raw.split('.'), int = parts[0].replace(/^0+(?=\d)/, '').slice(0, 13);
		var out = int.replace(/\B(?=(\d{3})+(?!\d))/g, ',') + (parts.length > 1 ? '.' + parts[1] : '');
		if (out === inp.value) return;
		var fromEnd = inp.value.length - (inp.selectionEnd == null ? inp.value.length : inp.selectionEnd);
		inp.value = out;
		var p = Math.max(0, out.length - fromEnd);
		try { inp.setSelectionRange(p, p); } catch (e) {}
	}

	function Sheet(el) {
		var self = this;
		this.open = function () {
			d.body.appendChild(el);
			el.hidden = false;
			d.documentElement.classList.add('dcx-lock');
			requestAnimationFrame(function () { requestAnimationFrame(function () { el.classList.add('is-open'); }); });
		};
		this.close = function () {
			el.classList.remove('is-open');
			d.documentElement.classList.remove('dcx-lock');
			setTimeout(function () { if (!el.classList.contains('is-open')) el.hidden = true; }, 340);
		};
		el.addEventListener('click', function (e) { if (e.target.hasAttribute('data-close')) self.close(); });
		d.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !el.hidden) self.close(); });
	}

	function banner(box) {
		var track = box.querySelector('.dcx-track'), dots = box.querySelectorAll('.dcx-dot'), n = dots.length, i = 0, t = null, x0 = null;
		if (n < 2) return;
		function go(k) {
			i = (k + n) % n;
			track.style.transform = 'translateX(' + (i * 100) + '%)'; // RTL: the next slide sits on the left
			dots.forEach(function (dd, j) { dd.classList.toggle('is-on', j === i); });
		}
		function auto() { if (box.getAttribute('data-autoplay') === '1') { clearInterval(t); t = setInterval(function () { go(i + 1); }, 5000); } }
		dots.forEach(function (dd, j) { dd.addEventListener('click', function () { go(j); auto(); }); });
		box.addEventListener('touchstart', function (e) { x0 = e.touches[0].clientX; }, { passive: true });
		box.addEventListener('touchend', function (e) {
			if (x0 == null) return;
			var dx = e.changedTouches[0].clientX - x0;
			x0 = null;
			if (Math.abs(dx) > 40) { go(i + (dx > 0 ? 1 : -1)); auto(); }
		}, { passive: true });
		auto();
	}

	function init(root) {
		if (root.__dcx) return;
		root.__dcx = 1;
		var bn = root.querySelector('.dcx-banner');
		if (bn) banner(bn);
		var ex = root.querySelector('.dcx-ex');
		if (!ex) return;

		var rates = {};
		try { rates = JSON.parse(root.getAttribute('data-rates') || '{}'); } catch (e) {}
		var mode = 'buy', cur = ex.querySelector('.dcx-cur.is-on');
		var seg = ex.querySelector('.dcx-seg'), amt = ex.querySelector('.dcx-amt-in'), total = ex.querySelector('.dcx-total'),
			totalU = ex.querySelector('.dcx-total-u'), rateLine = ex.querySelector('.dcx-rate-line'), amtLab = ex.querySelector('.dcx-amt-lab'),
			amtU = ex.querySelector('.dcx-amt-u'), curLab = ex.querySelector('.dcx-cur-lab'), go = ex.querySelector('.dcx-go');

		function calc() {
			if (!cur) return;
			var a = num(amt.value), r = parseFloat(rates[cur.getAttribute('data-sym')]) || 0, name = cur.getAttribute('data-name'), code = cur.getAttribute('data-code');
			if (mode === 'buy') {
				total.textContent = fmt(r ? a / r : 0, 2);
				totalU.textContent = name;
				amtLab.textContent = 'المبلغ بالتومان';
				amtU.textContent = 'تومان';
				curLab.textContent = 'العملة المطلوبة';
			} else {
				total.textContent = fmt(a * r, 0);
				totalU.textContent = 'تومان';
				amtLab.textContent = 'المبلغ بالعملة (' + code + ')';
				amtU.textContent = code;
				curLab.textContent = 'العملة التي ستبيعها';
			}
			rateLine.textContent = r ? '1 ' + code + ' = ' + fmt(r, 0) + ' تومان' : '';
			go.disabled = !(a > 0 && r > 0);
		}
		seg.addEventListener('click', function (e) {
			var b = e.target.closest('button[data-mode]');
			if (!b || b.classList.contains('is-on')) return;
			seg.querySelectorAll('button').forEach(function (x) { var on = x === b; x.classList.toggle('is-on', on); x.setAttribute('aria-selected', on ? 'true' : 'false'); });
			mode = b.getAttribute('data-mode');
			seg.classList.toggle('is-sell', mode === 'sell');
			amt.value = '';
			calc();
		});
		ex.querySelector('.dcx-curs').addEventListener('click', function (e) {
			var b = e.target.closest('.dcx-cur');
			if (!b) return;
			ex.querySelectorAll('.dcx-cur').forEach(function (x) { var on = x === b; x.classList.toggle('is-on', on); x.setAttribute('aria-checked', on ? 'true' : 'false'); });
			cur = b;
			calc();
		});
		amt.addEventListener('input', function () { liveFormat(amt); calc(); });
		calc();

		/* sheets */
		var sh = {
			choice: new Sheet(root.querySelector('.dcx-s-choice')),
			office: new Sheet(root.querySelector('.dcx-s-office')),
			home: new Sheet(root.querySelector('.dcx-s-home'))
		};
		var homeEl = root.querySelector('.dcx-s-home'), choiceEl = root.querySelector('.dcx-s-choice');
		go.addEventListener('click', function () { if (!go.disabled) sh.choice.open(); });
		choiceEl.addEventListener('click', function (e) {
			var b = e.target.closest('.dcx-opt');
			if (!b) return;
			sh.choice.close();
			setTimeout(function () {
				if (b.getAttribute('data-choice') === 'office') { sh.office.open(); return; }
				var f = homeEl.querySelector('form');
				f.elements.mode.value = mode;
				f.elements.currency.value = cur.getAttribute('data-sym');
				f.elements.amount.value = num(amt.value);
				homeEl.querySelector('.dcx-sum').innerHTML =
					'<span>' + (mode === 'buy' ? 'شراء' : 'بيع') + ' ' + cur.getAttribute('data-name') + '</span>' +
					'<span dir="ltr">' + amt.value + ' ' + (mode === 'buy' ? 'تومان' : cur.getAttribute('data-code')) + '</span>';
				homeEl.querySelector('form').hidden = false;
				homeEl.querySelector('.dcx-ok').hidden = true;
				sh.home.open();
			}, 200);
		});

		/* «نأتي إليك» — sent with AJAX, normal post when it fails */
		var form = homeEl.querySelector('form'), err = form.querySelector('.dcx-form-err'), btn = form.querySelector('.dcx-submit'), idle = btn.textContent;
		form.elements.phone.addEventListener('input', function () { var p = form.elements.phone; p.value = latin(p.value).replace(/[^\d+ ]/g, ''); });
		form.addEventListener('submit', function (e) {
			e.preventDefault();
			var f = form.elements;
			err.hidden = true;
			if (f.name.value.trim().length < 2 || latin(f.phone.value).replace(/\D/g, '').length < 7 || f.address.value.trim().length < 4) {
				err.textContent = 'يرجى إكمال جميع البيانات.';
				err.hidden = false;
				return;
			}
			btn.disabled = true;
			btn.textContent = 'جارٍ الإرسال…';
			var body = new FormData(form);
			body.set('action', 'dalil_cr_exchange');
			fetch(root.getAttribute('data-ajax'), { method: 'POST', body: body, credentials: 'same-origin' })
				.then(function (r) { return r.json(); })
				.then(function (r) {
					if (r && r.success) { form.hidden = true; homeEl.querySelector('.dcx-ok').hidden = false; form.elements.address.value = ''; }
					else { err.textContent = (r && r.data && r.data.message) || 'تعذّر الإرسال، حاول مرة أخرى.'; err.hidden = false; }
				})
				.catch(function () { form.submit(); })
				.then(function () { btn.disabled = false; btn.textContent = idle; });
		});
	}

	function boot() { var all = d.querySelectorAll('.dcx'); all.forEach(init); if (all.length === 1) setTimeout(function () { lift(all[0]); }, 0); }
	if (d.readyState === 'loading') d.addEventListener('DOMContentLoaded', boot); else boot();
	window.addEventListener('elementor/frontend/init', function () {
		if (window.elementorFrontend && elementorFrontend.hooks) elementorFrontend.hooks.addAction('frontend/element_ready/dalil_currency_rates.default', function ($s) { var el = $s && $s[0] ? $s[0] : $s; if (el && el.querySelectorAll) el.querySelectorAll('.dcx').forEach(init); });
	});
})();
