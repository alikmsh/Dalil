<?php
if (!defined('ABSPATH')) exit;

class Dalil_Currency_Core {
    const OPTION='dalil_cr_options';
    const CACHE='dalil_cr_cache';
    const CRON='dalil_cr_refresh';

    private $currencies=array(
        'USD_RLS'=>array('name'=>'الدولار الأمريكي','icon'=>'🇺🇸'),
        'IQD_RLS'=>array('name'=>'الدينار العراقي','icon'=>'🇮🇶'),
        'KWD_RLS'=>array('name'=>'الدينار الكويتي','icon'=>'🇰🇼'),
        'SAR_RLS'=>array('name'=>'الريال السعودي','icon'=>'🇸🇦'),
        'OMR_RLS'=>array('name'=>'الريال العُماني','icon'=>'🇴🇲')
    );

    public function __construct(){
        add_action('admin_menu',array($this,'admin_menu'));
        add_action('admin_init',array($this,'register_settings'));
        add_action('admin_enqueue_scripts',array($this,'admin_assets'));
        add_action('admin_post_dalil_cr_test',array($this,'test_api'));
        add_action('admin_post_nopriv_dalil_cr_exchange',array($this,'exchange_request'));
        add_action('admin_post_dalil_cr_exchange',array($this,'exchange_request'));
        add_action('wp_ajax_dalil_cr_exchange',array($this,'exchange_request'));
        add_action('wp_ajax_nopriv_dalil_cr_exchange',array($this,'exchange_request'));
        add_action('wp_enqueue_scripts',array($this,'head_assets'));
        add_action('admin_menu',array($this,'requests_menu'));
        add_action(self::CRON,array($this,'refresh'));
        add_shortcode('dalil_currency_rates',array($this,'shortcode'));
        add_action('elementor/widgets/register',array($this,'elementor'));
        add_action('wp_footer',array($this,'auto_frontend'),99);
    }

    public static function activate(){
        if(!wp_next_scheduled(self::CRON)) wp_schedule_event(time()+300,'dalil_cr_30m',self::CRON);
    }
    public static function deactivate(){
        wp_clear_scheduled_hook(self::CRON);
        delete_transient(self::CACHE);
    }

    public function register_settings(){
        register_setting('dalil_cr_group',self::OPTION,array($this,'sanitize'));
    }

    public function sanitize($v){
        $v=is_array($v)?$v:array();
        $b=array();
        if(isset($v['banners'])&&is_array($v['banners'])){
            foreach($v['banners'] as $id){$id=absint($id);if($id)$b[]=$id;}
        }
        return array(
            // the Servix key is kept encrypted; an empty field keeps the saved one
            'api_key'=>(function($k){$old=(array)get_option(self::OPTION,array());$k=trim((string)$k);if($k==='')return isset($old['api_key'])?$old['api_key']:'';return class_exists('DLZ_Security')?DLZ_Security::seal($k):$k;})(isset($v['api_key'])?sanitize_text_field(wp_unslash($v['api_key'])):''),
            'title'=>isset($v['title'])?sanitize_text_field($v['title']):'أسعار العملات',
            'digits'=>isset($v['digits'])?min(2,max(0,(int)$v['digits'])):0,
            'icons'=>empty($v['icons'])?0:1,
            'time'=>empty($v['time'])?0:1,
            'banners'=>array_slice(array_values(array_unique($b)),0,3),
            'banner_link'=>isset($v['banner_link'])?esc_url_raw($v['banner_link']):'',
            'autoplay'=>empty($v['autoplay'])?0:1,
            'auto_page'=>empty($v['auto_page'])?0:1,
            'office_image'=>absint(isset($v['office_image'])?$v['office_image']:0),
            'office_map'=>isset($v['office_map'])?esc_url_raw($v['office_map']):'',
            'office_title'=>isset($v['office_title'])?sanitize_text_field($v['office_title']):'مكتبنا',
        );
    }

    private function options(){
        $o=$this->raw_options();
        if(class_exists('DLZ_Security')) $o['api_key']=DLZ_Security::unseal($o['api_key']);
        return $o;
    }

    private function raw_options(){
        return wp_parse_args(get_option(self::OPTION,array()),array(
            'api_key'=>'','title'=>'أسعار العملات','digits'=>0,'icons'=>1,'time'=>1,
            'banners'=>array(),'banner_link'=>'','autoplay'=>1,'auto_page'=>1,
            'office_image'=>0,'office_map'=>'','office_title'=>'مكتبنا'
        ));
    }

    public function admin_menu(){
        add_menu_page('أسعار العملات','أسعار العملات','manage_options',
            'dalil-currency-rates',array($this,'admin_page'),'dashicons-money-alt',58);
    }

    public function requests_menu(){
        add_submenu_page(
            'dalil-currency-rates',
            'طلبات تبديل العملة',
            'طلبات التبديل',
            'manage_options',
            'dalil-currency-requests',
            array($this,'requests_page')
        );
    }

    public function requests_page(){
        if(!current_user_can('manage_options')) return;
        $requests=get_option('dalil_cr_requests',array());
        if(!is_array($requests)) $requests=array();

        if(isset($_GET['clear_request']) && isset($_GET['_wpnonce']) && wp_verify_nonce(sanitize_text_field(wp_unslash($_GET['_wpnonce'])),'dalil_clear_request_'.absint($_GET['clear_request']))){
            $i=absint($_GET['clear_request']);
            if(isset($requests[$i])){
                unset($requests[$i]);
                update_option('dalil_cr_requests',array_values($requests),false);
                $requests=array_values($requests);
            }
        }
        ?>
        <div class="wrap" dir="rtl">
            <h1>طلبات تبديل العملة</h1>
            <p>طلبات «نأتي إليك» هنا ثبت می‌شوند و دیگر ایمیلی ارسال نمی‌شود.</p>
            <div style="background:#fff;border:1px solid #ddd;border-radius:14px;overflow:auto">
            <table class="widefat striped">
                <thead><tr><th>التاريخ</th><th>النوع</th><th>العملة</th><th>المبلغ</th><th>الاسم</th><th>الهاتف</th><th>العنوان</th><th>إجراء</th></tr></thead>
                <tbody>
                <?php if(!$requests): ?><tr><td colspan="8">لا توجد طلبات حتى الآن.</td></tr>
                <?php else: foreach(array_reverse($requests,true) as $i=>$r): ?>
                    <tr>
                        <td><?php echo esc_html($r['date']??''); ?></td>
                        <td><?php echo esc_html(($r['mode']??'buy')==='sell'?'بيع':'شراء'); ?></td>
                        <td><?php echo esc_html($r['currency_name']??''); ?></td>
                        <td><?php echo esc_html($r['amount']??''); ?></td>
                        <td><?php echo esc_html($r['name']??''); ?></td>
                        <td dir="ltr"><?php echo esc_html($r['phone']??''); ?></td>
                        <td><?php echo esc_html($r['address']??''); ?></td>
                        <td><a class="button" href="<?php echo esc_url(wp_nonce_url(add_query_arg(array('page'=>'dalil-currency-requests','clear_request'=>$i),admin_url('admin.php')),'dalil_clear_request_'.$i)); ?>" onclick="return confirm('حذف هذا الطلب؟');">حذف</a></td>
                    </tr>
                <?php endforeach; endif; ?>
                </tbody>
            </table>
            </div>
        </div>
        <?php
    }

    public function admin_assets($hook){
        if($hook!=='toplevel_page_dalil-currency-rates') return;
        wp_enqueue_media();
        wp_add_inline_script('jquery',"
        jQuery(function($){
            $(document).on('click','.dalil-cr311-pick',function(e){
                e.preventDefault();
                var target=$(this).data('target');
                var frame=wp.media({title:'انتخاب بنر',button:{text:'استفاده از تصویر'},multiple:false,library:{type:'image'}});
                frame.on('select',function(){
                    var a=frame.state().get('selection').first().toJSON();
                    $('#'+target).val(a.id);
                    $('#'+target+'-preview').html('<img src=\"'+(a.sizes&&a.sizes.medium?a.sizes.medium.url:a.url)+'\" style=\"max-width:420px;height:auto;border-radius:14px;border:1px solid #d9b44a\">');
                });
                frame.open();
            });
            $(document).on('click','.dalil-cr311-remove',function(e){
                e.preventDefault(); var target=$(this).data('target');
                $('#'+target).val(''); $('#'+target+'-preview').empty();
            });
        });");
    }

    public function admin_page(){
        if(!current_user_can('manage_options')) return;
        $o=$this->options(); $b=array_pad($o['banners'],3,0);
        ?>
        <div class="wrap" dir="rtl">
        <h1>أسعار العملات <small style="font-size:12px;color:#777">v<?php echo esc_html(DALIL_CR_VERSION); ?></small></h1>
        <div style="max-width:900px;background:#fff;border:1px solid #ddd;border-radius:14px;padding:20px;margin:16px 0">
        <form method="post" action="options.php">
        <?php settings_fields('dalil_cr_group'); ?>
        <h2 style="margin-top:0">بنر بالای صفحه</h2>
        <p>بنر انتخاب‌شده مستقیماً بالای کارت قیمت‌ها نمایش داده می‌شود.</p>
        <?php for($i=0;$i<3;$i++): $id=absint($b[$i]); ?>
        <div style="padding:14px 0;border-bottom:1px solid #eee">
            <input type="hidden" id="dalil_cr311_<?php echo $i; ?>" name="<?php echo esc_attr(self::OPTION); ?>[banners][]" value="<?php echo $id; ?>">
            <div id="dalil_cr311_<?php echo $i; ?>-preview">
            <?php if($id) echo wp_get_attachment_image($id,'medium',false,array('style'=>'max-width:420px;height:auto;border-radius:14px;border:1px solid #d9b44a')); ?>
            </div>
            <p>
                <button class="button dalil-cr311-pick" data-target="dalil_cr311_<?php echo $i; ?>">انتخاب / آپلود بنر <?php echo $i+1; ?></button>
                <button class="button dalil-cr311-remove" data-target="dalil_cr311_<?php echo $i; ?>">حذف</button>
            </p>
        </div>
        <?php endfor; ?>
        <table class="form-table">
        <tr><th>لینک بنر</th><td><input type="url" class="regular-text" name="<?php echo esc_attr(self::OPTION); ?>[banner_link]" value="<?php echo esc_attr($o['banner_link']); ?>"></td></tr>
        <tr><th>حرکت خودکار</th><td><label><input type="checkbox" name="<?php echo esc_attr(self::OPTION); ?>[autoplay]" value="1" <?php checked($o['autoplay'],1); ?>> فعال</label></td></tr>
        <tr><th>نمایش خودکار در صفحه تبادل</th><td><label><input type="checkbox" name="<?php echo esc_attr(self::OPTION); ?>[auto_page]" value="1" <?php checked($o['auto_page'],1); ?>> فعال — افزونه بدون نیاز به Elementor یا Shortcode در صفحه «تبادل» نمایش داده می‌شود.</label></td></tr>
        </table>
        <h2>اتصال Servix</h2>
        <input type="password" class="regular-text" autocomplete="off" name="<?php echo esc_attr(self::OPTION); ?>[api_key]" value="" placeholder="<?php echo $o['api_key']!==''?'•••••••• (ذخیره شده — برای تغییر، کلید جدید را بنویسید)':''; ?>">
        <h2>عنوان و نمایش</h2>
        <p><input class="regular-text" name="<?php echo esc_attr(self::OPTION); ?>[title]" value="<?php echo esc_attr($o['title']); ?>"></p>
        <p>اعشار: <input type="number" min="0" max="2" name="<?php echo esc_attr(self::OPTION); ?>[digits]" value="<?php echo esc_attr($o['digits']); ?>"></p>
        <p><label><input type="checkbox" name="<?php echo esc_attr(self::OPTION); ?>[icons]" value="1" <?php checked($o['icons'],1); ?>> پرچم</label>
        &nbsp;&nbsp;<label><input type="checkbox" name="<?php echo esc_attr(self::OPTION); ?>[time]" value="1" <?php checked($o['time'],1); ?>> زمان</label></p>
        <h2>دفتر چنج</h2>
        <p>این تصویر وقتی کاربر گزینه «میام دفتر» را انتخاب کند نمایش داده می‌شود.</p>
        <input type="hidden" id="dalil_cr_office_image" name="<?php echo esc_attr(self::OPTION); ?>[office_image]" value="<?php echo absint($o['office_image']); ?>">
        <div id="dalil_cr_office_preview" style="margin:8px 0">
        <?php if(!empty($o['office_image'])) echo wp_get_attachment_image($o['office_image'],'medium',false,array('style'=>'max-width:420px;border-radius:14px;border:1px solid #d9b44a')); ?>
        </div>
        <p><button type="button" class="button dalil-cr311-pick" data-target="dalil_cr_office_image">انتخاب / آپلود عکس دفتر</button>
        <button type="button" class="button dalil-cr311-remove" data-target="dalil_cr_office_image">حذف عکس</button></p>
        <table class="form-table">
        <tr><th>عنوان دفتر</th><td><input class="regular-text" name="<?php echo esc_attr(self::OPTION); ?>[office_title]" value="<?php echo esc_attr($o['office_title']); ?>"></td></tr>
        <tr><th>لینک Google Maps</th><td><input type="url" class="regular-text" name="<?php echo esc_attr(self::OPTION); ?>[office_map]" value="<?php echo esc_attr($o['office_map']); ?>" placeholder="https://maps.google.com/..."></td></tr>
        </table>
        <?php submit_button('ذخیره همه تغییرات'); ?>
        </form></div>
        <div style="max-width:900px;background:#fff;border:1px solid #ddd;border-radius:14px;padding:20px">
        <h2>نحوه نمایش</h2>
        <p>در Elementor ویجت <strong>أسعار العملات</strong> را قرار بده.</p>
        <p>یا از شورت‌کد <code>[dalil_currency_rates]</code> استفاده کن.</p>
        </div>
        </div>
        <?php
    }

    public function test_api(){
        if(!current_user_can('manage_options')) wp_die('Unauthorized');
        check_admin_referer('dalil_cr_test_action');
        delete_transient(self::CACHE);
        $r=$this->request_rates();
        wp_safe_redirect(add_query_arg(array('page'=>'dalil-currency-rates'),admin_url('admin.php'))); exit;
    }

    private function request_rates(){
        $o=$this->options();
        if(empty($o['api_key'])) return new WP_Error('key','API Key سرویکس وارد نشده است.');
        $r=wp_remote_get('https://servix.cc/api/v1/assets',array(
            'timeout'=>15,'headers'=>array('X-API-Key'=>$o['api_key'],'Accept'=>'application/json')
        ));
        if(is_wp_error($r)) return $r;
        $code=(int)wp_remote_retrieve_response_code($r);
        $data=json_decode(wp_remote_retrieve_body($r),true);
        if($code<200||$code>=300||!is_array($data)) return new WP_Error('api','پاسخ معتبر از Servix دریافت نشد. HTTP '.$code);
        $items=(isset($data['assets'])&&is_array($data['assets']))?$data['assets']:$data;
        if(isset($data['code'])&&isset($data['value'])) $items=array($data);
        $out=array();
        foreach($items as $item){
            if(!is_array($item)||empty($item['code'])||!isset($item['value'])||!is_numeric($item['value'])) continue;
            $symbol=strtoupper(sanitize_text_field($item['code']));
            if(!isset($this->currencies[$symbol])) continue;
            $out[$symbol]=array('value'=>(float)$item['value'],'time'=>isset($item['businessTime'])?sanitize_text_field($item['businessTime']):'');
        }
        return empty($out)?new WP_Error('empty','ارزهای موردنظر در پاسخ Servix پیدا نشدند.'):$out;
    }

    public function rates(){
        $c=get_transient(self::CACHE);
        if($c!==false&&is_array($c)) return $c;
        $r=$this->request_rates();
        if(!is_wp_error($r)) set_transient(self::CACHE,$r,30*MINUTE_IN_SECONDS);
        return $r;
    }
    public function refresh(){delete_transient(self::CACHE);$this->rates();}

    /** «نأتي إليك»: saved for the admin (دلیل الزائر → نرخ ارز → طلبات التبديل). AJAX with a normal form post as fallback. */
    public function exchange_request(){
        $ajax=wp_doing_ajax();
        $fail=function($m) use ($ajax){ if($ajax) wp_send_json_error(array('message'=>$m),400); wp_die(esc_html($m)); };
        if(!isset($_POST['_wpnonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['_wpnonce'])),'dalil_cr_exchange'))
            $fail('انتهت صلاحية الصفحة، يرجى تحديثها والمحاولة مرة أخرى.');
        if(!empty($_POST['website'])) $fail('الطلب غير صالح.'); // bots fill the hidden field

        // at most 5 requests per visitor in 10 minutes
        $ip=isset($_SERVER['REMOTE_ADDR'])?preg_replace('/[^0-9a-f:.]/i','',(string)$_SERVER['REMOTE_ADDR']):'';
        $key='dalil_cr_rl_'.md5($ip.'|'.get_current_user_id());
        $hits=(int)get_transient($key);
        if($hits>=5) $fail('تم إرسال عدة طلبات، يرجى المحاولة بعد قليل.');
        set_transient($key,$hits+1,10*MINUTE_IN_SECONDS);

        $digits=array('۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9','٠'=>'0','١'=>'1','٢'=>'2','٣'=>'3','٤'=>'4','٥'=>'5','٦'=>'6','٧'=>'7','٨'=>'8','٩'=>'9');
        $name=mb_substr(sanitize_text_field(wp_unslash($_POST['name']??'')),0,80);
        $phone=preg_replace('/[^0-9+ ]/','',strtr(sanitize_text_field(wp_unslash($_POST['phone']??'')),$digits));
        $address=mb_substr(sanitize_textarea_field(wp_unslash($_POST['address']??'')),0,400);
        $mode=($_POST['mode']??'')==='sell'?'sell':'buy';
        $currency=sanitize_text_field(wp_unslash($_POST['currency']??''));
        $amount=str_replace(',','',strtr(sanitize_text_field(wp_unslash($_POST['amount']??'')),$digits));

        if(!isset($this->currencies[$currency])) $fail('العملة غير صالحة.');
        if(mb_strlen($name)<2||strlen(preg_replace('/\D/','',$phone))<7||mb_strlen($address)<4||!is_numeric($amount)||$amount<=0||$amount>1e12)
            $fail('يرجى إكمال جميع البيانات.');

        $requests=get_option('dalil_cr_requests',array());
        if(!is_array($requests)) $requests=array();
        $requests[]=array(
            'date'=>current_time('Y-m-d H:i'),
            'mode'=>$mode,
            'currency'=>$currency,
            'currency_name'=>$this->currencies[$currency]['name'],
            'amount'=>(string)(0+$amount),
            'name'=>$name,
            'phone'=>trim($phone),
            'address'=>$address,
            'user_id'=>get_current_user_id(),
        );
        if(count($requests)>200) $requests=array_slice($requests,-200);
        update_option('dalil_cr_requests',$requests,false);
        do_action('dalil_cr_exchange_request',end($requests));

        if($ajax) wp_send_json_success(array('message'=>'تم استلام طلبك'));
        $ref=wp_get_referer();
        wp_safe_redirect(add_query_arg('dalil_exchange_sent','1',$ref?:home_url('/')));
        exit;
    }

    /** Currency → flag key and ISO code. */
    private function meta($symbol){
        $m=array('USD_RLS'=>array('us','USD'),'IQD_RLS'=>array('iq','IQD'),'KWD_RLS'=>array('kw','KWD'),'SAR_RLS'=>array('sa','SAR'),'OMR_RLS'=>array('om','OMR'));
        return isset($m[$symbol])?$m[$symbol]:array('','');
    }

    private function flag($symbol){
        $f=$this->meta($symbol)[0];
        if(!$f) return '';
        return '<span class="dcx-flag" aria-hidden="true"><svg viewBox="0 0 300 200" preserveAspectRatio="none" focusable="false"><use href="#dlzf-'.esc_attr($f).'"/></svg></span>';
    }

    /** CSS / JS once per page; in <head> when possible so the page never flashes unstyled. */
    private static $assets=false;
    public function head_assets(){
        if(is_admin()) return;
        $o=$this->options();
        $post=get_queried_object();
        $hit=$post && isset($post->post_content) && (has_shortcode($post->post_content,'dalil_currency_rates') || false!==strpos($post->post_content,'dalil_currency_rates'));
        if(!$hit && is_singular()){
            $data=get_post_meta(get_queried_object_id(),'_elementor_data',true);
            $hit=is_string($data) && false!==strpos($data,'dalil_currency_rates');
        }
        if(!$hit && !empty($o['auto_page']) && (is_page('تبادل')||is_page('tabadol')||is_page('exchange'))) $hit=true;
        if($hit){ $base=plugins_url('assets/',DALIL_CR_DIR.'dalil-currency-rates.php'); wp_enqueue_script('dalil-currency',$base.'currency.js',array(),DALIL_CR_VERSION,true); }
    }
    private function assets(){
        if(self::$assets) return '';
        self::$assets=true;
        $base=plugins_url('assets/',DALIL_CR_DIR.'dalil-currency-rates.php');
        $ver=DALIL_CR_VERSION;
        wp_enqueue_script('dalil-currency',$base.'currency.js',array(),$ver,true);
        // the look travels inline with the block: no theme / cache / optimiser can drop it
        if(function_exists('dlz_inline_css')) return dlz_inline_css('dalil-currency',DALIL_CR_DIR.'assets/currency.css');
        if(!did_action('wp_head')){ wp_enqueue_style('dalil-currency',$base.'currency.css',array(),$ver); return ''; }
        return '<link rel="stylesheet" id="dalil-currency-inline-css" href="'.esc_url($base.'currency.css?ver='.$ver).'">';
    }

    private function banner($o){
        $ids=array_values(array_filter(array_map('absint',(array)$o['banners'])));
        if(!$ids) return '';
        $valid=array();
        foreach($ids as $id){$src=wp_get_attachment_image_url($id,'large');if(!$src)$src=wp_get_attachment_image_url($id,'full');if($src)$valid[]=array($id,$src);}
        if(!$valid) return '';
        ob_start(); ?>
        <div class="dcx-banner" data-autoplay="<?php echo !empty($o['autoplay'])?'1':'0'; ?>">
            <div class="dcx-track">
            <?php foreach($valid as $i=>$v):
                $img=wp_get_attachment_image($v[0],'large',false,array('class'=>'dcx-bimg','alt'=>'تبادل العملات','loading'=>$i?'lazy':'eager','decoding'=>'async'));
                if(!$img) $img='<img class="dcx-bimg" src="'.esc_url($v[1]).'" alt="تبادل العملات" loading="'.($i?'lazy':'eager').'" decoding="async">'; ?>
                <div class="dcx-slide"><?php echo !empty($o['banner_link'])?'<a href="'.esc_url($o['banner_link']).'">'.$img.'</a>':$img; // phpcs:ignore ?></div>
            <?php endforeach; ?>
            </div>
            <?php if(count($valid)>1): ?><div class="dcx-dots"><?php foreach($valid as $i=>$v): ?><button type="button" class="dcx-dot<?php echo $i===0?' is-on':''; ?>" aria-label="<?php echo esc_attr('بنر '.($i+1)); ?>"></button><?php endforeach; ?></div><?php endif; ?>
        </div>
        <?php return ob_get_clean();
    }

    private function fmt($v,$digits){ return number_format((float)$v,(int)$digits,'.',','); }

    private function profile_defaults(){
        $u=wp_get_current_user();
        if(!$u||!$u->exists()) return array('','');
        $name=trim((string)get_user_meta($u->ID,'mp_full_name',true));
        if($name==='') $name=trim(get_user_meta($u->ID,'first_name',true).' '.get_user_meta($u->ID,'last_name',true));
        $phone=(string)get_user_meta($u->ID,'mp_sms_phone',true);
        return array($name,$phone);
    }

    private static $done=false;

    public function render($args=array()){
        $o=$this->options();$rates=$this->rates();
        $title=isset($args['title'])&&$args['title']!==''?$args['title']:$o['title'];
        $icons=array_key_exists('icons',$args)?(int)$args['icons']:(int)$o['icons'];
        $time=array_key_exists('time',$args)?(int)$args['time']:(int)$o['time'];
        $digits=isset($args['digits'])?min(2,max(0,(int)$args['digits'])):(int)$o['digits'];
        $editor=class_exists('\\Elementor\\Plugin') && isset(\Elementor\Plugin::$instance->editor) && \Elementor\Plugin::$instance->editor->is_edit_mode();
        if(self::$done && !$editor) return ''; // one exchange block per page (widget + automatic block showed it twice)
        self::$done=true;
        $updated='';
        if(!is_wp_error($rates)) foreach($rates as $v){ if(!empty($v['time'])){ $t=strtotime($v['time']); $updated=$t?wp_date('H:i',$t):$v['time']; break; } }
        $rate_json=array();
        if(!is_wp_error($rates)) foreach($this->currencies as $symbol=>$c) if(isset($rates[$symbol])) $rate_json[$symbol]=round((float)$rates[$symbol]['value']/10,4);
        $office=$o['office_image']?wp_get_attachment_image_url($o['office_image'],'large'):'';
        list($pname,$pphone)=$this->profile_defaults();
        ob_start();
        echo $this->assets(); // phpcs:ignore
        if(class_exists('DLZ_Countries')) echo DLZ_Countries::defs(array('us','iq','kw','sa','om')); // phpcs:ignore
        ?>
<div class="dcx" dir="rtl" data-rates="<?php echo esc_attr(wp_json_encode($rate_json)); ?>" data-ajax="<?php echo esc_url(admin_url('admin-ajax.php')); ?>">
    <?php echo $this->banner($o); // phpcs:ignore ?>

    <section class="dcx-card dcx-rates" aria-labelledby="dcx-rates-t">
        <header class="dcx-head">
            <div>
                <h3 id="dcx-rates-t"><?php echo esc_html($title); ?></h3>
                <p class="dcx-live"><i aria-hidden="true"></i>أسعار مباشرة<?php if($time&&$updated): ?> · آخر تحديث <b dir="ltr"><?php echo esc_html($updated); ?></b><?php endif; ?></p>
            </div>
            <span class="dcx-unit-badge">بالتومان</span>
        </header>
        <?php if(is_wp_error($rates)): ?>
            <div class="dcx-error">الأسعار غير متوفرة حالياً، يرجى المحاولة بعد قليل.</div>
            <?php if(current_user_can('manage_options')): ?><div class="dcx-error dcx-error-adm"><?php echo esc_html($rates->get_error_message()); ?></div><?php endif; ?>
        <?php else: ?>
        <ul class="dcx-list">
            <?php foreach($this->currencies as $symbol=>$c): if(!isset($rates[$symbol]))continue; ?>
            <li class="dcx-row" data-sym="<?php echo esc_attr($symbol); ?>">
                <?php echo $icons?$this->flag($symbol):''; // phpcs:ignore ?>
                <span class="dcx-nm"><b><?php echo esc_html($c['name']); ?></b><small dir="ltr"><?php echo esc_html($this->meta($symbol)[1]); ?></small></span>
                <span class="dcx-val"><b dir="ltr"><?php echo esc_html($this->fmt($rates[$symbol]['value']/10,$digits)); ?></b><small>تومان</small></span>
            </li>
            <?php endforeach; ?>
        </ul>
        <?php endif; ?>
    </section>

    <?php if($rate_json): ?>
    <section class="dcx-card dcx-ex" aria-labelledby="dcx-ex-t">
        <div class="dcx-ex-head">
            <span class="dcx-kicker"><i></i>خدمة تبديل العملات<i></i></span>
            <h3 id="dcx-ex-t">بدّل عملتك بسهولة</h3>
            <p>اختر شراء أو بيع، أدخل المبلغ وشاهد القيمة التقريبية فوراً.</p>
        </div>
        <div class="dcx-seg" role="tablist">
            <button type="button" class="is-on" data-mode="buy" role="tab" aria-selected="true">شراء عملة</button>
            <button type="button" data-mode="sell" role="tab" aria-selected="false">بيع عملة</button>
            <i class="dcx-seg-ind" aria-hidden="true"></i>
        </div>
        <p class="dcx-lab dcx-cur-lab">العملة المطلوبة</p>
        <div class="dcx-curs" role="radiogroup">
            <?php $first=true; foreach($this->currencies as $symbol=>$c): if(!isset($rate_json[$symbol]))continue; ?>
            <button type="button" class="dcx-cur<?php echo $first?' is-on':''; ?>" data-sym="<?php echo esc_attr($symbol); ?>" data-name="<?php echo esc_attr($c['name']); ?>" data-code="<?php echo esc_attr($this->meta($symbol)[1]); ?>" role="radio" aria-checked="<?php echo $first?'true':'false'; ?>"><?php echo $this->flag($symbol); // phpcs:ignore ?><span dir="ltr"><?php echo esc_html($this->meta($symbol)[1]); ?></span></button>
            <?php $first=false; endforeach; ?>
        </div>
        <label class="dcx-lab dcx-amt-lab" for="dcx-amt">المبلغ بالتومان</label>
        <div class="dcx-amt">
            <input id="dcx-amt" class="dcx-amt-in" type="text" inputmode="decimal" autocomplete="off" dir="ltr" placeholder="0">
            <span class="dcx-amt-u">تومان</span>
        </div>
        <div class="dcx-res" aria-live="polite">
            <small>المبلغ الذي ستحصل عليه تقريباً</small>
            <strong class="dcx-total" dir="ltr">0</strong>
            <span class="dcx-total-u">الدولار الأمريكي</span>
            <em class="dcx-rate-line"></em>
        </div>
        <button type="button" class="dcx-go"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 8h13l-3.5-3.5M20 16H7l3.5 3.5" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>طلب تبديل العملة</button>
        <p class="dcx-note">الحساب تقريبي حسب آخر سعر معلن، وقد يتغير السعر عند تنفيذ العملية.</p>
    </section>

    <div class="dcx-sheet dcx-s-choice" hidden><div class="dcx-sheet-bd" data-close></div><div class="dcx-sheet-box" role="dialog" aria-modal="true" aria-label="طريقة التبديل">
        <span class="dcx-grip" aria-hidden="true"></span>
        <h4>كيف تفضّل إتمام التبديل؟</h4><p>اختر الطريقة الأنسب لك.</p>
        <div class="dcx-opts">
            <button type="button" class="dcx-opt" data-choice="office"><span class="dcx-opt-ic"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 20V9l8-5 8 5v11M9 20v-6h6v6M3 20h18" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/></svg></span><b>آتي إلى المكتب</b><small>العنوان والموقع</small></button>
            <button type="button" class="dcx-opt" data-choice="home"><span class="dcx-opt-ic"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 7h11v9H3zM14 10h4l3 3v3h-7M7 19a2 2 0 1 1 0-.01M17 19a2 2 0 1 1 0-.01" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/></svg></span><b>نأتي إليك</b><small>الخدمة في موقعك</small></button>
        </div>
    </div></div>

    <div class="dcx-sheet dcx-s-office" hidden><div class="dcx-sheet-bd" data-close></div><div class="dcx-sheet-box" role="dialog" aria-modal="true" aria-label="<?php echo esc_attr($o['office_title']); ?>">
        <span class="dcx-grip" aria-hidden="true"></span>
        <h4><?php echo esc_html($o['office_title']); ?></h4><p>يمكنك الحضور إلى مكتبنا لإتمام عملية التبديل.</p>
        <?php if($office): ?><img class="dcx-office" src="<?php echo esc_url($office); ?>" alt="" loading="lazy" decoding="async"><?php endif; ?>
        <?php if(!empty($o['office_map'])): ?><a class="dcx-btn dcx-btn-gold" href="<?php echo esc_url($o['office_map']); ?>" target="_blank" rel="noopener">فتح الموقع على الخريطة</a><?php endif; ?>
    </div></div>

    <div class="dcx-sheet dcx-s-home" hidden><div class="dcx-sheet-bd" data-close></div><div class="dcx-sheet-box" role="dialog" aria-modal="true" aria-label="نأتي إليك">
        <span class="dcx-grip" aria-hidden="true"></span>
        <h4>نأتي إليك</h4><p>أدخل بياناتك وسنتواصل معك لتنسيق موعد التبديل.</p>
        <div class="dcx-sum"></div>
        <form class="dcx-form" method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" novalidate>
            <input type="hidden" name="action" value="dalil_cr_exchange">
            <input type="hidden" name="_wpnonce" value="<?php echo esc_attr(wp_create_nonce('dalil_cr_exchange')); ?>">
            <input type="hidden" name="mode" value="buy"><input type="hidden" name="currency" value="USD_RLS"><input type="hidden" name="amount" value="">
            <input type="text" name="website" value="" tabindex="-1" autocomplete="off" class="dcx-hp" aria-hidden="true">
            <label>الاسم الكامل<input name="name" required maxlength="80" autocomplete="name" value="<?php echo esc_attr($pname); ?>"></label>
            <label>رقم الهاتف / واتساب<input name="phone" required type="tel" inputmode="tel" dir="ltr" maxlength="20" autocomplete="tel" value="<?php echo esc_attr($pphone); ?>"></label>
            <label>العنوان بالتفصيل<textarea name="address" required maxlength="400" rows="3"></textarea></label>
            <p class="dcx-form-err" hidden></p>
            <button class="dcx-btn dcx-btn-gold dcx-submit" type="submit">إرسال طلب التبديل</button>
        </form>
        <div class="dcx-ok" hidden><span class="dcx-ok-ic"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="m5 12.5 4.3 4.3L19 7" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"/></svg></span><b>تم استلام طلبك</b><p>سنتواصل معك قريباً لتنسيق موعد التبديل.</p></div>
    </div></div>
    <?php endif; ?>
    <?php if(isset($_GET['dalil_exchange_sent'])): // phpcs:ignore ?><div class="dcx-flash" role="status">تم استلام طلبك، سنتواصل معك قريباً.</div><?php endif; ?>
</div>
        <?php return ob_get_clean();
    }

    public function shortcode($atts=array()){return $this->render(is_array($atts)?$atts:array());}

    public function auto_frontend(){
        if(is_admin()||self::$done) return; // the page already shows the widget / shortcode
        $o=$this->options();
        if(empty($o['auto_page'])) return;
        if(!is_page('تبادل') && !is_page('tabadol') && !is_page('exchange')) return;
        $html=$this->render();
        if($html==='') return;
        echo '<div id="dalil-cr311-auto" hidden>'.$html.'</div>'; // phpcs:ignore
        echo '<script>(function(){var x=document.getElementById("dalil-cr311-auto");if(!x)return;var t=document.querySelector("main .elementor, main, .elementor-location-single, .site-main, #primary");if(t){t.insertBefore(x,t.firstChild);}x.hidden=false;})();</script>';
    }

    public function elementor($manager){
        if(!class_exists('\\Elementor\\Widget_Base')) return;
        require_once DALIL_CR_DIR.'includes/class-dalil-currency-elementor.php';
        if(class_exists('Dalil_Currency_Elementor_Widget')) $manager->register(new Dalil_Currency_Elementor_Widget());
    }
}
add_filter('cron_schedules',function($s){$s['dalil_cr_30m']=array('interval'=>1800,'display'=>'Dalil Currency 30 Minutes');return $s;});
