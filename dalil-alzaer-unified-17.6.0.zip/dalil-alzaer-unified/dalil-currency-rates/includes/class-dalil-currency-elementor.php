<?php
if (!defined('ABSPATH')) exit;
class Dalil_Currency_Elementor_Widget extends \Elementor\Widget_Base {
    public function get_name(){return 'dalil_currency_rates';}
    public function get_title(){return 'أسعار العملات';}
    public function get_icon(){return 'eicon-price-table';}
    public function get_categories(){return array('dalil-alzaer');}
    protected function register_controls(){
        $this->start_controls_section('content',array('label'=>'محتوا','tab'=>\Elementor\Controls_Manager::TAB_CONTENT));
        $this->add_control('title',array('label'=>'عنوان','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'أسعار العملات'));
        $this->add_control('icons',array('label'=>'پرچم','type'=>\Elementor\Controls_Manager::SWITCHER,'return_value'=>'1','default'=>'1'));
        $this->add_control('time',array('label'=>'زمان','type'=>\Elementor\Controls_Manager::SWITCHER,'return_value'=>'1','default'=>'1'));
        $this->add_control('digits',array('label'=>'اعشار','type'=>\Elementor\Controls_Manager::SELECT,'default'=>'0','options'=>array('0'=>'۰','1'=>'۱','2'=>'۲')));
        $this->end_controls_section();
    }
    protected function render(){
        $s=$this->get_settings_for_display();
        if(isset($GLOBALS['dalil_currency_core'])) echo $GLOBALS['dalil_currency_core']->render(array(
            'title'=>isset($s['title'])?$s['title']:'أسعار العملات',
            'icons'=>!empty($s['icons'])?1:0,
            'time'=>!empty($s['time'])?1:0,
            'digits'=>isset($s['digits'])?(int)$s['digits']:0
        ));
    }
}
