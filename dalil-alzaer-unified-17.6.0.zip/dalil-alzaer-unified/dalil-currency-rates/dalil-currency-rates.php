<?php
if (!defined('ABSPATH')) exit;

define('DALIL_CR_VERSION','4.1.0');
define('DALIL_CR_DIR',plugin_dir_path(__FILE__));

require_once DALIL_CR_DIR.'includes/class-dalil-currency.php';

$GLOBALS['dalil_currency_core']=new Dalil_Currency_Core();

register_activation_hook(__FILE__,array('Dalil_Currency_Core','activate'));
register_deactivation_hook(__FILE__,array('Dalil_Currency_Core','deactivate'));
