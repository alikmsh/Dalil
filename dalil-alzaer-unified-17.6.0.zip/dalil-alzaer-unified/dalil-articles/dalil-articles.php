<?php
if (!defined('ABSPATH')) { exit; }

define('DALIL_ARTICLES_VERSION', '1.4.4');
define('DALIL_ARTICLES_FILE', __FILE__);
define('DALIL_ARTICLES_DIR', plugin_dir_path(__FILE__));
define('DALIL_ARTICLES_URL', plugin_dir_url(__FILE__));

if (!class_exists('Dalil_Articles_Core', false)) {
final class Dalil_Articles_Core {
    const OPTION = 'dalil_articles_settings';
    const POST_TYPE = 'dalil_article';
    const TAXONOMY = 'dalil_category';

    public function __construct() {
        add_action('init', array($this, 'register_content'), 5);
        add_action('admin_menu', array($this, 'admin_menu'));
        add_action('admin_init', array($this, 'register_settings'));
        add_action('add_meta_boxes', array($this, 'meta_boxes'));
        add_action('save_post_' . self::POST_TYPE, array($this, 'save_meta'), 10, 2);
        add_filter('manage_' . self::POST_TYPE . '_posts_columns', array($this, 'columns'));
        add_action('manage_' . self::POST_TYPE . '_posts_custom_column', array($this, 'column_content'), 10, 2);
        add_action('wp_enqueue_scripts', array($this, 'register_assets'));
        add_action('wp_ajax_dalil_article_view', array($this, 'track_view'));
        add_action('wp_ajax_nopriv_dalil_article_view', array($this, 'track_view'));
        add_action('elementor/widgets/register', array($this, 'elementor_widget'));
        add_action('elementor/elements/categories_registered', array($this, 'elementor_category'));
    }

    public static function defaults() {
        return array(
            'title' => 'مقالات دليل الزائر',
            'subtitle' => 'كل ما تحتاج معرفته قبل وأثناء رحلتك إلى إيران',
            'featured_id' => 0,
            'banner_id' => 0,
            'accent' => '#D5AA45',
            'navy' => '#09233D',
            'posts_per_page' => 6,
            'show_popular' => 1,
            'show_categories' => 1,
        );
    }

    public static function settings() {
        return wp_parse_args(get_option(self::OPTION, array()), self::defaults());
    }

    public function register_content() {
        register_post_type(self::POST_TYPE, array(
            'labels' => array(
                'name' => 'مقالات دلیل الزائر', 'singular_name' => 'مقاله',
                'add_new' => 'افزودن مقاله', 'add_new_item' => 'افزودن مقاله جدید',
                'edit_item' => 'ویرایش مقاله', 'new_item' => 'مقاله جدید',
                'view_item' => 'مشاهده مقاله', 'search_items' => 'جستجوی مقالات',
                'not_found' => 'مقاله‌ای پیدا نشد', 'menu_name' => 'مقالات',
            ),
            'public' => true, 'show_ui' => true, 'show_in_rest' => true,
            'menu_icon' => 'dashicons-media-document',
            'supports' => array('title','editor','thumbnail','excerpt','author','revisions'),
            'has_archive' => true, 'rewrite' => array('slug' => 'articles'),
            'capability_type' => 'post', 'map_meta_cap' => true,
        ));
        register_taxonomy(self::TAXONOMY, self::POST_TYPE, array(
            'labels' => array(
                'name' => 'دسته‌بندی مقالات', 'singular_name' => 'دسته‌بندی',
                'add_new_item' => 'افزودن دسته‌بندی', 'edit_item' => 'ویرایش دسته‌بندی',
            ),
            'public' => true, 'show_ui' => true, 'show_in_rest' => true,
            'hierarchical' => true, 'rewrite' => array('slug' => 'article-category'),
        ));
    }

    public function admin_menu() {
        add_menu_page('دلیل الزائر', 'دلیل الزائر', 'edit_posts', 'dalil-articles', array($this,'dashboard'), 'dashicons-media-document', 25);
        add_submenu_page('dalil-articles', 'داشبورد', 'داشبورد', 'edit_posts', 'dalil-articles', array($this,'dashboard'));
        add_submenu_page('dalil-articles', 'همه مقالات', 'همه مقالات', 'edit_posts', 'edit.php?post_type=' . self::POST_TYPE);
        add_submenu_page('dalil-articles', 'افزودن مقاله', 'افزودن مقاله', 'edit_posts', 'post-new.php?post_type=' . self::POST_TYPE);
        add_submenu_page('dalil-articles', 'دسته‌بندی‌ها', 'دسته‌بندی‌ها', 'manage_categories', 'edit-tags.php?taxonomy=' . self::TAXONOMY . '&post_type=' . self::POST_TYPE);
        add_submenu_page('dalil-articles', 'تنظیمات طراحی', 'تنظیمات طراحی', 'manage_options', 'dalil-articles-settings', array($this,'settings_page'));
    }

    public function register_settings() { register_setting(self::OPTION, self::OPTION, array($this,'sanitize_settings')); }

    public function sanitize_settings($input) {
        $d = self::defaults();
        $accent = isset($input['accent']) ? sanitize_hex_color($input['accent']) : $d['accent'];
        $navy = isset($input['navy']) ? sanitize_hex_color($input['navy']) : $d['navy'];
        return array(
            'title' => isset($input['title']) ? sanitize_text_field($input['title']) : $d['title'],
            'subtitle' => isset($input['subtitle']) ? sanitize_text_field($input['subtitle']) : $d['subtitle'],
            'featured_id' => isset($input['featured_id']) ? absint($input['featured_id']) : 0,
            'banner_id' => isset($input['banner_id']) ? absint($input['banner_id']) : 0,
            'accent' => $accent ? $accent : $d['accent'], 'navy' => $navy ? $navy : $d['navy'],
            'posts_per_page' => isset($input['posts_per_page']) ? max(1,min(24,absint($input['posts_per_page']))) : $d['posts_per_page'],
            'show_popular' => empty($input['show_popular']) ? 0 : 1,
            'show_categories' => empty($input['show_categories']) ? 0 : 1,
        );
    }

    private function admin_box($label,$value) {
        echo '<div style="background:#fff;border:1px solid #e5e7eb;border-radius:16px;padding:20px"><div style="color:#64748b">'.esc_html($label).'</div><strong style="display:block;font-size:30px;margin-top:7px;color:#09233D">'.esc_html($value).'</strong></div>';
    }
    public function dashboard() {
        $counts = wp_count_posts(self::POST_TYPE);
        $terms = get_terms(array('taxonomy'=>self::TAXONOMY,'hide_empty'=>false,'fields'=>'count'));
        if (is_wp_error($terms)) $terms = 0;
        ?>
        <div class="wrap" dir="rtl" style="font-family:Tahoma,Arial,sans-serif"><h1>دلیل الزائر — مدیریت مقالات</h1>
        <div style="display:grid;grid-template-columns:repeat(3,minmax(180px,1fr));gap:16px;max-width:950px;margin-top:24px">
        <?php $this->admin_box('مقالات منتشرشده',isset($counts->publish)?$counts->publish:0); $this->admin_box('پیش‌نویس‌ها',isset($counts->draft)?$counts->draft:0); $this->admin_box('دسته‌بندی‌ها',$terms); ?></div>
        <div style="background:#fff;border:1px solid #e5e7eb;border-radius:18px;padding:24px;max-width:950px;margin-top:20px"><h2 style="margin-top:0">مدیریت محتوا</h2><p>همه مقاله‌ها را از همین بخش بسازید و مدیریت کنید.</p><p><a class="button button-primary" href="<?php echo esc_url(admin_url('post-new.php?post_type='.self::POST_TYPE)); ?>">افزودن مقاله</a> <a class="button" href="<?php echo esc_url(admin_url('edit.php?post_type='.self::POST_TYPE)); ?>">همه مقالات</a> <a class="button" href="<?php echo esc_url(admin_url('admin.php?page=dalil-articles-settings')); ?>">تنظیمات طراحی</a></p></div>
        <div style="background:#f8fafc;border:1px solid #e5e7eb;border-radius:18px;padding:20px;max-width:950px;margin-top:16px"><strong>ویجت Elementor</strong><p style="margin-bottom:0">ویجت «مقالات دلیل الزائر» فقط وقتی Elementor فعال باشد ثبت می‌شود.</p></div></div>
        <?php
    }

    public function settings_page() {
        $s=self::settings();
        $posts=get_posts(array('post_type'=>self::POST_TYPE,'numberposts'=>-1,'post_status'=>'publish','orderby'=>'date','order'=>'DESC'));
        $banner=$s['banner_id'] ? wp_get_attachment_image_url($s['banner_id'],'large') : '';
        ?>
        <div class="wrap" dir="rtl" style="font-family:Tahoma,Arial,sans-serif"><h1>تنظیمات صفحه مقالات</h1>
        <form method="post" action="options.php"><?php settings_fields(self::OPTION); ?>
        <table class="form-table">
        <tr><th>عنوان صفحه</th><td><input class="regular-text" name="<?php echo esc_attr(self::OPTION); ?>[title]" value="<?php echo esc_attr($s['title']); ?>"></td></tr>
        <tr><th>توضیح صفحه</th><td><input class="regular-text" name="<?php echo esc_attr(self::OPTION); ?>[subtitle]" value="<?php echo esc_attr($s['subtitle']); ?>"></td></tr>
        <tr><th>تصویر کادر بالای صفحه</th><td><input type="hidden" id="dalil_banner_id" name="<?php echo esc_attr(self::OPTION); ?>[banner_id]" value="<?php echo esc_attr($s['banner_id']); ?>"><button type="button" class="button" id="dalil_banner_btn">انتخاب / آپلود تصویر</button> <button type="button" class="button" id="dalil_banner_remove">حذف تصویر</button><div id="dalil_banner_preview" style="margin-top:12px;max-width:600px"><?php if($banner): ?><img src="<?php echo esc_url($banner); ?>" style="max-width:100%;height:auto;border-radius:14px"><?php endif; ?></div></td></tr>
        <tr><th>مقاله ویژه</th><td><select name="<?php echo esc_attr(self::OPTION); ?>[featured_id]"><option value="0">انتخاب خودکار</option><?php foreach($posts as $p): ?><option value="<?php echo esc_attr($p->ID); ?>" <?php selected($s['featured_id'],$p->ID); ?>><?php echo esc_html($p->post_title); ?></option><?php endforeach; ?></select></td></tr>
        <tr><th>رنگ طلایی</th><td><input type="color" name="<?php echo esc_attr(self::OPTION); ?>[accent]" value="<?php echo esc_attr($s['accent']); ?>"></td></tr>
        <tr><th>رنگ سرمه‌ای</th><td><input type="color" name="<?php echo esc_attr(self::OPTION); ?>[navy]" value="<?php echo esc_attr($s['navy']); ?>"></td></tr>
        <tr><th>تعداد مقالات</th><td><input type="number" min="1" max="24" name="<?php echo esc_attr(self::OPTION); ?>[posts_per_page]" value="<?php echo esc_attr($s['posts_per_page']); ?>"></td></tr>
        <tr><th>پربازدیدها</th><td><label><input type="checkbox" name="<?php echo esc_attr(self::OPTION); ?>[show_popular]" value="1" <?php checked($s['show_popular'],1); ?>> نمایش داده شود</label></td></tr>
        <tr><th>دسته‌بندی‌ها</th><td><label><input type="checkbox" name="<?php echo esc_attr(self::OPTION); ?>[show_categories]" value="1" <?php checked($s['show_categories'],1); ?>> نمایش داده شود</label></td></tr>
        </table><?php submit_button('ذخیره تنظیمات'); ?></form>
        <script>jQuery(function($){var f;$('#dalil_banner_btn').on('click',function(e){e.preventDefault();if(f){f.open();return;}f=wp.media({title:'انتخاب تصویر',button:{text:'استفاده از تصویر'},multiple:false});f.on('select',function(){var a=f.state().get('selection').first().toJSON();$('#dalil_banner_id').val(a.id);$('#dalil_banner_preview').html('<img src="'+a.url+'" style="max-width:100%;height:auto;border-radius:14px">');});f.open();});$('#dalil_banner_remove').on('click',function(){$('#dalil_banner_id').val('0');$('#dalil_banner_preview').empty();});});</script>
        <?php wp_enqueue_media(); ?></div><?php
    }

    public function meta_boxes() { add_meta_box('dalil_article_meta','تنظیمات مقاله',array($this,'meta_box'),self::POST_TYPE,'side','high'); }
    public function meta_box($post) { wp_nonce_field('dalil_article_meta_save','dalil_article_meta_nonce'); $read=get_post_meta($post->ID,'_dalil_read_time',true); $views=(int)get_post_meta($post->ID,'_dalil_views',true); ?><p><label for="dalil_read_time"><strong>زمان مطالعه (دقیقه)</strong></label><input id="dalil_read_time" type="number" min="1" max="120" name="dalil_read_time" value="<?php echo esc_attr($read?$read:5); ?>" style="width:100%;margin-top:6px"></p><p><strong>تعداد بازدید:</strong> <?php echo esc_html($views); ?></p><?php }
    public function save_meta($post_id,$post) { if(!isset($_POST['dalil_article_meta_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['dalil_article_meta_nonce'])),'dalil_article_meta_save')) return; if(defined('DOING_AUTOSAVE')&&DOING_AUTOSAVE) return; if(wp_is_post_revision($post_id)||!current_user_can('edit_post',$post_id)) return; if(isset($_POST['dalil_read_time'])) update_post_meta($post_id,'_dalil_read_time',max(1,min(120,absint($_POST['dalil_read_time'])))); }
    public function columns($columns) { $columns['dalil_views']='بازدیدها'; return $columns; }
    public function column_content($column,$post_id) { if($column==='dalil_views') echo esc_html((int)get_post_meta($post_id,'_dalil_views',true)); }

    public function register_assets() { wp_register_style('dalil-articles',DALIL_ARTICLES_URL.'assets/articles.css',array(),DALIL_ARTICLES_VERSION); wp_register_script('dalil-articles',DALIL_ARTICLES_URL.'assets/articles.js',array('jquery'),DALIL_ARTICLES_VERSION,true); wp_localize_script('dalil-articles','DalilArticles',array('ajax'=>admin_url('admin-ajax.php'),'nonce'=>wp_create_nonce('dalil_article_view'))); }
    public function track_view() { check_ajax_referer('dalil_article_view','nonce'); $id=isset($_POST['id'])?absint($_POST['id']):0; if(!$id||self::POST_TYPE!==get_post_type($id)) wp_send_json_error(); $v=(int)get_post_meta($id,'_dalil_views',true); update_post_meta($id,'_dalil_views',$v+1); wp_send_json_success(); }

    public function elementor_category($manager) { if(!class_exists('Elementor\\Elements_Manager')) return; $manager->add_category('dalil-zaer',array('title'=>'دلیل الزائر','icon'=>'fa fa-star')); }
    public function elementor_widget($manager) {
        if(!class_exists('Elementor\\Widget_Base')) return;
        $file=DALIL_ARTICLES_DIR.'elementor-widget.php';
        if(!file_exists($file)) return;
        require_once $file;
        if(class_exists('Dalil_Articles_Elementor_Widget')) $manager->register(new Dalil_Articles_Elementor_Widget());
    }

    public function render($atts=array()) {
        $this->register_assets(); wp_enqueue_style('dalil-articles'); wp_enqueue_script('dalil-articles');
        $s=self::settings(); $atts=wp_parse_args($atts,array('count'=>$s['posts_per_page'],'category'=>'','show_featured'=>'yes','show_popular'=>$s['show_popular']?'yes':'no','show_categories'=>$s['show_categories']?'yes':'no'));
        $cats=get_terms(array('taxonomy'=>self::TAXONOMY,'hide_empty'=>false));
        $featured=null; if($atts['show_featured']==='yes' && $s['featured_id']) { $p=get_post(absint($s['featured_id'])); if($p&&$p->post_type===self::POST_TYPE&&$p->post_status==='publish') $featured=$p; }
        if($atts['show_featured']==='yes'&&!$featured){$a=get_posts(array('post_type'=>self::POST_TYPE,'numberposts'=>1,'post_status'=>'publish','orderby'=>'date','order'=>'DESC'));if($a)$featured=$a[0];}
        $qargs=array('post_type'=>self::POST_TYPE,'posts_per_page'=>max(1,min(24,absint($atts['count']))),'post_status'=>'publish','post__not_in'=>$featured?array($featured->ID):array(),'ignore_sticky_posts'=>true);
        if(!empty($atts['category']))$qargs['tax_query']=array(array('taxonomy'=>self::TAXONOMY,'field'=>'slug','terms'=>sanitize_title($atts['category'])));
        $q=new WP_Query($qargs); $banner=$s['banner_id']?wp_get_attachment_image_url($s['banner_id'],'large'):'';
        ob_start(); ?>
        <section class="dalil-articles" dir="rtl" style="--dalil-navy:<?php echo esc_attr($s['navy']); ?>;--dalil-gold:<?php echo esc_attr($s['accent']); ?>">
        <?php if($banner): ?><div class="da-banner"><img src="<?php echo esc_url($banner); ?>" alt="دليل الزائر"></div><?php else: ?><header class="da-head"><div class="da-kicker">دليل الزائر ✦</div><h1><?php echo esc_html($s['title']); ?></h1><p><?php echo esc_html($s['subtitle']); ?></p></header><?php endif; ?>
        <?php if($atts['show_categories']==='yes'&&!is_wp_error($cats)&&$cats): ?><div class="da-cats"><button type="button" class="active" data-cat="all">الكل</button><?php foreach($cats as $cat): ?><button type="button" data-cat="<?php echo esc_attr($cat->term_id); ?>"><?php echo esc_html($cat->name); ?></button><?php endforeach; ?></div><?php endif; ?>
        <?php if($featured): $terms=get_the_terms($featured->ID,self::TAXONOMY); ?><article class="da-featured"><?php if(has_post_thumbnail($featured->ID)): ?><a class="da-featured-media" href="<?php echo esc_url(get_permalink($featured->ID)); ?>" data-id="<?php echo esc_attr($featured->ID); ?>"><img src="<?php echo esc_url(get_the_post_thumbnail_url($featured->ID,'large')); ?>" alt="<?php echo esc_attr(get_the_title($featured->ID)); ?>"><span class="da-featured-badge">مقال مميز</span></a><?php endif; ?><div class="da-featured-text"><?php if($terms&&!is_wp_error($terms)): ?><span class="da-pill"><?php echo esc_html($terms[0]->name); ?></span><?php endif; ?><h2><?php echo esc_html(get_the_title($featured->ID)); ?></h2><p><?php echo esc_html(wp_trim_words($featured->post_excerpt?$featured->post_excerpt:wp_strip_all_tags($featured->post_content),28)); ?></p><div class="da-meta"><span><?php echo esc_html(get_post_meta($featured->ID,'_dalil_read_time',true)?get_post_meta($featured->ID,'_dalil_read_time',true):5); ?> دقائق قراءة</span><span><?php echo esc_html(get_the_date('Y/m/d',$featured->ID)); ?></span></div><a class="da-btn" href="<?php echo esc_url(get_permalink($featured->ID)); ?>" data-id="<?php echo esc_attr($featured->ID); ?>">اقرأ المزيد ←</a></div></article><?php endif; ?>
        <div class="da-section-heading"><h2>أحدث المقالات</h2><span>محتوى مختار لك</span></div><div class="da-grid">
        <?php if($q->have_posts()): while($q->have_posts()):$q->the_post();$id=get_the_ID();$terms=get_the_terms($id,self::TAXONOMY);$cat_id=($terms&&!is_wp_error($terms))?$terms[0]->term_id:0; ?><article class="da-card" data-category="<?php echo esc_attr($cat_id); ?>"><a class="da-card-media" href="<?php the_permalink(); ?>" data-id="<?php echo esc_attr($id); ?>"><?php if(has_post_thumbnail()): ?><img src="<?php echo esc_url(get_the_post_thumbnail_url($id,'medium_large')); ?>" alt="<?php the_title_attribute(); ?>"><?php else: ?><span class="da-placeholder"><span>دليل الزائر</span></span><?php endif; ?></a><div class="da-card-body"><?php if($terms&&!is_wp_error($terms)): ?><span class="da-pill"><?php echo esc_html($terms[0]->name); ?></span><?php endif; ?><h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3><p><?php echo esc_html(wp_trim_words(get_the_excerpt(),18)); ?></p><div class="da-card-foot"><span><?php echo esc_html(get_post_meta($id,'_dalil_read_time',true)?get_post_meta($id,'_dalil_read_time',true):5); ?> دقائق</span><a href="<?php the_permalink(); ?>" data-id="<?php echo esc_attr($id); ?>">اقرأ المزيد ←</a></div></div></article><?php endwhile;wp_reset_postdata();else:?><div class="da-empty">لا توجد مقالات حالياً.</div><?php endif; ?></div>
        <?php if($atts['show_popular']==='yes'):$pop=new WP_Query(array('post_type'=>self::POST_TYPE,'posts_per_page'=>5,'post_status'=>'publish','meta_key'=>'_dalil_views','orderby'=>'meta_value_num','order'=>'DESC'));if($pop->have_posts()): ?><section class="da-popular"><div class="da-section-heading"><h2>الأكثر قراءة</h2><span>اختيارات الزوار</span></div><div class="da-popular-grid"><?php while($pop->have_posts()):$pop->the_post();$pid=get_the_ID(); ?><a class="da-pop-card" href="<?php the_permalink(); ?>" data-id="<?php echo esc_attr($pid); ?>"><?php if(has_post_thumbnail()): ?><img src="<?php echo esc_url(get_the_post_thumbnail_url($pid,'medium')); ?>" alt="<?php the_title_attribute(); ?>"><?php else: ?><span class="da-placeholder"><span>دليل الزائر</span></span><?php endif; ?><strong><?php the_title(); ?></strong></a><?php endwhile;wp_reset_postdata(); ?></div></section><?php endif;endif; ?></section>
        <?php return ob_get_clean();
    }
}
}

$dalil_articles_core = new Dalil_Articles_Core();

register_activation_hook(__FILE__, 'dalil_articles_activate');
function dalil_articles_activate() {
    if(!class_exists('Dalil_Articles_Core')) return;
    $core = new Dalil_Articles_Core();
    $core->register_content();
    if(false === get_option(Dalil_Articles_Core::OPTION,false)) add_option(Dalil_Articles_Core::OPTION,Dalil_Articles_Core::defaults());
    flush_rewrite_rules();
}
register_deactivation_hook(__FILE__, 'dalil_articles_deactivate');
function dalil_articles_deactivate(){ flush_rewrite_rules(); }
