<?php
if (!defined('ABSPATH')) { exit; }
if (!class_exists('Dalil_Articles_Elementor_Widget', false) && class_exists('Elementor\\Widget_Base')) {
class Dalil_Articles_Elementor_Widget extends \Elementor\Widget_Base {
    public function get_name(){return 'dalil_articles';}
    public function get_title(){return 'مقالات دلیل الزائر';}
    public function get_icon(){return 'eicon-posts-grid';}
    public function get_categories(){return array('dalil-alzaer');}
    protected function register_controls(){
        $this->start_controls_section('content_section',array('label'=>'محتوای مقالات','tab'=>\Elementor\Controls_Manager::TAB_CONTENT));
        $this->add_control('count',array('label'=>'تعداد مقالات','type'=>\Elementor\Controls_Manager::NUMBER,'min'=>1,'max'=>24,'default'=>6));
        $this->add_control('category',array('label'=>'دسته‌بندی','type'=>\Elementor\Controls_Manager::SELECT2,'options'=>$this->get_categories_list(),'label_block'=>true));
        foreach(array('show_featured'=>'نمایش مقاله ویژه','show_categories'=>'نمایش دسته‌بندی‌ها','show_popular'=>'نمایش پربازدیدترین‌ها') as $key=>$label){$this->add_control($key,array('label'=>$label,'type'=>\Elementor\Controls_Manager::SWITCHER,'label_on'=>'بله','label_off'=>'خیر','return_value'=>'yes','default'=>'yes'));}
        $this->end_controls_section();
        $this->start_controls_section('style_section',array('label'=>'رنگ‌ها','tab'=>\Elementor\Controls_Manager::TAB_STYLE));
        $this->add_control('gold',array('label'=>'طلایی','type'=>\Elementor\Controls_Manager::COLOR,'default'=>'#D5AA45','selectors'=>array('{{WRAPPER}} .dalil-articles'=>'--dalil-gold: {{VALUE}};')));
        $this->add_control('navy',array('label'=>'سرمه‌ای','type'=>\Elementor\Controls_Manager::COLOR,'default'=>'#09233D','selectors'=>array('{{WRAPPER}} .dalil-articles'=>'--dalil-navy: {{VALUE}};')));
        $this->end_controls_section();
    }
    private function get_categories_list(){ $out=array(''=>'همه دسته‌بندی‌ها');$terms=get_terms(array('taxonomy'=>Dalil_Articles_Core::TAXONOMY,'hide_empty'=>false));if(!is_wp_error($terms)){foreach($terms as $term)$out[$term->slug]=$term->name;}return $out; }
    protected function render(){ $s=$this->get_settings_for_display();$core=new Dalil_Articles_Core();echo $core->render(array('count'=>!empty($s['count'])?absint($s['count']):6,'category'=>isset($s['category'])?sanitize_title($s['category']):'','show_featured'=>isset($s['show_featured'])?$s['show_featured']:'yes','show_categories'=>isset($s['show_categories'])?$s['show_categories']:'yes','show_popular'=>isset($s['show_popular'])?$s['show_popular']:'yes')); }
}
}
