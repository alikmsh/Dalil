<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'DALIL_TICKET_VERSION', '1.2.2' );
define( 'DALIL_TICKET_FILE', __FILE__ );
define( 'DALIL_TICKET_DIR', plugin_dir_path( __FILE__ ) );
define( 'DALIL_TICKET_URL', plugin_dir_url( __FILE__ ) );

require_once DALIL_TICKET_DIR . 'includes/class-dalil-ticket.php';

function dalil_alzaer_ticket() {
    return Dalil_Alzaer_Ticket::instance();
}

dalil_alzaer_ticket();
