<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class Dalil_Ticket_Elementor_Widget extends \Elementor\Widget_Base {
    public function get_name() { return 'dalil_ticket_search'; }
    public function get_title() { return 'بلیط دلیل الزائر'; }
    public function get_icon() { return 'eicon-tickets'; }
    public function get_categories() { return array( 'dalil-alzaer' ); }

    protected function register_controls() {
        $this->start_controls_section( 'content_section', array(
            'label' => 'محتوا', 'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
        ) );
        $this->add_control( 'button_text', array(
            'label' => 'متن دکمه', 'type' => \Elementor\Controls_Manager::TEXT,
            'default' => 'البحث عن رحلة',
        ) );
        $this->end_controls_section();
    }

    protected function render() {
        wp_enqueue_style( 'dalil-ticket-front' );
        wp_enqueue_script( 'dalil-ticket-front' );
        $settings = $this->get_settings_for_display();
        $cities = Dalil_Alzaer_Ticket::instance()->cities();
        $banner = Dalil_Alzaer_Ticket::instance()->get_banner_url();
        ?>
        <div class="dalil-ticket-widget" dir="rtl">
            <?php if ( $banner ) : ?><div class="dalil-ticket-banner"><img src="<?php echo esc_url( $banner ); ?>" alt=""></div><?php endif; ?>
            <div class="dalil-ticket-types">
                <button type="button" class="dalil-ticket-type active" data-transport="">الكل</button>
                <button type="button" class="dalil-ticket-type" data-transport="air">هوائي</button>
                <button type="button" class="dalil-ticket-type" data-transport="bus">بري</button>
                <button type="button" class="dalil-ticket-type" data-transport="train">قطار</button>
            </div>
            <form class="dalil-ticket-form">
                <div class="dalil-ticket-route">
                    <div class="dalil-ticket-field"><label>مدينة الانطلاق</label>
                        <select name="origin" required>
                            <?php foreach ( $cities as $key => $label ) : ?><option value="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></option><?php endforeach; ?>
                        </select>
                    </div>
                    <button type="button" class="dalil-ticket-swap" aria-label="تبديل المدن">↕</button>
                    <div class="dalil-ticket-field"><label>مدينة الوصول</label>
                        <select name="destination" required>
                            <?php foreach ( $cities as $key => $label ) : ?><option value="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></option><?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="dalil-ticket-row">
                    <div class="dalil-ticket-field"><label>تاريخ السفر</label><input type="date" name="date"></div>
                    <div class="dalil-ticket-field"><label>المسافرون</label>
                        <select name="passengers">
                            <option value="1">1</option><option value="2">2</option><option value="3">3</option><option value="4">4</option><option value="5">5</option>
                        </select>
                    </div>
                </div>
                <input type="hidden" name="transport" value="">
                <button type="submit" class="dalil-ticket-submit"><?php echo esc_html( $settings['button_text'] ); ?></button>
                <div class="dalil-ticket-message" aria-live="polite"></div>
                <div class="dalil-ticket-results"></div>
                <div class="dalil-ticket-booking-area"></div>
            </form>
        </div>
        <?php
    }
}
