<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class Dalil_Alzaer_Ticket {

    private static $instance = null;
    private $post_type = 'dalil_ticket_trip';

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action( 'init', array( $this, 'register_post_type' ) );
        add_action( 'add_meta_boxes', array( $this, 'add_meta_boxes' ) );
        add_action( 'save_post_' . $this->post_type, array( $this, 'save_trip' ), 10, 2 );
        add_action( 'admin_enqueue_scripts', array( $this, 'admin_assets' ) );
        add_action( 'admin_menu', array( $this, 'admin_menu' ) );
        add_action( 'admin_init', array( $this, 'register_settings' ) );
        add_action( 'wp_enqueue_scripts', array( $this, 'register_front_assets' ) );
        add_action( 'wp_ajax_dalil_ticket_search', array( $this, 'ajax_search' ) );
        add_action( 'wp_ajax_nopriv_dalil_ticket_search', array( $this, 'ajax_search' ) );
        add_action( 'wp_ajax_dalil_ticket_booking', array( $this, 'ajax_booking' ) );
        add_action( 'wp_ajax_nopriv_dalil_ticket_booking', array( $this, 'ajax_booking' ) );
        add_action( 'elementor/widgets/register', array( $this, 'register_elementor_widget' ) );
    }

    public function register_post_type() {
        register_post_type( $this->post_type, array(
            'labels' => array(
                'name' => 'سفرها و بلیط‌ها', 'singular_name' => 'سفر',
                'menu_name' => 'بلیط', 'add_new' => 'افزودن سفر',
                'add_new_item' => 'افزودن سفر جدید', 'edit_item' => 'ویرایش سفر',
                'all_items' => 'همه سفرها',
            ),
            'public' => false, 'show_ui' => true, 'show_in_menu' => true,
            'menu_icon' => 'dashicons-tickets-alt', 'supports' => array( 'title' ),
            'capability_type' => 'post', 'map_meta_cap' => true,
        ) );

        register_post_type( 'dalil_ticket_booking', array(
            'labels' => array(
                'name' => 'رزروها', 'singular_name' => 'رزرو',
                'menu_name' => 'رزروها', 'all_items' => 'همه رزروها',
            ),
            'public' => false, 'show_ui' => true,
            'show_in_menu' => 'edit.php?post_type=' . $this->post_type,
            'supports' => array( 'title' ), 'capability_type' => 'post',
            'map_meta_cap' => true,
        ) );
    }

    public function add_meta_boxes() {
        add_meta_box(
            'dalil_ticket_booking_details', 'جزئیات رزرو', array( $this, 'render_booking_meta_box' ), 'dalil_ticket_booking', 'normal', 'high'
        );

        add_meta_box(
            'dalil_ticket_details',
            'اطلاعات سفر',
            array( $this, 'render_meta_box' ),
            $this->post_type,
            'normal',
            'high'
        );
    }

    public function render_meta_box( $post ) {
        wp_nonce_field( 'dalil_ticket_save_trip', 'dalil_ticket_nonce' );

        $origin      = get_post_meta( $post->ID, '_dalil_origin', true );
        $destination = get_post_meta( $post->ID, '_dalil_destination', true );
        $transport   = get_post_meta( $post->ID, '_dalil_transport', true );
        $date        = get_post_meta( $post->ID, '_dalil_date', true );
        $time        = get_post_meta( $post->ID, '_dalil_time', true );
        $duration    = get_post_meta( $post->ID, '_dalil_duration', true );
        $price       = get_post_meta( $post->ID, '_dalil_price', true );
        $capacity    = get_post_meta( $post->ID, '_dalil_capacity', true );
        $active      = get_post_meta( $post->ID, '_dalil_active', true );
        if ( '' === $active ) {
            $active = '1';
        }

        $cities = array(
            'mashhad' => 'مشهد',
            'qom'     => 'قم',
            'shiraz'  => 'شیراز',
            'tehran'  => 'تهران',
        );
        $types = array(
            'air'   => 'هوایی',
            'bus'   => 'زمینی',
            'train' => 'قطار',
        );
        ?>
        <div class="dalil-ticket-admin">
            <div class="dalil-ticket-grid">
                <p>
                    <label for="dalil_origin"><strong>مبدأ</strong></label>
                    <select id="dalil_origin" name="dalil_origin" required>
                        <option value="">انتخاب شهر</option>
                        <?php foreach ( $cities as $key => $label ) : ?>
                            <option value="<?php echo esc_attr( $key ); ?>" <?php selected( $origin, $key ); ?>><?php echo esc_html( $label ); ?></option>
                        <?php endforeach; ?>
                    </select>
                </p>
                <p>
                    <label for="dalil_destination"><strong>مقصد</strong></label>
                    <select id="dalil_destination" name="dalil_destination" required>
                        <option value="">انتخاب شهر</option>
                        <?php foreach ( $cities as $key => $label ) : ?>
                            <option value="<?php echo esc_attr( $key ); ?>" <?php selected( $destination, $key ); ?>><?php echo esc_html( $label ); ?></option>
                        <?php endforeach; ?>
                    </select>
                </p>
                <p>
                    <label for="dalil_transport"><strong>نوع سفر</strong></label>
                    <select id="dalil_transport" name="dalil_transport" required>
                        <?php foreach ( $types as $key => $label ) : ?>
                            <option value="<?php echo esc_attr( $key ); ?>" <?php selected( $transport, $key ); ?>><?php echo esc_html( $label ); ?></option>
                        <?php endforeach; ?>
                    </select>
                </p>
                <p>
                    <label for="dalil_date"><strong>تاریخ حرکت</strong></label>
                    <input type="date" id="dalil_date" name="dalil_date" value="<?php echo esc_attr( $date ); ?>" required>
                </p>
                <p>
                    <label for="dalil_time"><strong>ساعت حرکت</strong></label>
                    <input type="time" id="dalil_time" name="dalil_time" value="<?php echo esc_attr( $time ); ?>">
                </p>
                <p>
                    <label for="dalil_duration"><strong>مدت سفر</strong></label>
                    <input type="text" id="dalil_duration" name="dalil_duration" value="<?php echo esc_attr( $duration ); ?>" placeholder="مثلاً 2 ساعت و 30 دقیقه">
                </p>
                <p>
                    <label for="dalil_price"><strong>قیمت</strong></label>
                    <input type="number" min="0" step="1" id="dalil_price" name="dalil_price" value="<?php echo esc_attr( $price ); ?>" placeholder="به تومان" required><br><small style="color:#646970">به تومان؛ برای هر زائر خودکار به ارز کشورش تبدیل می‌شود.</small>
                </p>
                <p>
                    <label for="dalil_capacity"><strong>ظرفیت کل</strong></label>
                    <input type="number" min="1" step="1" id="dalil_capacity" name="dalil_capacity" value="<?php echo esc_attr( $capacity ); ?>" placeholder="مثلاً 40">
                </p>
                <p>
                    <label for="dalil_available"><strong>ظرفیت باقی‌مانده</strong></label>
                    <input type="number" min="0" step="1" id="dalil_available" name="dalil_available" value="<?php echo esc_attr( get_post_meta( $post->ID, '_dalil_available', true ) ); ?>">
                </p>
            </div>
            <p class="dalil-ticket-switch">
                <label>
                    <input type="checkbox" name="dalil_active" value="1" <?php checked( $active, '1' ); ?>>
                    <strong>این سفر فعال و قابل نمایش باشد</strong>
                </label>
            </p>
        </div>
        <?php
    }

    public function save_trip( $post_id, $post ) {
        if ( ! isset( $_POST['dalil_ticket_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['dalil_ticket_nonce'] ) ), 'dalil_ticket_save_trip' ) ) {
            return;
        }
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
            return;
        }
        if ( ! current_user_can( 'edit_post', $post_id ) ) {
            return;
        }

        $fields = array(
            '_dalil_origin'      => isset( $_POST['dalil_origin'] ) ? sanitize_key( wp_unslash( $_POST['dalil_origin'] ) ) : '',
            '_dalil_destination' => isset( $_POST['dalil_destination'] ) ? sanitize_key( wp_unslash( $_POST['dalil_destination'] ) ) : '',
            '_dalil_transport'   => isset( $_POST['dalil_transport'] ) ? sanitize_key( wp_unslash( $_POST['dalil_transport'] ) ) : '',
            '_dalil_date'        => isset( $_POST['dalil_date'] ) ? sanitize_text_field( wp_unslash( $_POST['dalil_date'] ) ) : '',
            '_dalil_time'        => isset( $_POST['dalil_time'] ) ? sanitize_text_field( wp_unslash( $_POST['dalil_time'] ) ) : '',
            '_dalil_duration'    => isset( $_POST['dalil_duration'] ) ? sanitize_text_field( wp_unslash( $_POST['dalil_duration'] ) ) : '',
            '_dalil_price'       => isset( $_POST['dalil_price'] ) ? absint( $_POST['dalil_price'] ) : 0,
            '_dalil_capacity'    => isset( $_POST['dalil_capacity'] ) ? absint( $_POST['dalil_capacity'] ) : 0,
            '_dalil_available'   => isset( $_POST['dalil_available'] ) ? absint( $_POST['dalil_available'] ) : 0,
            '_dalil_active'      => isset( $_POST['dalil_active'] ) ? '1' : '0',
        );

        foreach ( $fields as $key => $value ) {
            update_post_meta( $post_id, $key, $value );
        }

        // If the title was not intentionally entered, build a useful title from the route.
        if ( empty( trim( $post->post_title ) ) || 'auto-draft' === $post->post_status ) {
            $cities = $this->cities();
            $transport = $this->transport_types();
            $o = isset( $cities[ $fields['_dalil_origin'] ] ) ? $cities[ $fields['_dalil_origin'] ] : '';
            $d = isset( $cities[ $fields['_dalil_destination'] ] ) ? $cities[ $fields['_dalil_destination'] ] : '';
            $t = isset( $transport[ $fields['_dalil_transport'] ] ) ? $transport[ $fields['_dalil_transport'] ] : '';
            if ( $o && $d ) {
                remove_action( 'save_post_' . $this->post_type, array( $this, 'save_trip' ), 10 );
                wp_update_post(
                    array(
                        'ID'         => $post_id,
                        'post_title' => $o . ' → ' . $d . ( $t ? ' | ' . $t : '' ),
                    )
                );
                add_action( 'save_post_' . $this->post_type, array( $this, 'save_trip' ), 10, 2 );
            }
        }
    }

    public function admin_assets( $hook ) {
        global $post_type;
        if ( false !== strpos( $hook, 'dalil-ticket-settings' ) ) {
            wp_enqueue_media();
            wp_enqueue_script( 'dalil-ticket-admin', DALIL_TICKET_URL . 'assets/js/admin.js', array( 'jquery' ), DALIL_TICKET_VERSION, true );
            wp_enqueue_style( 'dalil-ticket-admin', DALIL_TICKET_URL . 'assets/css/admin.css', array(), DALIL_TICKET_VERSION );
        }
        if ( 'post.php' === $hook || 'post-new.php' === $hook ) {
            if ( $this->post_type === $post_type ) {
                wp_enqueue_style(
                    'dalil-ticket-admin',
                    DALIL_TICKET_URL . 'assets/css/admin.css',
                    array(),
                    DALIL_TICKET_VERSION
                );
            }
        }
    }

    public function render_booking_meta_box( $post ) {
        $name = get_post_meta( $post->ID, '_dalil_booking_name', true );
        $phone = get_post_meta( $post->ID, '_dalil_booking_phone', true );
        $trip_id = absint( get_post_meta( $post->ID, '_dalil_booking_trip', true ) );
        $passengers = absint( get_post_meta( $post->ID, '_dalil_booking_passengers', true ) );
        echo '<p><strong>نام مسافر:</strong> ' . esc_html( $name ) . '</p>';
        echo '<p><strong>شماره تماس:</strong> ' . esc_html( $phone ) . '</p>';
        echo '<p><strong>سفر:</strong> ' . esc_html( $trip_id ? get_the_title( $trip_id ) : '' ) . '</p>';
        echo '<p><strong>تعداد مسافر:</strong> ' . esc_html( $passengers ) . '</p>';
        echo '<p><strong>شماره رزرو:</strong> ' . esc_html( $post->ID ) . '</p>';
    }

    public function admin_menu() {
        add_submenu_page(
            'edit.php?post_type=' . $this->post_type, 'تنظیمات بلیط', 'تنظیمات',
            'manage_options', 'dalil-ticket-settings', array( $this, 'settings_page' )
        );
    }

    public function register_settings() {
        register_setting( 'dalil_ticket_settings_group', 'dalil_ticket_banner_id', array( 'sanitize_callback' => 'absint' ) );
        register_setting( 'dalil_ticket_settings_group', 'dalil_ticket_map_id', array( 'sanitize_callback' => 'absint' ) );
        register_setting( 'dalil_ticket_settings_group', 'dalil_ticket_map_url', array( 'sanitize_callback' => 'esc_url_raw' ) );
    }

    public function settings_page() {
        $banner = absint( get_option( 'dalil_ticket_banner_id', 0 ) );
        $map = absint( get_option( 'dalil_ticket_map_id', 0 ) );
        $url = get_option( 'dalil_ticket_map_url', '' );
        ?>
        <div class="wrap" dir="rtl">
            <h1>تنظیمات بلیط</h1>
            <form method="post" action="options.php">
                <?php settings_fields( 'dalil_ticket_settings_group' ); ?>
                <table class="form-table">
                    <tr><th>تصویر بالای فرم</th><td>
                        <input type="hidden" id="dalil_ticket_banner_id" name="dalil_ticket_banner_id" value="<?php echo esc_attr( $banner ); ?>">
                        <div id="dalil-ticket-banner-preview"><?php if ( $banner ) echo wp_get_attachment_image( $banner, 'medium' ); ?></div>
                        <button type="button" class="button dalil-media-button" data-target="banner">انتخاب / آپلود تصویر</button>
                        <button type="button" class="button dalil-media-remove" data-target="banner">حذف</button>
                    </td></tr>
                    <tr><th>تصویر نقشه دفتر</th><td>
                        <input type="hidden" id="dalil_ticket_map_id" name="dalil_ticket_map_id" value="<?php echo esc_attr( $map ); ?>">
                        <div id="dalil-ticket-map-preview"><?php if ( $map ) echo wp_get_attachment_image( $map, 'medium' ); ?></div>
                        <button type="button" class="button dalil-media-button" data-target="map">انتخاب / آپلود نقشه</button>
                        <button type="button" class="button dalil-media-remove" data-target="map">حذف</button>
                    </td></tr>
                    <tr><th>لینک Google Maps</th><td>
                        <input type="url" class="regular-text" name="dalil_ticket_map_url" value="<?php echo esc_attr( $url ); ?>" placeholder="https://maps.google.com/...">
                    </td></tr>
                </table>
                <?php submit_button( 'ذخیره تنظیمات' ); ?>
            </form>
        </div>
        <?php
    }

    public function register_front_assets() {
        wp_register_style(
            'dalil-ticket-front',
            DALIL_TICKET_URL . 'assets/css/front.css',
            array(),
            DALIL_TICKET_VERSION
        );
        wp_register_script(
            'dalil-ticket-front',
            DALIL_TICKET_URL . 'assets/js/front.js',
            array( 'jquery' ),
            DALIL_TICKET_VERSION,
            true
        );
        wp_localize_script(
            'dalil-ticket-front',
            'DalilTicket',
            array(
                'ajaxUrl' => admin_url( 'admin-ajax.php' ),
                'nonce'   => wp_create_nonce( 'dalil_ticket_search' ),
                'error'   => 'حدث خطأ أثناء العملية. يرجى المحاولة مرة أخرى.',
                'banner'  => $this->get_banner_url(),
            )
        );
    }

    public function register_elementor_widget( $widgets_manager ) {
        if ( ! did_action( 'elementor/loaded' ) ) {
            return;
        }
        require_once DALIL_TICKET_DIR . 'includes/class-dalil-ticket-elementor-widget.php';
        $widgets_manager->register( new Dalil_Ticket_Elementor_Widget() );
    }

    public function ajax_search() {
        check_ajax_referer( 'dalil_ticket_search', 'nonce' );

        $origin      = isset( $_POST['origin'] ) ? sanitize_key( wp_unslash( $_POST['origin'] ) ) : '';
        $destination = isset( $_POST['destination'] ) ? sanitize_key( wp_unslash( $_POST['destination'] ) ) : '';
        $transport   = isset( $_POST['transport'] ) ? sanitize_key( wp_unslash( $_POST['transport'] ) ) : '';
        $date        = isset( $_POST['date'] ) ? sanitize_text_field( wp_unslash( $_POST['date'] ) ) : '';

        if ( ! $origin || ! $destination || $origin === $destination ) {
            wp_send_json_error( array( 'message' => 'مبدأ و مقصد را به‌درستی انتخاب کنید.' ), 400 );
        }

        $meta_query = array(
            'relation' => 'AND',
            array(
                'key'     => '_dalil_origin',
                'value'   => $origin,
                'compare' => '=',
            ),
            array(
                'key'     => '_dalil_destination',
                'value'   => $destination,
                'compare' => '=',
            ),
            array(
                'key'     => '_dalil_active',
                'value'   => '1',
                'compare' => '=',
            ),
        );

        if ( $transport ) {
            $meta_query[] = array(
                'key'     => '_dalil_transport',
                'value'   => $transport,
                'compare' => '=',
            );
        }

        if ( function_exists('dlz_current_city') ) {
            $city = dlz_current_city();
            $meta_query[] = array(
                'relation' => 'OR',
                array('key'=>'_dalil_origin','value'=>$city,'compare'=>'='),
                array('key'=>'_dalil_destination','value'=>$city,'compare'=>'='),
            );
        }

        if ( $date ) {
            $meta_query[] = array(
                'key'     => '_dalil_date',
                'value'   => $date,
                'compare' => '=',
            );
        }

        $query = new WP_Query(
            array(
                'post_type'      => $this->post_type,
                'post_status'    => 'publish',
                'posts_per_page' => 50,
                'meta_query'     => $meta_query,
                'meta_key'       => '_dalil_price',
                'orderby'        => 'meta_value_num',
                'order'          => 'ASC',
                'no_found_rows' => true,
            )
        );

        $results = array();
        foreach ( $query->posts as $trip ) {
            $results[] = $this->format_trip( $trip->ID );
        }

        wp_send_json_success( array( 'items' => $results ) );
    }

    private function format_trip( $post_id ) {
        $cities = $this->cities();
        $types  = $this->transport_types();

        $origin      = get_post_meta( $post_id, '_dalil_origin', true );
        $destination = get_post_meta( $post_id, '_dalil_destination', true );
        $transport   = get_post_meta( $post_id, '_dalil_transport', true );
        $price       = absint( get_post_meta( $post_id, '_dalil_price', true ) );
        $capacity    = absint( get_post_meta( $post_id, '_dalil_capacity', true ) );
        $time        = get_post_meta( $post_id, '_dalil_time', true );
        $duration    = get_post_meta( $post_id, '_dalil_duration', true );

        return array(
            'id'          => $post_id,
            'origin'      => isset( $cities[ $origin ] ) ? $cities[ $origin ] : $origin,
            'destination' => isset( $cities[ $destination ] ) ? $cities[ $destination ] : $destination,
            'transport'   => isset( $types[ $transport ] ) ? $types[ $transport ] : $transport,
            'icon'        => '',
            'price'       => class_exists( 'DLZ_Money' ) ? DLZ_Money::fmt( $price, 'IRT' ) : number_format_i18n( $price ) . ' تومان', // entered in toman, shown in the visitor's currency
            'time'        => $time,
            'duration'    => $duration,
            'capacity'    => $capacity,
            'available'   => get_post_meta( $post_id, '_dalil_available', true ) !== '' ? absint( get_post_meta( $post_id, '_dalil_available', true ) ) : $capacity,
        );
    }

    public function ajax_booking() {
        check_ajax_referer( 'dalil_ticket_search', 'nonce' );
        $trip_id = isset( $_POST['trip_id'] ) ? absint( $_POST['trip_id'] ) : 0;
        $name = isset( $_POST['name'] ) ? sanitize_text_field( wp_unslash( $_POST['name'] ) ) : '';
        $phone = isset( $_POST['phone'] ) ? sanitize_text_field( wp_unslash( $_POST['phone'] ) ) : '';
        $passengers = isset( $_POST['passengers'] ) ? max( 1, min( 10, absint( $_POST['passengers'] ) ) ) : 1;

        $name  = mb_substr( $name, 0, 80 );
        $phone = mb_substr( preg_replace( '/[^0-9+\-\s()]/u', '', strtr( $phone, array( '۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9','٠'=>'0','١'=>'1','٢'=>'2','٣'=>'3','٤'=>'4','٥'=>'5','٦'=>'6','٧'=>'7','٨'=>'8','٩'=>'9' ) ) ), 0, 30 );
        if ( $trip_id && ( get_post_type( $trip_id ) !== $this->post_type || 'publish' !== get_post_status( $trip_id ) ) ) {
            wp_send_json_error( array( 'message' => 'هذه الرحلة غير متاحة.' ), 404 );
        }
        if ( ! $trip_id || ! $name || strlen( preg_replace( '/\D/', '', $phone ) ) < 7 ) {
            wp_send_json_error( array( 'message' => 'يرجى إدخال الاسم ورقم الهاتف.' ), 400 );
        }

        $available = absint( get_post_meta( $trip_id, '_dalil_available', true ) );
        if ( ! $available ) {
            $available = absint( get_post_meta( $trip_id, '_dalil_capacity', true ) );
        }
        if ( $available < $passengers ) {
            wp_send_json_error( array( 'message' => 'عذراً، لا توجد سعة كافية لهذا السفر.' ), 400 );
        }

        $trip = $this->format_trip( $trip_id );
        $booking_id = wp_insert_post( array(
            'post_type' => 'dalil_ticket_booking',
            'post_status' => 'publish',
            'post_title' => 'حجز ' . $name . ' - ' . $trip['origin'] . ' إلى ' . $trip['destination'],
        ), true );

        if ( is_wp_error( $booking_id ) ) {
            wp_send_json_error( array( 'message' => 'تعذر تسجيل الحجز.' ), 500 );
        }

        update_post_meta( $booking_id, '_dalil_booking_name', $name );
        update_post_meta( $booking_id, '_dalil_booking_phone', $phone );
        update_post_meta( $booking_id, '_dalil_booking_trip', $trip_id );
        update_post_meta( $booking_id, '_dalil_booking_passengers', $passengers );
        update_post_meta( $booking_id, '_dalil_booking_status', 'در انتظار مراجعه' );
        update_post_meta( $trip_id, '_dalil_available', max( 0, $available - $passengers ) );

        $map_id = absint( get_option( 'dalil_ticket_map_id', 0 ) );
        wp_send_json_success( array(
            'booking_id' => $booking_id,
            'office_text' => 'يرجى الحضور إلى المكتب لاستلام التذكرة.',
            'map_image' => $map_id ? wp_get_attachment_image_url( $map_id, 'large' ) : '',
            'map_url' => get_option( 'dalil_ticket_map_url', '' ),
        ) );
    }

    public function get_banner_url() {
        $id = absint( get_option( 'dalil_ticket_banner_id', 0 ) );
        return $id ? wp_get_attachment_image_url( $id, 'large' ) : '';
    }


    public function cities() {
        return array(
            'mashhad' => 'مشهد',
            'qom'     => 'قم',
            'shiraz'  => 'شیراز',
            'tehran'  => 'تهران',
        );
    }

    public function transport_types() {
        return array(
            'air'   => 'هوایی',
            'bus'   => 'زمینی',
            'train' => 'قطار',
        );
    }
}
