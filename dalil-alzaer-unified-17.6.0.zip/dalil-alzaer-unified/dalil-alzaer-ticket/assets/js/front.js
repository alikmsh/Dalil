jQuery(function($){
function esc(v){return $('<div>').text(v==null?'':v).html();}
function resultHtml(i){var m=[];if(i.transport)m.push(i.transport);if(i.date)m.push('تاريخ السفر: '+i.date);if(i.time)m.push('الساعة: '+i.time);if(i.duration)m.push(i.duration);m.push('المقاعد المتاحة: '+i.available);
return '<div class="dalil-ticket-result"><div><div class="dalil-ticket-result-route">'+esc(i.origin)+' ← '+esc(i.destination)+'</div><div class="dalil-ticket-result-meta">'+m.join(' • ')+'</div></div><div class="dalil-ticket-result-price" dir="auto">'+esc(i.price)+'</div><div class="dalil-ticket-result-action"><button type="button" class="dalil-ticket-reserve" data-trip-id="'+esc(i.id)+'">حجز هذه الرحلة</button></div></div>';}
$('.dalil-ticket-widget').each(function(){
var w=$(this),f=w.find('.dalil-ticket-form'),r=w.find('.dalil-ticket-results'),msg=w.find('.dalil-ticket-message');
function closeModal(){w.find('.dalil-ticket-modal').remove();}
function openBooking(id){
var p=f.find('[name="passengers"]').val();
w.find('.dalil-ticket-modal').remove();
var modal=$('<div class="dalil-ticket-modal" role="dialog" aria-modal="true">'+
'<div class="dalil-ticket-modal-card"><button type="button" class="dalil-ticket-modal-close" aria-label="إغلاق">×</button>'+
'<h3 class="dalil-ticket-modal-title">حجز التذكرة</h3>'+
'<div class="dalil-ticket-booking-fields"><input name="booking_name" type="text" placeholder="الاسم الكامل" required><input name="booking_phone" type="tel" placeholder="رقم الهاتف" required></div>'+
'<div style="margin-top:10px"><div class="dalil-ticket-field" style="border:1px solid var(--dalil-border);border-radius:12px;padding:10px"><label>عدد المسافرين</label><select name="booking_passengers">'+
'<option value="1">1</option><option value="2">2</option><option value="3">3</option><option value="4">4</option><option value="5">5</option></select></div></div>'+
'<button type="button" class="dalil-ticket-book-submit" data-trip-id="'+esc(id)+'">تأكيد الحجز</button>'+
'<div class="dalil-ticket-book-message"></div></div></div>');
modal.find('[name="booking_passengers"]').val(p||'1');w.append(modal);modal.hide().fadeIn(160);
}
w.on('click','.dalil-ticket-type',function(){w.find('.dalil-ticket-type').removeClass('active');$(this).addClass('active');f.find('[name="transport"]').val($(this).data('transport')||'');});
w.on('click','.dalil-ticket-swap',function(){var o=f.find('[name="origin"]'),d=f.find('[name="destination"]'),v=o.val();o.val(d.val());d.val(v);});
w.on('click','.dalil-ticket-reserve',function(){openBooking($(this).data('trip-id'));});
w.on('click','.dalil-ticket-modal-close,.dalil-ticket-modal',function(e){if(e.target===this||$(e.target).hasClass('dalil-ticket-modal-close'))closeModal();});
w.on('click','.dalil-ticket-book-submit',function(){
var x=$(this),modal=w.find('.dalil-ticket-modal'),id=x.data('trip-id'),name=modal.find('[name="booking_name"]').val(),phone=modal.find('[name="booking_phone"]').val(),p=modal.find('[name="booking_passengers"]').val(),m=modal.find('.dalil-ticket-book-message');
if(!name||!phone){m.text('يرجى إدخال الاسم ورقم الهاتف.');return;}
x.prop('disabled',true).addClass('is-loading');
$.post(DalilTicket.ajaxUrl,{action:'dalil_ticket_booking',nonce:DalilTicket.nonce,trip_id:id,name:name,phone:phone,passengers:p}).done(function(res){
if(res.success){var h='<div class="dalil-ticket-confirmed"><strong>تم تسجيل طلب الحجز بنجاح</strong><p>'+esc(res.data.office_text)+'</p><p>رقم الحجز: '+esc(res.data.booking_id)+'</p>';if(res.data.map_image)h+='<img src="'+esc(res.data.map_image)+'" alt="موقع المكتب">';if(res.data.map_url)h+='<a class="dalil-ticket-map-link" href="'+esc(res.data.map_url)+'" target="_blank" rel="noopener">عرض موقع المكتب على خرائط Google</a>';h+='</div>';modal.find('.dalil-ticket-modal-card').html(h);r.find('.dalil-ticket-reserve[data-trip-id="'+id+'"]').closest('.dalil-ticket-result').remove();}}).fail(function(xhr){m.text(xhr.responseJSON&&xhr.responseJSON.data&&xhr.responseJSON.data.message?xhr.responseJSON.data.message:DalilTicket.error);x.prop('disabled',false).removeClass('is-loading');});
});
f.on('submit',function(e){e.preventDefault();var x=f.find('.dalil-ticket-submit'),d={action:'dalil_ticket_search',nonce:DalilTicket.nonce,origin:f.find('[name="origin"]').val(),destination:f.find('[name="destination"]').val(),transport:f.find('[name="transport"]').val(),date:f.find('[name="date"]').val()};r.empty();msg.text('');if(!d.origin||!d.destination||d.origin===d.destination){msg.text('يرجى اختيار مدينة الانطلاق والوصول بشكل صحيح.');return;}x.prop('disabled',true).addClass('is-loading');$.post(DalilTicket.ajaxUrl,d).done(function(res){if(res.success&&res.data.items.length)r.html(res.data.items.map(resultHtml).join(''));else r.html('<div class="dalil-ticket-empty">لا توجد رحلات متاحة لهذا الاختيار.</div>');}).fail(function(xhr){msg.text(xhr.responseJSON&&xhr.responseJSON.data&&xhr.responseJSON.data.message?xhr.responseJSON.data.message:DalilTicket.error);}).always(function(){x.prop('disabled',false).removeClass('is-loading');});});
});
});
