jQuery(function($){
$('.dalil-media-button').on('click',function(){
var t=$(this).data('target');
var frame=wp.media({title:t==='banner'?'انتخاب تصویر بالای فرم':'انتخاب تصویر نقشه دفتر',button:{text:'استفاده از تصویر'},multiple:false,library:{type:'image'}});
frame.on('select',function(){
var a=frame.state().get('selection').first().toJSON();
$('#dalil_ticket_'+t+'_id').val(a.id);
$('#dalil-ticket-'+t+'-preview').html('<img src="'+a.url+'" style="max-width:420px;height:auto;display:block;margin:0 0 10px">');
});
frame.open();
});
$('.dalil-media-remove').on('click',function(){var t=$(this).data('target');$('#dalil_ticket_'+t+'_id').val('');$('#dalil-ticket-'+t+'-preview').empty();});
});
