<?php
/**
 * Plugin Name: Dalil Al Zaer Unified Management System
 * Plugin URI: https://dalilalzaer.com/
 * Description: Unified management system for Dalil Al Zaer — App Shell (green / gold app header and bottom navigation, «المزيد», services launcher, live search) and «نفحات», an Instagram-style Explore with reels, likes and comments.
 * Version: 17.6.0
 * Author: Dalil Al Zaer
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * Text Domain: dalil-alzaer-unified
 */
if (!defined('ABSPATH')) { exit; }

if (!defined('DASE_VERSION')) define('DASE_VERSION','17.6.0');
define('DASE_URL', plugin_dir_url(__FILE__));
define('DASE_PATH', plugin_dir_path(__FILE__));
require_once DASE_PATH.'includes/class-dlz-qr.php';          // QR code for the two-step login set-up
require_once DASE_PATH.'includes/class-dlz-security.php';    // «امنیت سایت»: login limits, 2FA, headers, CORS/CSRF, leaked files, log
require_once DASE_PATH.'includes/class-dase-settings.php';
require_once DASE_PATH.'includes/class-dlz-app-shell.php';   // app header, bottom bar, «المزيد», search
require_once DASE_PATH.'includes/class-dlz-no-zoom.php';     // app-like pages: no pinch / double-tap zoom
require_once DASE_PATH.'includes/class-dlz-countries.php';   // the ten Arab countries: flags, pictures, dialling codes
require_once DASE_PATH.'includes/class-dlz-money.php';
require_once DASE_PATH.'includes/class-dlz-inbox.php';       // «درخواست‌های جدید»: every visitor request shows up for the admin       // prices in the visitor's currency (country of the profile)
require_once DASE_PATH.'includes/class-dlz-profile.php';     // «الملف الشخصي»
require_once DASE_PATH.'includes/class-dlz-socials.php';     // «تابعنا على» links
require_once DASE_PATH.'includes/class-dlz-admin-hub.php';   // every plugin menu as tiles on the WordPress Dashboard
require_once DASE_PATH.'includes/class-dlz-labels.php';      // page title = text of the home icon that opens it
require_once DASE_PATH.'includes/class-dlz-hide-hf.php';     // tick pages to hide the header / footer
require_once DASE_PATH.'includes/class-dlz-favorites.php';    // «المفضلة» page
require_once DASE_PATH.'includes/class-dlz-my.php';          // «حجوزاتي» + «طلباتي»
require_once DASE_PATH.'nafahat/nafahat.php'; // «نفحات» — Instagram-style Explore (merged IG Social Posts)
/* The App Shell boots after every plugin is loaded so it can detect the old standalone copy. */
add_action('plugins_loaded',array('DLZ_App_Shell','boot'),20);
/** app | hybrid | classic — decides which shell (app or the classic white/gold one) renders. */
function dlz_shell_mode(){ return class_exists('DLZ_App_Shell') ? DLZ_App_Shell::mode() : 'classic'; }

/** Does the current page hold one of these shortcodes / Elementor widgets? (decides which files load in <head>) */
function dlz_page_has($needles){
    static $hay=null;
    if($hay===null){
        $hay='';
        if(is_singular()){
            $p=get_queried_object();
            $hay=($p&&isset($p->post_content)?(string)$p->post_content:'').' '.(string)get_post_meta(get_queried_object_id(),'_elementor_data',true);
        } elseif(is_front_page()&&($fid=(int)get_option('page_on_front'))){
            $hay=(string)get_post_field('post_content',$fid).' '.(string)get_post_meta($fid,'_elementor_data',true);
        }
    }
    foreach((array)$needles as $n) if($n!==''&&false!==strpos($hay,$n)) return true;
    return false;
}

/* «نفحات» styles are only needed once its viewer opens from the app bar — don't let them block the first paint
   on pages that don't show the feed itself. */
add_filter('style_loader_tag',function($tag,$handle){
    if($handle!=='dlz-nafahat'||is_admin()||dlz_page_has(array('dlz_nafahat','ig_social_posts','ig_explore_grid','nafahat'))) return $tag;
    if(false===strpos($tag,"media='all'")&&false===strpos($tag,'media="all"')) return $tag;
    return str_replace(array("media='all'",'media="all"'),array("media='print' onload=\"this.media='all'\"",'media="print" onload="this.media=\'all\'"'),$tag).'<noscript>'.$tag.'</noscript>';
},10,2);

/* -------------------------------------------------------------
 * Every stylesheet / script of this plugin is versioned by its own file date,
 * so phones, Cloudflare and page caches fetch the new file the moment it changes
 * (some modules had a fixed «ver=2.0.0» and kept serving yesterday's file).
 * ----------------------------------------------------------- */
function dlz_bust_src($src){
    if(!$src) return $src;
    static $base=null,$bs=null; if($base===null){ $base=set_url_scheme(DASE_URL,'https'); $bs=strlen($base); }
    $u=set_url_scheme($src,'https');
    if(strncmp($u,$base,$bs)!==0) return $src;
    $rel=strtok(substr($u,$bs),'?#');
    $f=DASE_PATH.ltrim(rawurldecode($rel),'/');
    if(!is_file($f)) return $src;
    return add_query_arg('ver',DASE_VERSION.'.'.filemtime($f),remove_query_arg('ver',$src));
}
add_filter('style_loader_src','dlz_bust_src',20);
add_filter('script_loader_src','dlz_bust_src',20);

/* -------------------------------------------------------------
 * After an update: empty the page caches once, so no visitor keeps getting
 * yesterday's stylesheet / script with today's pages (the cause of giant icons).
 * ----------------------------------------------------------- */
function dlz_purge_caches(){
    try{
        do_action('litespeed_purge_all');                                          // LiteSpeed Cache
        if(function_exists('rocket_clean_domain')) rocket_clean_domain();           // WP Rocket
        if(function_exists('rocket_clean_minify')) rocket_clean_minify();
        if(function_exists('w3tc_flush_all')) w3tc_flush_all();                     // W3 Total Cache
        if(function_exists('wp_cache_clear_cache')) wp_cache_clear_cache();         // WP Super Cache
        do_action('wpfc_clear_all_cache',true);                                     // WP Fastest Cache
        if(isset($GLOBALS['wp_fastest_cache'])&&method_exists($GLOBALS['wp_fastest_cache'],'deleteCache')) $GLOBALS['wp_fastest_cache']->deleteCache(true);
        if(class_exists('autoptimizeCache')&&method_exists('autoptimizeCache','clearall')) autoptimizeCache::clearall(); // Autoptimize
        if(function_exists('sg_cachepress_purge_cache')) sg_cachepress_purge_cache(); // SiteGround
        do_action('cache_enabler_clear_complete_cache');                            // Cache Enabler
        do_action('breeze_clear_all_cache');                                        // Breeze
        do_action('wphb_clear_page_cache');                                         // Hummingbird
        do_action('swcfpc_purge_cache');                                            // Cloudflare (WP Cloudflare Super Page Cache)
        if(class_exists('\Elementor\Plugin')&&isset(\Elementor\Plugin::$instance->files_manager)) \Elementor\Plugin::$instance->files_manager->clear_cache();
    }catch(\Throwable $e){}
    wp_cache_flush();
}
/* 17.4.1 — the «الخدمات القانونية» widget already placed on the site (style «عکس کامل» saved in Elementor)
 * becomes the one-column list, once. Only the widget's look changes; titles, pictures and links stay. */
function dlz_migrate_widgets(){
    if(get_option('dlz_mig_leg_list')) return;
    update_option('dlz_mig_leg_list',1,false);
    global $wpdb;
    $ids=$wpdb->get_col("SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key='_elementor_data' AND meta_value LIKE '%dlz_sec_leg%'"); // phpcs:ignore
    $walk=function(&$els) use (&$walk){ $n=0; if(!is_array($els)) return 0;
        foreach($els as &$e){ if(!is_array($e)) continue;
            if(($e['widgetType']??'')==='dlz_sec_leg'){ if(!isset($e['settings'])||!is_array($e['settings'])) $e['settings']=array(); $e['settings']['style']='list'; unset($e['settings']['columns']); $n++; }
            if(!empty($e['elements'])) $n+=$walk($e['elements']);
        } unset($e); return $n; };
    foreach((array)$ids as $pid){
        $raw=get_post_meta((int)$pid,'_elementor_data',true);
        $tree=is_array($raw)?$raw:json_decode((string)$raw,true);
        if(!is_array($tree)) continue;
        if($walk($tree)){
            update_post_meta((int)$pid,'_elementor_data',wp_slash(wp_json_encode($tree)));
            delete_post_meta((int)$pid,'_elementor_css');
            delete_post_meta((int)$pid,'_elementor_element_cache');
            clean_post_cache((int)$pid);
        }
    }
}
add_action('admin_init',function(){
    if(get_option('dlz_last_ver')===DASE_VERSION) return;
    update_option('dlz_last_ver',DASE_VERSION);
    dlz_migrate_widgets();
    dlz_purge_caches();
},1);

/* -------------------------------------------------------------
 * Hardening
 * ----------------------------------------------------------- */
/** Flood guard for the public booking forms: N requests per visitor in a window. */
function dlz_flood_guard($action,$max=6,$window=600){
    // server-side size limit: no public form needs a field longer than 20 000 characters
    foreach($_POST as $v){ if(is_string($v)&&strlen($v)>20000){ if(class_exists('DLZ_Security'))DLZ_Security::log_once('big'.$action,600,'flood','درخواست بیش از حد بزرگ: '.$action,2); wp_send_json_error(array('message'=>'البيانات المرسلة طويلة جداً.'),413); } } // phpcs:ignore
    if(current_user_can('edit_posts')) return;
    $ip=class_exists('DLZ_Security')?DLZ_Security::ip():(isset($_SERVER['REMOTE_ADDR'])?preg_replace('/[^0-9a-f:.]/i','',(string)$_SERVER['REMOTE_ADDR']):'');
    $k='dlz_fg_'.md5($action.'|'.$ip.'|'.get_current_user_id());
    $n=(int)get_transient($k);
    if($n>=$max){ if(class_exists('DLZ_Security'))DLZ_Security::log_once('fg'.$action,$window,'flood',$action.' — بیش از '.$max.' درخواست',1); wp_send_json_error(array('message'=>'طلبات كثيرة خلال وقت قصير، يرجى المحاولة بعد قليل.'),429); }
    set_transient($k,$n+1,$window);
}
foreach(array('dlz_tour_booking'=>6,'dlz_ent_create_booking'=>6,'dalil_ticket_booking'=>6,'dalil_ticket_search'=>60,'dlz_sm_place_order'=>6,'mcr_submit'=>5,'lcr_submit'=>5,'dlz_support_send'=>40,'dlz_set_currency'=>30,'dlz_profile_save'=>20,'dlz_toggle_favorite'=>80,'dbd_detail'=>240,'dlz_shell_search'=>150,'dalil_article_view'=>60,'dnf_like'=>120,'dnf_comment'=>12) as $dlz_a=>$dlz_max){
    $dlz_cb=function() use($dlz_a,$dlz_max){dlz_flood_guard($dlz_a,$dlz_max);};
    add_action('wp_ajax_'.$dlz_a,$dlz_cb,0); add_action('wp_ajax_nopriv_'.$dlz_a,$dlz_cb,0);
}
unset($dlz_a,$dlz_max,$dlz_cb);
/* Basic browser security headers on the public site. */
add_action('send_headers',function(){
    if(is_admin()||headers_sent()) return;
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: SAMEORIGIN');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('Permissions-Policy: geolocation=(self), microphone=(self), camera=(self), payment=()');
});
/* Don't hand the user list (logins) to anonymous visitors. */
add_filter('rest_endpoints',function($e){
    if(is_user_logged_in()) return $e;
    foreach(array_keys($e) as $r) if(0===strpos($r,'/wp/v2/users')) unset($e[$r]);
    return $e;
});
add_action('template_redirect',function(){
    if(!is_user_logged_in()&&isset($_GET['author'])&&is_numeric($_GET['author'])){wp_safe_redirect(home_url('/'),301);exit;} // phpcs:ignore
},1);
remove_action('wp_head','wp_generator');

/**
 * Print a component stylesheet inline, once per page (scripts stay normal footer files:
 * some templates run the page through wptexturize, which would break inline JS).
 *
 * The widgets that live inside page content («حجوزاتي», «طلباتي», العملات, التاكسي…) carry their
 * own look with them, so it never depends on the theme, Elementor or a cache / optimisation plugin
 * loading (or dropping) an extra file — and it saves a request.
 */
function dlz_asset_text($file,$type){
    static $mem=array();
    $mt=@filemtime($file);
    $key='dlz_'.$type.'_'.md5($file.'|'.$mt.'|'.DASE_VERSION);
    if(isset($mem[$key])) return $mem[$key];
    $out=wp_cache_get($key,'dlz_assets');
    if(false===$out){
        $out=is_readable($file)?(string)file_get_contents($file):'';
        if('css'===$type){
            $out=str_replace('<','%3C',$out);
            $base=trailingslashit(dirname(plugins_url(basename($file),$file)));
            $out=preg_replace('#/\*.*?\*/#s','',$out);
            $out=preg_replace_callback('#url\(\s*([\'"]?)(?!data:|https?:|//|/|\#)([^\'")]+)\1\s*\)#i',function($m) use($base){ return 'url('.$m[1].$base.$m[2].$m[1].')'; },$out);
            $out=preg_replace('/\s+/',' ',$out);
            $out=preg_replace('/\s*([{};])\s*/','$1',$out);
            $out=str_ireplace('</style','<\/style',$out);
        } else {
            $out=str_ireplace('</script','<\/script',$out);
        }
        wp_cache_set($key,$out,'dlz_assets',DAY_IN_SECONDS);
    }
    return $mem[$key]=$out;
}
function dlz_inline_css($id,$file){
    static $done=array();
    if(isset($done[$id])) return '';
    $done[$id]=true;
    $css=dlz_asset_text($file,'css');
    return $css==='' ? '' : '<style id="'.esc_attr($id).'-css" data-no-optimize="1">'.$css.'</style>';
}

/* -------------------------------------------------------------
 * Core city helpers
 * ----------------------------------------------------------- */
function dlz_city_keys(){ return array('mashhad','qom','shiraz','tehran'); }
function dlz_city_labels(){
    $s = wp_parse_args(get_option('dase_settings',array()), dase_defaults());
    return array('mashhad'=>$s['city_mashhad'],'qom'=>$s['city_qom'],'shiraz'=>$s['city_shiraz'],'tehran'=>$s['city_tehran']);
}
function dlz_current_city(){
    $default='mashhad'; $settings=get_option('dase_settings',array());
    if(isset($settings['city_default']) && in_array($settings['city_default'],dlz_city_keys(),true)) $default=$settings['city_default'];
    $city=isset($_COOKIE['dase_city'])?sanitize_key(wp_unslash($_COOKIE['dase_city'])):$default;
    return in_array($city,dlz_city_keys(),true)?$city:$default;
}

function dase_defaults(){ return array(
 'header'=>1,'footer'=>1,'header_hide_pages'=>array(),'footer_hide_pages'=>array(),'logo'=>'',
 'home_text'=>'الرئيسية','home_url'=>'/','articles_text'=>'المقالات','articles_url'=>'',
 'cities_text'=>'المدن','cities_url'=>'','support_text'=>'التعليقات','support_url'=>'https://dalilalzaer.com/%d8%a7%d9%84%d8%aa%d8%b9%d9%84%db%8c%d9%82%d8%a7%d8%aa/',
 'profile_text'=>'الملف الشخصي','profile_url'=>'','cart_text'=>'السلة','cart_url'=>'',
 'orders_text'=>'طلباتي وحجوزاتي','orders_url'=>'','menu_title'=>'القائمة',
 'menu_1_text'=>'المقالات','menu_1_url'=>'','menu_2_text'=>'من نحن','menu_2_url'=>'#',
 'menu_3_text'=>'تواصل معنا','menu_3_url'=>'https://dalilalzaer.com/%d8%aa%d9%88%d8%a7%d8%b5%d9%84-%d9%85%d8%b9%d9%86%d8%a7/','city_default'=>'mashhad',
 'city_mashhad'=>'مشهد','city_mashhad_url'=>'#','city_qom'=>'قم','city_qom_url'=>'#',
 'city_shiraz'=>'شيراز','city_shiraz_url'=>'#','city_tehran'=>'طهران','city_tehran_url'=>'#'
); }

function dlz_unified_get_or_create_page($slug,$title,$shortcode=''){
    $page=get_page_by_path($slug);
    if(!$page) {
        $found=get_posts(array('post_type'=>'page','post_status'=>'any','title'=>$title,'numberposts'=>1,'orderby'=>'ID','order'=>'ASC','no_found_rows'=>true,'suppress_filters'=>true));
        $page=$found?$found[0]:null;
    }
    if(!$page){
        $id=wp_insert_post(array('post_title'=>$title,'post_name'=>$slug,'post_status'=>'publish','post_type'=>'page','post_content'=>$shortcode));
        if(is_wp_error($id) || !$id) return 0;
        return (int)$id;
    }
    if($shortcode && trim($page->post_content)==='') wp_update_post(array('ID'=>$page->ID,'post_content'=>$shortcode));
    return (int)$page->ID;
}

function dlz_unified_activate(){
    $s=wp_parse_args(get_option('dase_settings',array()),dase_defaults());
    $profile=dlz_unified_get_or_create_page('الملف-الشخصي','الملف الشخصي','[mp_user_panel]');
    $cart=dlz_unified_get_or_create_page('السلة','السلة','[dalil_sm_cart]');
    $orders=dlz_unified_get_or_create_page('طلباتي','طلباتي','[dlz_unified_orders]');
    $articles=dlz_unified_get_or_create_page('المقالات','المقالات','[dalil_articles]');
    $s['profile_url']=$profile?get_permalink($profile):home_url('/');
    $s['cart_url']=$cart?get_permalink($cart):home_url('/');
    $s['orders_url']=$orders?get_permalink($orders):home_url('/');
    $s['articles_url']=$articles?get_permalink($articles):home_url('/');
    $s['menu_1_url']=$s['articles_url'];
    update_option('dase_settings',$s);
    // Register important CPTs so fresh installs can flush safely.
    if(class_exists('DBD_Post_Type')) DBD_Post_Type::register();
    if(class_exists('DBD_Room')) DBD_Room::register();
    if(class_exists('DLZ_Entertainment_Post_Type')) DLZ_Entertainment_Post_Type::register_static();
    if(class_exists('LCR_DB')) LCR_DB::install();
    if(class_exists('MCR_DB')) MCR_DB::install();
    if(function_exists('dalil_alzaer_ticket')) { dalil_alzaer_ticket(); }
    if(class_exists('DLZ_SM')) DLZ_SM::activate();
    if(class_exists('DLZ_Taxi_Post_Types')) DLZ_Taxi_Post_Types::register_static();
    if(class_exists('DLZ_NF_CPT') && !defined('IGE_VERSION')) DLZ_NF_CPT::register();
    flush_rewrite_rules();
}
register_activation_hook(__FILE__,'dlz_unified_activate');
register_deactivation_hook(__FILE__,function(){ flush_rewrite_rules(); });

/* -------------------------------------------------------------
 * White / gold global shell
 * ----------------------------------------------------------- */
add_action('plugins_loaded',function(){
    if(!get_option('dase_settings')) update_option('dase_settings',dase_defaults());
},1);
add_action('wp_enqueue_scripts',function(){
    if(is_admin()) return;
    wp_enqueue_style('dase-style',DASE_URL.'assets/dase.css',array(),DASE_VERSION);
    wp_enqueue_script('dase-script',DASE_URL.'assets/dase.js',array(),DASE_VERSION,true);
    // The support chat (≈25 KB) loads on the first tap of «الدعم», not on every page view.
    wp_register_script('dlz-chat-boot',false,array(),DASE_VERSION,true);
    wp_enqueue_script('dlz-chat-boot');
    $dlz_logo=class_exists('DLZ_App_Shell')?DLZ_App_Shell::logo():'';
    $dlz_shell=class_exists('DLZ_App_Shell')?DLZ_App_Shell::get():array();
    $dlz_av=is_user_logged_in()?(string)get_user_meta(get_current_user_id(),'mp_avatar',true):'';
    wp_localize_script('dlz-chat-boot','DLZSupport',array(
        'ajax'=>admin_url('admin-ajax.php'),'nonce'=>is_user_logged_in()?wp_create_nonce('dlz_support_chat'):'','logged'=>is_user_logged_in(),'login'=>dlz_profile_url(),'poll'=>5000,'maxUpload'=>(int)wp_max_upload_size(),
        'css'=>DASE_URL.'assets/chat.css?ver='.DASE_VERSION,
        'brand'=>!empty($dlz_shell['name_ar'])?$dlz_shell['name_ar']:'دليل الزائر',
        'logo'=>$dlz_logo?'<img src="'.esc_url($dlz_logo).'" alt="">':(class_exists('DLZ_App_Shell')?DLZ_App_Shell::logo_svg():''),
        'whatsapp'=>!empty($dlz_shell['help_url'])&&false!==strpos($dlz_shell['help_url'],'wa.me')?esc_url_raw($dlz_shell['help_url']):'',
        'avatar'=>$dlz_av?esc_url_raw($dlz_av):'',
        'js'=>array(DASE_URL.'assets/voice-rec.js?ver='.DASE_VERSION,DASE_URL.'assets/chat.js?ver='.DASE_VERSION),
    ));
    wp_add_inline_script('dlz-chat-boot',dlz_chat_boot_js());
    // shell-fix.css restyles the classic header and the Elementor header; the app shell replaces both.
    if(dlz_shell_mode()==='app') wp_enqueue_style('dlz-modules-fix',DASE_URL.'assets/modules-fix.css',array('dase-style'),DASE_VERSION);
    else wp_enqueue_style('dlz-shell-fix',DASE_URL.'assets/shell-fix.css',array('dase-style'),DASE_VERSION);
});

/** Tiny loader: the first tap on a support button fetches voice-rec.js + chat.js, then opens the chat. */
function dlz_chat_boot_js(){
    return '(function(){var st=0,want=0;function done(){st=2;if(want&&window.DLZOpenChat)window.DLZOpenChat();}'
        .'function boot(){if(st)return;st=1;var js=(window.DLZSupport||{}).js||[],n=js.length;js.forEach(function(u){var s=document.createElement("script");s.src=u;s.async=false;s.onload=function(){if(--n===0)done();};s.onerror=function(){st=0;};document.body.appendChild(s);});}'
        .'function hit(e){return !window.DLZOpenChat&&e.target.closest&&e.target.closest(".dase-contact-btn,[data-dlz-chat]");}'
        .'document.addEventListener("pointerdown",function(e){if(hit(e))boot();},true);'
        .'document.addEventListener("click",function(e){if(!hit(e))return;e.preventDefault();e.stopPropagation();want=1;if(st===2)done();else boot();},true);})();';
}

function dase_svg($name){
    $i=array(
      'menu'=>'<svg viewBox="0 0 24 24"><path d="M4 7h16M4 12h16M4 17h16"/></svg>',
      'contact'=>'<svg viewBox="0 0 32 32" aria-hidden="true"><path d="M7 17v-3a9 9 0 0 1 18 0v3"/><rect x="4" y="16" width="7" height="9" rx="3"/><rect x="21" y="16" width="7" height="9" rx="3"/><path d="M25 25c0 2.2-1.8 4-4 4h-3"/><path d="M16 29h2"/></svg>',
      'home'=>'<svg viewBox="0 0 24 24"><path d="m3 10 9-7 9 7v10a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1Z"/></svg>',
      'cart'=>'<svg viewBox="0 0 24 24"><path d="M3 4h2l2 11h11l2-8H6"/><circle cx="9" cy="19" r="1.5"/><circle cx="17" cy="19" r="1.5"/></svg>',
      'orders'=>'<svg viewBox="0 0 24 24"><rect x="5" y="3" width="14" height="18" rx="2"/><path d="M8 8h8M8 12h8M8 16h5"/></svg>',
      'support'=>'<svg viewBox="0 0 24 24"><path d="M20 11.5a7.5 7.5 0 0 1-8 7.5 8.5 8.5 0 0 1-3-.6L4 20l1.6-3.8A7.4 7.4 0 0 1 4 11.5 7.5 7.5 0 0 1 12 4a7.5 7.5 0 0 1 8 7.5Z"/><path d="M8 10h8M8 14h5"/></svg>',
      'cities'=>'<svg viewBox="0 0 24 24"><path d="M12 21s7-6.1 7-12a7 7 0 1 0-14 0c0 5.9 7 12 7 12Z"/><circle cx="12" cy="9" r="2.3"/></svg>',
      'profile'=>'<svg viewBox="0 0 24 24"><circle cx="12" cy="8" r="3.5"/><path d="M5 20c.8-3.8 3.2-5.7 7-5.7s6.2 1.9 7 5.7"/></svg>',
      'comments'=>'<svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="6.5"/><path d="m16 16 4 4M8.5 11h5M11 8.5v5"/></svg>',
      'ticket'=>'<svg viewBox="0 0 24 24"><path d="M4 7a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v3a2 2 0 0 0 0 4v3a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2v-3a2 2 0 0 0 0-4Z"/><path d="M9 8v8" stroke-dasharray="2 2"/></svg>'
    ); return $i[$name]??'';
}
function dase_render_global(){
    static $done=false; if($done||is_admin()) return; $done=true;
    $s=dase_get_settings();
    $id=is_singular()?(int)get_queried_object_id():0;
    $hide_h=DLZ_Hide_HF::hidden('header'); $hide_f=DLZ_Hide_HF::hidden('footer');
    $classic=dlz_shell_mode()!=='app'; // in "app" mode the App Shell draws the header and the bottom bar
    if($classic&&$s['header']&&!$hide_h){
        $logo=$s['logo']?'<img src="'.esc_url($s['logo']).'" alt="'.esc_attr($s['logo_alt']!==''?$s['logo_alt']:get_bloginfo('name')).'">':'<span>'.esc_html(get_bloginfo('name')).'</span>';
        $labels=dlz_city_labels(); $cur=dlz_current_city(); $cur_label=$labels[$cur]??$cur;
        $city_options=''; foreach($labels as $key=>$label){ $city_options.='<button type="button" class="dase-city-option" data-city="'.esc_attr($key).'" aria-selected="'.($cur===$key?'true':'false').'"><span>'.esc_html($label).'</span><span class="dase-city-check">'.($cur===$key?'✓':'').'</span></button>'; }
        echo '<header class="dase-header" dir="rtl"><div class="dase-header-inner"><button class="dase-header-btn dase-menu-btn" type="button" aria-label="القائمة" aria-expanded="false">'.dase_svg('menu').'</button><a class="dase-logo" href="'.esc_url(home_url('/')).'">'.$logo.'</a><div class="dase-header-left"><button class="dase-city-trigger" type="button" aria-label="تغيير المدينة" aria-expanded="false"><span class="dase-city-pin">'.dase_svg('cities').'</span><span class="dase-city-label">'.esc_html($cur_label).'</span><span class="dase-city-chevron">⌄</span></button><button class="dase-header-btn dase-contact-btn" type="button" aria-label="'.esc_attr($s['support_label']).'" aria-expanded="false"><span class="dase-contact-icon">'.dase_svg('contact').'</span><span class="dase-contact-label">'.esc_html($s['support_label']).'</span></button></div></div></header>';
        echo '<div class="dase-city-panel" aria-hidden="true"><div class="dase-city-panel-inner" dir="rtl"><button class="dase-city-close" type="button" aria-label="إغلاق">×</button><h3>اختر المدينة</h3><p class="dase-city-sub">المدينة الحالية: <b>'.esc_html($cur_label).'</b></p><div class="dase-city-options">'.$city_options.'</div></div></div>';
        echo '<div class="dase-menu-overlay" aria-hidden="true"><div class="dase-side-menu" dir="rtl"><button class="dase-close-menu" type="button" aria-label="إغلاق">×</button><div class="dase-side-title">'.esc_html($s['menu_title']).'</div><a href="'.esc_url($s['home_url']).'">'.esc_html($s['home_text']).'</a><a href="'.esc_url($s['articles_url']).'">'.esc_html($s['articles_text']).'</a><a href="#" class="dase-info-open" data-info="faq">أسئلة شائعة</a><a href="#" class="dase-info-open" data-info="privacy">سياسة الخصوصية</a><a href="#" class="dase-info-open" data-info="about">من نحن</a><a href="https://dalilalzaer.com/%d8%aa%d9%88%d8%a7%d8%b5%d9%84-%d9%85%d8%b9%d9%86%d8%a7/" class="dase-contact-page-link">تواصل معنا</a></div></div>';
    }
    echo '<div class="dase-info-overlay" id="dase-info-faq" aria-hidden="true"><div class="dase-info-panel" dir="rtl"><button type="button" class="dase-info-close" aria-label="إغلاق">×</button><h2>أسئلة شائعة</h2><div class="dase-info-content">';
    $faq=array(
      'ما هو تطبيق «دلیل الزائر»؟'=>'هو منصة إلكترونية متكاملة تهدف إلى خدمة الزوار وتسهيل رحلتهم الدينية، من خلال توفير معلومات عن المزارات، أماكن الإقامة، خدمات النقل، المطاعم، والمراكز الطبية في المناطق المقدسة.',
      'هل التطبيق مجاني؟'=>'نعم، التطبيق متاح للجميع مجاناً. نحن نسعى لتقديم أفضل الخدمات للزوار الكرام دون مقابل مادي لاستخدام المنصة.',
      'كيف يمكنني تحميل التطبيق؟'=>'يمكنك تحميل التطبيق عبر dalilalzaer.com، كما تتوفر نسخة الويب (Web App) التي تعمل على جميع المتصفحات دون الحاجة للتحميل.',
      'كيف يمكنني حجز مكان للإقامة عبر التطبيق؟'=>'يمكنك تصفح قائمة الفنادق أو الحسينيات المسجلة، اختيار المكان المناسب، ثم الضغط على زر «حجز» أو التواصل مباشرة عبر أرقام الهاتف الموضحة في صفحة كل منشأة.',
      'هل يمكنني الوثوق بالخدمات والمطاعم المعروضة؟'=>'نحن نعتمد على نظام تقييمات من الزوار السابقين، بالإضافة إلى التحقق الدوري من المنشآت المسجلة لضمان تقديم أفضل جودة وخدمة للزوار.',
      'هل يوفر التطبيق خدمات النقل والمواصلات؟'=>'نعم، يوفر «دليل الزائر» قسماً خاصاً بوسائل النقل، حيث يمكنك العثور على أرقام السائقين الموثوقين، محطات الحافلات، وخدمات النقل بين المدن المقدسة.',
      'ضاعت مني حقيبة أو غرض شخصي، كيف يساعدني التطبيق؟'=>'يمكنك الدخول إلى قسم «المفقودات والمعلومات» في التطبيق، أو التواصل مع فريق الدعم الفني مباشرة عبر خدمة «مساعدة الزائر» لإبلاغنا بالتفاصيل، وسنحاول تعميم النداء في مراكزنا المنتشرة.',
      'هل يعمل التطبيق في حالة ضعف الإنترنت؟'=>'تم تصميم نسخة الويب لتكون خفيفة وسريعة التحميل. كما نعمل على توفير خرائط ومواقع يمكن الوصول إليها بشكل أسرع في حالات ضعف الشبكة.',
      'أرغب في إضافة فندقي/مطعمي إلى التطبيق، كيف ذلك؟'=>'يسعدنا انضمامكم إلينا! يمكنك الدخول إلى قسم «انضم كشريك» وملء النموذج الخاص، وسيقوم فريقنا بالتواصل معكم لتفعيل حسابكم وتوثيق المنشأة.',
      'كيف يمكنني التواصل مع فريق دعم «دليل الزائر»؟'=>'يمكنك التواصل معنا عبر «اتصل بنا» داخل التطبيق، أو عبر مراسلتنا على alz0945.asz@gmail.com. فريقنا جاهز لخدمتكم على مدار الساعة.'
    );
    foreach($faq as $q=>$a){ echo '<details class="dase-info-item"><summary>'.esc_html($q).'</summary><div>'.esc_html($a).'</div></details>'; }
    echo '</div></div></div>';
    echo '<div class="dase-info-overlay" id="dase-info-about" aria-hidden="true"><div class="dase-info-panel dase-about-panel" dir="rtl"><button type="button" class="dase-info-close" aria-label="إغلاق">×</button><h2>من نحن</h2><div class="dase-info-content">'
      .'<h3>عن «دليل الزائر»</h3>'
      .'<p>نحن في «دليل الزائر» ندرك أن رحلتكم ليست مجرد سفر، بل هي رحلة روحية هدفها السكينة. لذلك، صممنا هذه المنصة لتكون رفيقكم الرقمي الموثوق في كل خطوة.</p>'
      .'<h3>رسالتنا:</h3>'
      .'<p>تيسير سبل الزيارة وتذليل العقبات أمام زوار العتبات المقدسة، من خلال توفير معلومات دقيقة، خدمات سكنية، وتوجيهات عملية، مستندين إلى أحدث التقنيات الرقمية لنضمن لكم رحلة آمنة ومريحة.</p>'
      .'<h3>قيمنا:</h3>'
      .'<ul><li><strong>الخدمة:</strong> نسخر التكنولوجيا لخدمة الزائر.</li><li><strong>الأمان:</strong> شفافية تامة في التعامل مع كافة مقدمي الخدمات.</li><li><strong>التطوير المستمر:</strong> نعتبر كل ملاحظة منكم لبنة في صرح تطويرنا المستمر.</li></ul>'
      .'<p><strong>«دليل الزائر» – نرافقكم لتكون رحلتكم في أمان.</strong></p>'
      .'</div></div></div>';
    echo '<div class="dase-info-overlay" id="dase-info-privacy" aria-hidden="true"><div class="dase-info-panel dase-privacy-panel" dir="rtl"><button type="button" class="dase-info-close" aria-label="إغلاق">×</button><h2>سياسة الخصوصية</h2><div class="dase-info-content">'
      .'<p>نشكرك على ثقتك بمنصة "دليل الزائر".</p><p>نحن نولي أهمية قصوى لحماية خصوصيتك وتأمين معلوماتك الشخصية. يرجى قراءة هذه السياسة بعناية لفهم كيفية التعامل مع بياناتك.</p>'
      .'<h3>1. المعلومات التي نجمعها</h3><p>لتقديم تجربة مستخدم متميزة وخدمات مخصصة، نقوم بجمع البيانات التالية عند استخدامك للتطبيق:</p><ul><li>الاسم: لتخصيص تجربتك وللتواصل الفعّال معك.</li><li>رقم الجوال: لإرسال تنبيهات الحجوزات، وتحديثات الرحلات، والمعلومات الهامة.</li><li>البريد الإلكتروني: لتأكيد الحجوزات وإرسال الفواتير والمراسلات الرسمية.</li></ul>'
      .'<h3>2. كيف نستخدم معلوماتك</h3><p>نستخدم البيانات المجموعة للأغراض التالية:</p><ul><li>تحسين جودة الخدمات وتطوير ميزات التطبيق.</li><li>إرسال إشعارات وتنبيهات بخصوص حجوزاتك.</li><li>إرسال عروض خاصة وتحديثات تهمّك (بناءً على تفضيلاتك).</li></ul><p>نحن نتعهد بعدم بيع أو مشاركة بياناتك الشخصية مع أي طرف ثالث دون موافقتك الصريحة.</p>'
      .'<h3>3. أمن وحماية المعلومات</h3><p>نلتزم بتطبيق أعلى معايير الأمان لحماية بياناتك، بما في ذلك:</p><ul><li>استخدام تقنيات التشفير (Encryption) لتأمين نقل البيانات.</li><li>تخزين المعلومات في بيئات سحابية آمنة ومحمية.</li></ul>'
      .'<h3>4. ملفات تعريف الارتباط (Cookies)</h3><p>نستخدم ملفات تعريف الارتباط لتحسين أداء التطبيق وتذكر تفضيلاتك. يمكنك التحكم في إعدادات الكوكيز من خلال إعدادات متصفحك أو جهازك.</p>'
      .'<h3>5. التحديثات على السياسة</h3><p>نحتفظ بالحق في تحديث هذه السياسة لمواكبة التطورات التقنية أو القانونية. نوصي بمراجعة هذه الصفحة بصفة دورية.</p>'
      .'<h3>6. الموافقة</h3><p>باستمرارك في استخدام تطبيق "دليل الزائر"، فإنك تقر بموافقتك على ما ورد في سياسة الخصوصية هذه.</p>'
      .'<h3>هل لديك أي استفسار؟</h3><p>نحن هنا للمساعدة. يمكنك التواصل معنا مباشرة عبر البريد الإلكتروني:<br>alz0945.asz@gmail.com</p><p>دليل الزائر - رفيقك الموثوق في رحلاتك.</p>'
      .'</div></div></div>';
    echo '<div class="dase-info-overlay" id="dase-info-contact" aria-hidden="true"><div class="dase-info-panel dase-contact-panel" dir="rtl"><button type="button" class="dase-info-close dase-contact-close" aria-label="إغلاق">×</button><div class="dase-contact-hero"><h2>تواصل معنا</h2><p>نحن هنا لمساعدتك في رحلتك الإيمانية</p><div class="dase-contact-divider"><span></span><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 8.5 12 2l8 6.5V21H4Z"/><path d="M9 21v-6h6v6"/></svg><span></span></div></div><div class="dase-contact-section"><h3>إجراءات سريعة</h3><p class="dase-contact-sub">اختر الطريقة التي تناسبك للتواصل معنا</p><a class="dase-contact-card dase-contact-whatsapp" href="https://wa.me/9647822719796" target="_blank" rel="noopener"><span class="dase-contact-card-icon whatsapp-icon"><svg viewBox="0 0 32 32" aria-hidden="true"><path d="M16 4.5A11.5 11.5 0 0 0 6.2 22l-1.5 5.5 5.7-1.5A11.5 11.5 0 1 0 16 4.5Z"/><path d="M12.2 10.8c.4-.5.9-.5 1.3-.1l1.1 1.4c.3.4.3.8 0 1.2l-.7.8c.8 1.6 2.1 2.9 3.7 3.7l.8-.7c.4-.3.8-.3 1.2 0l1.4 1.1c.4.3.4.9-.1 1.3-.7.7-1.7 1-2.6.7-3.8-1.1-6.7-4-7.8-7.8-.3-.9 0-1.9.7-2.6Z"/></svg></span><span class="dase-contact-card-copy"><b>دعم واتساب</b><small>تواصل معنا عبر واتساب</small></span><strong>‹</strong></a><a class="dase-contact-card dase-contact-call" href="tel:09152082983"><span class="dase-contact-card-icon call-icon"><svg viewBox="0 0 32 32" aria-hidden="true"><path d="M9 5.5 13 4l3.2 7-3.1 2.1a16.5 16.5 0 0 0 5.8 5.8l2.1-3.1 7 3.2-1.5 4c-.5 1.4-2 2.1-3.4 1.7A19.8 19.8 0 0 1 7.3 8.9C6.9 7.5 7.6 6 9 5.5Z"/></svg></span><span class="dase-contact-card-copy"><b>اتصال فوري</b><small>تحدث معنا مباشرة</small></span><strong>‹</strong></a><div class="dase-contact-email-box"><div class="dase-contact-email-title"><span class="dase-contact-email-icon"><svg viewBox="0 0 32 32" aria-hidden="true"><rect x="4" y="7" width="24" height="18" rx="2"/><path d="m5 9 11 9L27 9"/></svg></span><span><b>راسلنا عبر البريد الإلكتروني</b><small>سنرد عليك في أقرب وقت ممكن</small></span></div><form class="dase-contact-email-form" action="mailto:alz0945.asz@gmail.com" method="post" enctype="text/plain"><label><svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="8" r="3.5"/><path d="M5 20c.6-3.3 2.9-5 7-5s6.4 1.7 7 5"/></svg><input type="text" name="name" placeholder="الاسم الكامل"></label><label><svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="m4 7 8 6 8-6"/></svg><input type="email" name="email" placeholder="البريد الإلكتروني"></label><label class="message-field"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 5h16v12H8l-4 4Z"/><path d="M8 9h8M8 13h5"/></svg><textarea name="message" placeholder="رسالتك"></textarea></label><button type="submit"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="m21 3-7.2 18-3.5-7.3L3 10.2Z"/><path d="M21 3 10.3 13.7"/></svg>إرسال الرسالة</button></form></div></div></div></div>';
    if($classic&&$s['footer']&&!$hide_f){
        $footer=array(
          array('home',$s['home_text'],$s['home_url']),
          array('cart',$s['cart_text'],$s['cart_url']),
          array('orders',$s['orders_text'],$s['orders_url'],'ticket'),
          array('comments','التعليقات','https://dalilalzaer.com/%d8%a7%d9%84%d8%aa%d8%b9%d9%84%db%8c%d9%82%d8%a7%d8%aa/','comments'),
          array('profile',$s['profile_text'],$s['profile_url'])
        );
        echo '<nav class="dase-bottom" dir="rtl">'; foreach($footer as $x){ $icon=!empty($x[3])?$x[3]:$x[0]; echo '<a href="'.esc_url($x[2]).'" data-item="'.esc_attr($x[0]).'"><span class="dase-bottom-icon">'.dase_svg($icon).'</span><span class="dase-bottom-label">'.esc_html($x[1]).'</span></a>'; } echo '</nav>';
    }
}
add_action('wp_body_open','dase_render_global',20);

/* -------------------------------------------------------------
 * Online support chat
 * ----------------------------------------------------------- */
function dlz_support_table(){ global $wpdb; return $wpdb->prefix.'dlz_support_messages'; }
function dlz_support_install(){
    if((int)get_option('dlz_support_db',0)>=2) return; // table is ready: no schema check on every page view (faster)
    global $wpdb; $table=dlz_support_table(); $charset=$wpdb->get_charset_collate();
    require_once ABSPATH.'wp-admin/includes/upgrade.php';
    $sql="CREATE TABLE {$table} (id bigint(20) unsigned NOT NULL AUTO_INCREMENT,user_id bigint(20) unsigned NOT NULL DEFAULT 0,is_admin tinyint(1) unsigned NOT NULL DEFAULT 0,message_type varchar(12) NOT NULL DEFAULT 'text',message_text longtext NULL,audio_url text NULL,image_url text NULL,created_at datetime NOT NULL,PRIMARY KEY (id),KEY user_id (user_id),KEY created_at (created_at)) {$charset};";
    dbDelta($sql);
    update_option('dlz_support_db',2);
}
add_action('plugins_loaded','dlz_support_install',6);
function dlz_support_user_info($uid){
    $u=get_userdata($uid); if(!$u)return array('name'=>'زائر','avatar'=>'');
    $name=trim($u->first_name.' '.$u->last_name); if(!$name)$name=$u->display_name?:$u->user_login;
    $avatar=(string)get_user_meta($uid,'mp_avatar',true); if(!$avatar)$avatar=get_avatar_url($uid,array('size'=>96));
    return array('name'=>$name,'avatar'=>$avatar);
}
function dlz_support_row($r){
    $info=$r->is_admin?array('name'=>'الدعم','avatar'=>''):dlz_support_user_info((int)$r->user_id);
    $ts=strtotime($r->created_at); return array('id'=>(int)$r->id,'is_admin'=>(bool)$r->is_admin,'type'=>$r->message_type,'text'=>(string)$r->message_text,'audio'=>(string)$r->audio_url,'image'=>(string)$r->image_url,'time'=>wp_date('H:i',$ts),'date'=>wp_date('Y/m/d',$ts),'name'=>$info['name'],'avatar'=>$info['avatar']);
}
function dlz_support_login_required(){ wp_send_json_error(array('code'=>'login_required','redirect'=>dlz_profile_url()),401); }
function dlz_support_load(){
    check_ajax_referer('dlz_support_chat','nonce'); if(!is_user_logged_in())dlz_support_login_required();
    global $wpdb; $rows=$wpdb->get_results($wpdb->prepare('SELECT * FROM '.dlz_support_table().' WHERE user_id=%d ORDER BY id ASC LIMIT 300',get_current_user_id()));
    wp_send_json_success(array('messages'=>array_map('dlz_support_row',$rows),'user'=>dlz_support_user_info(get_current_user_id())));
}
/**
 * Saves a recorded voice message. Browsers record WebM/Opus (Chrome, Android), MP4/AAC (Safari, iOS) or Ogg;
 * WordPress' own type check rejects most of them (it sees "video/webm"), so the file is identified by its
 * real header bytes instead and stored with the matching extension.
 * Returns the public URL, or a WP_Error.
 */
function dlz_support_store_audio($file){
    if(empty($file['tmp_name'])||!is_uploaded_file($file['tmp_name'])) return new WP_Error('audio','ارسال فایل صوتی انجام نشد.');
    if((int)$file['size']>14*1024*1024) return new WP_Error('audio','حجم فایل صوتی بیش از حد مجاز است.');
    if((int)$file['size']<200) return new WP_Error('audio','پیام صوتی خیلی کوتاه است.');
    $h=(string)file_get_contents($file['tmp_name'],false,null,0,64);
    $ext='';
    if(substr($h,0,4)==="\x1A\x45\xDF\xA3") $ext='webm';
    elseif(substr($h,0,4)==='OggS') $ext='ogg';
    elseif(substr($h,4,4)==='ftyp') $ext='m4a';
    elseif(substr($h,0,4)==='RIFF'&&substr($h,8,4)==='WAVE') $ext='wav';
    elseif(substr($h,0,3)==='ID3'||(strlen($h)>1&&ord($h[0])===0xFF&&(ord($h[1])&0xE0)===0xE0)) $ext=(ord($h[1])&0x06)===0?'aac':'mp3';
    if(!$ext) return new WP_Error('audio','نوع فایل صوتی پشتیبانی نمی‌شود.');
    $file['name']='voice-'.wp_generate_password(10,false).'-'.time().'.'.$ext;
    require_once ABSPATH.'wp-admin/includes/file.php';
    $mimes=array('webm'=>'audio/webm','ogg'=>'audio/ogg','m4a'=>'audio/mp4','wav'=>'audio/wav','mp3'=>'audio/mpeg','aac'=>'audio/aac');
    $up=wp_handle_upload($file,array('test_form'=>false,'test_type'=>false,'mimes'=>$mimes));
    if(isset($up['error'])) return new WP_Error('audio','ارسال فایل صوتی انجام نشد.');
    return esc_url_raw($up['url']);
}
function dlz_support_send(){
    check_ajax_referer('dlz_support_chat','nonce'); if(!is_user_logged_in())dlz_support_login_required();
    // flood guard: at most 20 messages a minute per account
    $rl='dlz_chat_rl_'.get_current_user_id(); $hits=(int)get_transient($rl);
    if($hits>=20) wp_send_json_error(array('message'=>'أرسلت رسائل كثيرة، انتظر دقيقة ثم حاول مرة أخرى.'),429);
    set_transient($rl,$hits+1,MINUTE_IN_SECONDS);
    global $wpdb; $text=isset($_POST['text'])?mb_substr(sanitize_textarea_field(wp_unslash($_POST['text'])),0,2000):''; $type='text'; $audio=''; $image='';
    require_once ABSPATH.'wp-admin/includes/file.php';
    if(!empty($_FILES['audio']['name'])){
        $audio=dlz_support_store_audio($_FILES['audio']);
        if(is_wp_error($audio))wp_send_json_error(array('message'=>$audio->get_error_message()),400);
        $type='audio';
    } elseif(!empty($_FILES['image']['name'])){
        if((int)$_FILES['image']['size']>12*1024*1024)wp_send_json_error(array('message'=>'حجم الصورة أكبر من 12 ميغابايت.'),413);
        $chk=wp_check_filetype_and_ext($_FILES['image']['tmp_name'],$_FILES['image']['name'],array('jpg'=>'image/jpeg','jpeg'=>'image/jpeg','png'=>'image/png','webp'=>'image/webp','gif'=>'image/gif'));
        if(empty($chk['type'])||!@getimagesize($_FILES['image']['tmp_name']))wp_send_json_error(array('message'=>'يرجى اختيار صورة صالحة.'),415);
        $upload=wp_handle_upload($_FILES['image'],array('test_form'=>false,'mimes'=>array('jpg'=>'image/jpeg','jpeg'=>'image/jpeg','png'=>'image/png','webp'=>'image/webp','gif'=>'image/gif')));
        if(isset($upload['error']))wp_send_json_error(array('message'=>'لم يتم إرسال الصورة.'));
        $image=esc_url_raw($upload['url']); $type='image';
    }
    if($type==='text'&&$text==='')wp_send_json_error(array('message'=>'اكتب رسالتك أولاً.'));
    $ok=$wpdb->insert(dlz_support_table(),array('user_id'=>get_current_user_id(),'is_admin'=>0,'message_type'=>$type,'message_text'=>$text,'audio_url'=>$audio,'image_url'=>$image,'created_at'=>current_time('mysql')),array('%d','%d','%s','%s','%s','%s','%s'));
    if($ok===false) wp_send_json_error(array('message'=>'لم يتم حفظ الرسالة، حاول مرة أخرى.'));
    if(class_exists('DLZ_Inbox')) DLZ_Inbox::add('chat',DLZ_Inbox::who()?:'زائر',$type==='text'?wp_html_excerpt($text,80,'…'):($type==='audio'?'پیام صوتی':'تصویر'),admin_url('admin.php?page=dlz-support-chat'),'chat-'.get_current_user_id());
    $row=$wpdb->get_row($wpdb->prepare('SELECT * FROM '.dlz_support_table().' WHERE id=%d',$wpdb->insert_id));
    if(!$row) wp_send_json_error(array('message'=>'پیام ذخیره نشد.'));
    wp_send_json_success(array('message'=>dlz_support_row($row)));
}
add_action('wp_ajax_dlz_support_load','dlz_support_load'); add_action('wp_ajax_nopriv_dlz_support_load','dlz_support_login_required');
add_action('wp_ajax_dlz_support_send','dlz_support_send'); add_action('wp_ajax_nopriv_dlz_support_send','dlz_support_login_required');
/** «ویس» for the admin reply box: record with the microphone and send to the selected user. */
function dlz_support_admin_voice_js(){
    ob_start(); ?>
<script src="<?php echo esc_url( DASE_URL.'assets/voice-rec.js?ver='.DASE_VERSION ); ?>"></script>
<style>
#dlz-support-admin-form{align-items:center;flex-wrap:wrap}
.dlz-admin-mic{width:46px;height:46px;flex:0 0 46px;border-radius:50%;border:1px solid #d7ad35;background:#fff;color:#0f4d2e;cursor:pointer;display:flex;align-items:center;justify-content:center;padding:0}
.dlz-admin-mic svg,.dlz-admin-recbar svg{width:21px;height:21px;fill:none;stroke:currentColor;stroke-width:1.9;stroke-linecap:round;stroke-linejoin:round}
.dlz-admin-recbar{display:none;flex:1 1 100%;align-items:center;gap:10px;padding:8px 10px;border-radius:12px;background:#fff6f4;border:1px solid #f2d3cd}
.dlz-admin-recbar.on{display:flex}
.dlz-admin-recbar i{width:10px;height:10px;border-radius:50%;background:#e0342b;animation:dlzRecDot 1s ease-in-out infinite}
@keyframes dlzRecDot{50%{opacity:.25}}
.dlz-admin-recbar b{color:#c0392b;font-variant-numeric:tabular-nums;min-width:46px}
.dlz-admin-recbar span{flex:1;color:#8a6d68}
.dlz-admin-recbar button{display:inline-flex;align-items:center;gap:6px;height:40px;padding:0 14px;border-radius:999px;cursor:pointer;font-weight:700}
.dlz-admin-recbar .rec-cancel{background:#fff;border:1px solid #f0cfc9;color:#c0392b}
.dlz-admin-recbar .rec-send{background:#0f4d2e;border:0;color:#fff;padding:0 18px}
.dlz-admin-msg audio{width:260px;max-width:100%}
</style>
<script>
(function(){
	var f=document.getElementById("dlz-support-admin-form"); if(!f||!window.DLZVoiceRec||!DLZVoiceRec.supported()) return;
	var c=window.DLZSupportAdmin||{}, send=f.querySelector("button[type=submit]");
	var mic=document.createElement("button"); mic.type="button"; mic.className="dlz-admin-mic"; mic.title="ضبط ویس";
	mic.innerHTML='<svg viewBox="0 0 24 24"><rect x="8" y="3" width="8" height="12" rx="4"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3M8.5 21h7"/></svg>';
	var bar=document.createElement("div"); bar.className="dlz-admin-recbar";
	bar.innerHTML='<i></i><b>00:00</b><span>در حال ضبط ویس…</span>'
		+'<button type="button" class="rec-cancel"><svg viewBox="0 0 24 24"><path d="M4.5 7h15M9.5 7V4.8h5V7M6.5 7l.9 12.2a1.6 1.6 0 0 0 1.6 1.5h6a1.6 1.6 0 0 0 1.6-1.5L17.5 7"/></svg>لغو</button>'
		+'<button type="button" class="rec-send"><svg viewBox="0 0 24 24"><path d="M20.5 3.6 9.8 14.3M20.5 3.6l-6.6 17-4.1-6.3-6.3-4.1z"/></svg>پایان و ارسال</button>';
	f.insertBefore(mic,send); f.appendChild(bar);
	var rec=null, t0=0, tm=null;
	function tick(){var s=Math.floor((Date.now()-t0)/1000);if(s>=DLZVoiceRec.maxSeconds(c.maxUpload)){finish(false);return;}bar.querySelector("b").textContent=String(Math.floor(s/60)).padStart(2,"0")+":"+String(s%60).padStart(2,"0");}
	function finish(cancel){if(!rec)return;var r=rec,uid=document.getElementById("dlz-support-admin-user").value;rec=null;clearInterval(tm);bar.classList.remove("on");mic.style.display="";if(cancel){r.cancel();return;}var blob=r.stop();if(blob&&uid)upload(blob,uid);}
	function upload(blob,uid){
		var d=new FormData();
		d.append("action","dlz_support_admin_send");d.append("nonce",c.nonce);d.append("user_id",uid);d.append("audio",blob,"voice.wav");
		mic.disabled=true;
		fetch(c.ajax,{method:"POST",body:d,credentials:"same-origin"}).then(function(r){return r.json();}).then(function(r){
			mic.disabled=false;
			if(r&&r.success){var b=document.querySelector(".dlz-admin-user.is-active");if(b)b.click();}
			else alert((r&&r.data&&r.data.message)||"ارسال ویس انجام نشد.");
		}).catch(function(){mic.disabled=false;alert("ارسال ویس انجام نشد.");});
	}
	mic.addEventListener("click",function(){
		if(!document.getElementById("dlz-support-admin-user").value){alert("ابتدا یک کاربر را انتخاب کنید.");return;}
		DLZVoiceRec.start().then(function(r){rec=r;t0=Date.now();tick();tm=setInterval(tick,500);bar.classList.add("on");mic.style.display="none";}).catch(function(){alert("دسترسی میکروفن داده نشد.");});
	});
	bar.querySelector(".rec-send").addEventListener("click",function(){finish(false);});
	bar.querySelector(".rec-cancel").addEventListener("click",function(){finish(true);});
	/* one voice at a time */
	document.addEventListener("play",function(e){if(e.target.tagName==="AUDIO")document.querySelectorAll("#dlz-support-admin-messages audio").forEach(function(a){if(a!==e.target)a.pause();});},true);
})();
</script>
<?php
    return ob_get_clean();
}
function dlz_support_admin_page(){
    if(!current_user_can('manage_options'))return; global $wpdb; $table=dlz_support_table();
    $users=$wpdb->get_results("SELECT user_id,MAX(id) last_id,MAX(created_at) last_time FROM {$table} WHERE is_admin=0 GROUP BY user_id ORDER BY last_id DESC");
    echo '<div class="wrap" dir="rtl"><h1>پشتیبانی آنلاین</h1><div id="dlz-support-admin" style="display:grid;grid-template-columns:280px 1fr;gap:16px;max-width:1100px"><div id="dlz-support-users" style="background:#fff;border:1px solid #ddd;border-radius:14px;padding:8px">';
    foreach($users as $u){$i=dlz_support_user_info((int)$u->user_id);echo '<button type="button" class="dlz-admin-user" data-user="'.(int)$u->user_id.'" style="display:flex;width:100%;gap:10px;align-items:center;text-align:right;background:#fff;border:0;border-bottom:1px solid #eee;padding:12px;cursor:pointer"><img src="'.esc_url($i['avatar']).'" style="width:42px;height:42px;border-radius:50%;object-fit:cover"><span><b>'.esc_html($i['name']).'</b><small style="display:block;color:#888">'.esc_html($u->last_time).'</small></span></button>';}
    if(!$users)echo '<div style="padding:20px;color:#777">هنوز پیامی دریافت نشده است.</div>';
    echo '</div><div style="background:#fff;border:1px solid #ddd;border-radius:14px;padding:14px"><div id="dlz-support-admin-head" style="font-weight:800;margin-bottom:10px">یک کاربر را انتخاب کنید</div><div id="dlz-support-admin-messages" style="min-height:380px;max-height:560px;overflow:auto;background:#f8f8f8;border-radius:12px;padding:12px"></div><form id="dlz-support-admin-form" style="display:flex;gap:8px;margin-top:10px"><input type="hidden" id="dlz-support-admin-user"><input type="text" id="dlz-support-admin-text" placeholder="پاسخ شما..." style="flex:1;padding:12px;border:1px solid #ddd;border-radius:10px"><button type="submit" style="padding:12px 18px;border:1px solid #d7ad35;border-radius:10px;background:#fff;cursor:pointer">إرسال</button></form></div></div></div>';
    echo '<script>window.DLZSupportAdmin='.wp_json_encode(array('ajax'=>admin_url('admin-ajax.php'),'nonce'=>wp_create_nonce('dlz_support_admin'),'maxUpload'=>(int)wp_max_upload_size())).';(function(){var c=window.DLZSupportAdmin||{},uid=0,box=document.getElementById("dlz-support-admin-messages"),head=document.getElementById("dlz-support-admin-head");function esc(v){var d=document.createElement("div");d.textContent=v==null?"":String(v);return d.innerHTML;}function load(id){uid=id;document.getElementById("dlz-support-admin-user").value=id;var d=new FormData();d.append("action","dlz_support_admin_load");d.append("nonce",c.nonce);d.append("user_id",id);fetch(c.ajax,{method:"POST",body:d,credentials:"same-origin"}).then(function(r){return r.json();}).then(function(r){if(!r.success)return;head.textContent=r.data.user.name;var h=(r.data.messages||[]).map(function(m){var x=m.type==="audio"?"<audio controls src=\""+esc(m.audio)+"\"></audio>":(m.type==="image"?"<img src=\""+esc(m.image)+"\" style=\"max-width:280px;max-height:300px;border-radius:12px;display:block;object-fit:cover\">":esc(m.text).replace(/\n/g,"<br>"));return "<div class=\"dlz-admin-msg "+(m.is_admin?"admin":"user")+"\"><b>"+esc(m.name)+"</b><div>"+x+"</div><small>"+esc(m.date)+" "+esc(m.time)+"</small></div>";}).join("");if(box.getAttribute("data-h")===id+"|"+h)return;box.setAttribute("data-h",id+"|"+h);box.innerHTML=h;box.scrollTop=box.scrollHeight;});}document.querySelectorAll(".dlz-admin-user").forEach(function(b){b.addEventListener("click",function(){document.querySelectorAll(".dlz-admin-user").forEach(function(x){x.classList.remove("is-active")});b.classList.add("is-active");load(b.dataset.user);});});document.getElementById("dlz-support-admin-form").addEventListener("submit",function(e){e.preventDefault();if(!uid)return;var t=document.getElementById("dlz-support-admin-text"),v=t.value.trim();if(!v)return;var d=new FormData();d.append("action","dlz_support_admin_send");d.append("nonce",c.nonce);d.append("user_id",uid);d.append("text",v);fetch(c.ajax,{method:"POST",body:d,credentials:"same-origin"}).then(function(r){return r.json();}).then(function(r){if(r.success){t.value="";load(uid);}});});setInterval(function(){if(uid)load(uid);},5000);})();</script>'.dlz_support_admin_voice_js().'<style>.dlz-admin-user.is-active{background:#fff8df!important}.dlz-admin-msg{padding:9px 12px;margin:7px 0;border-radius:12px;max-width:75%}.dlz-admin-msg.user{background:#fff;margin-left:auto}.dlz-admin-msg.admin{background:#102f4b;color:#fff;margin-right:auto}.dlz-admin-msg small{display:block;opacity:.65;margin-top:4px}.dlz-admin-msg audio{max-width:100%}</style>';
}
add_action('wp_ajax_dlz_support_admin_load',function(){check_ajax_referer('dlz_support_admin','nonce');if(!current_user_can('manage_options'))wp_send_json_error();global $wpdb;$uid=absint($_POST['user_id']??0);$rows=$wpdb->get_results($wpdb->prepare('SELECT * FROM '.dlz_support_table().' WHERE user_id=%d ORDER BY id ASC LIMIT 300',$uid));wp_send_json_success(array('messages'=>array_map('dlz_support_row',$rows),'user'=>dlz_support_user_info($uid)));});
add_action('wp_ajax_dlz_support_admin_send',function(){check_ajax_referer('dlz_support_admin','nonce');if(!current_user_can('manage_options'))wp_send_json_error();global $wpdb;$uid=absint($_POST['user_id']??0);$text=sanitize_textarea_field(wp_unslash($_POST['text']??''));$type='text';$audio='';if(!empty($_FILES['audio']['name'])){$audio=dlz_support_store_audio($_FILES['audio']);if(is_wp_error($audio))wp_send_json_error(array('message'=>$audio->get_error_message()));$type='audio';}if(!$uid||($type==='text'&&$text===''))wp_send_json_error(array('message'=>'پیام نامعتبر است.'));$wpdb->insert(dlz_support_table(),array('user_id'=>$uid,'is_admin'=>1,'message_type'=>$type,'message_text'=>$type==='audio'?'':$text,'audio_url'=>$audio,'image_url'=>'','created_at'=>current_time('mysql')),array('%d','%d','%s','%s','%s','%s','%s'));$row=$wpdb->get_row($wpdb->prepare('SELECT * FROM '.dlz_support_table().' WHERE id=%d',$wpdb->insert_id));wp_send_json_success(array('message'=>dlz_support_row($row)));});

/* -------------------------------------------------------------
 * Central admin hub
 * ----------------------------------------------------------- */
add_action('admin_menu',function(){
    add_menu_page('سیستم مدیریت یکپارچه دلیل الزائر','دلیل الزائر','manage_options','dlz-unified','dlz_unified_admin_home','dashicons-screenoptions',25);
    $items=array(
      array('مدیریت سوپرمارکت','dlz-sm','admin.php?page=dlz-sm'),
      array('بلیط‌های سفر','dalil-ticket','edit.php?post_type=dalil_ticket_trip'),
      array('تورهای روزانه','dlz-daily-tours','edit.php?post_type=dlz_daily_tour'),
      array('مراکز تفریحی','dlz-entertainment','edit.php?post_type=dlz_entertainment'),
      array('آگهی‌ها و کسب‌وکارها','edit.php?post_type=dbd_business','edit.php?post_type=dbd_business'),
      array('تاكسي VIP','dlz-taxi-panel','admin.php?page=dlz-taxi-panel'),
      array('پشتیبانی آنلاین','dlz-support-chat','admin.php?page=dlz-support-chat'),
      array('ورود پیامکی و کاربران','mp-sms-login','options-general.php?page=mp-sms-login'),
      array('نفحات (اکسپلور)','edit.php?post_type=ige_photo','edit.php?post_type=ige_photo'),
      array('هدر و نوار اپ','dlz-app-shell','admin.php?page=dlz-app-shell'),
      array('تنظیمات ظاهر سایت','dase-settings','admin.php?page=dase-settings')
    );
    foreach($items as $it){ if($it[1]==='dlz-support-chat') add_submenu_page('dlz-unified',$it[0],$it[0],'manage_options',$it[1],'dlz_support_admin_page'); elseif($it[1]==='dase-settings') add_submenu_page('dlz-unified',$it[0],$it[0],'manage_options',$it[1],'dase_settings_page'); elseif($it[1]==='dlz-app-shell') add_submenu_page('dlz-unified',$it[0],$it[0],'manage_options',$it[1],array('DLZ_App_Shell','admin_page')); else add_submenu_page('dlz-unified',$it[0],$it[0],'manage_options',$it[2]); }
});
function dlz_unified_admin_home(){
    $count=function($pt){ if(!post_type_exists($pt)) return null; $c=wp_count_posts($pt); return (int)($c->publish??0); };
    $cards=array(
      array('آگهی‌ها و کسب‌وکارها','dashicons-store','edit.php?post_type=dbd_business',$count('dbd_business'),'هتل‌ها، رستوران‌ها و سایر آگهی‌ها'),
      array('Room ها','dashicons-screenoptions','edit.php?post_type=dbd_room',$count('dbd_room'),'گروه‌بندی آگهی‌ها برای هر صفحه'),
      array('هدر و فوتر صفحات','dashicons-hidden','admin.php?page=dlz-hide-hf',null,'با تیک، هدر یا فوتر را در هر صفحه مخفی کنید'),
      array('ارز قیمت‌ها','dashicons-money-alt','admin.php?page=dlz-money',null,'قیمت‌ها به ارز کشور هر زائر؛ نرخ‌ها'),
      array('صفحه‌ی «متجري»','dashicons-products','post.php?post='.(int)get_option('dbd_owner_page').'&action=edit',null,'پنل صاحب مغازه: محصول، قیمت، توضیحات'),
      array('مغازه‌های در انتظار تأیید','dashicons-yes-alt','edit.php?post_status=pending&post_type=dbd_business',post_type_exists('dbd_business')?(int)(wp_count_posts('dbd_business')->pending??0):null,'ثبت‌شده با فرم «سجّل متجرك»'),
      array('تنظیمات نقشه','dashicons-location-alt','edit.php?post_type=dbd_business&page=dbd-map-settings',null,'نقشه‌ی عربی (کلید MapTiler)'),
      array('تورهای روزانه','dashicons-palmtree','edit.php?post_type=dlz_daily_tour',$count('dlz_daily_tour'),'تورها و رزروها'),
      array('مراکز تفریحی','dashicons-tickets-alt','edit.php?post_type=dlz_entertainment',$count('dlz_entertainment'),'تفریحات رایگان و پولی'),
      array('بلیط‌های سفر','dashicons-airplane','edit.php?post_type=dalil_ticket_trip',$count('dalil_ticket_trip'),'سفرها و رزرو بلیط'),
      array('تاکسی VIP','dashicons-car','admin.php?page=dlz-taxi-panel',$count('dlz_taxi_driver'),'رانندگان و رزروها'),
      array('سوپرمارکت','dashicons-cart','admin.php?page=dlz-sm',null,'محصولات و سفارش‌ها'),
      array('مقالات','dashicons-media-document','edit.php?post_type=dalil_article',$count('dalil_article'),'مقالات و راهنماها'),
      array('نفحات','dashicons-format-gallery','edit.php?post_type=ige_photo',$count('ige_photo'),'اکسپلور اینستاگرامی؛ عکس و ویدیو با لایک و نظر'),
      array('مشاوره پزشکی','dashicons-heart','admin.php?page=mcr-submissions',null,'درخواست‌های مشاوره'),
      array('مشاوره حقوقی','dashicons-businessperson','admin.php?page=lcr-submissions',null,'درخواست‌های مشاوره'),
      array('نرخ ارز','dashicons-money-alt','admin.php?page=dalil-currency-rates',null,'قیمت ارزها'),
      array('پشتیبانی آنلاین','dashicons-format-chat','admin.php?page=dlz-support-chat',null,'گفتگو با کاربران'),
      array('ورود پیامکی','dashicons-smartphone','options-general.php?page=mp-sms-login',null,'کاربران و تنظیمات پیامک'),
      array('هدر و نوار اپ','dashicons-smartphone','admin.php?page=dlz-app-shell',null,'هدر اپ، نوار پایین، خدمات و جستجوی زنده'),
      array('تنظیمات ظاهر سایت','dashicons-admin-appearance','admin.php?page=dase-settings',null,'لوگو، شهرها، هدر کلاسیک و صفحات مخفی'),
    );
    echo '<div class="wrap dlz-dash" dir="rtl"><style>
.dlz-dash h1{display:flex;align-items:center;gap:10px}.dlz-dash .dlz-ver{font-size:12px;background:#102f4b;color:#fff;border-radius:20px;padding:2px 10px}
.dlz-dash-sub{color:#646970;margin:4px 0 20px}
.dlz-dash-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(230px,1fr));gap:14px}
.dlz-dash-card{display:flex;gap:12px;align-items:flex-start;padding:16px;background:#fff;border:1px solid #e2e4e7;border-radius:14px;text-decoration:none;color:#1d2327;transition:.15s;box-shadow:0 1px 2px rgba(0,0,0,.04)}
.dlz-dash-card:hover{border-color:#d7ad35;box-shadow:0 6px 18px rgba(16,47,75,.10);transform:translateY(-1px);color:#1d2327}
.dlz-dash-ico{flex:0 0 44px;height:44px;border-radius:12px;background:#fffdf4;border:1px solid #d7ad35;display:flex;align-items:center;justify-content:center;color:#a67c14}
.dlz-dash-ico .dashicons{font-size:22px;width:22px;height:22px}
.dlz-dash-card b{display:block;font-size:14px;margin-bottom:3px}.dlz-dash-card small{color:#646970}
.dlz-dash-num{margin-right:auto;font-size:20px;font-weight:700;color:#102f4b}
</style>';
    echo '<h1>سیستم مدیریت یکپارچه دلیل الزائر <span class="dlz-ver">v'.esc_html(DASE_VERSION).'</span></h1>';
    echo '<p class="dlz-dash-sub">همه‌ی بخش‌های سایت از اینجا در دسترس است. بخش کاربری عربی و بخش مدیریت فارسی است.</p><div class="dlz-dash-grid">';
    foreach($cards as $c){
        echo '<a class="dlz-dash-card" href="'.esc_url(admin_url($c[2])).'"><span class="dlz-dash-ico"><span class="dashicons '.esc_attr($c[1]).'"></span></span><span><b>'.esc_html($c[0]).'</b><small>'.esc_html($c[4]).'</small></span>'.($c[3]!==null?'<span class="dlz-dash-num">'.number_format_i18n($c[3]).'</span>':'').'</a>';
    }
    echo '</div></div>';
}
/* One shared Elementor category for every Dalil Al Zaer widget. */
add_action('elementor/elements/categories_registered',function($m){ if(is_object($m)&&method_exists($m,'add_category')) $m->add_category('dalil-alzaer',array('title'=>'دلیل الزائر','icon'=>'eicon-star')); },5);

/* -------------------------------------------------------------
 * Profile completion gate: server-side protection for actions
 * ----------------------------------------------------------- */
function dlz_profile_is_complete($uid=0){ $uid=$uid?:get_current_user_id(); return $uid && is_user_logged_in() && (bool)get_user_meta($uid,'mp_profile_complete',true); }
/** Name + phone of the signed-in visitor (from «الملف الشخصي») to pre-fill booking forms. */
function dlz_me(){
    if(!is_user_logged_in()) return array('name'=>'','phone'=>'');
    $uid=get_current_user_id();
    $name=trim((string)get_user_meta($uid,'mp_full_name',true));
    if($name==='') $name=trim(get_user_meta($uid,'first_name',true).' '.get_user_meta($uid,'last_name',true));
    $phone=trim((string)get_user_meta($uid,'mp_sms_phone',true));
    if($phone==='') $phone=trim((string)get_user_meta($uid,'mp_intl_phone',true));
    return array('name'=>$name,'phone'=>$phone);
}
function dlz_profile_url(){ $s=wp_parse_args(get_option('dase_settings',array()),dase_defaults()); return !empty($s['profile_url'])?$s['profile_url']:home_url('/'); }
function dlz_require_profile_for_ajax(){
    if(!is_user_logged_in()) wp_send_json_error(array('message'=>'يرجى تسجيل الدخول أولاً.','code'=>'login_required'),401);
    if(!dlz_profile_is_complete()) wp_send_json_error(array('message'=>'يرجى إكمال ملفك الشخصي أولاً.','code'=>'profile_required','redirect'=>dlz_profile_url()),403);
}
foreach(array('dlz_sm_place_order','dalil_ticket_booking','dlz_tour_booking','dlz_ent_create_booking','lcr_submit','mcr_submit') as $act){
    add_action('wp_ajax_'.$act,'dlz_profile_gate',1);
}
/* Attach the real logged-in user to every booking so the unified orders page is not phone-only. */
add_action('save_post',function($post_id,$post,$update){
 if(wp_is_post_revision($post_id)||!$post)return;
 if(in_array($post->post_type,array('dalil_ticket_booking','dlz_tour_booking','dlz_ent_booking','dlz_taxi_booking'),true)&&is_user_logged_in()){
  if(!get_post_meta($post_id,'_dlz_user_id',true))update_post_meta($post_id,'_dlz_user_id',get_current_user_id());
 }
},20,3);
function dlz_profile_gate(){ dlz_require_profile_for_ajax(); }

/* Front-end click/form guard for modules that expose non-AJAX UI. */
add_action('wp_footer',function(){ if(is_admin())return; if(!is_user_logged_in())return; if(dlz_profile_is_complete())return; echo '<script>document.addEventListener("submit",function(e){var f=e.target;if(!f)return;var s=f.closest("form");if(!s)return;var txt=(s.innerText||"").toLowerCase();if(/طلب|حجز|شراء|استشارة|تأكيد|booking|order|checkout/.test(txt)){e.preventDefault();window.location.href='.wp_json_encode(dlz_profile_url()).';}},true);</script>'; },999);

/* -------------------------------------------------------------
 * Unified bookings / reservations + downloadable tickets
 * Includes: travel tickets, daily tours and paid entertainment.
 * Supermarket orders are intentionally excluded.
 * ----------------------------------------------------------- */
function dlz_booking_owner_ok($id,$post_type){
    if(!is_user_logged_in()) return false;
    $u=wp_get_current_user();
    $uid=(int)get_post_meta($id,'_dlz_user_id',true);
    if($uid && $uid===(int)$u->ID) return true;
    $phone='';
    if($post_type==='dalil_ticket_booking') $phone=(string)get_post_meta($id,'_dalil_booking_phone',true);
    elseif($post_type==='dlz_taxi_booking') $phone=(string)get_post_meta($id,'_dlz_customer_phone',true);
    else $phone=(string)get_post_meta($id,'_dlz_booking_phone',true);
    $myphone=(string)get_user_meta($u->ID,'mp_sms_phone',true);
    return $phone && $myphone && preg_replace('/\D+/','',$phone)===preg_replace('/\D+/','',$myphone);
}

add_action('admin_post_dlz_download_booking_ticket','dlz_download_booking_ticket');
function dlz_download_booking_ticket(){
    if(!is_user_logged_in()) wp_die('يرجى تسجيل الدخول أولاً.');
    $id=absint($_GET['booking_id']??0); $nonce=$_GET['_wpnonce']??'';
    if(!$id || !wp_verify_nonce($nonce,'dlz_download_booking_ticket_'.$id)) wp_die('رابط غير صالح.');
    $p=get_post($id);
    if(!$p || !in_array($p->post_type,array('dalil_ticket_booking','dlz_tour_booking','dlz_ent_booking','dlz_taxi_booking'),true)) wp_die('الحجز غير موجود.');
    if(!dlz_booking_owner_ok($id,$p->post_type)) wp_die('لا تملك صلاحية تحميل هذه التذكرة.');

    nocache_headers();
    header('Content-Type: text/html; charset=UTF-8');
    header('Content-Disposition: attachment; filename="dalil-ticket-'.$id.'.html"');
    $city_labels=dlz_city_labels();
    $html='<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>تذكرة دليل الزائر</title><style>body{font-family:Arial,sans-serif;background:#f7f4ec;margin:0;padding:24px;color:#102f4b}.ticket{max-width:760px;margin:auto;background:#fff;border:2px solid #d7ad35;border-radius:24px;padding:28px;box-shadow:0 10px 30px rgba(0,0,0,.08)}.brand{color:#b18417;font-weight:800;font-size:22px;margin-bottom:8px}.sub{color:#777;margin-bottom:20px}.grid{display:grid;grid-template-columns:1fr 1fr;gap:12px}.item{border:1px solid #eadfbe;border-radius:14px;padding:12px}.item b{display:block;color:#777;font-size:12px;margin-bottom:5px}.code{font-size:24px;font-weight:800;color:#b18417}.footer{margin-top:20px;padding-top:15px;border-top:1px dashed #d7ad35;text-align:center;color:#777}@media(max-width:600px){.grid{grid-template-columns:1fr}}</style></head><body><div class="ticket"><div class="brand">دليل الزائر</div>';
    $items=array(); $heading='تذكرة الحجز'; $code='';
    if($p->post_type==='dalil_ticket_booking'){
        $heading='تذكرة سفر'; $trip_id=absint(get_post_meta($id,'_dalil_booking_trip',true));
        $origin=$trip_id?get_post_meta($trip_id,'_dalil_origin',true):''; $destination=$trip_id?get_post_meta($trip_id,'_dalil_destination',true):'';
        $transport=$trip_id?get_post_meta($trip_id,'_dalil_transport',true):''; $time=$trip_id?get_post_meta($trip_id,'_dalil_time',true):'';
        $types=array('plane'=>'طائرة','bus'=>'حافلة','train'=>'قطار');
        $code=(string)$id; $items=array('المسافر'=>get_post_meta($id,'_dalil_booking_name',true),'من'=>$city_labels[$origin]??$origin,'إلى'=>$city_labels[$destination]??$destination,'وسيلة السفر'=>$types[$transport]??$transport,'موعد السفر'=>$time,'عدد المسافرين'=>absint(get_post_meta($id,'_dalil_booking_passengers',true)),'الحالة'=>get_post_meta($id,'_dalil_booking_status',true)?:'قيد المعالجة');
    } elseif($p->post_type==='dlz_tour_booking'){
        $heading='تذكرة جولة يومية'; $code=(string)get_post_meta($id,'_dlz_booking_code',true);
        $items=array('الجولة'=>get_post_meta($id,'_dlz_booking_tour_title',true),'الاسم'=>get_post_meta($id,'_dlz_booking_name',true),'الهاتف'=>get_post_meta($id,'_dlz_booking_phone',true),'اليوم'=>get_post_meta($id,'_dlz_booking_day',true),'عدد الأشخاص'=>get_post_meta($id,'_dlz_booking_people',true),'السعر الإجمالي'=>(class_exists('DLZ_Money')?DLZ_Money::fmt((float)get_post_meta($id,'_dlz_booking_total',true)):number_format_i18n((float)get_post_meta($id,'_dlz_booking_total',true)).' د.ع'),'المدينة'=>$city_labels[get_post_meta($id,'_dlz_booking_city',true)]??get_post_meta($id,'_dlz_booking_city',true),'المكان'=>get_post_meta($id,'_dlz_booking_location',true),'العنوان'=>get_post_meta($id,'_dlz_booking_address',true),'الحالة'=>'تم تسجيل الحجز');
    } elseif($p->post_type==='dlz_taxi_booking'){
        $heading='تذكرة حجز تاكسي VIP'; $code=(string)$id;
        $items=array('التاكسي'=>get_post_meta($id,'_dlz_taxi_title',true),'الخدمة'=>get_post_meta($id,'_dlz_service',true),'السعر'=>(class_exists('DLZ_Money')?DLZ_Money::text((string)get_post_meta($id,'_dlz_price',true)):get_post_meta($id,'_dlz_price',true)),'اسم العميل'=>get_post_meta($id,'_dlz_customer_name',true),'رقم الهاتف'=>get_post_meta($id,'_dlz_customer_phone',true),'الحالة'=>'تم تسجيل طلب الحجز');
    } else {
        $heading='تذكرة مركز ترفيهي'; $code=(string)$id;
        $men=(int)get_post_meta($id,'_dlz_booking_men',true); $women=(int)get_post_meta($id,'_dlz_booking_women',true);
        $items=array('المركز'=>get_post_meta($id,'_dlz_booking_entertainment',true),'الاسم'=>get_post_meta($id,'_dlz_booking_name',true),'الهاتف'=>get_post_meta($id,'_dlz_booking_phone',true),'التاريخ'=>get_post_meta($id,'_dlz_booking_date',true),'عدد الرجال'=>$men,'عدد النساء'=>$women,'المدينة'=>$city_labels[get_post_meta($id,'_dlz_booking_city',true)]??get_post_meta($id,'_dlz_booking_city',true),'الحالة'=>'تم تسجيل الحجز');
    }
    $html.='<h1>'.esc_html($heading).'</h1><p class="sub">رقم الحجز: <span class="code">'.esc_html($code?:$id).'</span></p><div class="grid">';
    foreach($items as $k=>$v) $html.='<div class="item"><b>'.esc_html($k).'</b>'.esc_html((string)$v).'</div>';
    $html.='</div><div class="footer">هذه التذكرة صادرة من نظام دليل الزائر</div></div></body></html>';
    echo $html; exit;
}

add_shortcode('dlz_unified_orders',function(){
    if(!is_user_logged_in()) return '<div class="dlz-unified-box" dir="rtl"><h2>طلباتي وحجوزاتي</h2><p>يرجى تسجيل الدخول أولاً.</p></div>';
    $u=wp_get_current_user(); $phone=(string)get_user_meta($u->ID,'mp_sms_phone',true); $rows=array();
    $types=array('dalil_ticket_booking','dlz_tour_booking','dlz_ent_booking','dlz_taxi_booking');
    foreach($types as $pt){
        $meta_user=array('key'=>'_dlz_user_id','value'=>$u->ID,'compare'=>'=');
        $meta_phone_key=$pt==='dalil_ticket_booking'?'_dalil_booking_phone':($pt==='dlz_taxi_booking'?'_dlz_customer_phone':'_dlz_booking_phone');
        $mq=array('relation'=>'OR',$meta_user);
        if($phone)$mq[]=array('key'=>$meta_phone_key,'value'=>$phone,'compare'=>'=');
        $q=new WP_Query(array('post_type'=>$pt,'post_status'=>array('publish','private'),'posts_per_page'=>50,'meta_query'=>$mq,'orderby'=>'date','order'=>'DESC','no_found_rows'=>true));
        foreach($q->posts as $p){
            $row=array('id'=>$p->ID,'type'=>$pt,'time'=>get_post_time('U',true,$p),'title'=>$p->post_title,'status'=>'قيد المعالجة','detail'=>'','code'=>'');
            if($pt==='dalil_ticket_booking'){
                $trip_id=absint(get_post_meta($p->ID,'_dalil_booking_trip',true));
                $origin=$trip_id?get_post_meta($trip_id,'_dalil_origin',true):''; $destination=$trip_id?get_post_meta($trip_id,'_dalil_destination',true):'';
                $row['label']='تذكرة سفر'; $row['detail']=$origin.' → '.$destination; $row['status']=get_post_meta($p->ID,'_dalil_booking_status',true)?:'قيد المعالجة';
            } elseif($pt==='dlz_tour_booking'){
                $row['label']='جولة يومية'; $row['detail']=get_post_meta($p->ID,'_dlz_booking_tour_title',true).' — '.get_post_meta($p->ID,'_dlz_booking_day',true); $row['status']='تم تسجيل الحجز'; $row['code']=get_post_meta($p->ID,'_dlz_booking_code',true);
            } elseif($pt==='dlz_taxi_booking'){
                $row['label']='تاكسي VIP'; $row['detail']=get_post_meta($p->ID,'_dlz_taxi_title',true).' — '.get_post_meta($p->ID,'_dlz_service',true); $row['status']='تم تسجيل طلب الحجز'; $row['code']=(string)$p->ID;
            } else {
                $row['label']='مركز ترفيهي'; $row['detail']=get_post_meta($p->ID,'_dlz_booking_entertainment',true).' — '.get_post_meta($p->ID,'_dlz_booking_date',true); $row['status']='تم تسجيل الحجز'; $row['code']=(string)$p->ID;
            }
            $rows[]=$row;
        }
    }
    usort($rows,function($a,$b){return $b['time']<=>$a['time'];});
    ob_start(); ?><div class="dlz-unified-orders" dir="rtl"><div class="dlz-orders-head"><h2>طلباتي وحجوزاتي</h2><p>تذاكر السفر والجولات اليومية وحجوزات المراكز الترفيهية وتاكسي VIP</p></div><?php if(!$rows): ?><div class="dlz-empty-orders">لا توجد حجوزات بعد.</div><?php else: foreach($rows as $r): $download=wp_nonce_url(admin_url('admin-post.php?action=dlz_download_booking_ticket&booking_id='.(int)$r['id']),'dlz_download_booking_ticket_'.$r['id']); ?><article class="dlz-order-card dlz-ticket-order"><div class="dlz-order-ticket-icon" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M4 7a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v3a2 2 0 0 0 0 4v3a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2v-3a2 2 0 0 0 0-4Z"/><path d="M9 8v8" stroke-dasharray="2 2"/></svg></div><div><strong><?php echo esc_html($r['label']); ?></strong><h3><?php echo esc_html($r['title']); ?></h3><small><?php echo esc_html($r['detail']); ?></small><?php if($r['code']): ?><small>رقم الحجز: <?php echo esc_html($r['code']); ?></small><?php endif; ?></div><span class="dlz-order-status"><?php echo esc_html($r['status']); ?></span><time><?php echo esc_html($r['time']?wp_date('Y/m/d H:i',$r['time']):''); ?></time><a class="dlz-ticket-download" href="<?php echo esc_url($download); ?>" download>تحميل التذكرة</a></article><?php endforeach; endif; ?></div><?php return ob_get_clean();
});

/* -------------------------------------------------------------
 * Unified favorites: business ads, tours and entertainment
 * ----------------------------------------------------------- */
function dlz_favorite_types(){ return array('dbd_business','dlz_daily_tour','dlz_entertainment'); }
function dlz_favorites_get($uid=0){
    $uid=$uid?:get_current_user_id(); if(!$uid)return array();
    $raw=get_user_meta($uid,'dlz_favorites_v2',true); if(!is_array($raw))$raw=array();
    $out=array(); foreach($raw as $item){
        if(!is_array($item)||!in_array($item['type']??'',dlz_favorite_types(),true)||empty($item['id']))continue;
        $clean=['type'=>sanitize_key($item['type']),'id'=>absint($item['id'])];
        if(!empty($item['snapshot']) && is_array($item['snapshot'])){
            $sn=$item['snapshot'];
            $clean['snapshot']=[
                'title'=>sanitize_text_field($sn['title']??''),
                'description'=>sanitize_textarea_field($sn['description']??''),
                'image'=>esc_url_raw($sn['image']??''),
                'phone'=>sanitize_text_field($sn['phone']??''),
                'whatsapp'=>sanitize_text_field($sn['whatsapp']??''),
                'map'=>esc_url_raw($sn['map']??''),
                'type_label'=>sanitize_text_field($sn['type_label']??''),
            ];
        }
        $out[]=$clean;
    }
    return $out;
}
function dlz_favorite_snapshot($type,$id){
    $title=get_the_title($id); $image=get_the_post_thumbnail_url($id,'large'); $description=wp_strip_all_tags(get_post_field('post_excerpt',$id));
    if(!$description)$description=wp_strip_all_tags(get_post_field('post_content',$id));
    $snap=['title'=>$title,'description'=>wp_trim_words($description,60,''),'image'=>$image,'phone'=>'','whatsapp'=>'','map'=>'','type_label'=>$type==='dbd_business'?'إعلان':($type==='dlz_daily_tour'?'جولة يومية':'مركز ترفيهي')];
    if($type==='dbd_business' && class_exists('DBD_Meta')){
        $profile=DBD_Meta::get($id,'profile_image'); $snap['image']=$profile?:$snap['image'];
        $snap['description']=wp_trim_words(wp_strip_all_tags((string)DBD_Meta::get($id,'slogan')) ?: $snap['description'],60,'');
        $snap['phone']=DBD_Meta::get($id,'phone'); $snap['whatsapp']=DBD_Meta::get($id,'whatsapp'); $snap['map']=DBD_Meta::get($id,'map_url');
    }
    return $snap;
}
function dlz_favorite_has($type,$id,$uid=0){ foreach(dlz_favorites_get($uid) as $x)if($x['type']===$type&&$x['id']===(int)$id)return true; return false; }
add_action('wp_ajax_dlz_toggle_favorite','dlz_toggle_favorite');
function dlz_toggle_favorite(){
    check_ajax_referer('dlz_favorite','nonce'); dlz_require_profile_for_ajax();
    $type=sanitize_key($_POST['favorite_type']??'dbd_business');
    $f=dlz_favorites_get(); $found=null;
    $id=absint($_POST['favorite_id']??($_POST['business_id']??0));
    $source_url=esc_url_raw(wp_unslash($_POST['favorite_url']??''));
    if(!$id||!in_array($type,dlz_favorite_types(),true)||get_post_type($id)!==$type||get_post_status($id)!=='publish')wp_send_json_error(['message'=>'العنصر غير موجود.'],404);
    foreach($f as $i=>$x)if(($x['type']??'')===$type&&($x['id']??0)===$id){$found=$i;break;}
    if($found!==null){array_splice($f,$found,1);$on=false;}else{$item=['type'=>$type,'id'=>$id,'snapshot'=>dlz_favorite_snapshot($type,$id)]; $f[]=$item;$on=true;}
    update_user_meta(get_current_user_id(),'dlz_favorites_v2',$f);
    wp_send_json_success(['favorite'=>$on,'count'=>count($f),'message'=>$on?'تمت الإضافة إلى المفضلة':'تمت الإزالة من المفضلة']);
}
/** One standard heart for every favourite button (outline = not saved, filled red = saved; CSS in unified.css). */
function dlz_heart_svg(){ return '<svg class="dlz-hrt" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M12 20.6l-1.3-1.2C5.9 15.1 3 12.4 3 8.9 3 6.1 5.2 4 7.9 4c1.6 0 3.1.7 4.1 1.9C13 4.7 14.5 4 16.1 4 18.8 4 21 6.1 21 8.9c0 3.5-2.9 6.2-7.7 10.5L12 20.6z"/></svg>'; }
function dlz_favorite_button($type,$id){
    if(!in_array($type,dlz_favorite_types(),true))return '';
    $on=is_user_logged_in()&&dlz_favorite_has($type,$id); return '<button type="button" class="dlz-unified-favorite '.($on?'is-favorite':''). '" data-favorite-type="'.esc_attr($type).'" data-favorite-id="'.(int)$id.'" aria-label="المفضلة" aria-pressed="'.($on?'true':'false').'"><span>'.dlz_heart_svg().'</span><b>المفضلة</b></button>';
}
function dlz_business_directory_url(){
    static $url=null; if($url!==null)return $url;
    $url=home_url('/');
    $pages=get_posts(['post_type'=>'page','post_status'=>'publish','posts_per_page'=>100,'fields'=>'ids']);
    foreach($pages as $pid){$content=(string)get_post_field('post_content',$pid);if(stripos($content,'[dalil_businesses')!==false){$u=get_permalink($pid);if($u){$url=$u;break;}}}
    return $url;
}
add_shortcode('dlz_favorites',function(){ return DLZ_Favorites_Page::render(); }); // 17.4: compact cards (includes/class-dlz-favorites.php)

/* Favorite buttons for existing cards, without changing Elementor widget settings. */
add_action('wp_enqueue_scripts',function(){
    if(is_admin())return;
    wp_register_style('dlz-unified-extra',DASE_URL.'assets/unified.css',array(),DASE_VERSION);wp_enqueue_style('dlz-unified-extra');
    wp_register_script('dlz-unified-extra',DASE_URL.'assets/unified.js',array(),DASE_VERSION,true);wp_enqueue_script('dlz-unified-extra');
    wp_localize_script('dlz-unified-extra','DLZUnified',array('ajax'=>admin_url('admin-ajax.php'),'nonce'=>wp_create_nonce('dlz_favorite'),'profile'=>dlz_profile_url(),'logged'=>is_user_logged_in(),'complete'=>dlz_profile_is_complete(),'favorites'=>dlz_favorites_get()));
});
add_action('wp_footer',function(){if(!is_admin())echo '<script>window.DLZFavoriteIds='.wp_json_encode(dlz_favorites_get()).';</script>';},998);

/* City selection is global: save once in profile and every city-aware module reads dase_city. */
add_action('wp_footer',function(){if(is_admin())return; echo '<script>(function(){document.addEventListener("click",function(e){var b=e.target.closest(".dlz-profile-cities [data-city]");if(!b)return;var c=b.getAttribute("data-city");if(!c)return;document.cookie="dase_city="+encodeURIComponent(c)+";path=/;max-age="+(60*60*24*365);var u=new URL(window.location.href);u.searchParams.delete("dlz_city");window.location.href=u.toString();});})();</script>';},1000);
/* Make the saved profile identity follow every WordPress comment/review avatar lookup. */
add_filter('get_avatar_url',function($url,$id_or_email,$args){
 $uid=0;
 if(is_numeric($id_or_email))$uid=(int)$id_or_email;
 elseif($id_or_email instanceof WP_Comment)$uid=(int)$id_or_email->user_id;
 elseif($id_or_email instanceof WP_User)$uid=(int)$id_or_email->ID;
 elseif(is_string($id_or_email)&&is_email($id_or_email)){ $u=get_user_by('email',$id_or_email);$uid=$u?(int)$u->ID:0; }
 if($uid){$avatar=get_user_meta($uid,'mp_avatar',true);if($avatar)return esc_url_raw($avatar);}
 return $url;
},20,3);
add_filter('get_avatar_data',function($args,$id_or_email){
 $uid=0;
 if(is_numeric($id_or_email))$uid=(int)$id_or_email;
 elseif($id_or_email instanceof WP_Comment)$uid=(int)$id_or_email->user_id;
 elseif($id_or_email instanceof WP_User)$uid=(int)$id_or_email->ID;
 elseif(is_string($id_or_email)&&is_email($id_or_email)){ $u=get_user_by('email',$id_or_email);$uid=$u?(int)$u->ID:0; }
 if($uid){$avatar=get_user_meta($uid,'mp_avatar',true);if($avatar){$args['url']=esc_url_raw($avatar);$args['found_avatar']=true;}}
 return $args;
},20,2);
add_action('wp_head',function(){if(!is_admin())echo '<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">';},0);

/* -------------------------------------------------------------
 * Load the original functional modules INSIDE this single plugin.
 * Their files live below this plugin folder, so WordPress does not
 * see them as separate installed plugins.
 * ----------------------------------------------------------- */
function dlz_unified_load_modules(){
    $base=DASE_PATH;
    $files=array(
      'melipayamak-sms-login-v1.1/melipayamak-sms-login.php',
      'dalil-articles/dalil-articles.php',
      'dalil-currency-rates/dalil-currency-rates.php',
      'dalil-supermarket/dalil-supermarket.php',
      'dalil-alzaer-ticket/dalil-alzaer-ticket.php',
      'dalil-alzaer-daily-tours/dalil-alzaer-daily-tours.php',
      'dalil-alzaer-entertainment/dalil-alzaer-entertainment.php',
      'dalil-business-directory/dalil-business-directory.php',
      'legal-consultation-requests/legal-consultation-requests.php',
      'medical-consultation-requests/medical-consultation-requests.php',
      'dlz-taxi-vip/dalil-alzaer-taxi.php'
    );
    foreach($files as $f){
      $skip = false;
      if (strpos($f,'melipayamak') !== false && class_exists('MP_SMS_User_Panel', false)) $skip = true;
      if (strpos($f,'dalil-articles') !== false && defined('DALIL_ARTICLES_VERSION')) $skip = true;
      if (strpos($f,'dalil-currency-rates') !== false && defined('DALIL_CR_VERSION')) $skip = true;
      if (strpos($f,'dalil-supermarket') !== false && defined('DLZ_SM_VERSION')) $skip = true;
      if (strpos($f,'dalil-alzaer-ticket') !== false && defined('DALIL_TICKET_VERSION')) $skip = true;
      if (strpos($f,'daily-tours') !== false && defined('DLZ_TOUR_VER')) $skip = true;
      if (strpos($f,'entertainment') !== false && defined('DLZ_ENT_VERSION')) $skip = true;
      if (strpos($f,'business-directory') !== false && defined('DBD_VERSION')) $skip = true;
      if (strpos($f,'legal-consultation') !== false && defined('LCR_VERSION')) $skip = true;
      if (strpos($f,'medical-consultation') !== false && defined('MCR_VERSION')) $skip = true;
      if (strpos($f,'dlz-taxi-vip') !== false && defined('DLZ_TAXI_VERSION')) $skip = true;
      $p=$base.$f;
      if($skip) $GLOBALS['dlz_skipped_modules'][]=$f;
      elseif(file_exists($p)) require_once $p;
    }
}
dlz_unified_load_modules();
/* An old standalone copy that is still active wins over the built-in (newer) module — say so loudly. */
add_action('admin_notices',function(){
    if(empty($GLOBALS['dlz_skipped_modules']) || !current_user_can('activate_plugins')) return;
    $names=array(
      'melipayamak'=>'ورود با پیامک (ملی‌پیامک)','dalil-articles'=>'مقالات','dalil-currency-rates'=>'نرخ ارز / تبادل','dalil-supermarket'=>'سوپرمارکت',
      'dalil-alzaer-ticket'=>'بلیط','daily-tours'=>'تورهای روزانه','entertainment'=>'مراکز تفریحی','business-directory'=>'راهنمای کسب‌وکارها',
      'legal-consultation'=>'مشاوره حقوقی','medical-consultation'=>'مشاوره پزشکی','dlz-taxi-vip'=>'تاکسی VIP'
    );
    $list=array();
    foreach($GLOBALS['dlz_skipped_modules'] as $f){ foreach($names as $k=>$n){ if(false!==strpos($f,$k)){ $list[]=$n; break; } } }
    if(!$list) return;
    echo '<div class="notice notice-warning"><p><strong>دلیل الزائر یکپارچه:</strong> نسخه‌ی قدیمیِ جداگانه‌ی این بخش‌ها هنوز در «افزونه‌ها» فعال است، برای همین طراحی و امکانات جدیدشان اجرا نمی‌شود: <b>'.esc_html(implode('، ',$list)).'</b>. لطفاً آن افزونه‌های جداگانه را غیرفعال کنید (اطلاعات‌شان از بین نمی‌رود).</p></div>';
});
/* Cart shortcode bridge: register AFTER module initialization. The previous build checked too early
 * (before plugins_loaded), so [dlz_sm_cart] could appear literally on the page. */
add_action('plugins_loaded', function(){
    if (shortcode_exists('dalil_sm_cart') && !shortcode_exists('dlz_sm_cart')) {
        add_shortcode('dlz_sm_cart', function($atts=array(), $content=''){
            return do_shortcode('[dalil_sm_cart]');
        });
    }
}, 30);

/* Hide the old standalone taxi from this unified build completely. */
remove_action('wp_body_open','dlz_render_taxi',20);

/* Profile navigation is rendered directly by the panel markup; no duplicate menu injection. */
add_action('init',function(){
 if(isset($_GET['dlz_view']) && $_GET['dlz_view']==='favorites' && is_user_logged_in()){
   add_filter('the_content',function($content){return do_shortcode('[dlz_favorites]');},99);
 }
});


/* Central city selector: one city controls all directory-style content. */
add_shortcode('dlz_cities_profile',function(){
 if(!is_user_logged_in()) return '<div dir="rtl">يرجى تسجيل الدخول أولاً.</div>';
 $labels=dlz_city_labels(); $cur=dlz_current_city(); ob_start();
 echo '<div class="dlz-profile-cities" dir="rtl"><div class="dlz-profile-cities-head"><span class="dlz-city-icon">'.dase_svg('cities').'</span><div><h3>المدينة</h3><p>اختر مدينتك لعرض الإعلانات والخدمات المتاحة فيها.</p></div></div><div class="dlz-city-grid">';
 foreach($labels as $key=>$label){ echo '<button type="button" class="'.($cur===$key?'is-active':'').'" data-city="'.esc_attr($key).'">'.esc_html($label).'</button>'; }
 echo '</div><div class="dlz-city-current">المدينة الحالية: <b>'.esc_html($labels[$cur]??$cur).'</b></div></div>'; return ob_get_clean();
});
add_action('init',function(){
 if(isset($_GET['dlz_city'])){
  $city=sanitize_key(wp_unslash($_GET['dlz_city']));
  if(in_array($city,dlz_city_keys(),true)){ setcookie('dase_city',$city,time()+YEAR_IN_SECONDS,'/',COOKIE_DOMAIN, is_ssl(),true); $_COOKIE['dase_city']=$city; }
 }
});
/* City context: individual modules use the same dase_city cookie. Do not alter generic WP queries here; modules with a real city field filter themselves. */
/* Use the logged-in profile identity for every WordPress comment/review. */
add_filter('preprocess_comment',function($data){
 if(is_user_logged_in()){
  $u=wp_get_current_user();
  if($u && $u->ID){
   $name=trim((string)get_user_meta($u->ID,'first_name',true).' '.(string)get_user_meta($u->ID,'last_name',true));
   if(!$name) $name=(string)$u->display_name;
   $data['user_id']=$u->ID; $data['comment_author']=$name; $data['comment_author_email']=$u->user_email;
  }
 }
 return $data;
},2);

/* Disable page zoom on touch devices as requested. */
add_filter('wp_head',function(){ if(is_admin())return; echo '<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">'; echo '<style>html,body{touch-action:pan-x pan-y;-ms-touch-action:pan-x pan-y}</style>'; echo '<script>document.addEventListener("gesturestart",function(e){e.preventDefault();},{passive:false});document.addEventListener("gesturechange",function(e){e.preventDefault();},{passive:false});document.addEventListener("gestureend",function(e){e.preventDefault();},{passive:false});document.addEventListener("wheel",function(e){if(e.ctrlKey)e.preventDefault();},{passive:false});</script>'; },1);

/* -------------------------------------------------------------
 * 16.1 — phone fit: nothing on any page (theme, Elementor, embeds, long links, wide tables)
 * may push the page wider than the screen, so it never slides sideways or shows an empty strip.
 * ----------------------------------------------------------- */
add_action('wp_head',function(){
    if(is_admin()) return;
    echo '<style id="dlz-fit">html{overflow-x:hidden}@supports (overflow:clip){html,body{overflow-x:clip}}body{max-width:100%;overflow-wrap:break-word}'
        .'img,video,iframe,embed,object,canvas{max-width:100%}input,select,textarea{max-width:100%}'
        .'.entry-content table,.elementor-widget-text-editor table,.wp-block-table table{display:block;max-width:100%;overflow-x:auto;-webkit-overflow-scrolling:touch}'
        .'pre{max-width:100%;overflow-x:auto;white-space:pre-wrap}'
        .'.entry-content a,.elementor-widget-text-editor a,.elementor-widget-container p{overflow-wrap:anywhere}'
        .'.elementor-section.elementor-section-stretched,.e-con.e-con-full{max-width:100vw}'
        .'@media (max-width:767px){.elementor-section .elementor-container,.e-con-inner{max-width:100%}.elementor-widget-wrap,.elementor-widget,.elementor-widget-container{min-width:0}}'
        .'</style>';
},3);

/* -------------------------------------------------------------
 * 16.0 — consultation forms (medical / legal): site theme, profile pre-fill,
 * styles in <head> when the page holds a form (no flash of unstyled form).
 * ----------------------------------------------------------- */
add_action('wp_enqueue_scripts',function(){
    if(is_admin()) return;
    wp_register_script('dlz-consult',DASE_URL.'assets/consult.js',array(),DASE_VERSION,true);
    $p=array();
    if(is_user_logged_in()){
        $uid=get_current_user_id();
        $name=trim((string)get_user_meta($uid,'mp_full_name',true));
        if($name==='') $name=trim(get_user_meta($uid,'first_name',true).' '.get_user_meta($uid,'last_name',true));
        $ck=class_exists('DLZ_Countries')?DLZ_Countries::of_user($uid):'';
        $c=$ck?DLZ_Countries::get($ck):null;
        $g=(string)get_user_meta($uid,'mp_gender',true);
        $p=array('name'=>$name,'phone'=>(string)get_user_meta($uid,'mp_sms_phone',true),'gender'=>in_array($g,array('male','female'),true)?$g:'','country'=>$c?$c['short']:'');
    }
    $cities=array('mashhad'=>'مشهد','qom'=>'قم','shiraz'=>'شيراز','tehran'=>'طهران');
    $cur=function_exists('dlz_current_city')?dlz_current_city():'';
    if(isset($cities[$cur])) $p['city']=$cities[$cur];
    wp_localize_script('dlz-consult','DLZConsult',$p);
    global $wp_scripts;
    foreach(array('mcr-frontend','lcr-frontend') as $h){ if(isset($wp_scripts->registered[$h])&&!in_array('dlz-consult',$wp_scripts->registered[$h]->deps,true)) $wp_scripts->registered[$h]->deps[]='dlz-consult'; }
    if(is_singular()){
        $post=get_queried_object(); $content=$post&&isset($post->post_content)?$post->post_content:'';
        $el=get_post_meta(get_queried_object_id(),'_elementor_data',true); $el=is_string($el)?$el:'';
        if(false!==strpos($content,'mcr_form')||false!==strpos($el,'mcr_consultation_form')){wp_enqueue_style('mcr-frontend');wp_enqueue_script('mcr-frontend');}
        if(false!==strpos($content,'lcr_form')||false!==strpos($el,'lcr_consultation_form')){wp_enqueue_style('lcr-frontend');wp_enqueue_script('lcr-frontend');}
    }
},20);
