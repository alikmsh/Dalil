<?php
if (!defined('ABSPATH')) exit;

define('DLZ_TOUR_VER','1.4.0');
define('DLZ_TOUR_DIR',plugin_dir_path(__FILE__));
define('DLZ_TOUR_URL',plugin_dir_url(__FILE__));

function dlzdt_cities(){
    if(function_exists('dlz_city_labels')) return dlz_city_labels();
    return array('mashhad'=>'مشهد','qom'=>'قم','shiraz'=>'شیراز','tehran'=>'تهران','qazvin'=>'قزوین');
}
function dlzdt_city(){
    if(function_exists('dlz_current_city')) return dlz_current_city();
    $c=isset($_COOKIE['dase_city'])?sanitize_key(wp_unslash($_COOKIE['dase_city'])):'mashhad';
    return array_key_exists($c,dlzdt_cities())?$c:'mashhad';
}
function dlzdt_days(){ return array('saturday'=>'السبت','sunday'=>'الأحد','monday'=>'الاثنين','tuesday'=>'الثلاثاء','wednesday'=>'الأربعاء','thursday'=>'الخميس','friday'=>'الجمعة'); }
function dlzdt_admin_days(){ return array('saturday'=>'شنبه','sunday'=>'یکشنبه','monday'=>'دوشنبه','tuesday'=>'سه‌شنبه','wednesday'=>'چهارشنبه','thursday'=>'پنجشنبه','friday'=>'جمعه'); }

add_action('init',function(){
    register_post_type('dlz_daily_tour',array(
        'labels'=>array('name'=>'تورهای روزانه','singular_name'=>'تور روزانه','add_new'=>'افزودن تور','add_new_item'=>'افزودن تور روزانه','edit_item'=>'ویرایش تور','all_items'=>'همه تورها','menu_name'=>'تورهای روزانه'),
        'public'=>true,'show_ui'=>true,'menu_icon'=>'dashicons-palmtree','supports'=>array('title','editor','thumbnail'),'show_in_rest'=>false
    ));
    register_post_type('dlz_tour_booking',array(
        'labels'=>array('name'=>'رزروهای تور','singular_name'=>'رزرو تور','all_items'=>'رزروها','menu_name'=>'رزروها'),
        'public'=>false,'show_ui'=>true,'show_in_menu'=>'edit.php?post_type=dlz_daily_tour','menu_icon'=>'dashicons-tickets-alt','supports'=>array('title'),'capability_type'=>'post'
    ));
});

add_action('add_meta_boxes',function(){ add_meta_box('dlz_tour_details','اطلاعات تور روزانه','dlzdt_meta_box','dlz_daily_tour','normal','high'); });
function dlzdt_meta_box($post){
    $m=function($k,$d='')use($post){$v=get_post_meta($post->ID,$k,true);return $v!==''?$v:$d;};
    $city=$m('_dlz_tour_city','mashhad');$days=(array)$m('_dlz_tour_days',array());$photos=(array)$m('_dlz_tour_photos',array());
    wp_nonce_field('dlz_tour_save','dlz_tour_nonce');
    echo '<div style="display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px">';
    echo '<p><label><strong>شهر</strong></label><select name="dlz_tour_city" style="width:100%">';foreach(dlzdt_cities() as $k=>$v)echo '<option value="'.esc_attr($k).'" '.selected($city,$k,false).'>'.esc_html($v).'</option>';echo '</select></p>';
    echo '<p><label><strong>قیمت پایه هر نفر (دینار عراق — برای هر زائر خودکار به ارز کشورش تبدیل می‌شود)</strong></label><input type="number" min="0" step="1" name="dlz_tour_price" value="'.esc_attr($m('_dlz_tour_price','')).'" style="width:100%"></p>';
    echo '<p><label><strong>ساعت حرکت</strong></label><input type="time" name="dlz_tour_time" value="'.esc_attr($m('_dlz_tour_time','')).'" style="width:100%"></p>';
    echo '<p><label><strong>مکان حرکت</strong></label><input type="text" name="dlz_tour_location" value="'.esc_attr($m('_dlz_tour_location','')).'" placeholder="خالی = مقابل حرم الإمام الرضا" style="width:100%"></p>';
    echo '<p style="grid-column:1/-1"><label><strong>خط طلایی زیر عنوان (اختیاری)</strong></label><input type="text" name="dlz_tour_note" value="'.esc_attr($m('_dlz_tour_note','')).'" placeholder="مثلاً: مع وجبة غداء في مطعم" style="width:100%"><span style="color:#646970;font-size:12px">با رنگ طلایی و آیکن زیر نام تور در کارت نمایش داده می‌شود (متن عربی).</span></p>';
    $location_image=$m('_dlz_tour_location_image','');
    echo '<p><label><strong>تصویر محل حرکت</strong></label><div class="dlz-media-row"><input type="hidden" id="dlz_tour_location_image" name="dlz_tour_location_image" value="'.esc_attr($location_image).'"><div id="dlz_tour_location_image_preview" class="dlz-media-preview">'.($location_image?'<img src="'.esc_url($location_image).'" alt="">':'').'</div><button type="button" class="button dlz-media-pick" data-target="dlz_tour_location_image" data-preview="dlz_tour_location_image_preview">انتخاب تصویر محل حرکت</button><button type="button" class="button dlz-media-clear" data-target="dlz_tour_location_image" data-preview="dlz_tour_location_image_preview">حذف تصویر</button></div></p>';
    echo '<p style="grid-column:1/-1"><label><strong>آدرس مکان مقصد</strong></label><input type="text" name="dlz_tour_address" value="'.esc_attr($m('_dlz_tour_address','')).'" style="width:100%"></p>';
    echo '<p style="grid-column:1/-1"><label><strong>روزهای قابل رزرو</strong></label><br>';foreach(dlzdt_admin_days() as $k=>$v)echo '<label style="margin:0 16px 8px 0;display:inline-block"><input type="checkbox" name="dlz_tour_days[]" value="'.esc_attr($k).'" '.checked(in_array($k,$days,true),true,false).'> '.esc_html($v).'</label>';echo '</p>';
    $image=$m('_dlz_tour_image',''); $location_image=$m('_dlz_tour_location_image',''); $map_image=$m('_dlz_tour_map_image','');
    echo '<p style="grid-column:1/-1"><label><strong>تصویر اصلی مکان</strong></label><div class="dlz-media-row"><input type="hidden" id="dlz_tour_image" name="dlz_tour_image" value="'.esc_attr($image).'"><div id="dlz_tour_image_preview" class="dlz-media-preview">'.($image?'<img src="'.esc_url($image).'" alt="">':'').'</div><button type="button" class="button dlz-media-pick" data-target="dlz_tour_image" data-preview="dlz_tour_image_preview">انتخاب تصویر</button><button type="button" class="button dlz-media-clear" data-target="dlz_tour_image" data-preview="dlz_tour_image_preview">حذف تصویر</button></div></p>';
    echo '<p style="grid-column:1/-1"><label><strong>تصاویر پاپ‌آپ</strong></label><input type="hidden" id="dlz_tour_photos" name="dlz_tour_photos" value="'.esc_attr(wp_json_encode($photos)).'"><div id="dlz_tour_photos_preview" class="dlz-media-gallery">';foreach($photos as $u)echo '<div><img src="'.esc_url($u).'" alt=""></div>';echo '</div><button type="button" class="button dlz-media-pick-multiple" data-target="dlz_tour_photos" data-preview="dlz_tour_photos_preview">انتخاب چند تصویر</button> <button type="button" class="button dlz-media-clear" data-target="dlz_tour_photos" data-preview="dlz_tour_photos_preview">حذف همه تصاویر</button></p>';
    echo '<p><label><strong>تصویر نقشه</strong></label><div class="dlz-media-row"><input type="hidden" id="dlz_tour_map_image" name="dlz_tour_map_image" value="'.esc_attr($map_image).'"><div id="dlz_tour_map_image_preview" class="dlz-media-preview">'.($map_image?'<img src="'.esc_url($map_image).'" alt="">':'').'</div><button type="button" class="button dlz-media-pick" data-target="dlz_tour_map_image" data-preview="dlz_tour_map_image_preview">انتخاب نقشه</button><button type="button" class="button dlz-media-clear" data-target="dlz_tour_map_image" data-preview="dlz_tour_map_image_preview">حذف نقشه</button></div></p>';
    echo '<p><label><strong>لینک Google Maps</strong></label><input type="url" name="dlz_tour_map_url" value="'.esc_attr($m('_dlz_tour_map_url','')).'" style="width:100%"></p>';
    echo '</div><p style="background:#f7f2e5;padding:10px;border-radius:8px">عنوان تور در سایت به عنوان <strong>نام مکان مقصد</strong> نمایش داده می‌شود؛ بنابراین عنوان را نام مکان وارد کنید.</p>';
}
add_action('save_post_dlz_daily_tour',function($id){
    if(!isset($_POST['dlz_tour_nonce'])||!wp_verify_nonce($_POST['dlz_tour_nonce'],'dlz_tour_save')||defined('DOING_AUTOSAVE')||!current_user_can('edit_post',$id))return;
    $fields=array('city'=>'sanitize_key','price'=>'sanitize_text_field','time'=>'sanitize_text_field','location'=>'sanitize_text_field','note'=>'sanitize_text_field','address'=>'sanitize_text_field','image'=>'esc_url_raw','location_image'=>'esc_url_raw','map_image'=>'esc_url_raw','map_url'=>'esc_url_raw');
    foreach($fields as $k=>$fn){$key='_dlz_tour_'.$k;$val=isset($_POST['dlz_tour_'.$k])?call_user_func($fn,wp_unslash($_POST['dlz_tour_'.$k])):'';if($k==='city'&&!array_key_exists($val,dlzdt_cities()))$val='mashhad';update_post_meta($id,$key,$val);}
    $days=isset($_POST['dlz_tour_days'])?array_map('sanitize_key',(array)$_POST['dlz_tour_days']):array();update_post_meta($id,'_dlz_tour_days',$days);
    $photos=array(); if(isset($_POST['dlz_tour_photos'])){ $raw=json_decode(wp_unslash($_POST['dlz_tour_photos']),true); if(is_array($raw)) $photos=array_values(array_filter(array_map('esc_url_raw',$raw))); } update_post_meta($id,'_dlz_tour_photos',$photos);
});

add_filter('manage_dlz_daily_tour_posts_columns',function($c){return array('cb'=>$c['cb'],'title'=>'نام مکان','dlz_city'=>'شهر','dlz_price'=>'قیمت پایه','dlz_days'=>'روزها','dlz_time'=>'حرکت','date'=>'تاریخ');});
add_action('manage_dlz_daily_tour_posts_custom_column',function($col,$id){
    if($col==='dlz_city'){$c=get_post_meta($id,'_dlz_tour_city',true)?:'mashhad';echo esc_html(dlzdt_cities()[$c]??$c);}
    elseif($col==='dlz_price')echo esc_html(number_format_i18n((float)get_post_meta($id,'_dlz_tour_price',true)).' د.ع');
    elseif($col==='dlz_time')echo esc_html(get_post_meta($id,'_dlz_tour_time',true));
    elseif($col==='dlz_days'){$d=(array)get_post_meta($id,'_dlz_tour_days',true);$all=dlzdt_days();echo esc_html(implode('، ',array_map(function($x)use($all){return $all[$x]??$x;},$d)));}
},10,2);

add_action('admin_enqueue_scripts',function($hook){
    $screen=get_current_screen();
    if($screen && (in_array($screen->post_type,array('dlz_daily_tour','dlz_tour_booking'),true) || $screen->id==='dlz_daily_tour_page_dlz-tour-ticket-settings')){wp_enqueue_media();wp_enqueue_script('jquery');}
});
add_action('admin_head',function(){
    $screen=get_current_screen(); if(!$screen || $screen->post_type!=='dlz_daily_tour') return; ?>
    <style>.dlz-media-row{display:flex;gap:8px;align-items:center;flex-wrap:wrap}.dlz-media-preview{width:110px;height:80px;border:1px solid #ddd;border-radius:8px;background:#f7f7f7;display:flex;align-items:center;justify-content:center;overflow:hidden}.dlz-media-preview img{width:100%;height:100%;object-fit:cover}.dlz-media-gallery{display:flex;gap:8px;flex-wrap:wrap;margin:8px 0}.dlz-media-gallery div{width:86px;height:70px;border:1px solid #ddd;border-radius:7px;overflow:hidden}.dlz-media-gallery img{width:100%;height:100%;object-fit:cover}</style>
    <script>jQuery(function($){
      function previewOne(id,url){$('#'+id).html(url?'<img src="'+url.replace(/"/g,'&quot;')+'" alt="">':'');}
      $(document).on('click','.dlz-media-pick',function(e){e.preventDefault();var b=$(this),target=b.data('target'),preview=b.data('preview'),frame=wp.media({title:'انتخاب تصویر',button:{text:'استفاده از تصویر'},multiple:false});frame.on('select',function(){var a=frame.state().get('selection').first().toJSON();$('#'+target).val(a.url);previewOne(preview,a.url);});frame.open();});
      $(document).on('click','.dlz-media-pick-multiple',function(e){e.preventDefault();var b=$(this),target=b.data('target'),preview=b.data('preview'),frame=wp.media({title:'انتخاب تصاویر',button:{text:'استفاده از تصاویر'},multiple:true});frame.on('select',function(){var urls=[];frame.state().get('selection').each(function(m){urls.push(m.toJSON().url);});$('#'+target).val(JSON.stringify(urls));$('#'+preview).html(urls.map(function(u){return '<div><img src="'+u.replace(/"/g,'&quot;')+'" alt=""></div>';}).join(''));});frame.open();});
      $(document).on('click','.dlz-media-clear',function(e){e.preventDefault();var b=$(this);$('#'+b.data('target')).val('');$('#'+b.data('preview')).empty();});
    });</script>
<?php });
add_action('admin_menu',function(){add_submenu_page('edit.php?post_type=dlz_daily_tour','تنظیمات بلیت','تنظیمات بلیت','manage_options','dlz-tour-ticket-settings','dlzdt_ticket_settings_page');});
add_action('admin_init',function(){register_setting('dlz_ticket_settings','dlz_ticket_logo',array('sanitize_callback'=>'esc_url_raw'));});
function dlzdt_ticket_settings_page(){
    if(!current_user_can('manage_options'))return; $logo=get_option('dlz_ticket_logo',''); ?>
    <div class="wrap" dir="rtl"><h1>تنظیمات بلیت تور</h1><form method="post" action="options.php"><?php settings_fields('dlz_ticket_settings'); ?>
    <table class="form-table"><tr><th>لوگوی بلیت</th><td><input type="hidden" id="dlz_ticket_logo" name="dlz_ticket_logo" value="<?php echo esc_attr($logo); ?>"><div id="dlz_ticket_logo_preview" style="width:180px;height:90px;border:1px solid #ddd;border-radius:8px;display:flex;align-items:center;justify-content:center;margin-bottom:10px;background:#fafafa;overflow:hidden"><?php if($logo): ?><img src="<?php echo esc_url($logo); ?>" style="max-width:100%;max-height:100%" alt=""><?php endif; ?></div><button type="button" class="button" id="dlz-ticket-logo-pick">انتخاب لوگو از رسانه</button> <button type="button" class="button" id="dlz-ticket-logo-clear">حذف لوگو</button></td></tr></table><?php submit_button('ذخیره تنظیمات'); ?></form></div>
    <script>jQuery(function($){$('#dlz-ticket-logo-pick').on('click',function(){var f=wp.media({title:'انتخاب لوگو',button:{text:'استفاده از لوگو'},multiple:false});f.on('select',function(){var a=f.state().get('selection').first().toJSON();$('#dlz_ticket_logo').val(a.url);$('#dlz_ticket_logo_preview').html('<img src="'+a.url.replace(/"/g,'&quot;')+'" style="max-width:100%;max-height:100%" alt="">');});f.open();});$('#dlz-ticket-logo-clear').on('click',function(){$('#dlz_ticket_logo').val('');$('#dlz_ticket_logo_preview').empty();});});</script><?php
}

function dlzdt_get_query($city=null){$city=$city?:dlzdt_city();return new WP_Query(array('post_type'=>'dlz_daily_tour','post_status'=>'publish','posts_per_page'=>-1,'orderby'=>array('menu_order'=>'ASC','date'=>'DESC'),'no_found_rows'=>true,'meta_query'=>($city==='mashhad'?array(array('relation'=>'OR',array('key'=>'_dlz_tour_city','value'=>$city),array('key'=>'_dlz_tour_city','compare'=>'NOT EXISTS'),array('key'=>'_dlz_tour_city','value'=>''))):array(array('key'=>'_dlz_tour_city','value'=>$city)))));}
/** Small line icons of the tour / entertainment cards. */
function dlzdt_icon($k){
    $p=array(
        'pin'=>'<path d="M12 21.5s-6.5-6.2-6.5-11.6a6.5 6.5 0 0 1 13 0c0 5.4-6.5 11.6-6.5 11.6z"/><circle cx="12" cy="9.8" r="2.3"/>',
        'clock'=>'<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/>',
        'cal'=>'<rect x="4" y="5.5" width="16" height="14" rx="2.5"/><path d="M4 10h16M8.5 3.5v4M15.5 3.5v4"/>',
        'food'=>'<path d="M7 3v8M5 3v5a2 2 0 0 0 4 0V3M7 11v10M16.5 21V3c-2 1.4-3 3.8-3 7v4h3"/>',
        'star'=>'<path d="M12 3.8l2.4 5 5.4.7-4 3.7 1 5.4L12 16l-4.8 2.6 1-5.4-4-3.7 5.4-.7z"/>',
        'bus'=>'<rect x="4.5" y="4" width="15" height="13" rx="3"/><path d="M4.5 11h15M8 17v2.5M16 17v2.5"/><circle cx="8.5" cy="14" r=".6" fill="currentColor"/><circle cx="15.5" cy="14" r=".6" fill="currentColor"/>',
    );
    return '<svg class="dlzc-i" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'.($p[$k]??$p['star']).'</svg>';
}
/** The gold line under the title: a fork for meals, a bus for transport, a star otherwise. */
function dlzdt_note_icon($t){
    if(preg_match('/وجبة|غداء|عشاء|فطور|مطعم|طعام|ناهار|شام|صبحانه|رستوران/u',$t)) return dlzdt_icon('food');
    if(preg_match('/نقل|حافلة|باص|سيارة|اتوبوس|ماشین/u',$t)) return dlzdt_icon('bus');
    return dlzdt_icon('star');
}
function dlzdt_markup(){
    $q=dlzdt_get_query();$days=dlzdt_days();$uid='dlz-tour-'.wp_rand(1000,99999);$city=dlzdt_city();$nonce=wp_create_nonce('dlz_tour_booking');
    $me=function_exists('dlz_me')?dlz_me():array('name'=>'','phone'=>'');
    ob_start();
    ?>
    <section id="<?php echo esc_attr($uid); ?>" class="dlz-tour-widget" dir="rtl" data-city="<?php echo esc_attr($city); ?>" data-nonce="<?php echo esc_attr($nonce); ?>" data-me-name="<?php echo esc_attr($me['name']); ?>" data-me-phone="<?php echo esc_attr($me['phone']); ?>">
      <div class="dlz-tour-grid">
      <?php if($q->have_posts()):while($q->have_posts()):$q->the_post();$id=get_the_ID();$price=(float)get_post_meta($id,'_dlz_tour_price',true);$time=get_post_meta($id,'_dlz_tour_time',true);$loc=trim((string)get_post_meta($id,'_dlz_tour_location',true));$loc=$loc!==''?$loc:'مقابل حرم الإمام الرضا';$note=trim((string)get_post_meta($id,'_dlz_tour_note',true));$address=get_post_meta($id,'_dlz_tour_address',true);$img=get_post_meta($id,'_dlz_tour_image',true);$tdays=array_values(array_filter((array)get_post_meta($id,'_dlz_tour_days',true)));$photos=(array)get_post_meta($id,'_dlz_tour_photos',true);$map=get_post_meta($id,'_dlz_tour_map_image',true);$mapurl=get_post_meta($id,'_dlz_tour_map_url',true);if(!$img&&has_post_thumbnail())$img=get_the_post_thumbnail_url($id,'medium_large');$allphotos=array_values(array_unique(array_filter(array_merge(array($img),$photos))));$data=array('id'=>$id,'title'=>get_the_title(),'price'=>$price,'time'=>$time,'location'=>$loc,'address'=>$address,'note'=>$note,'photos'=>$allphotos,'main_image'=>$img,'location_image'=>get_post_meta($id,'_dlz_tour_location_image',true),'days'=>$tdays,'map_image'=>$map,'map_url'=>$mapurl);
        $dayl=implode('، ',array_map(function($x)use($days){return $days[$x]??$x;},$tdays));
        $pp=$price>0?(class_exists('DLZ_Money')?array(DLZ_Money::num(DLZ_Money::conv($price)),DLZ_Money::sym()):array(number_format($price),'د.ع')):null; ?>
        <article class="dlz-tour-card dlzc" id="tour-<?php echo (int)$id; ?>" data-favorite-id="<?php echo (int)$id; ?>" data-tour='<?php echo esc_attr(wp_json_encode($data)); ?>' tabindex="0" role="button" aria-label="<?php echo esc_attr(get_the_title()); ?>">
          <div class="dlz-tour-image-wrap dlzc-ph"><?php if($img): ?><img class="dlz-tour-image" src="<?php echo esc_url($img); ?>" alt="" loading="lazy" decoding="async"><?php endif; ?><?php echo function_exists('dlz_favorite_button')?dlz_favorite_button('dlz_daily_tour',$id):''; // phpcs:ignore ?><button type="button" class="dlz-tour-open dlzc-cta">احجز</button></div>
          <div class="dlz-tour-body dlzc-b"><h3><?php the_title(); ?></h3>
            <?php if($note): ?><p class="dlzc-hl"><?php echo dlzdt_note_icon($note); // phpcs:ignore ?><span><?php echo esc_html($note); ?></span></p><?php endif; ?>
            <ul class="dlzc-m"><li><?php echo dlzdt_icon('pin'); // phpcs:ignore ?><span>الحركة: <?php echo esc_html($loc); ?></span></li><?php if($time): ?><li><?php echo dlzdt_icon('clock'); // phpcs:ignore ?><bdi dir="ltr"><?php echo esc_html($time); ?></bdi></li><?php endif; ?></ul>
            <?php if($dayl||$pp): ?><div class="dlzc-ft"><?php if($dayl): ?><span class="dlzc-days"><?php echo dlzdt_icon('cal'); // phpcs:ignore ?><?php echo esc_html($dayl); ?></span><?php endif; ?><?php if($pp): ?><span class="dlzc-pr"><b dir="ltr"><?php echo esc_html($pp[0]); ?></b> <?php echo esc_html($pp[1]); ?></span><?php endif; ?></div><?php endif; ?>
          </div>
        </article>
      <?php endwhile;wp_reset_postdata();else: ?><div class="dlz-tour-empty">لا توجد جولات متاحة لهذه المدينة حالياً.</div><?php endif; ?>
      </div>
      <div class="dlz-tour-modal" hidden><div class="dlz-tour-overlay"></div><div class="dlz-tour-dialog">
        <button type="button" class="dlz-tour-close" aria-label="إغلاق">×</button>
        <div class="dlz-tour-slider"><div class="dlz-tour-slides"></div><button type="button" class="dlz-tour-prev" aria-label="الصورة السابقة">‹</button><button type="button" class="dlz-tour-next" aria-label="الصورة التالية">›</button><div class="dlz-tour-dots"></div></div>
        <h2 class="dlz-tour-modal-title"></h2><p class="dlz-tour-address"></p><p class="dlz-tour-mnote" hidden></p>
        <form class="dlz-tour-form"><label>الاسم الكامل<input required name="name" type="text" autocomplete="name" placeholder="اكتب اسمك الكامل"></label><label>رقم الهاتف<input required name="phone" type="tel" inputmode="tel" autocomplete="tel" dir="ltr" placeholder="رقم الهاتف"></label><label>اختر يوم الجولة<select required name="day"></select></label><label>عدد الأشخاص<input required min="1" value="1" name="people" type="number" inputmode="numeric"></label><div class="dlz-tour-price-row"><span>سعر الفرد</span><strong class="dlz-tour-unit">0</strong><span>السعر الإجمالي</span><strong class="dlz-tour-total-value">0</strong></div><p class="dlz-tour-pay">الدفع عند الوصول</p><button class="dlz-tour-submit" type="submit">تأكيد الحجز وإصدار التذكرة</button><div class="dlz-tour-msg" aria-live="polite"></div></form>
      </div></div>
    </section>
    <?php return ob_get_clean();
}
add_shortcode('dlz_daily_tours',function(){wp_enqueue_style('dlz-tour');wp_enqueue_script('dlz-tour');return dlzdt_markup();});

add_action('wp_ajax_dlz_tour_booking','dlzdt_booking');add_action('wp_ajax_nopriv_dlz_tour_booking','dlzdt_booking');
function dlzdt_booking(){
    check_ajax_referer('dlz_tour_booking','nonce');$id=absint($_POST['tour_id']??0);$tour=get_post($id);if(!$tour||$tour->post_type!=='dlz_daily_tour'||$tour->post_status!=='publish')wp_send_json_error(array('message'=>'الجولة غير موجودة.'));
    $name=mb_substr(sanitize_text_field(wp_unslash($_POST['name']??'')),0,80);$phone=substr(preg_replace('/[^0-9+ ]/','',sanitize_text_field(wp_unslash($_POST['phone']??''))),0,30);$day=sanitize_key($_POST['day']??'');$people=max(1,min(50,absint($_POST['people']??1)));$days=(array)get_post_meta($id,'_dlz_tour_days',true);
    if(!$name||!$phone||!in_array($day,$days,true))wp_send_json_error(array('message'=>'يرجى إكمال بيانات الحجز.'));
    $price=(float)get_post_meta($id,'_dlz_tour_price',true);$total=$price*$people;$city=get_post_meta($id,'_dlz_tour_city',true)?:'mashhad';
    do{$code=str_pad((string)wp_rand(0,999999999999),12,'0',STR_PAD_LEFT);}while(get_posts(array('post_type'=>'dlz_tour_booking','meta_key'=>'_dlz_booking_code','meta_value'=>$code,'fields'=>'ids','posts_per_page'=>1)));
    $bid=wp_insert_post(array('post_type'=>'dlz_tour_booking','post_status'=>'publish','post_title'=>$name.' - '.$tour->post_title.' - '.$code));if(!$bid)wp_send_json_error(array('message'=>'تعذر تسجيل الحجز.'));
    if(is_user_logged_in()) update_post_meta($bid,'_dlz_user_id',get_current_user_id());
    $meta=array('tour_id'=>$id,'tour_title'=>$tour->post_title,'name'=>$name,'phone'=>$phone,'day'=>$day,'people'=>$people,'unit_price'=>$price,'total'=>$total,'city'=>$city,'code'=>$code,'created'=>current_time('mysql'),'location'=>get_post_meta($id,'_dlz_tour_location',true),'location_image'=>get_post_meta($id,'_dlz_tour_location_image',true),'address'=>get_post_meta($id,'_dlz_tour_address',true),'map_image'=>get_post_meta($id,'_dlz_tour_map_image',true),'map_url'=>get_post_meta($id,'_dlz_tour_map_url',true),'main_image'=>get_post_meta($id,'_dlz_tour_image',true));
    foreach($meta as $k=>$v)update_post_meta($bid,'_dlz_booking_'.$k,$v);
    $ticket=$meta;$ticket['booking_id']=$bid;$ticket['download_url']=wp_nonce_url(admin_url('admin-post.php?action=dlz_download_booking_ticket&booking_id='.(int)$bid),'dlz_download_booking_ticket_'.$bid);wp_send_json_success(array('ticket'=>$ticket));
}
add_filter('manage_dlz_tour_booking_posts_columns',function(){return array('cb'=>'<input type="checkbox">','title'=>'رزرو','dlz_code'=>'کد رهگیری','dlz_tour'=>'مکان','dlz_name'=>'نام','dlz_phone'=>'تلفن','dlz_people'=>'نفرات','dlz_day'=>'روز','dlz_total'=>'مبلغ','dlz_city'=>'شهر','date'=>'ثبت شده');});
add_action('manage_dlz_tour_booking_posts_custom_column',function($col,$id){$m=function($k)use($id){return get_post_meta($id,$k,true);};if($col==='dlz_code')echo esc_html($m('_dlz_booking_code'));if($col==='dlz_tour')echo esc_html($m('_dlz_booking_tour_title'));if($col==='dlz_name')echo esc_html($m('_dlz_booking_name'));if($col==='dlz_phone')echo esc_html($m('_dlz_booking_phone'));if($col==='dlz_people')echo esc_html($m('_dlz_booking_people'));if($col==='dlz_day'){$d=dlzdt_admin_days();$v=$m('_dlz_booking_day');echo esc_html($d[$v]??$v);}if($col==='dlz_total')echo esc_html(number_format_i18n((float)$m('_dlz_booking_total')).' د.ع');if($col==='dlz_city'){$c=$m('_dlz_booking_city');$l=dlzdt_cities();echo esc_html($l[$c]??$c);}},10,2);

/* Registered on every page, loaded only where the tours are shown (shortcode / Elementor widget). */
add_action('wp_enqueue_scripts',function(){
    wp_register_style('dlz-tour',DLZ_TOUR_URL.'assets/tours.css',array(),DLZ_TOUR_VER);
    wp_register_script('dlz-tour',DLZ_TOUR_URL.'assets/tours.js',array(),DLZ_TOUR_VER,true);
    wp_localize_script('dlz-tour','DLZTourCfg',array('ajax'=>admin_url('admin-ajax.php'),'days'=>dlzdt_days(),'logo'=>get_option('dlz_ticket_logo','')));
    if(function_exists('dlz_page_has')&&dlz_page_has(array('dlz_daily_tours'))){wp_enqueue_style('dlz-tour');wp_enqueue_script('dlz-tour');}
});
function dlzdt_register_elementor_widget($manager){if(!class_exists('\Elementor\Widget_Base'))return;$file=DLZ_TOUR_DIR.'elementor/class-dlz-daily-tours-widget.php';if(file_exists($file))require_once $file;if(class_exists('DLZ_Daily_Tours_Elementor_Widget'))$manager->register(new DLZ_Daily_Tours_Elementor_Widget());}
add_action('elementor/widgets/register','dlzdt_register_elementor_widget');
add_action('elementor/elements/categories_registered',function($elements_manager){$elements_manager->add_category('dlz-dalil-alzaer',array('title'=>'دلیل الزائر','icon'=>'eicon-map-pin'));});
