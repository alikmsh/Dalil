(function(){
'use strict';
const cfg=window.DLZTourCfg||{ajax:'/wp-admin/admin-ajax.php',days:{saturday:'السبت',sunday:'الأحد',monday:'الاثنين',tuesday:'الثلاثاء',wednesday:'الأربعاء',thursday:'الخميس',friday:'الجمعة'}};
function fm(n){return window.DLZM&&DLZM.f?DLZM.f(n):Number(n||0).toLocaleString('en')+' د.ع';}
function city(){let c='';try{c=localStorage.getItem('dase_city')||'';}catch(e){}if(!c){const m=document.cookie.match(/(?:^|;\s*)dase_city=([^;]+)/);c=m?decodeURIComponent(m[1]):'';}return c||'mashhad';}
async function makePdf(t){
 const W=1600,H=920,c=document.createElement('canvas');c.width=W;c.height=H;const x=c.getContext('2d');
 const gold='#caa32a',gold2='#f0ca4d',navy='#0d1626',navy2='#15243a',cream='#f8f4e9',ink='#172033',muted='#697180',white='#ffffff',line='#e5d7b8';
 x.direction='rtl';x.textBaseline='middle';
 function rr(px,py,w,h,r,fill,stroke,lw){x.beginPath();if(x.roundRect)x.roundRect(px,py,w,h,r);else x.rect(px,py,w,h);if(fill){x.fillStyle=fill;x.fill();}if(stroke){x.strokeStyle=stroke;x.lineWidth=lw||2;x.stroke();}}
 function txt(s,px,py,size,color,bold,align='right'){x.fillStyle=color;x.font=(bold?'700 ':'400 ')+size+'px Arial';x.textAlign=align;x.direction='rtl';x.fillText(String(s||''),px,py);}
 function fitText(s,max,size,min=12){let z=size;while(z>min){x.font='700 '+z+'px Arial';if(x.measureText(String(s||'')).width<=max)return z;z-=1;}return min;}
 function load(url){return new Promise(resolve=>{if(!url){resolve(null);return;}const im=new Image();im.onload=()=>resolve(im);im.onerror=()=>resolve(null);im.src=url;});}
 function drawImage(im,px,py,w,h,r){if(!im)return; x.save();x.beginPath();if(x.roundRect)x.roundRect(px,py,w,h,r);else x.rect(px,py,w,h);x.clip();const scale=Math.max(w/im.width,h/im.height),nw=im.width*scale,nh=im.height*scale;x.drawImage(im,px+(w-nw)/2,py+(h-nh)/2,nw,nh);x.restore();}
 const [logo,main,locationImg,mapImg]=await Promise.all([load(cfg.logo),load(t.main_image),load(t.location_image),load(t.map_image)]);
 x.fillStyle='#e8dfcc';x.fillRect(0,0,W,H);rr(35,35,1530,850,34,cream,gold,3);rr(35,35,1020,850,34,navy,gold,3);rr(1055,35,510,850,34,cream,gold,3);
 if(logo)drawImage(logo,70,65,180,90,8);else{rr(70,65,180,90,12,navy2,gold,2);txt('دليل الزائر',160,110,27,gold2,true,'center');}
 txt('تذكرة رحلة يومية',1005,88,40,gold2,true);txt('استمتع برحلة جميلة مع دليل الزائر',1005,130,18,white,false);x.strokeStyle='rgba(240,202,77,.35)';x.lineWidth=1;x.beginPath();x.moveTo(300,160);x.lineTo(1000,160);x.stroke();
 rr(70,190,350,350,24,navy2,gold,2);drawImage(main,70,190,350,350,24);
 const bx=455,bw=545;function row(y,label,value){rr(bx,y,bw,74,16,navy2,'rgba(240,202,77,.35)',1);txt(label,bx+bw-22,y+22,15,'#cbd2dc',false);let sz=fitText(value,bw-120,23,13);txt(value,bx+bw-22,y+52,sz,white,true);}
 row(190,'اسم المكان',t.tour_title||t.title||'');row(276,'اسم المسافر',t.name||'');row(362,'رقم الهاتف',t.phone||'');row(448,'يوم الجولة',cfg.days[t.day]||t.day||'');
 rr(bx,534,bw,92,18,'#ead080',gold,2);txt('السعر الإجمالي',bx+bw-22,566,16,navy,true);txt(fm(t.total),bx+bw-22,603,31,navy,true);
 rr(455,646,545,82,18,navy2,gold,2);txt('كود التتبع',978,674,15,'#cbd2dc',false);txt(t.code||'',978,708,25,gold2,true);
 rr(455,748,545,82,18,gold,'',0);txt('الدفع عند الوصول',728,789,23,navy,true,'center');
 if(logo)drawImage(logo,1360,52,145,72,10);
 txt('موقع الانطلاق',1515,135,18,ink,true);
 rr(1090,155,440,82,14,'#efe5cc',line,1);
 if(locationImg)drawImage(locationImg,1100,164,92,64,10);
 txt(t.location||'مقابل حرم الإمام الرضا',1508,196,17,ink,true);
 txt('موقع الجولة',1515,270,18,ink,true);
 rr(1090,290,440,72,14,'#efe5cc',line,1);
 txt(t.address||t.tour_title||t.title||'',1510,326,17,ink,true);
 txt('خريطة موقع الحركة',1515,395,18,ink,true);
 rr(1090,418,440,190,18,'#e6e1d6',line,1);
 drawImage(mapImg,1090,418,440,190,18);
 rr(1090,626,440,54,15,navy,'',0);txt('فتح الموقع في خرائط جوجل',1310,653,17,white,true,'center');
 rr(1090,704,440,110,18,'#efe5cc',line,1);txt('رقم الحجز',1510,732,14,muted,false);txt(t.code||'',1510,765,22,ink,true);txt('يرجى الحضور قبل الحركة بعشر دقائق',1510,795,14,muted,false);
 txt('دليل الزائر',1515,846,18,gold,true);txt('شكراً لاختياركم دليل الزائر',1110,846,15,muted,false,'left');
 downloadPdf(c,t);
 function downloadPdf(canvas,ticket){const jpg=canvas.toDataURL('image/jpeg',0.96).split(',')[1],bin=atob(jpg),arr=new Uint8Array(bin.length);for(let i=0;i<bin.length;i++)arr[i]=bin.charCodeAt(i);const pdf=pdfFromJpeg(arr,canvas.width,canvas.height,ticket.map_url);const blob=new Blob([pdf],{type:'application/pdf'}),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='dalil-alzaer-ticket-'+ticket.code+'.pdf';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(a.href),1500);}
 function pdfFromJpeg(jpg,w,h,url){let chunks=[],offs=[],pos=0,enc=new TextEncoder();const push=s=>{const b=enc.encode(s);chunks.push(b);pos+=b.length;};push('%PDF-1.4\n%\xE2\xE3\xCF\xD3\n');offs[1]=pos;push('1 0 obj<< /Type /Catalog /Pages 2 0 R >>endobj\n');offs[2]=pos;push('2 0 obj<< /Type /Pages /Kids [3 0 R] /Count 1 >>endobj\n');offs[3]=pos;let ann=url?' /Annots [6 0 R]':'';push('3 0 obj<< /Type /Page /Parent 2 0 R /MediaBox [0 0 '+w+' '+h+'] /Resources<< /XObject<< /Im1 5 0 R >> /ProcSet [/PDF /Image] >> /Contents 4 0 R'+ann+' >>endobj\n');offs[4]=pos;const stream='q\n'+w+' 0 0 '+h+' 0 0 cm\n/Im1 Do\nQ\n';push('4 0 obj<< /Length '+stream.length+' >>stream\n'+stream+'endstream\nendobj\n');offs[5]=pos;push('5 0 obj<< /Type /XObject /Subtype /Image /Width '+w+' /Height '+h+' /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length '+jpg.length+' >>stream\n');chunks.push(jpg);pos+=jpg.length;push('\nendstream\nendobj\n');if(url){offs[6]=pos;const safe=String(url).replace(/[()\\]/g,'');push('6 0 obj<< /Type /Annot /Subtype /Link /Rect [1090 625 1530 679] /Border [0 0 0] /A<< /S /URI /URI ('+safe+') >> >>endobj\n');}const start=pos;push('xref\n0 7\n0000000000 65535 f \n');for(let i=1;i<=6;i++)push(String(offs[i]||0).padStart(10,'0')+' 00000 n \n');push('trailer<< /Size 7 /Root 1 0 R >>\nstartxref\n'+start+'\n%%EOF');let total=0;chunks.forEach(b=>total+=b.length);const out=new Uint8Array(total);let p=0;chunks.forEach(b=>{out.set(b,p);p+=b.length;});return out;}
}
function init(root){if(root.dataset.ready)return;root.dataset.ready='1';const modal=root.querySelector('.dlz-tour-modal'),form=root.querySelector('.dlz-tour-form'),slides=root.querySelector('.dlz-tour-slides'),dots=root.querySelector('.dlz-tour-dots');let current=null,index=0,startX=0;
 function openCard(card){try{current=JSON.parse(card.dataset.tour);}catch(e){return;}open();}
 root.querySelectorAll('.dlz-tour-card').forEach(card=>{card.addEventListener('click',e=>{if(e.target.closest('.dlz-unified-favorite,a'))return;openCard(card);});card.addEventListener('keydown',e=>{if((e.key==='Enter'||e.key===' ')&&e.target===card){e.preventDefault();openCard(card);}});});
 const hm=location.hash.match(/^#tour-(\d+)$/);if(hm){const c=root.querySelector('#tour-'+hm[1]);if(c)setTimeout(()=>{c.scrollIntoView({block:'center'});openCard(c);},120);}
 function renderGallery(){slides.innerHTML='';dots.innerHTML='';const arr=(current.photos&&current.photos.length?current.photos:[current.main_image]).filter(Boolean);arr.forEach((u,i)=>{const s=document.createElement('div');s.className='dlz-tour-slide';const im=document.createElement('img');im.src=u;im.alt=current.title;s.appendChild(im);slides.appendChild(s);const d=document.createElement('button');d.type='button';d.className='dlz-tour-dot'+(i===0?' active':'');d.addEventListener('click',()=>go(i));dots.appendChild(d);});index=0;go(0);}
 function go(i){const count=slides.children.length;if(!count)return;index=(i+count)%count;slides.style.transform='translateX(-'+(index*100)+'%)';dots.querySelectorAll('.dlz-tour-dot').forEach((d,n)=>d.classList.toggle('active',n===index));}
 function open(){modal.hidden=false;root.querySelector('.dlz-tour-modal-title').textContent=current.title;root.querySelector('.dlz-tour-address').textContent=current.address||current.location||'';renderGallery();const sel=form.querySelector('[name=day]');sel.innerHTML='';(current.days||[]).forEach(k=>{const o=document.createElement('option');o.value=k;o.textContent=cfg.days[k]||k;sel.appendChild(o);});root.querySelector('.dlz-tour-unit').textContent=fm(current.price);const mn=root.querySelector('.dlz-tour-mnote');if(mn){mn.textContent=current.note||'';mn.hidden=!current.note;}const nm=form.querySelector('[name=name]'),ph=form.querySelector('[name=phone]');if(nm&&!nm.value&&root.dataset.meName)nm.value=root.dataset.meName;if(ph&&!ph.value&&root.dataset.mePhone)ph.value=root.dataset.mePhone;update();}
 function update(){const p=Math.max(1,parseInt(form.querySelector('[name=people]').value||1,10)||1);const total=p*Number(current.price||0);root.querySelector('.dlz-tour-total-value').textContent=fm(total);}
 root.querySelector('.dlz-tour-next').addEventListener('click',()=>go(index+1));root.querySelector('.dlz-tour-prev').addEventListener('click',()=>go(index-1));
 slides.addEventListener('pointerdown',e=>{startX=e.clientX;});slides.addEventListener('pointerup',e=>{const dx=e.clientX-startX;if(Math.abs(dx)>45)go(index+(dx<0?1:-1));});
 root.querySelector('.dlz-tour-close').addEventListener('click',()=>modal.hidden=true);root.querySelector('.dlz-tour-overlay').addEventListener('click',()=>modal.hidden=true);form.querySelector('[name=people]').addEventListener('input',update);
 form.addEventListener('submit',e=>{e.preventDefault();const msg=root.querySelector('.dlz-tour-msg');msg.className='dlz-tour-msg';msg.textContent='جارٍ تسجيل الحجز...';const fd=new FormData();fd.append('action','dlz_tour_booking');fd.append('nonce',root.dataset.nonce);fd.append('tour_id',current.id);fd.append('name',form.querySelector('[name=name]').value.trim());fd.append('phone',form.querySelector('[name=phone]').value.trim());fd.append('day',form.querySelector('[name=day]').value);fd.append('people',form.querySelector('[name=people]').value);fetch(cfg.ajax,{method:'POST',body:fd,credentials:'same-origin'}).then(r=>r.json()).then(r=>{if(!r.success)throw new Error(r.data&&r.data.message||'تعذر تسجيل الحجز.');msg.className='dlz-tour-msg ok';msg.textContent='تم تسجيل الحجز بنجاح. جارٍ إصدار التذكرة...';makePdf(r.data.ticket);}).catch(err=>{msg.textContent=err.message;});});
 document.addEventListener('dase:cityChanged',()=>{const c=city();if(c!==root.dataset.city)location.reload();});
}
document.querySelectorAll('.dlz-tour-widget').forEach(init);
if(window.elementorFrontend&&window.elementorFrontend.hooks){window.elementorFrontend.hooks.addAction('frontend/element_ready/dlz_daily_tours.default',function($scope){$scope.find('.dlz-tour-widget').each(function(){init(this);});});}
})();
