<?php
if(!defined('ABSPATH'))exit;
if(!class_exists('DLZ_Daily_Tours_Elementor_Widget')){
class DLZ_Daily_Tours_Elementor_Widget extends \Elementor\Widget_Base{
 public function get_name(){return 'dlz_daily_tours';}
 public function get_title(){return 'دلیل الزائر - تورهای روزانه';}
 public function get_icon(){return 'eicon-calendar';}
 public function get_categories(){return array('dalil-alzaer');}
 public function get_keywords(){return array('دلیل الزائر','تور','رحلات','daily tours','tour');}
 protected function register_controls(){
   $this->start_controls_section('info',array('label'=>'تورهای روزانه'));
   $this->add_control('notice',array('type'=>\Elementor\Controls_Manager::RAW_HTML,'raw'=>'<div style="line-height:1.8">لیست تورها از منوی تورهای روزانه مدیریت می‌شود و با شهر انتخاب‌شده در بخش «المدن» هماهنگ است.</div>'));
   $this->end_controls_section();
 }
 protected function render(){wp_enqueue_style('dlz-tour');wp_enqueue_script('dlz-tour');echo dlzdt_markup();}
}}
