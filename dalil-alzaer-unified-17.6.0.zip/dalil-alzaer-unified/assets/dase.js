(function(){
"use strict";
const menu=document.querySelector(".dase-menu-btn");
const overlay=document.querySelector(".dase-menu-overlay");
const close=document.querySelector(".dase-close-menu");
const city=document.querySelector(".dase-city-trigger");
const panel=document.querySelector(".dase-city-panel");
const cityClose=document.querySelector(".dase-city-close");

function closeMenu(){
  if(overlay){overlay.classList.remove("dase-open");overlay.setAttribute("aria-hidden","true")}
  if(menu)menu.setAttribute("aria-expanded","false");
}
if(menu)menu.addEventListener("click",()=>{if(overlay){overlay.classList.add("dase-open");overlay.setAttribute("aria-hidden","false")}menu.setAttribute("aria-expanded","true")});
if(close)close.addEventListener("click",closeMenu);
if(overlay)overlay.addEventListener("click",e=>{if(e.target===overlay)closeMenu()});

function getCity(){
 const x=localStorage.getItem("dase_city");
 if(x)return x;
 const m=document.cookie.match(/(?:^|;\s*)dase_city=([^;]+)/);
 return m?decodeURIComponent(m[1]):"mashhad";
}
function markCity(key){
 document.querySelectorAll(".dase-city-option").forEach(function(x){
  const on=x.dataset.city===key;
  x.classList.toggle("dase-active",on);
  x.setAttribute("aria-selected",on?"true":"false");
  const check=x.querySelector(".dase-city-check"); if(check)check.textContent=on?"✓":"";
 });
 const active=document.querySelector('.dase-city-option[data-city="'+key+'"]');
 const label=active?active.querySelector("span")?.textContent.trim():"";
 const current=document.querySelector(".dase-city-label"); if(current&&label)current.textContent=label;
 const sub=document.querySelector(".dase-city-sub b"); if(sub&&label)sub.textContent=label;
}
function openCity(){
 if(!panel)return;
 panel.classList.add("dase-open"); panel.setAttribute("aria-hidden","false");
 if(city)city.setAttribute("aria-expanded","true");
 markCity(getCity());
}
function closeCity(){
 if(!panel)return;
 panel.classList.remove("dase-open"); panel.setAttribute("aria-hidden","true");
 if(city)city.setAttribute("aria-expanded","false");
}
if(city)city.addEventListener("click",function(e){e.preventDefault();e.stopPropagation();openCity()});
if(cityClose)cityClose.addEventListener("click",closeCity);
if(panel)panel.addEventListener("click",e=>{if(e.target===panel)closeCity()});

const initial=getCity();
markCity(initial);
document.querySelectorAll(".dase-city-option").forEach(function(x){
 x.addEventListener("click",function(e){
  e.preventDefault(); e.stopPropagation();
  const key=x.dataset.city;
  localStorage.setItem("dase_city",key);
  document.cookie="dase_city="+encodeURIComponent(key)+";path=/;max-age=31536000;SameSite=Lax";
  markCity(key);
  document.dispatchEvent(new CustomEvent("dase:cityChanged",{detail:{city:key}}));
  closeCity();
  window.location.reload();
 });
});
})();

/* Online support chat: assets/chat.js (16.0) */

/* 13.16.2 — FAQ + Privacy menu panels */
(function(){
 "use strict";
 function closeInfo(o){if(o){o.classList.remove('is-open');o.setAttribute('aria-hidden','true')}}
 function openInfo(name){var o=document.getElementById('dase-info-'+name);if(!o)return false;document.querySelectorAll('.dase-info-overlay.is-open').forEach(closeInfo);o.classList.add('is-open');o.setAttribute('aria-hidden','false');return true;}
 window.DLZOpenInfo=openInfo;
 /* 14.0 — delegated so the app shell «المزيد» rows ([data-dlz-info]) work too */
 document.addEventListener('click',function(e){var a=e.target.closest&&e.target.closest('.dase-info-open,[data-dlz-info]');if(!a)return;var name=a.getAttribute('data-dlz-info')||a.getAttribute('data-info');if(openInfo(name)){e.preventDefault();e.stopPropagation();}});
 document.querySelectorAll('.dase-info-overlay').forEach(function(o){var c=o.querySelector('.dase-info-close');if(c)c.addEventListener('click',function(){closeInfo(o)});o.addEventListener('click',function(e){if(e.target===o)closeInfo(o)})})
 document.addEventListener('keydown',function(e){if(e.key==='Escape')document.querySelectorAll('.dase-info-overlay.is-open').forEach(closeInfo)})
})();
