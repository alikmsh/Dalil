/* Dalil Al Zaer — shared favourites button + city field sync (no jQuery). */
(function () {
	'use strict';
	var d = document, C = window.DLZUnified || {};
	function profile() { return C.profile || '/'; }
	var HEART = '<svg class="dlz-hrt" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M12 20.6l-1.3-1.2C5.9 15.1 3 12.4 3 8.9 3 6.1 5.2 4 7.9 4c1.6 0 3.1.7 4.1 1.9C13 4.7 14.5 4 16.1 4 18.8 4 21 6.1 21 8.9c0 3.5-2.9 6.2-7.7 10.5L12 20.6z"/></svg>';
	function sync(btn, on) { btn.classList.toggle('is-favorite', !!on); btn.setAttribute('aria-pressed', on ? 'true' : 'false'); var s = btn.querySelector('span'); if (s && !s.querySelector('svg')) s.innerHTML = HEART; }
	function toggle(btn) {
		if (!C.logged || !C.complete) { location.href = profile(); return; }
		var type = btn.getAttribute('data-favorite-type'), id = btn.getAttribute('data-favorite-id');
		btn.disabled = true;
		var f = new FormData();
		f.append('action', 'dlz_toggle_favorite'); f.append('nonce', C.nonce || ''); f.append('favorite_type', type); f.append('favorite_id', id); f.append('favorite_url', location.href);
		fetch(C.ajax, { method: 'POST', body: f, credentials: 'same-origin' }).then(function (r) { return r.json(); }).then(function (r) {
			if (!r || !r.success) return;
			try { d.dispatchEvent(new CustomEvent('dlz:favorite', { detail: r.data })); } catch (x) {}
			d.querySelectorAll('.dlz-unified-favorite[data-favorite-type="' + type + '"]').forEach(function (b) { if (b.getAttribute('data-favorite-id') === String(id)) sync(b, r.data.favorite); });
		}).catch(function () {}).then(function () { btn.disabled = false; });
	}
	d.addEventListener('click', function (e) {
		var b = e.target.closest && e.target.closest('.dlz-unified-favorite');
		if (!b) return;
		e.preventDefault(); e.stopPropagation(); toggle(b);
	});
	function isFav(type, id) { return Array.isArray(C.favorites) && C.favorites.some(function (x) { return x.type === type && String(x.id) === String(id); }); }
	function btnHtml(type, id) {
		var on = isFav(type, id);
		return '<button type="button" class="dlz-unified-favorite' + (on ? ' is-favorite' : '') + '" data-favorite-type="' + type + '" data-favorite-id="' + String(id).replace(/[^\w-]/g, '') + '" aria-label="المفضلة" aria-pressed="' + (on ? 'true' : 'false') + '"><span>' + HEART + '</span><b>المفضلة</b></button>';
	}
	/* Business cards carry their own favourite button; tours / entertainment cards get one here. */
	function inject() {
		d.querySelectorAll('.dlz-tour-card').forEach(function (c) {
			if (c.querySelector('.dlz-unified-favorite')) return;
			var o = c.querySelector('.dlz-tour-open'), id = c.getAttribute('data-favorite-id') || (o && o.getAttribute('data-id'));
			if (!id) try { id = JSON.parse(c.getAttribute('data-tour') || '{}').id; } catch (x) {}
			var bottom = c.querySelector('.dlz-tour-image-wrap') || c.querySelector('.dlz-tour-bottom');
			if (!id || !bottom) return;
			c.setAttribute('data-favorite-id', id);
			bottom.insertAdjacentHTML('afterbegin', btnHtml('dlz_daily_tour', id));
		});
		d.querySelectorAll('.dlz-ent-card').forEach(function (c) {
			if (c.querySelector('.dlz-unified-favorite')) return;
			var o = c.querySelector('.dlz-ent-book'), id = c.getAttribute('data-favorite-id') || (o && o.getAttribute('data-id'));
			var bottom = c.querySelector('.dlz-ent-media') || c.querySelector('.dlz-ent-bottom');
			if (!id || !bottom) return;
			c.setAttribute('data-favorite-id', id);
			bottom.insertAdjacentHTML('afterbegin', btnHtml('dlz_entertainment', id));
		});
	}
	var queued = 0;
	function soon() { if (queued) return; queued = 1; requestAnimationFrame(function () { queued = 0; inject(); }); }
	function start() {
		inject();
		if (!d.querySelector('.dlz-tour-wrap,.dlz-ent-wrap,.dlz-tour-card,.dlz-ent-card,[class*="dlz-tour"],[class*="dlz-ent"]')) return;
		if (window.MutationObserver) new MutationObserver(soon).observe(d.body, { childList: true, subtree: true });
	}
	/* city <select> fields follow the chosen city */
	function cityName() { var m = d.cookie.match(/(?:^|; )dase_city=([^;]+)/), c = m ? decodeURIComponent(m[1]) : 'mashhad'; return { mashhad: 'مشهد', qom: 'قم', shiraz: 'شیراز', tehran: 'تهران' }[c] || 'مشهد'; }
	function syncCity() {
		var t = cityName();
		d.querySelectorAll('select[name="city"]').forEach(function (s) { Array.prototype.forEach.call(s.options, function (o) { if (o.value === t || o.textContent.trim() === t) o.selected = true; }); });
	}
	if (d.readyState === 'loading') d.addEventListener('DOMContentLoaded', function () { start(); syncCity(); }); else { start(); syncCity(); }
})();
