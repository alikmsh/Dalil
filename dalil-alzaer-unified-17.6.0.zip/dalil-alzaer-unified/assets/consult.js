/* Dalil Al Zaer — consultation forms: the visitor's profile fills the form, English digits in the phone */
(function () {
	'use strict';
	var P = window.DLZConsult || {}, d = document;
	function latin(s) {
		return String(s || '').replace(/[۰-۹]/g, function (c) { return c.charCodeAt(0) - 0x06F0; })
			.replace(/[٠-٩]/g, function (c) { return c.charCodeAt(0) - 0x0660; });
	}
	function pick(sel, val) {
		if (!sel || !val) return;
		var opts = [].slice.call(sel.options), n = String(val).replace(/[ًٌٍَُِّْ]/g, '');
		var hit = opts.filter(function (o) { return o.value === val || o.text === val; })[0] ||
			opts.filter(function (o) { var t = o.text.replace(/[ًٌٍَُِّْ]/g, ''); return t.indexOf(n) === 0 || n.indexOf(t) === 0; })[0];
		if (hit) sel.value = hit.value;
	}
	function fill(form) {
		if (form.__dlzc) return;
		form.__dlzc = 1;
		var e = form.elements;
		if (e.name && !e.name.value && P.name) e.name.value = P.name;
		if (e.phone && !e.phone.value && P.phone) e.phone.value = P.phone;
		if (e.gender && P.gender) e.gender.value = P.gender;
		if (e.nationality && P.country) pick(e.nationality, P.country);
		if (e.city && P.city) pick(e.city, P.city);
		if (e.phone) {
			e.phone.removeAttribute('placeholder');
			e.phone.setAttribute('inputmode', 'tel');
			e.phone.addEventListener('input', function () { var v = latin(e.phone.value).replace(/[^\d+ ]/g, ''); if (v !== e.phone.value) e.phone.value = v; });
		}
	}
	function boot() { d.querySelectorAll('.mcr-form,.lcr-form').forEach(fill); }
	if (d.readyState === 'loading') d.addEventListener('DOMContentLoaded', boot); else boot();
	window.addEventListener('elementor/frontend/init', function () { setTimeout(boot, 400); });
})();
