/* Dalil Al Zaer — voice notes recorded as WAV (12 kHz mono).
 * MediaRecorder files from Chrome (fragmented MP4 / WebM) report a wrong length, so many phones stopped
 * playing them after a few seconds. WAV has the exact length in its header and plays on every phone and browser.
 *
 * DLZVoiceRec.start() → Promise<{ stop(): Blob, cancel(): void, seconds(): number }>
 * Call start() directly inside the tap / click handler (iOS needs the user gesture for audio).
 */
(function (w) {
	'use strict';
	var RATE = 12000; // speech-quality WAV ≈ 24 KB per second

	function supported() {
		return !!((w.AudioContext || w.webkitAudioContext) && navigator.mediaDevices && navigator.mediaDevices.getUserMedia);
	}

	function downsample(buf, from, to) {
		if (to >= from) return buf;
		var ratio = from / to, len = Math.floor(buf.length / ratio), out = new Float32Array(len), pos = 0;
		for (var i = 0; i < len; i++) {
			var next = Math.floor((i + 1) * ratio), sum = 0, n = 0;
			for (var j = pos; j < next && j < buf.length; j++) { sum += buf[j]; n++; }
			out[i] = n ? sum / n : 0;
			pos = next;
		}
		return out;
	}

	function wav(samples, rate) {
		var b = new ArrayBuffer(44 + samples.length * 2), v = new DataView(b), o = 0;
		function str(s) { for (var i = 0; i < s.length; i++) v.setUint8(o++, s.charCodeAt(i)); }
		function u32(x) { v.setUint32(o, x, true); o += 4; }
		function u16(x) { v.setUint16(o, x, true); o += 2; }
		str('RIFF'); u32(36 + samples.length * 2); str('WAVE');
		str('fmt '); u32(16); u16(1); u16(1); u32(rate); u32(rate * 2); u16(2); u16(16);
		str('data'); u32(samples.length * 2);
		var peak = 0;
		for (var k = 0; k < samples.length; k++) { var a = Math.abs(samples[k]); if (a > peak) peak = a; }
		var gain = peak > 0 && peak < 0.5 ? Math.min(3, 0.9 / peak) : 1; // gentle normalisation for quiet phones
		for (var i = 0; i < samples.length; i++, o += 2) {
			var s = Math.max(-1, Math.min(1, samples[i] * gain));
			v.setInt16(o, s < 0 ? s * 0x8000 : s * 0x7FFF, true);
		}
		return new Blob([v], { type: 'audio/wav' });
	}

	function start() {
		var AC = w.AudioContext || w.webkitAudioContext;
		var ctx = new AC();
		if (ctx.resume) { try { ctx.resume(); } catch (e) {} }
		return navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true, channelCount: 1 } }).then(function (stream) {
			var src = ctx.createMediaStreamSource(stream),
				node = (ctx.createScriptProcessor || ctx.createJavaScriptNode).call(ctx, 4096, 1, 1),
				bufs = [], len = 0, t0 = Date.now(), done = false;
			node.onaudioprocess = function (e) {
				if (done) return;
				var d = e.inputBuffer.getChannelData(0);
				bufs.push(new Float32Array(d));
				len += d.length;
			};
			src.connect(node);
			node.connect(ctx.destination); // silent output; keeps the processor running on every browser
			function end() {
				done = true;
				try { src.disconnect(); node.disconnect(); } catch (e) {}
				stream.getTracks().forEach(function (t) { t.stop(); });
				var rate = ctx.sampleRate;
				try { ctx.close(); } catch (e) {}
				return rate;
			}
			return {
				seconds: function () { return (Date.now() - t0) / 1000; },
				cancel: function () { if (!done) end(); bufs = []; },
				stop: function () {
					if (done) return null;
					var rate = end(), all = new Float32Array(len), p = 0;
					bufs.forEach(function (x) { all.set(x, p); p += x.length; });
					bufs = [];
					return len > rate * 0.3 ? wav(downsample(all, rate, RATE), Math.min(RATE, rate)) : null;
				}
			};
		}, function (err) { try { ctx.close(); } catch (e) {} throw err; });
	}

	/** longest note (seconds) that still fits the server's upload limit */
	function maxSeconds(limitBytes) {
		var lim = +limitBytes || 0;
		if (!lim) return 300;
		return Math.max(20, Math.min(300, Math.floor((lim - 64 * 1024) / (RATE * 2))));
	}

	w.DLZVoiceRec = { supported: supported, start: start, maxSeconds: maxSeconds };
})(window);
