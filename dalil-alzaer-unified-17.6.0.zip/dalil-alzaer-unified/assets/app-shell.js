/* Dalil Al Zaer 14 — App Shell (header, bottom nav, المزيد, services, live search) */
(function () {
	'use strict';
	var d = document, html = d.documentElement, cfg = window.DLZShell || {};
	var T = cfg.i18n || {};

	function store(k, v) {
		try {
			if (arguments.length > 1) { localStorage.setItem(k, v); return v; }
			return localStorage.getItem(k);
		} catch (e) { return null; }
	}
	function esc(v) { var x = d.createElement('div'); x.textContent = v == null ? '' : String(v); return x.innerHTML.replace(/"/g, '&quot;').replace(/'/g, '&#39;'); }
	function ic(name) {
		var p = (cfg.icons || {})[name] || (cfg.icons || {}).star || '';
		return '<svg class="dsh-i" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + p + '</svg>';
	}

	/* Follow the site's own font: read it from real page content (Elementor text, theme text) */
	if (cfg.fontAuto) {
		try {
			var bs = getComputedStyle(d.body), gv = '';
			['--e-global-typography-text-font-family', '--e-global-typography-primary-font-family'].some(function (k) { gv = (bs.getPropertyValue(k) || '').trim(); return !!gv; });
			var probe = d.querySelector('.elementor-widget-text-editor, .elementor-heading-title, .dase-bottom-label, .entry-content p, main p, article p, .elementor-button-text') || d.body;
			var ff = getComputedStyle(probe).fontFamily;
			if (gv) ff = gv + (ff ? ',' + ff : '');
			if (ff && ff.indexOf('var(') < 0) html.style.setProperty('--dsh-font', (cfg.digits ? '"DlzDigits",' : '') + ff + ',system-ui,sans-serif');
		} catch (e) {}
	}

	/* English digits everywhere: every @font-face of the site's fonts gets a twin that only holds 0-9
	 * (also drawn for ۰-۹ / ٠-٩). Same family, weight and style, added after the theme's faces → wins for digits only. */
	if (cfg.digits && d.fonts && window.FontFace) {
		var digitsDone = {};
		var addDigits = function () {
			try {
				var faces = [];
				d.fonts.forEach(function (f) { faces.push(f); });
				faces.forEach(function (f) {
					var fam = (f.family || '').replace(/^["']|["']$/g, '');
					if (!fam || /^(DlzDigits|DalilKufi)$/i.test(fam) || /icon|awesome|eicons|dashicons|swiper|slick/i.test(fam) || f.__dlzDigits) return;
					var key = fam + '|' + f.weight + '|' + f.style + '|' + f.stretch;
					if (digitsDone[key]) return;
					digitsDone[key] = 1;
					var nf = new FontFace(fam, 'url(' + cfg.digits + ') format("woff")', {
						weight: f.weight, style: f.style, stretch: f.stretch, display: 'swap',
						unicodeRange: 'U+0030-0039, U+0660-0669, U+06F0-06F9'
					});
					nf.__dlzDigits = 1;
					d.fonts.add(nf);
					nf.load().catch(function () {});
				});
			} catch (e) {}
		};
		addDigits();
		if (d.fonts.ready) d.fonts.ready.then(addDigits);
		window.addEventListener('load', addDigits);
	}

	/* Header moved to the top of <body> when the theme has no wp_body_open */
	var late = d.getElementById('dsh-late');
	if (late) {
		var lh = late.querySelector('.dsh-header');
		if (lh) d.body.insertBefore(lh, d.body.firstChild);
		late.remove();
	}

	var header = d.getElementById('dsh-header');
	var nav = d.getElementById('dsh-nav');
	var panels = {
		more: d.getElementById('dsh-more'),
		city: d.getElementById('dsh-city'),
		services: d.getElementById('dsh-services'),
		search: d.getElementById('dsh-search'),
		explore: d.getElementById('dsh-explore')
	};
	if (!nav && !header) return;

	/* ---------- header height for sticky filter bars (--dsh-hh) ---------- */
	if (header) {
		var setH = function () { d.documentElement.style.setProperty('--dsh-hh', Math.round(header.getBoundingClientRect().height) + 'px'); };
		setH();
		if (window.ResizeObserver) new ResizeObserver(setH).observe(header); else window.addEventListener('resize', setH);
	}

	/* ---------- compact header on scroll ---------- */
	if (header) {
		var compact = false, ticking = false;
		window.addEventListener('scroll', function () {
			if (ticking) return;
			ticking = true;
			requestAnimationFrame(function () {
				var y = window.scrollY || window.pageYOffset;
				if (!compact && y > 90) { compact = true; header.classList.add('dsh-compact'); }
				else if (compact && y < 20) { compact = false; header.classList.remove('dsh-compact'); }
				ticking = false;
			});
		}, { passive: true });
	}

	/* ---------- active tab ---------- */
	function norm(u) {
		try {
			var a = new URL(u, location.href), q = [];
			['page_id', 'p', 'dlz_view'].forEach(function (k) { if (a.searchParams.get(k)) q.push(k + '=' + a.searchParams.get(k)); });
			return (a.origin + a.pathname).replace(/\/+$/, '') + (q.length ? '?' + q.join('&') : '');
		}
		catch (e) { return ''; }
	}
	var here = norm(location.href), activeTab = null;
	if (nav) {
		nav.querySelectorAll('a[data-tab]').forEach(function (a) {
			var href = a.getAttribute('href');
			if (!href || href === '#') return;
			if (norm(href) === here) activeTab = a;
		});
		if (!activeTab && /\/(cart|basket|%d8%a7%d9%84%d8%b3%d9%84%d8%a9|السلة)/i.test(location.pathname)) activeTab = nav.querySelector('[data-tab=cart]');
	}
	if (header) header.querySelectorAll('a[data-tab=favorites]').forEach(function (a) { if (norm(a.href) === here) a.classList.add('is-active'); });
	var moreBtn = nav && nav.querySelector('[data-tab=more]');
	var centerBtn = nav && nav.querySelector('[data-tab=center]');
	function setActive(el) {
		if (!nav) return;
		nav.querySelectorAll('.dsh-tab,.dsh-center').forEach(function (t) { t.classList.toggle('is-active', t === el); t.removeAttribute('aria-current'); });
		if (el) el.setAttribute('aria-current', 'page');
	}
	function restoreActive() { setActive(activeTab); }
	restoreActive();

	/* ---------- panels ---------- */
	var open = null, lastFocus = null;
	function nameOf(p) { for (var k in panels) if (panels[k] === p) return k; return ''; }

	function show(panel, push) {
		if (!panel || open === panel) return;
		var swap = false;
		if (open) { hide(open, true); swap = true; }
		lastFocus = (d.activeElement && d.activeElement.hasAttribute && d.activeElement.hasAttribute('data-dsh-live')) ? null : d.activeElement;
		panel.hidden = false;
		html.classList.add('dsh-lock');
		requestAnimationFrame(function () { requestAnimationFrame(function () { panel.classList.add('is-open'); }); });
		open = panel;
		var n = nameOf(panel);
		if (n === 'more') setActive(moreBtn);
		if (n === 'services') setActive(centerBtn);
		if (push) {
			var st = {}, hs = history.state;
			if (hs && typeof hs === 'object') for (var hk in hs) if (hk !== 'dsh' && hk !== 'dnf') st[hk] = hs[hk];
			st.dsh = panel.id;
			try { history[swap && history.state && history.state.dsh ? 'replaceState' : 'pushState'](st, '', '#' + n); } catch (e) {}
		}
		if (n === 'explore') { setActive(centerBtn); initExplore(); return; }
		if (n === 'search') { openSearch(); return; }
		var f = panel.querySelector('a,button');
		if (f) try { f.focus({ preventScroll: true }); } catch (e) {}
	}
	function hide(panel, fromHistory) {
		if (!panel || panel.hidden) return;
		panel.classList.remove('is-open');
		html.classList.remove('dsh-lock');
		restoreActive();
		setTimeout(function () { if (!panel.classList.contains('is-open')) panel.hidden = true; }, 380);
		if (open === panel) open = null;
		if (!fromHistory && history.state && history.state.dsh === panel.id) { try { history.back(); } catch (e) {} }
		if (lastFocus && lastFocus.focus) try { lastFocus.focus({ preventScroll: true }); } catch (e) {}
	}
	window.DLZShellOpen = function (n) { if (panels[n]) show(panels[n], true); };

	d.addEventListener('click', function (e) {
		var t = e.target.closest('[data-dsh-open]');
		if (t) {
			var p = panels[t.getAttribute('data-dsh-open')];
			if (!p) return;
			e.preventDefault();
			if (open === p) hide(p, false); else show(p, true);
			return;
		}
		if (e.target.closest('[data-dsh-close]')) { e.preventDefault(); if (open) hide(open, false); return; }
		if (open && e.target === open && open.classList.contains('dsh-sheet')) { hide(open, false); return; }
		var tab = e.target.closest('.dsh-nav a');
		if (tab && open) { open.classList.remove('is-open'); html.classList.remove('dsh-lock'); }
	});
	/* «نفحات» viewer / comments sit above the shell and own the back button while open */
	function nafahatBusy() {
		var C = window.DLZChat;
		if (C && (C.isOpen() || Date.now() - (C.state.lastBack || 0) < 120)) return true; // the chat owns the back button while open
		var N = window.DLZNafahat;
		return !!(N && ((N.isOpen && N.isOpen()) || Date.now() - (N.lastBack || 0) < 80));
	}
	/* «دعوة الأصدقاء» → our share sheet: WhatsApp, Telegram, SMS, Facebook, e-mail, copy,
	   plus the phone's own share menu (every other messenger) when the browser has one. */
	var shareEl = d.getElementById('dsh-share'), shareData = { text: '', url: '' };
	function isIOS() { var ua = navigator.userAgent || ''; return /iPad|iPhone|iPod/.test(ua) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1); }
	var shareDef = shareEl ? { title: shareEl.querySelector('h3').textContent, sub: shareEl.querySelector('.dsh-share-sub').textContent } : {};
	function shareOpen(text, url, title, sub) {
		shareData = { text: text, url: url };
		if (!shareEl) { if (navigator.share) navigator.share({ text: text, url: url }).catch(function () {}); return; }
		shareEl.querySelector('h3').textContent = title || shareDef.title;
		shareEl.querySelector('.dsh-share-sub').textContent = sub || shareDef.sub;
		shareEl.querySelector('.dsh-share-msg span').textContent = text;
		shareEl.querySelector('.dsh-share-msg b').textContent = url;
		shareEl.querySelector('.dsh-share-msg span').hidden = !text;
		d.body.appendChild(shareEl);
		var more = shareEl.querySelector('[data-share=native]');
		if (more) more.hidden = !navigator.share;
		shareEl.hidden = false;
		requestAnimationFrame(function () { requestAnimationFrame(function () { shareEl.classList.add('is-open'); }); });
	}
	function shareClose() {
		if (!shareEl || shareEl.hidden) return;
		shareEl.classList.remove('is-open');
		setTimeout(function () { if (!shareEl.classList.contains('is-open')) shareEl.hidden = true; }, 320);
	}
	function copied(btn) {
		var em = btn.querySelector('em'), was = em ? em.textContent : '';
		if (em) em.textContent = 'تم النسخ ✓';
		btn.classList.add('is-done');
		setTimeout(function () { if (em) em.textContent = was; btn.classList.remove('is-done'); }, 1800);
	}
	function openUrl(u) {
		var w = null;
		try { w = window.open(u, '_blank'); } catch (e) {}
		if (w) { try { w.opener = null; } catch (e) {} } else location.href = u; // in-app WebViews block pop-ups: open in place
	}
	d.addEventListener('click', function (e) {
		var a = e.target.closest('[data-dsh-share]');
		if (a) {
			e.preventDefault();
			shareOpen(a.getAttribute('data-text') || '', a.getAttribute('data-url') || location.origin + '/');
			return;
		}
		if (!shareEl || shareEl.hidden) return;
		if (e.target.closest('[data-share-close]')) { shareClose(); return; }
		var b = e.target.closest('[data-share]');
		if (!b) return;
		var t = shareData.text, u = shareData.url, full = (t ? t + '\n' : '') + u, enc = encodeURIComponent(full), how = b.getAttribute('data-share');
		if (how === 'wa') openUrl('https://wa.me/?text=' + enc);
		else if (how === 'tg') openUrl('https://t.me/share/url?url=' + encodeURIComponent(u) + '&text=' + encodeURIComponent(t));
		else if (how === 'fb') openUrl('https://www.facebook.com/sharer/sharer.php?u=' + encodeURIComponent(u));
		else if (how === 'sms') location.href = (isIOS() ? 'sms:&body=' : 'sms:?body=') + enc;
		else if (how === 'mail') location.href = 'mailto:?subject=' + encodeURIComponent(d.title || '') + '&body=' + enc;
		else if (how === 'native' && navigator.share) navigator.share({ text: t, url: u }).catch(function () {});
		else if (how === 'copy') {
			var done = function () { copied(b); };
			if (navigator.clipboard && window.isSecureContext) navigator.clipboard.writeText(full).then(done, function () { legacyCopy(full); done(); });
			else { legacyCopy(full); done(); }
			return;
		}
		if (how !== 'copy') shareClose();
	});
	function legacyCopy(txt) {
		var ta = d.createElement('textarea');
		ta.value = txt; ta.setAttribute('readonly', ''); ta.style.cssText = 'position:fixed;top:0;left:0;opacity:0';
		d.body.appendChild(ta); ta.select();
		try { d.execCommand('copy'); } catch (e) {}
		ta.remove();
	}
	d.addEventListener('keydown', function (e) { if (e.key === 'Escape') shareClose(); });
	/* used by «نفحات» → «مشاركة» */
	window.DLZShare = function (o) { o = o || {}; shareOpen(o.text || '', o.url || location.href, o.title, o.sub); };
	window.addEventListener('popstate', function () {
		if (nafahatBusy()) return;
		if (open) hide(open, true);
	});
	d.addEventListener('keydown', function (e) {
		if (e.key !== 'Escape' || !open || nafahatBusy()) return;
		// a unified overlay (chat / info) on top closes first
		if (d.querySelector('.dlz-support-overlay.is-open,.dase-info-overlay.is-open,.dch.is-open')) return;
		hide(open, false);
	});

	/* ---------- «نفحات»: the Instagram-style Explore module mounts on first open ---------- */
	var ex = panels.explore;
	function initExplore() {
		if (!ex || ex.getAttribute('data-ready')) return;
		ex.setAttribute('data-ready', '1');
		if (window.DLZNafahat && window.DLZNafahat.mount) window.DLZNafahat.mount(ex);
	}

	var h = (location.hash || '').replace('#', '');
	if (h === 'nafahat') h = 'explore';
	if (panels[h] && h !== 'city') {
		try { history.replaceState(null, '', location.pathname + location.search); } catch (e) {}
		show(panels[h], true);
	}

	/* ---------- city: one global city for every module ---------- */
	if (panels.city) {
		panels.city.querySelectorAll('a[data-city]').forEach(function (a) {
			a.addEventListener('click', function (e) {
				e.preventDefault();
				var key = a.getAttribute('data-city');
				var label = (a.querySelector('span') || a).textContent.trim();
				panels.city.querySelectorAll('a[data-city]').forEach(function (x) { x.classList.remove('is-current'); });
				a.classList.add('is-current', 'is-loading');
				d.querySelectorAll('.dsh-city-name').forEach(function (n) { n.textContent = label; });
				store('dase_city', key);
				d.cookie = 'dase_city=' + encodeURIComponent(key) + ';path=/;max-age=31536000;SameSite=Lax';
				d.dispatchEvent(new CustomEvent('dase:cityChanged', { detail: { city: key } }));
				var u = new URL(location.href); u.searchParams.delete('dlz_city'); u.hash = '';
				setTimeout(function () { location.replace(u.toString()); }, 260);
			});
		});
	}

	/* ---------- cart badge (supermarket cart lives in localStorage) ---------- */
	var lastCart = -1;
	function cartCount() {
		var c = 0;
		try { var a = JSON.parse(store('dlz_sm_cart') || '[]'); if (Array.isArray(a)) a.forEach(function (x) { c += Math.max(0, +x.qty || 0); }); } catch (e) {}
		return c;
	}
	function paintBadge(sel, n) {
		d.querySelectorAll(sel).forEach(function (b) {
			var was = b.textContent;
			b.textContent = n > 99 ? '99+' : n;
			b.hidden = !n;
			if (n && was !== b.textContent && lastCart !== -1) { b.classList.remove('dsh-bump'); void b.offsetWidth; b.classList.add('dsh-bump'); }
		});
	}
	function syncCart() { var n = cartCount(); if (n !== lastCart) { paintBadge('.dsh-badge', n); lastCart = n; } }
	syncCart();
	window.addEventListener('storage', function (e) { if (!e.key || e.key === 'dlz_sm_cart') syncCart(); });
	setInterval(syncCart, 1500);
	d.addEventListener('visibilitychange', function () { if (!d.hidden) syncCart(); });

	/* ---------- favorites badge follows the unified toggle ---------- */
	function favBadge(n) { d.querySelectorAll('.dsh-fav-badge').forEach(function (b) { b.textContent = n; b.hidden = !n; b.classList.remove('dsh-bump'); void b.offsetWidth; b.classList.add('dsh-bump'); }); }
	d.addEventListener('dlz:favorite', function (e) { if (e.detail && typeof e.detail.count !== 'undefined') favBadge(e.detail.count); });
	if (window.jQuery) {
		window.jQuery(d).ajaxSuccess(function (ev, xhr, s) {
			if (!s || typeof s.data !== 'string' || s.data.indexOf('dlz_toggle_favorite') < 0) return;
			var r = xhr.responseJSON; if (!r) try { r = JSON.parse(xhr.responseText); } catch (e) {}
			if (r && r.success && r.data && typeof r.data.count !== 'undefined') {
				d.querySelectorAll('.dsh-fav-badge').forEach(function (b) { b.textContent = r.data.count; b.hidden = !r.data.count; b.classList.remove('dsh-bump'); void b.offsetWidth; b.classList.add('dsh-bump'); });
			}
		});
	}

	/* ---------- live search ---------- */
	var finder = panels.search, fInput, fBody, fClear, timer = null, ctrl = null, lastQ = '';
	var headInput = header && header.querySelector('.dsh-search input[data-dsh-live]');
	if (finder) {
		fInput = finder.querySelector('input[type=search]');
		fBody = finder.querySelector('.dsh-find-body');
		fClear = finder.querySelector('.dsh-find-clear');
		if (headInput) {
			headInput.setAttribute('readonly', 'readonly');
			var go = function (e) { e.preventDefault(); show(finder, true); };
			headInput.addEventListener('click', go);
			headInput.addEventListener('focus', go);
			var hf = headInput.form; if (hf) hf.addEventListener('submit', go);
		}
		fInput.addEventListener('input', function () {
			var q = fInput.value.trim();
			fClear.hidden = !fInput.value;
			clearTimeout(timer);
			if (q.length < 2) { lastQ = ''; if (ctrl) ctrl.abort(); renderHome(q); return; }
			timer = setTimeout(function () { run(q); }, 260);
		});
		fClear.addEventListener('click', function () { fInput.value = ''; fClear.hidden = true; renderHome(''); fInput.focus(); });
		finder.querySelector('form').addEventListener('submit', function (e) {
			var q = fInput.value.trim();
			if (q.length < 2) { e.preventDefault(); return; }
			remember(q);
		});
		fBody.addEventListener('click', function (e) {
			var chip = e.target.closest('[data-q]');
			if (chip) { e.preventDefault(); fInput.value = chip.getAttribute('data-q'); fClear.hidden = false; run(fInput.value.trim()); return; }
			if (e.target.closest('[data-clear-recent]')) { store('dlz_recent_q', '[]'); renderHome(''); return; }
			var row = e.target.closest('.dsh-frow[data-toggle]');
			if (row) {
				e.preventDefault();
				var it = row.parentNode, was = it.classList.contains('is-open');
				fBody.querySelectorAll('.dsh-fitem.is-open').forEach(function (x) { x.classList.remove('is-open'); });
				if (!was) it.classList.add('is-open');
				row.setAttribute('aria-expanded', was ? 'false' : 'true');
				return;
			}
			if (e.target.closest('a[href]') && lastQ) remember(lastQ);
		});
	}
	function openSearch() {
		if (!finder) return;
		renderHome(fInput.value.trim());
		try { fInput.focus({ preventScroll: true }); } catch (e) { fInput.focus(); }
		if (fInput.value.trim().length >= 2) run(fInput.value.trim());
	}
	function recent() { try { var a = JSON.parse(store('dlz_recent_q') || '[]'); return Array.isArray(a) ? a : []; } catch (e) { return []; } }
	function remember(q) { var a = recent().filter(function (x) { return x !== q; }); a.unshift(q); store('dlz_recent_q', JSON.stringify(a.slice(0, 8))); }
	function matchServices(q) {
		var s = cfg.services || [];
		if (!q) return s;
		q = q.toLowerCase();
		return s.filter(function (x) { return (x.label + ' ' + (x.kw || '')).toLowerCase().indexOf(q) >= 0; });
	}
	function serviceChips(list) {
		return list.map(function (x) { return '<a class="dsh-chip" href="' + esc(x.url) + '">' + ic(x.icon) + esc(x.label) + '</a>'; }).join('');
	}
	function renderHome(q) {
		var r = recent(), out = '';
		if (r.length) {
			out += '<div class="dsh-fh"><span>' + esc(T.recent) + '</span><button type="button" data-clear-recent>' + esc(T.clear) + '</button></div><div class="dsh-chips">'
				+ r.map(function (x) { return '<button type="button" class="dsh-chip" data-q="' + esc(x) + '">' + ic('clock') + esc(x) + '</button>'; }).join('') + '</div>';
		}
		var sv = matchServices(q);
		if (sv.length) out += '<div class="dsh-fh"><span>' + esc(T.services) + '</span></div><div class="dsh-chips">' + serviceChips(sv) + '</div>';
		fBody.innerHTML = out;
	}
	function hl(text, q) {
		var t = esc(text); if (!q) return t;
		var i = String(text).toLowerCase().indexOf(q.toLowerCase());
		if (i < 0) return t;
		return esc(text.slice(0, i)) + '<mark>' + esc(text.slice(i, i + q.length)) + '</mark>' + esc(text.slice(i + q.length));
	}
	function run(q) {
		if (!cfg.live || q === lastQ) return;
		lastQ = q;
		if (ctrl) ctrl.abort();
		ctrl = window.AbortController ? new AbortController() : null;
		var sv = matchServices(q);
		fBody.innerHTML = (sv.length ? '<div class="dsh-fh"><span>' + esc(T.services) + '</span></div><div class="dsh-chips">' + serviceChips(sv) + '</div>' : '') + '<div class="dsh-fload">' + esc(T.loading) + '</div>';
		var body = new FormData();
		body.append('action', 'dlz_shell_search'); body.append('nonce', cfg.nonce || ''); body.append('q', q);
		fetch(cfg.ajax, { method: 'POST', body: body, credentials: 'same-origin', signal: ctrl ? ctrl.signal : undefined })
			.then(function (r) { return r.json(); })
			.then(function (r) {
				if (q !== lastQ) return;
				var groups = (r && r.success && r.data && r.data.groups) || [];
				var out = sv.length ? '<div class="dsh-fh"><span>' + esc(T.services) + '</span></div><div class="dsh-chips">' + serviceChips(sv) + '</div>' : '';
				groups.forEach(function (g, gi) {
					out += '<section class="dsh-fgroup" style="animation-delay:' + (gi * 50) + 'ms"><div class="dsh-fh"><span>' + esc(g.label) + '</span></div><div class="dsh-fres">';
					g.items.forEach(function (it) {
						var hasDet = it.desc || it.phone || it.wa || it.map;
						var thumb = '<span class="dsh-fthumb">' + (it.img ? '<img src="' + esc(it.img) + '" alt="" loading="lazy">' : ic(g.icon)) + '</span>';
						var sub = (it.here ? '<span class="dsh-here">📍 ' + esc(it.sub) + '</span>' : esc(it.sub || ''));
						var txt = '<span class="dsh-ftxt"><b>' + hl(it.title, q) + '</b>' + (sub ? '<small>' + sub + '</small>' : '') + '</span>';
						out += '<div class="dsh-fitem">';
						if (hasDet) {
							out += '<button type="button" class="dsh-frow" data-toggle aria-expanded="false">' + thumb + txt + ic('chev') + '</button><div class="dsh-fdet">'
								+ (it.desc ? '<p>' + esc(it.desc) + '</p>' : '') + '<div class="dsh-facts">'
								+ (it.phone ? '<a class="dsh-fact is-call" href="tel:' + esc(String(it.phone).replace(/[^\d+]/g, '')) + '">' + ic('phone') + esc(T.call) + '</a>' : '')
								+ (it.wa ? '<a class="dsh-fact is-wa" href="https://wa.me/' + esc(it.wa) + '" target="_blank" rel="noopener">' + ic('whatsapp') + esc(T.wa) + '</a>' : '')
								+ (it.map ? '<a class="dsh-fact" href="' + esc(it.map) + '" target="_blank" rel="noopener">' + ic('map') + esc(T.map) + '</a>' : '')
								+ (it.url ? '<a class="dsh-fact is-open" href="' + esc(it.url) + '">' + ic('external') + esc(T.open) + '</a>' : '')
								+ '</div></div>';
						} else {
							out += '<a class="dsh-frow" href="' + esc(it.url || '#') + '">' + thumb + txt + ic('chev') + '</a>';
						}
						out += '</div>';
					});
					out += '</div></section>';
				});
				if (!groups.length && !sv.length) out += '<div class="dsh-fempty">' + ic('search') + esc(T.empty) + '</div>';
				if (r && r.data && r.data.all) out += '<a class="dsh-fall" href="' + esc(r.data.all) + '">' + ic('search') + esc(T.all) + '</a>';
				fBody.innerHTML = out;
			})
			.catch(function (err) { if (err && err.name === 'AbortError') return; fBody.innerHTML = '<div class="dsh-fempty">' + ic('search') + esc(T.empty) + '</div>'; lastQ = ''; });
	}
})();
