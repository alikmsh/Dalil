/* Dalil Al Zaer — «حجوزاتي» / «طلباتي»: category tabs + supermarket cart reminder */
(function () {
	'use strict';
	var d = document;
	/* pull the block up under the app header when only empty theme / Elementor spacing sits above it */
	var lift = window.DLZLift || (window.DLZLift = function (root) {
		if (!root || root.__lift) return;
		root.__lift = 1;
		var pt = d.querySelector('.dlz-ptitle'), hd = pt && pt.offsetHeight ? pt : d.getElementById('dsh-header'), ab = d.getElementById('wpadminbar'); // under the page title when there is one
		var y = window.scrollY || 0, ref = 0;
		if (hd && hd.offsetHeight) ref = getComputedStyle(hd).position === 'fixed' ? hd.offsetHeight : hd.getBoundingClientRect().bottom + y;
		else if (ab && getComputedStyle(ab).position === 'fixed') ref = ab.offsetHeight;
		var gap = root.getBoundingClientRect().top + y - ref - 10;
		if (gap < 6 || gap > 420) return;
		var w = d.createTreeWalker(d.body, NodeFilter.SHOW_ELEMENT), el;
		while ((el = w.nextNode())) {
			if (el === root) break;
			if (el.contains(root) || (hd && (el === hd || hd.contains(el))) || /^(SCRIPT|STYLE|LINK|META|NOSCRIPT|TEMPLATE)$/.test(el.tagName)) continue;
			var r = el.getBoundingClientRect();
			if (r.width < 2 || r.height < 2 || r.bottom + y <= ref) continue;
			var cs = getComputedStyle(el);
			if (cs.visibility === 'hidden' || cs.position === 'fixed' || cs.position === 'absolute' || +cs.opacity === 0) continue;
			if (/^(IMG|SVG|svg|VIDEO|IFRAME|INPUT|BUTTON|CANVAS|SELECT|TEXTAREA)$/.test(el.tagName) || [].some.call(el.childNodes, function (n) { return n.nodeType === 3 && n.textContent.trim(); })) return;
		}
		root.style.marginTop = (-gap) + 'px';
	});
	function init(root) {
		if (root.__dmy) return;
		root.__dmy = 1;
		var tabs = root.querySelectorAll('.dmy-tab'), cards = root.querySelectorAll('.dmy-card');
		function show(cat) {
			var n = 0;
			tabs.forEach(function (t) { var on = t.getAttribute('data-cat') === cat; t.classList.toggle('is-on', on); t.setAttribute('aria-selected', on ? 'true' : 'false'); });
			cards.forEach(function (c) { var on = cat === 'all' || c.getAttribute('data-cat') === cat; c.hidden = !on; if (on) n++; });
			root.querySelectorAll('.dmy-empty[data-for]').forEach(function (e) { e.hidden = !(n === 0 && e.getAttribute('data-for') === cat); });
			try { history.replaceState(history.state, '', cat === 'all' ? location.pathname + location.search : '#' + cat); } catch (e) {}
		}
		tabs.forEach(function (t) {
			t.addEventListener('click', function () {
				show(t.getAttribute('data-cat'));
				t.scrollIntoView({ inline: 'center', block: 'nearest', behavior: 'smooth' });
			});
		});
		var h = (location.hash || '').slice(1);
		if (h && root.querySelector('.dmy-tab[data-cat="' + h.replace(/[^a-z]/g, '') + '"]')) show(h.replace(/[^a-z]/g, ''));

		var cart = root.querySelector('.dmy-cart');
		if (cart) {
			var c = 0;
			try { var a = JSON.parse(localStorage.getItem('dlz_sm_cart') || '[]'); if (Array.isArray(a)) a.forEach(function (x) { c += Math.max(0, +x.qty || 0); }); } catch (e) {}
			if (c > 0) { cart.querySelector('.dmy-cart-n').textContent = c; cart.hidden = false; }
		}
	}
	function boot() { d.querySelectorAll('.dmy').forEach(function (r) { init(r); if (d.querySelectorAll('.dmy').length === 1) lift(r); }); }
	if (d.readyState === 'loading') d.addEventListener('DOMContentLoaded', boot); else boot();
})();
