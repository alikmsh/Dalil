/* Dalil Al Zaer — «الملف الشخصي» */
(function () {
	'use strict';
	var C = window.DLZProfile || {}, T = C.i18n || {}, CT = C.countries || {}, d = document;

	function esc(v) { var x = d.createElement('div'); x.textContent = v == null ? '' : String(v); return x.innerHTML.replace(/"/g, '&quot;').replace(/'/g, '&#39;'); }
	/** Persian / Arabic-Indic digits → 0-9 */
	function latin(s) {
		return String(s || '').replace(/[۰-۹]/g, function (c) { return c.charCodeAt(0) - 0x06F0; })
			.replace(/[٠-٩]/g, function (c) { return c.charCodeAt(0) - 0x0660; });
	}
	/** Same markup as DLZ_Countries::flag() */
	function flag(key, wave, cls) {
		if (!CT[key]) return '';
		var use = '<svg viewBox="0 0 300 200" preserveAspectRatio="none" focusable="false"><use href="#dlzf-' + key + '"/></svg>';
		if (!wave) return '<span class="dlzf is-still ' + (cls || '') + '" data-flag="' + key + '" aria-hidden="true">' + use + '</span>';
		var n = 12, h = '<span class="dlzf ' + (cls || '') + '" data-flag="' + key + '" style="--n:' + n + '" aria-hidden="true">';
		for (var i = 0; i < n; i++) h += '<i style="--i:' + i + ';--k:' + (0.25 + 0.75 * i / (n - 1)).toFixed(2) + '">' + use + '</i>';
		return h + '</span>';
	}

	/* bottom sheets: moved to <body> so no transformed page-builder column traps them */
	function Sheet(el) {
		var self = this;
		this.el = el;
		this.open = function () {
			d.body.appendChild(el);
			el.hidden = false;
			d.documentElement.classList.add('dpf-lock');
			requestAnimationFrame(function () { requestAnimationFrame(function () { el.classList.add('is-open'); }); });
		};
		this.close = function () {
			el.classList.remove('is-open');
			d.documentElement.classList.remove('dpf-lock');
			setTimeout(function () { if (!el.classList.contains('is-open')) el.hidden = true; }, 320);
		};
		el.querySelector('.dpf-sheet-bd').addEventListener('click', function () { self.close(); });
		d.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !el.hidden) self.close(); });
	}

	function init(root) {
		if (!root || root.__dpf) return;
		root.__dpf = 1;
		var form = root.querySelector('.dpf-form'), toastEl = root.querySelector('.dpf-toast'), tT;
		d.body.appendChild(toastEl);

		function toast(msg, err) {
			toastEl.textContent = msg;
			toastEl.classList.toggle('is-err', !!err);
			toastEl.classList.add('is-on');
			clearTimeout(tT);
			tT = setTimeout(function () { toastEl.classList.remove('is-on'); }, 2600);
		}
		function setErr(key, msg) {
			var f = root.querySelector('.dpf-f[data-f="' + key + '"]');
			if (!f) return;
			var p = f.querySelector('.dpf-err');
			f.classList.toggle('is-err', !!msg);
			if (p) { p.textContent = msg || ''; p.hidden = !msg; }
		}

		/* back */
		root.querySelector('.dpf-back').addEventListener('click', function () {
			if (history.length > 1 && d.referrer && d.referrer.indexOf(location.host) > -1) history.back();
			else location.href = '/';
		});

		/* avatar */
		var av = root.querySelector('.dpf-av'), file = root.querySelector('.dpf-file');
		root.querySelector('.dpf-cam').addEventListener('click', function () { file.click(); });
		av.querySelector('.dpf-av-ring').addEventListener('click', function () { file.click(); });
		file.addEventListener('change', function () {
			var f = file.files && file.files[0];
			if (!f) return;
			var inner = av.querySelector('.dpf-av-in'), url = URL.createObjectURL(f);
			inner.innerHTML = '<img src="' + url + '" alt="">';
			av.classList.add('is-busy');
			toast(T.photo);
			var body = new FormData();
			body.append('action', 'mp_upload_avatar');
			body.append('nonce', C.mpNonce);
			body.append('avatar', f);
			fetch(C.ajax, { method: 'POST', body: body, credentials: 'same-origin' }).then(function (r) { return r.json(); }).then(function (r) {
				av.classList.remove('is-busy');
				if (r && r.success) { toast(T.photoOk); d.querySelectorAll('.dsh-avatar').forEach(function (i) { if (i.tagName === 'IMG') i.src = r.data.url; });
					var acc = d.querySelector('.dsm-l-acc');
					var ic = acc && acc.parentNode.querySelector('.dsm-ic');
					if (ic && !ic.querySelector('img')) ic.innerHTML = '<span class="dsm-av"><img class="dsh-avatar" src="' + esc(r.data.url) + '" alt=""></span>'; }
				else toast((r && r.data && r.data.message) || T.failed, true);
			}).catch(function () { av.classList.remove('is-busy'); toast(T.failed, true); });
			file.value = '';
		});

		/* clear errors while typing */
		['name', 'gender'].forEach(function (k) {
			var el = form.elements[k];
			if (el) el.addEventListener(el.tagName === 'SELECT' ? 'change' : 'input', function () { setErr(k, ''); });
		});

		/* digit-only fields (Persian / Arabic keyboards type their own digits) */
		function keepCaret(el, fn) {
			var v = el.value, p = el.selectionStart, nv = fn(v);
			if (nv === v) return;
			var before = fn(v.slice(0, p == null ? v.length : p)).length;
			el.value = nv;
			try { el.setSelectionRange(before, before); } catch (e) {}
		}
		var pass = form.elements.passport, intl = form.elements.intl, comp = form.elements.companions;
		pass.addEventListener('input', function () { keepCaret(pass, function (v) { return latin(v).toUpperCase().replace(/[^A-Z0-9]/g, ''); }); });
		comp.addEventListener('input', function () { keepCaret(comp, function (v) { return latin(v).replace(/\D/g, '').slice(0, 2); }); });
		intl.addEventListener('input', function () {
			var v = latin(intl.value).replace(/[^\d+]/g, '');
			// a full international number pasted / typed with its code → move the code to the prefix button
			var m = /^(?:\+|00)(\d+)/.exec(v);
			if (m) {
				var all = m[1];
				Object.keys(CT).some(function (k) {
					var dc = CT[k].dial.slice(1);
					if (all.indexOf(dc) === 0) { setPrefix(k, true); v = all.slice(dc.length); return true; }
					return false;
				});
			}
			keepCaret(intl, function () { return v.replace(/\D/g, ''); });
		});

		/* ---------- country ---------- */
		var cIn = form.elements.country, cBtn = root.querySelector('.dpf-pick'), cs = new Sheet(root.querySelector('.dpf-cs')), csEl = cs.el;
		var kIn = form.elements.intl_key, pBtn = root.querySelector('.dpf-pre'), ps = new Sheet(root.querySelector('.dpf-ps')), psEl = ps.el;

		function setPrefix(k, manual) {
			if (!CT[k]) return;
			kIn.value = k;
			if (manual) kIn.setAttribute('data-set', '1');
			pBtn.querySelector('.dpf-pre-flag').innerHTML = flag(k, false, 'dpf-sflag');
			pBtn.querySelector('b').textContent = CT[k].dial;
			psEl.querySelectorAll('.dpf-pc').forEach(function (b) { b.classList.toggle('is-on', b.getAttribute('data-key') === k); });
		}
		function setCountry(k) {
			if (!CT[k]) return;
			cIn.value = k;
			cBtn.querySelector('.dpf-pick-flag').innerHTML = flag(k, true, 'dpf-fflag');
			cBtn.querySelector('.dpf-pick-t').textContent = CT[k].name;
			root.querySelector('.dpf-title-flag').innerHTML = flag(k, true, 'dpf-tflag');
			csEl.querySelectorAll('.dpf-cc').forEach(function (b) {
				var on = b.getAttribute('data-key') === k;
				b.classList.toggle('is-on', on);
				b.setAttribute('aria-pressed', on ? 'true' : 'false');
			});
			setErr('country', '');
			if (window.dlzCurCountry) window.dlzCurCountry(k);
			// the international code follows the country until the visitor picks another one himself
			if (kIn.getAttribute('data-set') !== '1' || !intl.value) setPrefix(k, false);
		}
		cBtn.addEventListener('click', function () {
			cs.open();
			var on = csEl.querySelector('.dpf-cc.is-on');
			if (on) setTimeout(function () { on.scrollIntoView({ block: 'center' }); }, 40);
		});
		csEl.addEventListener('click', function (e) {
			var b = e.target.closest('.dpf-cc');
			if (!b) return;
			setCountry(b.getAttribute('data-key'));
			setTimeout(cs.close, 180);
		});
		pBtn.addEventListener('click', ps.open);
		psEl.addEventListener('click', function (e) {
			var b = e.target.closest('.dpf-pc');
			if (!b) return;
			setPrefix(b.getAttribute('data-key'), true);
			setTimeout(function () { ps.close(); intl.focus({ preventScroll: true }); }, 160);
		});
		/* «العملة المفضلة» — opens under the field, saved the moment it is picked */
		var curBtn = root.querySelector('.dpf-cur-btn'), pop = root.querySelector('.dpf-cur-pop');
		if (curBtn && pop) {
			var curIn = form.elements.currency;
			curBtn.parentNode.parentNode.parentNode.insertBefore(pop, curBtn.parentNode.parentNode.nextSibling);
			function curOpen(on) { pop.hidden = !on; curBtn.setAttribute('aria-expanded', on ? 'true' : 'false'); root.querySelector('.dpf-f-cur').classList.toggle('is-open', on); if (on) setTimeout(function () { pop.scrollIntoView({ behavior: 'smooth', block: 'nearest' }); }, 30); }
			curBtn.addEventListener('click', function () { curOpen(pop.hidden); });
			pop.querySelector('.dpf-cur-more').addEventListener('click', function () { var r = pop.querySelector('.dpf-cur-rest'); r.hidden = !r.hidden; this.classList.toggle('is-open', !r.hidden); });
			pop.addEventListener('click', function (e) {
				var o = e.target.closest('.dpf-cur-o'); if (!o) return;
				var c = o.getAttribute('data-c');
				pop.querySelectorAll('.dpf-cur-o').forEach(function (b) { var on = b === o; b.classList.toggle('is-on', on); b.setAttribute('aria-selected', on ? 'true' : 'false'); });
				curIn.value = c;
				curBtn.querySelector('.dpf-cur-s').textContent = o.querySelector('.dpf-cur-s').textContent;
				curBtn.querySelector('.dpf-pick-t').textContent = o.querySelector('.dpf-cur-n').firstChild.textContent.trim();
				setTimeout(function () { curOpen(false); }, 160);
				var b = new FormData(); b.append('action', 'dlz_set_currency'); b.append('nonce', C.curNonce || ''); b.append('currency', c);
				fetch(C.ajax, { method: 'POST', body: b, credentials: 'same-origin' }).then(function (r) { return r.json(); }).then(function (r) {
					if (r && r.success) toast((T.curOk || '') + ' ' + r.data.name); else toast(T.failed, true);
				}).catch(function () { toast(T.failed, true); });
			});
			d.addEventListener('click', function (e) { if (!pop.hidden && !e.target.closest('.dpf-cur-pop,.dpf-cur-btn')) curOpen(false); });
			/* the currency of the chosen country is the third choice, after the dollar and the euro */
			window.dlzCurCountry = function (k) {
				var c = (C.curMap || {})[k], o = c && pop.querySelector('.dpf-cur-o[data-c="' + c + '"]'), main = pop.querySelector('.dpf-cur-main'), rest = pop.querySelector('.dpf-cur-rest');
				if (!o) return;
				main.querySelectorAll('.dpf-cur-o').forEach(function (b, i) { if (i > 1 && b !== o) rest.insertBefore(b, rest.firstChild); });
				if (o.parentNode !== main) main.appendChild(o);
			};
		}

		/* after the name, go straight to the country */
		var nameIn = form.elements.name;
		nameIn.addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); nameIn.blur(); if (!cIn.value) cBtn.click(); } });
		nameIn.addEventListener('change', function () { if (!cIn.value && nameIn.value.trim().length > 2) setTimeout(function () { cBtn.focus({ preventScroll: true }); }, 60); });

		/* save */
		var btn = form.querySelector('.dpf-save'), label = btn.querySelector('span'), idle = label.textContent;
		form.addEventListener('submit', function (e) {
			e.preventDefault();
			var name = nameIn.value.trim(), ok = true;
			if (name.length < 3) { setErr('name', T.name); ok = false; }
			if (!cIn.value) { setErr('country', T.country); ok = false; }
			if (!form.elements.gender.value) { setErr('gender', T.gender); ok = false; }
			if (!ok) {
				var first = root.querySelector('.dpf-f.is-err');
				if (first) { first.scrollIntoView({ behavior: 'smooth', block: 'center' }); var i = first.querySelector('input:not([type=hidden]),select,button'); if (i) setTimeout(function () { i.focus({ preventScroll: true }); }, 300); }
				return;
			}
			btn.disabled = true;
			label.textContent = T.saving;
			var body = new FormData();
			body.append('action', 'dlz_profile_save');
			body.append('nonce', C.nonce);
			['name', 'country', 'passport', 'intl_key', 'intl', 'gender', 'companions', 'currency'].forEach(function (k) { body.append(k, form.elements[k] ? latin(form.elements[k].value) : ''); });
			fetch(C.ajax, { method: 'POST', body: body, credentials: 'same-origin' }).then(function (r) { return r.json(); }).then(function (r) {
				if (r && r.success) {
					root.querySelector('.dpf-name').textContent = r.data.name;
					var note = root.querySelector('.dpf-note');
					if (note) note.remove();
					d.querySelectorAll('.dsm-card-flag').forEach(function (s) { s.innerHTML = flag(r.data.country, true, 'dsm-flag'); });
					d.querySelectorAll('.dsm-acc-t').forEach(function (t) { t.innerHTML = '<span class="dsm-acc-n">' + esc(r.data.name) + '</span><small>حسابي</small>'; });
					toast(r.data.first ? T.savedNew : T.saved);
				} else if (r && r.data && r.data.fields) {
					Object.keys(r.data.fields).forEach(function (k) { setErr(k, r.data.fields[k]); });
				} else {
					toast((r && r.data && r.data.message) || T.failed, true);
				}
			}).catch(function () { toast(T.failed, true); }).then(function () { btn.disabled = false; label.textContent = idle; });
		});
	}

	/* The app header is hidden on this page: pull the page up to the top of the screen
	   over the empty space themes / page builders leave above the content (never over real content). */
	function lift(root) {
		if (d.querySelectorAll('.dpf').length !== 1) return;
		root.style.marginTop = '';
		var ab = d.getElementById('wpadminbar'), abh = ab && getComputedStyle(ab).position === 'fixed' ? ab.offsetHeight : 0;
		var top = root.getBoundingClientRect().top + (window.scrollY || 0) - abh;
		if (top <= 1 || top > 260) return;
		var w = d.createTreeWalker(d.body, NodeFilter.SHOW_ELEMENT), el, blocked = false;
		while ((el = w.nextNode())) {
			if (el === root) break;
			if (el.contains(root) || /^(SCRIPT|STYLE|LINK|META|NOSCRIPT|TEMPLATE)$/.test(el.tagName)) continue;
			var r = el.getBoundingClientRect();
			if (r.width < 2 || r.height < 2) continue;
			var cs = getComputedStyle(el);
			if (cs.visibility === 'hidden' || cs.position === 'fixed' || +cs.opacity === 0) continue;
			var real = /^(IMG|SVG|svg|VIDEO|IFRAME|INPUT|BUTTON|CANVAS)$/.test(el.tagName) || [].some.call(el.childNodes, function (n) { return n.nodeType === 3 && n.textContent.trim(); });
			if (real) { blocked = true; break; }
		}
		if (!blocked) root.style.marginTop = (-top) + 'px';
	}

	function boot() { d.querySelectorAll('.dpf').forEach(function (r) { init(r); lift(r); }); }
	if (d.readyState === 'loading') d.addEventListener('DOMContentLoaded', boot); else boot();
	window.addEventListener('elementor/frontend/init', boot);
})();
