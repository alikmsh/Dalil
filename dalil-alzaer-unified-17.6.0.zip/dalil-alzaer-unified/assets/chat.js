/* Dalil Al Zaer — «الدعم» live support chat (green & gold, text / voice / photo) */
(function () {
	'use strict';
	var cfg = window.DLZSupport || {}, d = document, html = d.documentElement;
	var ICON = {
		back: '<path d="m15 5-7 7 7 7"/>',
		more: '<circle cx="12" cy="5.5" r="1.6" fill="currentColor" stroke="none"/><circle cx="12" cy="12" r="1.6" fill="currentColor" stroke="none"/><circle cx="12" cy="18.5" r="1.6" fill="currentColor" stroke="none"/>',
		clip: '<path d="m20 11.5-7.6 7.6a5 5 0 0 1-7.1-7.1l8.1-8.1a3.3 3.3 0 0 1 4.7 4.7l-8.1 8.1a1.7 1.7 0 0 1-2.4-2.4l7.4-7.4"/>',
		wave: '<path d="M4 10v4M8 7v10M12 4v16M16 7v10M20 10v4"/>',
		send: '<path d="M21 3 10.2 13.8M21 3l-6.8 18-4-7.2L3 9.8z"/>',
		trash: '<path d="M4.5 7h15M9.5 7V4.8h5V7M6.5 7l.9 12.2a1.6 1.6 0 0 0 1.6 1.5h6a1.6 1.6 0 0 0 1.6-1.5L17.5 7M10 11v6M14 11v6"/>',
		user: '<circle cx="12" cy="8.5" r="3.8"/><path d="M4.8 20c.8-3.8 3.6-6 7.2-6s6.4 2.2 7.2 6"/>',
		wa: '<path d="M12 3.1a8.9 8.9 0 0 0-7.7 13.3L3.1 20.9l4.6-1.2A8.9 8.9 0 1 0 12 3.1z"/><path d="M8.9 8.1c.3-.5.8-.6 1.1-.2l1.1 1.2c.3.3.3.7 0 1l-.5.6c.7 1.4 1.8 2.5 3.2 3.2l.6-.5c.3-.3.7-.3 1 0l1.2 1.1c.4.3.3.8-.2 1.1-.7.6-1.6.9-2.4.6-2.5-.9-4.5-2.9-5.4-5.4-.3-.8 0-1.7.3-2.5z" fill="currentColor" stroke="none"/>',
		refresh: '<path d="M20 11a8 8 0 0 0-14.3-4.9L4 8M4 4v4h4M4 13a8 8 0 0 0 14.3 4.9L20 16M20 20v-4h-4"/>',
		close: '<path d="M6 6l12 12M18 6 6 18"/>',
		checks: '<path d="m2.5 12.5 4 4L15 8M10 15.5l1 1L19.5 8"/>',
		clock: '<circle cx="12" cy="12" r="8"/><path d="M12 7.5V12l3 2"/>',
		play: '<path d="M8 5.5v13l10.5-6.5z" fill="currentColor"/>',
		pause: '<path d="M8.5 5.5v13M15.5 5.5v13" stroke-width="3.2"/>'
	};
	function ic(n, cls) { return '<svg class="dch-i ' + (cls || '') + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (ICON[n] || '') + '</svg>'; }
	function esc(v) { var x = d.createElement('div'); x.textContent = v == null ? '' : String(v); return x.innerHTML.replace(/"/g, '&quot;').replace(/'/g, '&#39;'); }
	function linkify(t) { return esc(t).replace(/(https?:\/\/[^\s<"']+)/g, '<a href="$1" target="_blank" rel="noopener nofollow">$1</a>').replace(/\n/g, '<br>'); }
	function fail(r, fallback) {
		if (r && r.data && r.data.code === 'login_required') { location.href = r.data.redirect || cfg.login || '/'; return; }
		toast((r && r.data && r.data.message) || fallback, true);
	}
	function request(data) {
		data.append('nonce', cfg.nonce);
		return fetch(cfg.ajax, { method: 'POST', body: data, credentials: 'same-origin', cache: 'no-store' }).then(function (r) {
			return r.text().then(function (t) { try { return JSON.parse(t); } catch (e) { throw new Error('تعذّر الاتصال بالخادم، حاول مرة أخرى.'); } });
		});
	}

	/* stylesheet on first open only — nothing extra on page load */
	var cssReady = null;
	function loadCss() {
		if (cssReady) return cssReady;
		cssReady = new Promise(function (res) {
			if (d.getElementById('dlz-chat-css')) return res();
			var l = d.createElement('link');
			l.id = 'dlz-chat-css'; l.rel = 'stylesheet'; l.href = cfg.css;
			l.onload = l.onerror = function () { res(); };
			d.head.appendChild(l);
			setTimeout(res, 2500);
		});
		return cssReady;
	}

	var root = null, box = null, input = null, rec = null, recTimer = null, recStart = 0, lastDate = '', poll = null, toastT = null, state = { lastBack: 0 };

	function build() {
		root = d.createElement('div');
		root.className = 'dch';
		root.setAttribute('dir', 'rtl');
		root.setAttribute('role', 'dialog');
		root.setAttribute('aria-modal', 'true');
		root.setAttribute('aria-label', 'الدعم');
		root.innerHTML =
			'<div class="dch-frame">' +
			'<header class="dch-head">' +
				'<div class="dch-menu-w"><button type="button" class="dch-hbtn dch-menu-btn" aria-label="خيارات" aria-haspopup="menu">' + ic('more') + '</button>' +
				'<div class="dch-menu" role="menu" hidden>' +
					(cfg.whatsapp ? '<a role="menuitem" href="' + esc(cfg.whatsapp) + '" target="_blank" rel="noopener">' + ic('wa') + 'تواصل عبر واتساب</a>' : '') +
					'<button type="button" role="menuitem" data-act="refresh">' + ic('refresh') + 'تحديث المحادثة</button>' +
					'<button type="button" role="menuitem" data-act="close">' + ic('close') + 'إغلاق</button>' +
				'</div></div>' +
				'<div class="dch-title"><b>' + esc(cfg.brand || 'دليل الزائر') + '</b><small><i class="dch-online"></i>الدعم المباشر · نرد عليك في أقرب وقت</small></div>' +
				'<span class="dch-logo">' + (cfg.logo || '') + '</span>' +
				'<button type="button" class="dch-hbtn dch-back" aria-label="رجوع">' + ic('back') + '</button>' +
			'</header>' +
			'<div class="dch-body" aria-live="polite"><div class="dch-loading"><i></i><i></i><i></i></div></div>' +
			'<footer class="dch-foot">' +
				'<form class="dch-form" autocomplete="off">' +
					'<button type="submit" class="dch-send" aria-label="إرسال">' + ic('send') + '</button>' +
					'<button type="button" class="dch-mic" aria-label="رسالة صوتية">' + ic('wave') + '</button>' +
					'<textarea class="dch-input" rows="1" placeholder="اكتب رسالتك..." aria-label="اكتب رسالتك" maxlength="2000"></textarea>' +
					'<button type="button" class="dch-attach" aria-label="إرسال صورة">' + ic('clip') + '</button>' +
					'<input class="dch-file" type="file" accept="image/jpeg,image/png,image/webp,image/gif" hidden>' +
				'</form>' +
				'<div class="dch-rec" hidden>' +
					'<button type="button" class="dch-rec-send" aria-label="إنهاء وإرسال">' + ic('send') + '<span>إرسال</span></button>' +
					'<span class="dch-rec-info"><i class="dch-rec-dot"></i><b class="dch-rec-time">00:00</b><small>جارٍ التسجيل…</small></span>' +
					'<button type="button" class="dch-rec-cancel" aria-label="حذف التسجيل">' + ic('trash') + '</button>' +
				'</div>' +
			'</footer>' +
			'<div class="dch-toast" role="status"></div>' +
			'</div>' +
			'<div class="dch-viewer" hidden><img alt=""><button type="button" class="dch-viewer-x" aria-label="إغلاق">' + ic('close') + '</button></div>';
		d.body.appendChild(root);
		box = root.querySelector('.dch-body');
		box.addEventListener('scroll', function () { stick = box.scrollHeight - box.scrollTop - box.clientHeight < 120; }, { passive: true });
		input = root.querySelector('.dch-input');
		var form = root.querySelector('.dch-form'), file = root.querySelector('.dch-file'), menu = root.querySelector('.dch-menu'), mbtn = root.querySelector('.dch-menu-btn');

		root.querySelector('.dch-back').addEventListener('click', function () { close(false); });
		mbtn.addEventListener('click', function (e) { e.stopPropagation(); menu.hidden = !menu.hidden; mbtn.setAttribute('aria-expanded', menu.hidden ? 'false' : 'true'); });
		root.addEventListener('click', function (e) {
			if (!menu.hidden && !e.target.closest('.dch-menu')) menu.hidden = true;
			var a = e.target.closest('[data-act]');
			if (a) { menu.hidden = true; if (a.getAttribute('data-act') === 'refresh') load(true); else close(false); }
			var img = e.target.closest('.dch-photo');
			if (img) { var v = root.querySelector('.dch-viewer'); v.querySelector('img').src = img.getAttribute('src'); v.hidden = false; }
			if (e.target.closest('.dch-viewer')) root.querySelector('.dch-viewer').hidden = true;
		});
		form.addEventListener('submit', function (e) { e.preventDefault(); sendText(); });
		input.addEventListener('keydown', function (e) { if (e.key === 'Enter' && !e.shiftKey && !('ontouchstart' in window)) { e.preventDefault(); sendText(); } });
		input.addEventListener('input', grow);
		root.querySelector('.dch-attach').addEventListener('click', function () { file.click(); });
		file.addEventListener('change', function () { var f = file.files && file.files[0]; file.value = ''; if (f) sendImage(f); });
		root.querySelector('.dch-mic').addEventListener('click', startRec);
		root.querySelector('.dch-rec-send').addEventListener('click', function () { stopRec(false); });
		root.querySelector('.dch-rec-cancel').addEventListener('click', function () { stopRec(true); });
	}
	function grow() { input.style.height = 'auto'; input.style.height = Math.min(120, input.scrollHeight) + 'px'; root.classList.toggle('has-text', !!input.value.trim()); }
	function toast(msg, err) {
		var t = root && root.querySelector('.dch-toast');
		if (!t) { alert(msg); return; }
		t.textContent = msg; t.classList.toggle('is-err', !!err); t.classList.add('is-on');
		clearTimeout(toastT); toastT = setTimeout(function () { t.classList.remove('is-on'); }, 2800);
	}

	/* ---------- open / close (Android back closes the chat) ---------- */
	function open() {
		if (!cfg.logged) { location.href = cfg.login || '/'; return; }
		loadCss().then(function () {
			if (!root) build();
			if (root.classList.contains('is-open')) return;
			root.hidden = false;
			html.classList.add('dch-lock');
			requestAnimationFrame(function () { requestAnimationFrame(function () { root.classList.add('is-open'); }); });
			try { var st = {}, hs = history.state; if (hs && typeof hs === 'object') for (var k in hs) st[k] = hs[k]; st.dch = 1; history.pushState(st, ''); } catch (e) {}
			load(true);
			clearInterval(poll);
			poll = setInterval(function () { if (!d.hidden) load(false); }, cfg.poll || 5000);
			setTimeout(function () { if (!('ontouchstart' in window)) input.focus(); }, 350);
		});
	}
	function close(fromHistory) {
		if (!root || !root.classList.contains('is-open')) return;
		if (rec) stopRec(true);
		root.classList.remove('is-open');
		html.classList.remove('dch-lock');
		clearInterval(poll);
		root.querySelectorAll('audio').forEach(function (a) { a.pause(); });
		setTimeout(function () { if (!root.classList.contains('is-open')) root.hidden = true; }, 320);
		if (!fromHistory && history.state && history.state.dch) { state.lastBack = Date.now(); try { history.back(); } catch (e) {} }
	}
	window.addEventListener('popstate', function () { if (root && root.classList.contains('is-open')) { state.lastBack = Date.now(); close(true); } });
	d.addEventListener('keydown', function (e) {
		if (e.key !== 'Escape' || !root || !root.classList.contains('is-open')) return;
		var v = root.querySelector('.dch-viewer');
		if (!v.hidden) { v.hidden = true; return; }
		close(false);
	});
	window.DLZChat = { open: open, close: close, isOpen: function () { return !!(root && root.classList.contains('is-open')); }, state: state };
	window.DLZOpenChat = open;
	d.addEventListener('click', function (e) {
		var t = e.target.closest && e.target.closest('.dase-contact-btn,[data-dlz-chat]');
		if (!t) return;
		e.preventDefault();
		open();
	});

	/* ---------- messages ---------- */
	function dayLabel(dt) {
		if (!dt) return '';
		var now = new Date(), p = dt.split('/'), x = new Date(+p[0], +p[1] - 1, +p[2]);
		var diff = Math.round((new Date(now.getFullYear(), now.getMonth(), now.getDate()) - x) / 864e5);
		return diff === 0 ? 'اليوم' : diff === 1 ? 'أمس' : dt;
	}
	/* custom voice player: play button + seeded waveform + duration */
	function voice(m) {
		var seed = 0, k = String(m.id || m.audio || 'v'), bars = '';
		for (var i = 0; i < k.length; i++) seed = (seed * 31 + k.charCodeAt(i)) >>> 0;
		for (var j = 0; j < 28; j++) {
			seed = (seed * 1103515245 + 12345) >>> 0;
			var h = 22 + (seed >>> 16) % 70;
			if (j < 3 || j > 24) h = Math.min(h, 34);
			bars += '<i style="height:' + h + '%"></i>';
		}
		return '<div class="dch-voice" dir="ltr"><button type="button" class="dch-vplay" aria-label="تشغيل">' + ic('play', 'dch-ip') + ic('pause', 'dch-is') + '</button>' +
			'<span class="dch-wave" role="slider" aria-label="موضع التشغيل" tabindex="0"><span class="dch-wave-b">' + bars + '</span><span class="dch-wave-f">' + bars + '</span></span>' +
			'<span class="dch-vdur">0:00</span><audio preload="metadata" src="' + esc(m.audio) + '"></audio></div>';
	}
	function fmt(t) { t = Math.max(0, Math.round(t || 0)); return Math.floor(t / 60) + ':' + ('0' + t % 60).slice(-2); }
	function bubble(m) {
		var body;
		if (m.type === 'audio') body = voice(m);
		else if (m.type === 'image') body = '<img class="dch-photo" src="' + esc(m.image || '') + '" alt="صورة" loading="lazy" decoding="async">';
		else body = '<div class="dch-text">' + linkify(m.text) + '</div>';
		var me = !m.is_admin;
		var av = me ? (cfg.avatar ? '<img src="' + esc(cfg.avatar) + '" alt="">' : ic('user')) : (cfg.logo || '');
		return '<div class="dch-msg ' + (me ? 'is-me' : 'is-them') + (m.type !== 'text' ? ' is-media' : '') + '" data-mid="' + esc(m.id) + '">' +
			'<span class="dch-av">' + av + '</span>' +
			'<div class="dch-bub">' + body +
			'<span class="dch-meta"><time>' + esc(m.time || '') + '</time>' + (me ? (m.pending ? ic('clock') : ic('checks')) : '') + '</span></div></div>';
	}
	function welcome() {
		return '<div class="dch-day"><span>مرحباً بك</span></div>' + bubble({ id: 'w', is_admin: true, type: 'text', time: '', text: 'السلام عليكم ورحمة الله 🌿\nأهلاً بك في «' + (cfg.brand || 'دليل الزائر') + '». كيف يمكننا مساعدتك؟ اكتب رسالتك أو أرسل رسالة صوتية أو صورة، وسيرد عليك فريق الدعم في أقرب وقت.' });
	}
	function render(rows, scroll) {
		if (!rows || !rows.length) {
			if (box.getAttribute('data-state') !== 'empty') { box.setAttribute('data-state', 'empty'); box.innerHTML = welcome(); lastDate = ''; }
			return;
		}
		if (box.getAttribute('data-state') !== 'list') { box.innerHTML = ''; box.setAttribute('data-state', 'list'); lastDate = ''; }
		var have = {}, out = '';
		box.querySelectorAll('[data-mid]').forEach(function (el) { have[el.getAttribute('data-mid')] = 1; });
		rows.forEach(function (m) {
			if (have[m.id]) return;
			if (m.date && m.date !== lastDate) { out += '<div class="dch-day"><span>' + esc(dayLabel(m.date)) + '</span></div>'; lastDate = m.date; }
			out += bubble(m);
		});
		box.querySelectorAll('.dch-msg.is-pending').forEach(function (p) { p.remove(); });
		if (!out) return;
		var near = scroll || box.scrollHeight - box.scrollTop - box.clientHeight < 160;
		box.insertAdjacentHTML('beforeend', out);
		fixAudio(box);
		if (near) toBottom();
	}
	/* keep the newest message in view while photos / players finish loading */
	var stick = true;
	function toBottom() {
		stick = true;
		box.scrollTop = box.scrollHeight;
		box.querySelectorAll('img:not([data-sc])').forEach(function (im) {
			im.setAttribute('data-sc', '1');
			if (!im.complete) im.addEventListener('load', function () { if (stick) box.scrollTop = box.scrollHeight; });
		});
		setTimeout(function () { if (stick) box.scrollTop = box.scrollHeight; }, 350);
	}
	function fixAudio(scope) {
		scope.querySelectorAll('audio:not([data-fx])').forEach(function (a) {
			a.setAttribute('data-fx', '1');
			var v = a.closest('.dch-voice'), fixing = false;
			var dur = v && v.querySelector('.dch-vdur'), fill = v && v.querySelector('.dch-wave-f');
			function len() { return isFinite(a.duration) ? a.duration : 0; }
			function paint() {
				if (!v) return;
				var L = len(), p = L ? Math.min(1, a.currentTime / L) : 0;
				fill.style.clipPath = 'inset(0 ' + (100 - p * 100).toFixed(2) + '% 0 0)';
				dur.textContent = fmt(a.paused && !a.currentTime ? L : a.currentTime);
			}
			a.addEventListener('loadedmetadata', function () {
				if (a.duration === Infinity || isNaN(a.duration)) {
					fixing = true; a.currentTime = 1e7;
					a.addEventListener('timeupdate', function f() { a.removeEventListener('timeupdate', f); a.currentTime = 0; fixing = false; paint(); });
				} else paint();
			});
			a.addEventListener('durationchange', function () { if (!fixing) paint(); });
			a.addEventListener('timeupdate', function () { if (!fixing) paint(); });
			a.addEventListener('play', function () { if (v) v.classList.add('is-on'); scope.querySelectorAll('audio').forEach(function (x) { if (x !== a) x.pause(); }); });
			a.addEventListener('pause', function () { if (v) v.classList.remove('is-on'); });
			a.addEventListener('ended', function () { if (v) v.classList.remove('is-on'); a.currentTime = 0; paint(); });
			if (!v) return;
			v.querySelector('.dch-vplay').addEventListener('click', function () { if (a.paused) { var p = a.play(); if (p && p.catch) p.catch(function () {}); } else a.pause(); });
			var w = v.querySelector('.dch-wave');
			function seek(x) { var r = w.getBoundingClientRect(), L = len(); if (!L) return; a.currentTime = Math.max(0, Math.min(1, (x - r.left) / r.width)) * L; paint(); }
			w.addEventListener('click', function (e) { seek(e.clientX); });
			w.addEventListener('keydown', function (e) { var L = len(); if (!L) return; if (e.key === 'ArrowRight') a.currentTime = Math.min(L, a.currentTime + 2); else if (e.key === 'ArrowLeft') a.currentTime = Math.max(0, a.currentTime - 2); else return; e.preventDefault(); paint(); });
		});
	}
	var loading = false;
	function load(scroll) {
		if (!root || loading) return;
		loading = true;
		var f = new FormData();
		f.append('action', 'dlz_support_load');
		request(f).then(function (r) {
			if (!r.success) { fail(r, 'تعذّر تحميل المحادثة.'); return; }
			if (r.data.user && r.data.user.avatar) cfg.avatar = r.data.user.avatar;
			render(r.data.messages, scroll);
		}).catch(function () { if (box.querySelector('.dch-loading')) box.innerHTML = '<p class="dch-err">تعذّر تحميل المحادثة، تحقق من الاتصال.</p>'; })
			.then(function () { loading = false; });
	}
	function pending(m) {
		if (box.getAttribute('data-state') !== 'list') { box.innerHTML = ''; box.setAttribute('data-state', 'list'); }
		var now = new Date();
		m.id = 'p' + Date.now(); m.pending = true; m.time = ('0' + now.getHours()).slice(-2) + ':' + ('0' + now.getMinutes()).slice(-2);
		box.insertAdjacentHTML('beforeend', bubble(m));
		var el = box.lastElementChild;
		el.classList.add('is-pending');
		toBottom();
		return el;
	}
	function send(f, temp, fallback) {
		f.append('action', 'dlz_support_send');
		return request(f).then(function (r) {
			if (r.success) { load(true); return true; }
			if (temp) temp.remove();
			fail(r, fallback);
			return false;
		}).catch(function (e) { if (temp) temp.remove(); toast(e.message || fallback, true); return false; });
	}
	function sendText() {
		var t = input.value.trim();
		if (!t) return;
		input.value = ''; grow();
		var temp = pending({ is_admin: false, type: 'text', text: t });
		var f = new FormData(); f.append('text', t);
		send(f, temp, 'لم يتم إرسال الرسالة.').then(function (ok) { if (!ok) { input.value = t; grow(); } });
	}
	function sendImage(file) {
		if (!/^image\/(jpeg|png|webp|gif)$/.test(file.type)) { toast('يرجى اختيار صورة (JPG أو PNG أو WEBP).', true); return; }
		if (file.size > 12 * 1024 * 1024) { toast('حجم الصورة أكبر من 12 ميغابايت.', true); return; }
		var url = URL.createObjectURL(file);
		var temp = pending({ is_admin: false, type: 'image', image: url });
		var f = new FormData(); f.append('image', file, file.name);
		send(f, temp, 'لم يتم إرسال الصورة.').then(function () { setTimeout(function () { URL.revokeObjectURL(url); }, 4000); });
	}

	/* ---------- voice ---------- */
	function startRec() {
		var mic = root.querySelector('.dch-mic');
		if (rec || mic.classList.contains('is-starting')) return;
		if (!window.DLZVoiceRec || !DLZVoiceRec.supported()) { toast('تسجيل الصوت غير متاح في هذا المتصفح.', true); return; }
		mic.classList.add('is-starting');
		DLZVoiceRec.start().then(function (r) {
			mic.classList.remove('is-starting');
			rec = r; recStart = Date.now();
			root.querySelector('.dch-form').hidden = true;
			root.querySelector('.dch-rec').hidden = false;
			recTimer = setInterval(tick, 250); tick();
		}).catch(function () { mic.classList.remove('is-starting'); toast('لتسجيل رسالة صوتية، اسمح باستخدام الميكروفون.', true); });
	}
	function tick() {
		var s = Math.floor((Date.now() - recStart) / 1000);
		if (s >= (window.DLZVoiceRec ? DLZVoiceRec.maxSeconds(cfg.maxUpload) : 300)) { stopRec(false); return; }
		root.querySelector('.dch-rec-time').textContent = ('0' + Math.floor(s / 60)).slice(-2) + ':' + ('0' + (s % 60)).slice(-2);
	}
	function stopRec(cancel) {
		clearInterval(recTimer);
		root.querySelector('.dch-form').hidden = false;
		root.querySelector('.dch-rec').hidden = true;
		if (!rec) return;
		var r = rec; rec = null;
		if (cancel) { r.cancel(); return; }
		var blob = r.stop();
		if (!blob || blob.size < 100) { toast('التسجيل قصير جداً.', true); return; }
		var temp = pending({ is_admin: false, type: 'text', text: '🎙️ جارٍ إرسال الرسالة الصوتية…' });
		var f = new FormData(); f.append('audio', blob, 'voice-' + Date.now() + '.wav');
		send(f, temp, 'لم يتم إرسال الرسالة الصوتية.');
	}
})();
