<?php
if (!defined('ABSPATH')) exit;

define('DLZ_ENT_VERSION', '1.4.0');
define('DLZ_ENT_PATH', plugin_dir_path(__FILE__));
define('DLZ_ENT_URL', plugin_dir_url(__FILE__));

function dlz_ent_city_keys() {
    if (function_exists('dlz_city_keys')) return dlz_city_keys();
    return array('mashhad','qom','shiraz','tehran');
}
function dlz_ent_city_labels() {
    $fallback = array('mashhad'=>'مشهد','qom'=>'قم','shiraz'=>'شیراز','tehran'=>'تهران');
    $s = function_exists('dase_defaults') ? wp_parse_args(get_option('dase_settings', array()), dase_defaults()) : array();
    foreach ($fallback as $key => $label) {
        if (!empty($s['city_'.$key])) $fallback[$key] = $s['city_'.$key];
    }
    return $fallback;
}
function dlz_ent_current_city() {
    if (function_exists('dlz_current_city')) return dlz_current_city();
    $city = isset($_COOKIE['dase_city']) ? sanitize_key(wp_unslash($_COOKIE['dase_city'])) : 'mashhad';
    return in_array($city, dlz_ent_city_keys(), true) ? $city : 'mashhad';
}

register_activation_hook(__FILE__, function(){
    DLZ_Entertainment_Post_Type::register_static();
    flush_rewrite_rules();
});
register_deactivation_hook(__FILE__, function(){ flush_rewrite_rules(); });

add_action('init', function(){ DLZ_Entertainment_Post_Type::register_static(); });

add_action('admin_menu', function(){
    // منوی اختصاصی مراکز تفریحی: فقط دو بخش برای ادمین
    add_menu_page('مراکز تفریحی', 'مراکز تفریحی', 'edit_posts', 'dlz-entertainment', 'dlz_ent_admin_add_location_page', 'dashicons-tickets-alt', 27);
    add_submenu_page('dlz-entertainment', 'افزودن مکان', 'افزودن مکان', 'edit_posts', 'dlz-entertainment', 'dlz_ent_admin_add_location_page');
    add_submenu_page('dlz-entertainment', 'رزروها', 'رزروها', 'edit_posts', 'edit.php?post_type=dlz_ent_booking', '', 27);
});

function dlz_ent_admin_add_location_page(){
    if (!current_user_can('edit_posts')) return;
    $url = admin_url('post-new.php?post_type=dlz_entertainment');
    wp_safe_redirect($url);
    exit;
}

add_action('admin_enqueue_scripts', function($hook){
    if (in_array($hook, array('post.php','post-new.php'), true) && isset($_GET['post_type']) && $_GET['post_type']==='dlz_entertainment') {
        wp_enqueue_media();
    }
    if (in_array($hook, array('post.php','post-new.php'), true) && isset($_GET['post']) && get_post_type(absint($_GET['post']))==='dlz_entertainment') wp_enqueue_media();
    $scr = function_exists('get_current_screen') ? get_current_screen() : null;
    if ($scr && $scr->post_type==='dlz_entertainment' && in_array($hook, array('post.php','post-new.php'), true) && defined('DBD_URL')) {
        wp_enqueue_script('dbd-tilemap', DBD_URL.'assets/js/tilemap.js', array(), defined('DBD_VERSION')?DBD_VERSION:DLZ_ENT_VERSION, true);
    }
});

add_action('add_meta_boxes', function(){
    add_meta_box('dlz_ent_details','اطلاعات مرکز تفریحی', 'dlz_ent_details_box', 'dlz_entertainment', 'normal', 'high');
});
function dlz_ent_details_box($post) {
    wp_nonce_field('dlz_ent_save','dlz_ent_nonce');
    $type = get_post_meta($post->ID,'_dlz_ent_type',true) ?: 'paid';
    $city = get_post_meta($post->ID,'_dlz_ent_city',true) ?: 'mashhad';
    $image = get_post_meta($post->ID,'_dlz_ent_image',true);
    $location = get_post_meta($post->ID,'_dlz_ent_location',true);
    $time = get_post_meta($post->ID,'_dlz_ent_time',true);
    $price = get_post_meta($post->ID,'_dlz_ent_price',true);
    $url = get_post_meta($post->ID,'_dlz_ent_url',true);
    $desc = get_post_meta($post->ID,'_dlz_ent_desc',true);
    $map_image = get_post_meta($post->ID,'_dlz_ent_map_image',true);
    $map_url = get_post_meta($post->ID,'_dlz_ent_map_url',true);
    $note = get_post_meta($post->ID,'_dlz_ent_note',true);
    $lat = get_post_meta($post->ID,'_dlz_ent_lat',true);
    $lng = get_post_meta($post->ID,'_dlz_ent_lng',true);
    $cities = dlz_ent_city_labels();
    $tiles = class_exists('DBD_Frontend') ? DBD_Frontend::tiles() : array('url'=>'https://tile.openstreetmap.org/{z}/{x}/{y}.png','attr'=>'© OpenStreetMap');
    $hc = array(); foreach (array_keys($cities) as $ck) { $hc[$ck] = class_exists('DBD_Look') ? DBD_Look::haram($ck) : array(36.2880,59.6158,''); }
    ?>
    <style>.dlz-ent-admin-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:18px}.dlz-ent-admin-grid .full{grid-column:1/-1}.dlz-ent-admin-grid label{display:block;font-weight:700;margin-bottom:7px}.dlz-ent-admin-grid input,.dlz-ent-admin-grid select,.dlz-ent-admin-grid textarea{width:100%;box-sizing:border-box}.dlz-ent-image-row{display:flex;gap:8px;align-items:center}.dlz-ent-image-row input{flex:1}.dlz-ent-preview{margin-top:10px}.dlz-ent-preview img{max-width:180px;height:110px;object-fit:cover;border-radius:12px}.dlz-ent-help{color:#646970;font-size:12px}@media(max-width:700px){.dlz-ent-admin-grid{grid-template-columns:1fr}}</style>
    <div class="dlz-ent-admin-grid">
        <div><label>نوع تفریح</label><select name="dlz_ent_type"><option value="free" <?php selected($type,'free'); ?>>تفریح رایگان</option><option value="paid" <?php selected($type,'paid'); ?>>تفریح پولی</option></select></div>
        <div><label>شهر</label><select name="dlz_ent_city"><?php foreach($cities as $key=>$label): ?><option value="<?php echo esc_attr($key); ?>" <?php selected($city,$key); ?>><?php echo esc_html($label); ?></option><?php endforeach; ?></select></div>
        <div class="full"><label>تصویر مرکز</label><div class="dlz-ent-image-row"><input type="url" id="dlz_ent_image" name="dlz_ent_image" value="<?php echo esc_attr($image); ?>"><button type="button" class="button" id="dlz_ent_pick_image">انتخاب تصویر</button></div><div class="dlz-ent-preview" id="dlz_ent_preview"><?php if($image): ?><img src="<?php echo esc_url($image); ?>" alt=""><?php endif; ?></div></div>
        <div><label>موقعیت / آدرس</label><input type="text" name="dlz_ent_location" value="<?php echo esc_attr($location); ?>" placeholder="مثلاً میدان بیت‌المقدس"></div>
        <div><label>ساعت فعالیت</label><input type="text" name="dlz_ent_time" value="<?php echo esc_attr($time); ?>" placeholder="مثلاً 08:00 تا 22:00"></div>
        <div><label>قیمت</label><input type="text" name="dlz_ent_price" value="<?php echo esc_attr($price); ?>" placeholder="مثلاً 15000 د.ع"><p class="dlz-ent-help">به دینار عراق (یا با واحدش، مثل «350000 تومان»)؛ برای هر زائر خودکار به ارز کشورش تبدیل می‌شود. برای تفریح رایگان خالی بگذارید.</p></div>
        <div class="full"><label>خط طلایی زیر نام (اختیاری)</label><input type="text" name="dlz_ent_note" value="<?php echo esc_attr($note); ?>" placeholder="مثلاً: مناسب للعائلات والأطفال"><p class="dlz-ent-help">با رنگ طلایی و آیکن زیر نام مرکز در کارت نمایش داده می‌شود (متن عربی).</p></div>
        <div><label>لینک جزئیات / رزرو</label><input type="url" name="dlz_ent_url" value="<?php echo esc_attr($url); ?>" placeholder="https://..."></div>
        <div class="full"><label>توضیحات کوتاه</label><textarea name="dlz_ent_desc" rows="4" placeholder="توضیح کوتاه درباره این مرکز..."><?php echo esc_textarea($desc); ?></textarea></div>
        <div class="full"><label>تصویر نقشه (اختیاری)</label><div class="dlz-ent-image-row"><input type="url" id="dlz_ent_map_image" name="dlz_ent_map_image" value="<?php echo esc_attr($map_image); ?>"><button type="button" class="button" id="dlz_ent_pick_map">انتخاب تصویر نقشه</button></div><div class="dlz-ent-preview" id="dlz_ent_map_preview"><?php if($map_image): ?><img src="<?php echo esc_url($map_image); ?>" alt=""><?php endif; ?></div></div>
        <div class="full"><label>لینک Google Maps</label><input type="url" name="dlz_ent_map_url" value="<?php echo esc_attr($map_url); ?>" placeholder="https://maps.google.com/..."><p class="dlz-ent-help">اگر پین نگذارید، مختصات از همین لینک خوانده می‌شود.</p></div>
        <div class="full dlz-ent-pinbox"><label>موقعیت روی نقشه (پین)</label><p class="dlz-ent-help">روی نقشه بزنید تا پین ثبت شود؛ پین را می‌توانید بکشید. با پین، نقشه و دکمه‌های مسیریابی (Google Maps و Waze) در صفحه‌ی مرکز نمایش داده می‌شوند.</p>
            <div class="dlz-ent-pinmap" data-tiles="<?php echo esc_attr($tiles['url']); ?>" data-attr="<?php echo esc_attr($tiles['attr']); ?>" data-haram="<?php echo esc_attr(wp_json_encode($hc)); ?>"></div>
            <div class="dlz-ent-ll"><span><label>Lat</label><input type="text" dir="ltr" name="dlz_ent_lat" class="dlz-ent-lat" value="<?php echo esc_attr($lat); ?>"></span><span><label>Lng</label><input type="text" dir="ltr" name="dlz_ent_lng" class="dlz-ent-lng" value="<?php echo esc_attr($lng); ?>"></span><button type="button" class="button-link dlz-ent-pinclear">حذف پین</button></div>
        </div>
    </div>
    <style>.dlz-ent-pinmap{height:300px;border-radius:12px;overflow:hidden;margin:6px 0 8px;background:#EAE6DA}.dlz-ent-ll{display:flex;gap:10px;align-items:flex-end}.dlz-ent-ll span{flex:1}.dlz-ent-ll label{font-weight:600!important;margin:0 0 4px!important}.dlzm{position:relative;overflow:hidden;user-select:none;touch-action:none;background:#EAE6DA;direction:ltr}.dlzm-layer{position:absolute;left:0;top:0}.dlzm-tile{position:absolute;left:0;top:0;width:256px;height:256px;max-width:none!important;opacity:0;transition:opacity .25s}.dlzm-tile.is-on{opacity:1}.dlzm-route{position:absolute;inset:0;pointer-events:none}.dlzm-pin{position:absolute;z-index:3;width:34px;height:42px;margin:-40px 0 0 -17px;padding:0;border:0;background:none;cursor:grab}.dlzm-pin svg{display:block;width:100%;height:100%}.dlzm-haram{position:absolute;z-index:2;width:120px;margin:-58px 0 0 -60px;pointer-events:none;display:flex;flex-direction:column;align-items:center}.dlzm-haram svg{width:40px;height:40px}.dlzm-haram b{font-size:11px;padding:1px 6px;border-radius:6px;background:rgba(255,255,255,.9)}.dlzm-attr{position:absolute;bottom:2px;right:4px;z-index:4;font-size:10px;color:#555;background:rgba(255,255,255,.7);padding:0 4px;border-radius:4px}.dlzm-zoom{position:absolute;top:10px;left:10px;z-index:5;display:flex;flex-direction:column;border-radius:10px;overflow:hidden;box-shadow:0 2px 8px rgba(0,0,0,.2)}.dlzm-zoom button{width:34px;height:34px;border:0;background:#fff;font-size:18px;cursor:pointer}</style>
    <script>window.addEventListener('load',function(){var box=document.querySelector('.dlz-ent-pinmap');if(!box||!window.DLZMap)return;var la=document.querySelector('.dlz-ent-lat'),ln=document.querySelector('.dlz-ent-lng'),cs=document.querySelector('select[name="dlz_ent_city"]'),H=JSON.parse(box.getAttribute('data-haram')||'{}'),h=H[cs?cs.value:'mashhad']||[36.288,59.6158,''];var map=new DLZMap(box,{tiles:box.getAttribute('data-tiles'),attr:box.getAttribute('data-attr'),interactive:true,center:[h[0],h[1]],zoom:14,onTap:function(a,b){set(a,b,true);}});var hm=map.haram(h),pin=null;function num(v){v=String(v||'').replace(/[۰-۹]/g,function(c){return '۰۱۲۳۴۵۶۷۸۹'.indexOf(c);}).trim();return v===''?NaN:+v;}function set(a,b,fromMap){a=+(+a).toFixed(6);b=+(+b).toFixed(6);if(!pin){pin=map.pin(a,b,'','');drag(pin);}else map.move(pin,a,b);if(fromMap!=='input'){la.value=a;ln.value=b;}if(!fromMap)map.view(a,b,Math.max(map.z,16));}function drag(p){p.el.addEventListener('pointerdown',function(e){e.preventDefault();e.stopPropagation();try{p.el.setPointerCapture(e.pointerId);}catch(x){}function mv(ev){var ll=map.at(ev.clientX,ev.clientY+4);set(ll[0],ll[1],true);}function up(){p.el.removeEventListener('pointermove',mv);p.el.removeEventListener('pointerup',up);}p.el.addEventListener('pointermove',mv);p.el.addEventListener('pointerup',up);});}var a0=num(la.value),b0=num(ln.value);requestAnimationFrame(function(){map.render();if(isFinite(a0)&&isFinite(b0))set(a0,b0,false);});[la,ln].forEach(function(i){i.addEventListener('change',function(){var a=num(la.value),b=num(ln.value);if(isFinite(a)&&isFinite(b))set(a,b,'input');});});if(cs)cs.addEventListener('change',function(){h=H[cs.value]||h;map.unmark(hm);hm=map.haram(h);if(!pin)map.view(h[0],h[1],14);});document.querySelector('.dlz-ent-pinclear').addEventListener('click',function(){if(pin){map.unmark(pin);pin=null;}la.value='';ln.value='';});});</script>
    <script>jQuery(function($){let frame, mapFrame;$('#dlz_ent_pick_image').on('click',function(e){e.preventDefault();if(frame){frame.open();return;}frame=wp.media({title:'انتخاب تصویر مرکز تفریحی',button:{text:'استفاده از این تصویر'},multiple:false});frame.on('select',function(){const a=frame.state().get('selection').first().toJSON();$('#dlz_ent_image').val(a.url);$('#dlz_ent_preview').html('<img src="'+a.url.replace(/"/g,'&quot;')+'" alt="">');});frame.open();});$('#dlz_ent_pick_map').on('click',function(e){e.preventDefault();if(mapFrame){mapFrame.open();return;}mapFrame=wp.media({title:'انتخاب تصویر نقشه',button:{text:'استفاده از این نقشه'},multiple:false});mapFrame.on('select',function(){const a=mapFrame.state().get('selection').first().toJSON();$('#dlz_ent_map_image').val(a.url);$('#dlz_ent_map_preview').html('<img src="'+a.url.replace(/"/g,'&quot;')+'" alt="">');});mapFrame.open();});});</script>
    <script>jQuery(function($){
        function dlzToggleType(){
            const free=$('select[name="dlz_ent_type"]').val()==='free';
            const price=$('input[name="dlz_ent_price"]').closest('div');
            const url=$('input[name="dlz_ent_url"]').closest('div');
            price.toggle(!free); url.toggle(!free);
            if(free){$('input[name="dlz_ent_price"]').val('');$('input[name="dlz_ent_url"]').val('');}
        }
        $('select[name="dlz_ent_type"]').on('change',dlzToggleType); dlzToggleType();
    });</script>
    <?php
}
add_action('save_post_dlz_entertainment', function($post_id){
    if (!isset($_POST['dlz_ent_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['dlz_ent_nonce'])),'dlz_ent_save')) return;
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if (!current_user_can('edit_post',$post_id)) return;
    $type = isset($_POST['dlz_ent_type']) ? sanitize_key(wp_unslash($_POST['dlz_ent_type'])) : 'paid';
    if (!in_array($type,array('free','paid'),true)) $type='paid';
    $city = isset($_POST['dlz_ent_city']) ? sanitize_key(wp_unslash($_POST['dlz_ent_city'])) : 'mashhad';
    if (!in_array($city,dlz_ent_city_keys(),true)) $city='mashhad';
    update_post_meta($post_id,'_dlz_ent_type',$type);
    update_post_meta($post_id,'_dlz_ent_city',$city);
    update_post_meta($post_id,'_dlz_ent_image',esc_url_raw(wp_unslash($_POST['dlz_ent_image']??'')));
    update_post_meta($post_id,'_dlz_ent_location',sanitize_text_field(wp_unslash($_POST['dlz_ent_location']??'')));
    update_post_meta($post_id,'_dlz_ent_time',sanitize_text_field(wp_unslash($_POST['dlz_ent_time']??'')));
    update_post_meta($post_id,'_dlz_ent_price',sanitize_text_field(wp_unslash($_POST['dlz_ent_price']??'')));
    update_post_meta($post_id,'_dlz_ent_url',esc_url_raw(wp_unslash($_POST['dlz_ent_url']??'')));
    update_post_meta($post_id,'_dlz_ent_desc',sanitize_textarea_field(wp_unslash($_POST['dlz_ent_desc']??'')));
    update_post_meta($post_id,'_dlz_ent_map_image',esc_url_raw(wp_unslash($_POST['dlz_ent_map_image']??'')));
    update_post_meta($post_id,'_dlz_ent_map_url',esc_url_raw(wp_unslash($_POST['dlz_ent_map_url']??'')));
    update_post_meta($post_id,'_dlz_ent_note',sanitize_text_field(wp_unslash($_POST['dlz_ent_note']??'')));
    // pin: typed / dragged coordinates, else read from the Google Maps link
    $la = isset($_POST['dlz_ent_lat']) ? (float) str_replace(',', '.', sanitize_text_field(wp_unslash($_POST['dlz_ent_lat']))) : 0;
    $ln = isset($_POST['dlz_ent_lng']) ? (float) str_replace(',', '.', sanitize_text_field(wp_unslash($_POST['dlz_ent_lng']))) : 0;
    if ((!$la || !$ln) && class_exists('DBD_Look')) { $pair = DBD_Look::parse_latlng(wp_unslash($_POST['dlz_ent_map_url']??'')); if ($pair) { $la = $pair[0]; $ln = $pair[1]; } }
    if ($la && $ln && abs($la) <= 90 && abs($ln) <= 180) { update_post_meta($post_id,'_dlz_ent_lat',round($la,6)); update_post_meta($post_id,'_dlz_ent_lng',round($ln,6)); }
    else { delete_post_meta($post_id,'_dlz_ent_lat'); delete_post_meta($post_id,'_dlz_ent_lng'); }
});

add_filter('manage_dlz_entertainment_posts_columns',function($cols){$new=array();foreach($cols as $k=>$v){$new[$k]=$v;if($k==='title'){$new['dlz_ent_city']='شهر';$new['dlz_ent_type']='نوع';}}return $new;});
add_action('manage_dlz_entertainment_posts_custom_column',function($col,$post_id){if($col==='dlz_ent_city'){ $c=get_post_meta($post_id,'_dlz_ent_city',true)?:'mashhad';$l=dlz_ent_city_labels();echo esc_html($l[$c]??$c);}if($col==='dlz_ent_type'){echo get_post_meta($post_id,'_dlz_ent_type',true)==='free'?'رایگان':'پولی';}},10,2);

function dlz_ent_get_items($city=null) {
    $city = $city ?: dlz_ent_current_city();
    return new WP_Query(array('post_type'=>'dlz_entertainment','post_status'=>'publish','posts_per_page'=>-1,'orderby'=>array('menu_order'=>'ASC','date'=>'DESC'),'no_found_rows'=>true,'meta_query'=>($city==='mashhad'?array(array('relation'=>'OR',array('key'=>'_dlz_ent_city','value'=>$city),array('key'=>'_dlz_ent_city','compare'=>'NOT EXISTS'),array('key'=>'_dlz_ent_city','value'=>''))):array(array('key'=>'_dlz_ent_city','value'=>$city)))));
}

add_shortcode('dlz_entertainment',function($atts){
    wp_enqueue_style('dlz-ent-style');wp_enqueue_script('dlz-ent-script');
    $atts=shortcode_atts(array('city'=>'','type'=>'all'),$atts,'dlz_entertainment');
    $city=$atts['city'] && in_array($atts['city'],dlz_ent_city_keys(),true)?$atts['city']:dlz_ent_current_city();
    $q=dlz_ent_get_items($city); ob_start(); dlz_ent_render_widget_markup($q); return ob_get_clean();
});

function dlz_ent_icon($k){
    if (function_exists('dlzdt_icon')) return dlzdt_icon($k);
    return '';
}
function dlz_ent_render_widget_markup($q,$uid='') {
    $uid=$uid?:'dlz-ent-'.wp_rand(1000,999999);
    $labels=dlz_ent_city_labels();$current=dlz_ent_current_city();
    $me=function_exists('dlz_me')?dlz_me():array('name'=>'','phone'=>'');
    $tiles=class_exists('DBD_Frontend')?DBD_Frontend::tiles():array('url'=>'https://tile.openstreetmap.org/{z}/{x}/{y}.png','attr'=>'© OpenStreetMap');
    ?>
    <section id="<?php echo esc_attr($uid); ?>" class="dlz-ent-widget" dir="rtl" data-current-city="<?php echo esc_attr($current); ?>" data-me-name="<?php echo esc_attr($me['name']); ?>" data-me-phone="<?php echo esc_attr($me['phone']); ?>" data-tiles="<?php echo esc_attr($tiles['url']); ?>" data-attr="<?php echo esc_attr($tiles['attr']); ?>">
      <div class="dlz-ent-head"><div><div class="dlz-ent-kicker">دلیل الزائر</div><h2>مراکز تفریحی</h2><p>أفضل أماكن الترفيه في مدينتك</p></div><div class="dlz-ent-city-badge"><span class="dlz-ent-pin">⌖</span><span class="dlz-ent-city-name"><?php echo esc_html($labels[$current]??'مشهد'); ?></span></div></div>
      <div class="dlz-ent-switch" role="tablist" aria-label="نوع الترفيه"><button type="button" class="is-active" data-filter="paid" role="tab" aria-selected="true">مدفوع</button><button type="button" data-filter="free" role="tab" aria-selected="false">مجاني</button></div>
      <div class="dlz-ent-count" aria-live="polite"></div>
      <div class="dlz-ent-list">
      <?php if($q->have_posts()): while($q->have_posts()):$q->the_post(); $id=get_the_ID();$type=get_post_meta($id,'_dlz_ent_type',true)?:'paid';$img=get_post_meta($id,'_dlz_ent_image',true);$loc=get_post_meta($id,'_dlz_ent_location',true);$time=get_post_meta($id,'_dlz_ent_time',true);$price=(string)get_post_meta($id,'_dlz_ent_price',true);$url=get_post_meta($id,'_dlz_ent_url',true);$desc=get_post_meta($id,'_dlz_ent_desc',true);$map_image=get_post_meta($id,'_dlz_ent_map_image',true);$map_url=get_post_meta($id,'_dlz_ent_map_url',true);$city=get_post_meta($id,'_dlz_ent_city',true)?:'mashhad';$note=trim((string)get_post_meta($id,'_dlz_ent_note',true));$lat=(float)get_post_meta($id,'_dlz_ent_lat',true);$lng=(float)get_post_meta($id,'_dlz_ent_lng',true);
        $pt=($type==='paid'&&$price!=='')?(class_exists('DLZ_Money')?DLZ_Money::text($price):$price):'';
        $data=array('id'=>$id,'title'=>get_the_title(),'type'=>$type,'img'=>$img,'loc'=>$loc,'time'=>$time,'price'=>$pt,'desc'=>$desc,'note'=>$note,'lat'=>$lat?:'','lng'=>$lng?:'','map'=>$map_url,'mapimg'=>$map_image,'url'=>$url); ?>
        <article class="dlz-ent-card dlzc" id="ent-<?php echo (int)$id; ?>" data-type="<?php echo esc_attr($type); ?>" data-city="<?php echo esc_attr($city); ?>" data-favorite-id="<?php echo (int)$id; ?>" data-ent="<?php echo esc_attr(wp_json_encode($data)); ?>" tabindex="0" role="button" aria-label="<?php echo esc_attr(get_the_title()); ?>">
          <div class="dlz-ent-media dlzc-ph"><?php if($img): ?><img src="<?php echo esc_url($img); ?>" alt="" loading="lazy" decoding="async"><?php else: ?><span class="dlzc-noimg"><?php echo dlz_ent_icon('star'); // phpcs:ignore ?></span><?php endif; ?><?php echo function_exists('dlz_favorite_button')?dlz_favorite_button('dlz_entertainment',$id):''; // phpcs:ignore ?><button type="button" class="dlz-ent-book dlzc-cta" data-id="<?php echo esc_attr($id); ?>" data-type="<?php echo esc_attr($type); ?>"><?php echo $type==='free' ? 'التفاصيل' : 'احجز التذكرة'; ?></button></div>
          <div class="dlz-ent-body dlzc-b"><h3><?php the_title(); ?></h3>
            <?php if($note): ?><p class="dlzc-hl"><?php echo function_exists('dlzdt_note_icon')?dlzdt_note_icon($note):''; // phpcs:ignore ?><span><?php echo esc_html($note); ?></span></p><?php endif; ?>
            <?php if($loc||$time): ?><ul class="dlzc-m"><?php if($loc): ?><li><?php echo dlz_ent_icon('pin'); // phpcs:ignore ?><span><?php echo esc_html($loc); ?></span></li><?php endif; ?><?php if($time): ?><li><?php echo dlz_ent_icon('clock'); // phpcs:ignore ?><span dir="auto"><?php echo esc_html($time); ?></span></li><?php endif; ?></ul><?php endif; ?>
            <div class="dlzc-ft"><?php if($type==='free'): ?><span class="dlzc-pr is-free">مجاني</span><?php elseif($pt!==''): ?><span class="dlzc-pr" dir="auto"><?php echo esc_html($pt); ?></span><?php endif; ?></div>
          </div>
        </article>
      <?php endwhile; wp_reset_postdata(); else: ?><div class="dlz-ent-empty">لا يوجد مركز ترفيهي مسجل لهذه المدينة حتى الآن.</div><?php endif; ?>
      </div>
      <div class="dlz-ent-modal" aria-hidden="true"><div class="dlz-ent-modal-backdrop"></div><div class="dlz-ent-modal-box" role="dialog" aria-modal="true" aria-labelledby="dlz-ent-modal-title"><button type="button" class="dlz-ent-modal-close" aria-label="إغلاق">×</button><div class="dlz-ent-modal-content"></div></div></div>
    </section>
    <?php
}

/* Registered on every page, loaded only where the entertainment centres are shown. */
add_action('wp_enqueue_scripts',function(){
    wp_register_style('dlz-ent-style',DLZ_ENT_URL.'assets/entertainment.css',array(),DLZ_ENT_VERSION);
    $deps = wp_script_is('dbd-tilemap','registered') ? array('dbd-tilemap') : array();
    wp_register_script('dlz-ent-script',DLZ_ENT_URL.'assets/entertainment.js',$deps,DLZ_ENT_VERSION,true);
    wp_localize_script('dlz-ent-script','DLZ_ENT_DATA',array('ajax_url'=>admin_url('admin-ajax.php'),'nonce'=>wp_create_nonce('dlz_ent_booking'),'action'=>'dlz_ent_create_booking'));
    if(function_exists('dlz_page_has')&&dlz_page_has(array('dlz_entertainment'))){wp_enqueue_style('dlz-ent-style');wp_enqueue_script('dlz-ent-script');}
},20);

add_action('elementor/elements/categories_registered',function($manager){
    if(method_exists($manager,'add_category')) $manager->add_category('dlz-ent-cat',array('title'=>'دلیل الزائر','icon'=>'fa fa-map-marker'));
});
add_action('elementor/widgets/register',function($manager){
    if(!class_exists('\Elementor\Widget_Base')) return;
    require_once DLZ_ENT_PATH.'elementor/class-dlz-entertainment-widget.php';
    if(class_exists('DLZ_Entertainment_Elementor_Widget')) $manager->register(new DLZ_Entertainment_Elementor_Widget());
});


/* رزروهای تفریحات: اطلاعات فقط داخل وردپرس ذخیره می‌شود و ایمیلی ارسال نمی‌شود. */
add_action('init', function(){
    register_post_type('dlz_ent_booking',array(
        'labels'=>array('name'=>'رزروهای تفریحات','singular_name'=>'رزرو تفریح','menu_name'=>'رزروهای تفریحات','all_items'=>'همه رزروها','view_item'=>'مشاهده رزرو','search_items'=>'جستجوی رزروها','not_found'=>'رزروی یافت نشد'),
        'public'=>false,'show_ui'=>true,'show_in_menu'=>'edit.php?post_type=dlz_entertainment','supports'=>array('title'),'capability_type'=>'post','map_meta_cap'=>true
    ));
});
add_action('add_meta_boxes',function(){
    add_meta_box('dlz_ent_booking_details','جزئیات رزرو','dlz_ent_booking_details_box','dlz_ent_booking','normal','high');
});
function dlz_ent_booking_details_box($post){
    $fields=array('مرکز تفریحی'=>'_dlz_booking_entertainment','نام و نام خانوادگی'=>'_dlz_booking_name','شماره موبایل'=>'_dlz_booking_phone','تعداد مرد'=>'_dlz_booking_men','تعداد زن'=>'_dlz_booking_women','تاریخ رزرو'=>'_dlz_booking_date','شهر'=>'_dlz_booking_city','زمان ثبت'=>'_dlz_booking_created');
    echo '<table class="widefat striped"><tbody>';
    foreach($fields as $label=>$key){$v=get_post_meta($post->ID,$key,true);if($key==='_dlz_booking_created'&&$v)$v=wp_date('Y-m-d H:i',$v);echo '<tr><td style="width:180px"><strong>'.esc_html($label).'</strong></td><td>'.esc_html($v).'</td></tr>';}
    echo '</tbody></table>';
}
add_filter('manage_dlz_ent_booking_posts_columns',function($cols){return array('cb'=>$cols['cb']??'','title'=>'مرکز تفریحی','dlz_name'=>'نام','dlz_phone'=>'موبایل','dlz_people'=>'تعداد نفرات','dlz_date'=>'تاریخ رزرو','dlz_city'=>'شهر','date'=>'ثبت شده در');});
add_action('manage_dlz_ent_booking_posts_custom_column',function($col,$id){
    if($col==='dlz_name')echo esc_html(get_post_meta($id,'_dlz_booking_name',true));
    if($col==='dlz_phone')echo esc_html(get_post_meta($id,'_dlz_booking_phone',true));
    if($col==='dlz_people')echo esc_html((int)get_post_meta($id,'_dlz_booking_men',true).' مرد / '.(int)get_post_meta($id,'_dlz_booking_women',true).' زن');
    if($col==='dlz_date')echo esc_html(get_post_meta($id,'_dlz_booking_date',true));
    if($col==='dlz_city'){ $c=get_post_meta($id,'_dlz_booking_city',true);$l=dlz_ent_city_labels();echo esc_html($l[$c]??$c);}
},10,2);
add_action('wp_ajax_dlz_ent_create_booking','dlz_ent_create_booking');
add_action('wp_ajax_nopriv_dlz_ent_create_booking','dlz_ent_create_booking');
function dlz_ent_create_booking(){
    check_ajax_referer('dlz_ent_booking','nonce');
    $ent_id=isset($_POST['entertainment_id'])?absint($_POST['entertainment_id']):0;
    if(!$ent_id||get_post_type($ent_id)!=='dlz_entertainment'||get_post_status($ent_id)!=='publish')wp_send_json_error(array('message'=>'هذا المركز غير متاح للحجز حالياً.'));
    if(get_post_meta($ent_id,'_dlz_ent_type',true)!=='paid')wp_send_json_error(array('message'=>'هذا المركز مجاني ولا يحتاج إلى حجز تذكرة.'));
    $name=mb_substr(sanitize_text_field(wp_unslash($_POST['name']??'')),0,80);$phone=mb_substr(sanitize_text_field(wp_unslash($_POST['phone']??'')),0,30);$men=max(0,min(99,absint($_POST['men']??0)));$women=max(0,min(99,absint($_POST['women']??0)));$date=sanitize_text_field(wp_unslash($_POST['date']??''));
    if($name==='')wp_send_json_error(array('message'=>'الرجاء إدخال الاسم الكامل.'));
    if($phone==='')wp_send_json_error(array('message'=>'الرجاء إدخال رقم الهاتف.'));
    if(($men+$women)<1)wp_send_json_error(array('message'=>'يرجى اختيار عدد الأشخاص.'));
    $dt=DateTime::createFromFormat('Y-m-d',$date);$valid=$dt&&$dt->format('Y-m-d')===$date;
    if(!$valid)wp_send_json_error(array('message'=>'يرجى اختيار تاريخ صحيح.'));
    $today=new DateTime('today');if($dt<$today)wp_send_json_error(array('message'=>'يرجى اختيار تاريخ اليوم أو تاريخاً لاحقاً.'));
    $city=get_post_meta($ent_id,'_dlz_ent_city',true)?:'mashhad';$title=get_the_title($ent_id);
    $booking_id=wp_insert_post(array('post_type'=>'dlz_ent_booking','post_status'=>'publish','post_title'=>$title.' — '.$name.' — '.$date),true);
    if(is_wp_error($booking_id))wp_send_json_error(array('message'=>'تعذر حفظ الحجز، حاول مرة أخرى.'));
    if(is_user_logged_in()) update_post_meta($booking_id,'_dlz_user_id',get_current_user_id());
    update_post_meta($booking_id,'_dlz_booking_code',(string)$booking_id);
    update_post_meta($booking_id,'_dlz_booking_entertainment',$title);update_post_meta($booking_id,'_dlz_booking_entertainment_id',$ent_id);update_post_meta($booking_id,'_dlz_booking_name',$name);update_post_meta($booking_id,'_dlz_booking_phone',$phone);update_post_meta($booking_id,'_dlz_booking_men',$men);update_post_meta($booking_id,'_dlz_booking_women',$women);update_post_meta($booking_id,'_dlz_booking_date',$date);update_post_meta($booking_id,'_dlz_booking_city',$city);update_post_meta($booking_id,'_dlz_booking_created',current_time('timestamp'));
    $download_url=wp_nonce_url(admin_url('admin-post.php?action=dlz_download_booking_ticket&booking_id='.(int)$booking_id),'dlz_download_booking_ticket_'.$booking_id);wp_send_json_success(array('message'=>'تم استلام طلب الحجز بنجاح. سنتواصل معكم لتأكيد الحجز.','booking_id'=>$booking_id,'download_url'=>$download_url));
}

class DLZ_Entertainment_Post_Type {
    public static function register_static(){
        register_post_type('dlz_entertainment',array('labels'=>array('name'=>'مراکز تفریحی','singular_name'=>'مرکز تفریحی','add_new'=>'افزودن مرکز','add_new_item'=>'افزودن مرکز تفریحی','edit_item'=>'ویرایش مرکز','new_item'=>'مرکز جدید','view_item'=>'مشاهده مرکز','search_items'=>'جستجوی مراکز','not_found'=>'مرکزی یافت نشد','menu_name'=>'مراکز تفریحی'),'public'=>false,'show_ui'=>true,'show_in_menu'=>false,'supports'=>array('title'),'capability_type'=>'post','map_meta_cap'=>true));
    }
}
