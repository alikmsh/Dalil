<?php
if (!defined('ABSPATH')) exit;
if (!class_exists('\\Elementor\\Widget_Base')) return;
class DLZ_Entertainment_Elementor_Widget extends \Elementor\Widget_Base {
    public function get_name(){return 'dlz_entertainment_cards';}
    public function get_title(){return 'دلیل الزائر — مراکز تفریحی';}
    public function get_icon(){return 'eicon-posts-grid';}
    public function get_categories(){return array('dalil-alzaer');}
    public function get_keywords(){return array('entertainment','تفریح','مراکز تفریحی','رایگان','پولی','دلیل الزائر');}
    protected function register_controls(){
        $this->start_controls_section('info',array('label'=>'دلیل الزائر'));
        $this->add_control('notice',array('type'=>\Elementor\Controls_Manager::RAW_HTML,'raw'=>'<div style="line-height:1.8">آگهی‌ها از منوی <strong>مراکز تفریحی</strong> مدیریت می‌شوند و شهر از انتخاب «المدن» خوانده می‌شود. سوییچ رایگان/پولی داخل ویجت فعال است.</div>','content_classes'=>'elementor-panel-alert elementor-panel-alert-info'));
        $this->end_controls_section();
    }
    protected function render(){
        wp_enqueue_style('dlz-ent-style');wp_enqueue_script('dlz-ent-script');
        $q=dlz_ent_get_items(dlz_ent_current_city());
        dlz_ent_render_widget_markup($q,'dlz-ent-'.sanitize_html_class($this->get_id()));
    }
}
