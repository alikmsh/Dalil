(function(){
  'use strict';
  /* 1.4.0 (17.4): the whole card opens the details (photo, address, hours, price, map + Google Maps / Waze);
     «احجز التذكرة» opens the booking form, pre-filled with the visitor's name and phone. */
  const cities=['mashhad','qom','shiraz','tehran'];
  const labels={mashhad:'مشهد',qom:'قم',shiraz:'شیراز',tehran:'تهران'};
  const SV=p=>'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'+p+'</svg>';
  const IC={
    pin:SV('<path d="M12 21.5s-6.5-6.2-6.5-11.6a6.5 6.5 0 0 1 13 0c0 5.4-6.5 11.6-6.5 11.6z"/><circle cx="12" cy="9.8" r="2.3"/>'),
    clock:SV('<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/>'),
    tag:SV('<path d="M3.5 12.5V4.5h8l9 9-8 8z"/><circle cx="8" cy="9" r="1.4"/>'),
    star:SV('<path d="M12 3.8l2.4 5 5.4.7-4 3.7 1 5.4L12 16l-4.8 2.6 1-5.4-4-3.7 5.4-.7z"/>'),
    g:SV('<path d="M12 21.5s-6.5-6.2-6.5-11.6a6.5 6.5 0 0 1 13 0c0 5.4-6.5 11.6-6.5 11.6z"/><circle cx="12" cy="9.8" r="2.4"/>'),
    w:SV('<path d="M20.5 3.5 3.5 10.6l7 2.9 2.9 7z"/>')
  };
  function init(root){
    if(!root || root.dataset.dlzEntReady==='1') return;
    root.dataset.dlzEntReady='1';
    const tabs=root.querySelectorAll('.dlz-ent-switch button');
    const cards=Array.from(root.querySelectorAll('.dlz-ent-card'));
    const count=root.querySelector('.dlz-ent-count');
    const cityName=root.querySelector('.dlz-ent-city-name');
    const modal=root.querySelector('.dlz-ent-modal');
    const modalContent=root.querySelector('.dlz-ent-modal-content');
    const closeBtn=root.querySelector('.dlz-ent-modal-close');
    let filter='paid';
    function getCity(){
      let c='';
      try{c=localStorage.getItem('dase_city')||'';}catch(e){}
      if(!c){const m=document.cookie.match(/(?:^|;\s*)dase_city=([^;]+)/);c=m?decodeURIComponent(m[1]):'';}
      return cities.includes(c)?c:(root.dataset.currentCity||'mashhad');
    }
    function render(){
      const city=getCity(); let shown=0;
      cards.forEach(card=>{const visible=card.dataset.city===city && card.dataset.type===filter;card.hidden=!visible;if(visible)shown++;});
      if(cityName)cityName.textContent=labels[city]||'مشهد';
      if(count)count.textContent=shown?shown+' مكان':'';
      root.dataset.currentCity=city;
      let empty=root.querySelector('.dlz-ent-filter-empty');
      if(!shown){if(!empty){empty=document.createElement('div');empty.className='dlz-ent-empty dlz-ent-filter-empty';root.querySelector('.dlz-ent-list').appendChild(empty);}empty.textContent=filter==='free'?'لا توجد أماكن ترفيه مجانية لهذه المدينة حتى الآن.':'لا توجد أماكن ترفيه مدفوعة لهذه المدينة حتى الآن.';empty.hidden=false;}else if(empty)empty.hidden=true;
    }
    function data(card){try{return JSON.parse(card.dataset.ent||'{}');}catch(e){return {};}}
    function openModal(html){modalContent.innerHTML=html;modal.classList.add('is-open');modal.setAttribute('aria-hidden','false');document.body.classList.add('dlz-ent-modal-open');const box=modal.querySelector('.dlz-ent-modal-box');if(box)box.scrollTop=0;}
    function closeModal(){modal.classList.remove('is-open');modal.setAttribute('aria-hidden','true');modalContent.innerHTML='';document.body.classList.remove('dlz-ent-modal-open');}
    function details(it){
      const lat=+it.lat||0,lng=+it.lng||0,ll=lat&&lng?(+lat.toFixed(6))+','+(+lng.toFixed(6)):'';
      const rows=(it.loc?'<li>'+IC.pin+'<span>'+esc(it.loc)+'</span></li>':'')+(it.time?'<li>'+IC.clock+'<span dir="auto">'+esc(it.time)+'</span></li>':'')+(it.type==='free'?'<li>'+IC.tag+'<span>الدخول</span><b>مجاني</b></li>':(it.price?'<li>'+IC.tag+'<span>السعر</span><b dir="auto">'+esc(it.price)+'</b></li>':''));
      let map='';
      if(ll){
        map='<div class="dlz-ent-d-map" data-lat="'+lat+'" data-lng="'+lng+'"></div><div class="dbd-nav2"><a class="dbd-n2 is-g" href="https://www.google.com/maps/dir/?api=1&destination='+ll+'&travelmode=driving" target="_blank" rel="noopener"><span class="dbd-n2-i">'+IC.g+'</span><span class="dbd-n2-t"><small>افتح في</small><b>Google Maps</b></span></a><a class="dbd-n2 is-w" href="https://waze.com/ul?ll='+ll+'&navigate=yes&zoom=17" target="_blank" rel="noopener"><span class="dbd-n2-i">'+IC.w+'</span><span class="dbd-n2-t"><small>افتح في</small><b>Waze</b></span></a></div>';
      }else if(it.mapimg){map='<img class="dlz-ent-d-mapimg" src="'+esc(it.mapimg)+'" alt="خريطة المكان" loading="lazy">';}
      if(!ll&&it.map)map+='<a class="dlz-ent-map-link" href="'+esc(it.map)+'" target="_blank" rel="noopener">فتح الموقع على Google Maps <span>↗</span></a>';
      openModal('<div class="dlz-ent-d">'+(it.img?'<img class="dlz-ent-d-img" src="'+esc(it.img)+'" alt="">':'')+'<h3 id="dlz-ent-modal-title">'+esc(it.title||'')+'</h3>'+(it.note?'<p class="dlz-ent-d-note">'+IC.star+'<span>'+esc(it.note)+'</span></p>':'')+(it.desc?'<p class="dlz-ent-d-desc">'+esc(it.desc)+'</p>':'')+(rows?'<ul class="dlz-ent-d-rows">'+rows+'</ul>':'')+map+(it.type==='paid'?'<button type="button" class="dlz-ent-d-book">احجز التذكرة</button>':'<button type="button" class="dlz-ent-secondary-close">إغلاق</button>')+'</div>');
      const bk=modalContent.querySelector('.dlz-ent-d-book');if(bk)bk.addEventListener('click',()=>paidForm(it));
      const cl=modalContent.querySelector('.dlz-ent-secondary-close');if(cl)cl.addEventListener('click',closeModal);
      const mp=modalContent.querySelector('.dlz-ent-d-map');
      if(mp&&window.DLZMap){requestAnimationFrame(()=>{try{const m=new window.DLZMap(mp,{tiles:root.dataset.tiles,attr:root.dataset.attr,center:[lat,lng],zoom:16});m.pin(lat,lng,'<path d="M5 20h14M7 20V9l5-4 5 4v11"/>');m.render();mp.addEventListener('click',()=>window.open('https://www.google.com/maps/dir/?api=1&destination='+ll,'_blank','noopener'));}catch(e){mp.remove();}});}
      else if(mp)mp.remove();
    }
    function paidForm(it){
      const name=root.dataset.meName||'',phone=root.dataset.mePhone||'';
      openModal('<div class="dlz-ent-modal-title-wrap"><div class="dlz-ent-modal-kicker">دليل الزائر</div><h3 id="dlz-ent-modal-title">حجز تذكرة</h3><p>'+esc(it.title||'')+'</p></div><div class="dlz-ent-modal-note">'+(it.price?'السعر: <strong dir="auto">'+esc(it.price)+'</strong><br>':'')+'الأطفال دون السنتين مجاناً.</div><form class="dlz-ent-booking-form"><label>الاسم الكامل<input name="name" type="text" required autocomplete="name" placeholder="اكتب الاسم الكامل" value="'+esc(name)+'"></label><label>رقم الهاتف<input name="phone" type="tel" required autocomplete="tel" inputmode="tel" dir="ltr" placeholder="رقم الهاتف" value="'+esc(phone)+'"></label><div class="dlz-ent-two"><label>عدد الرجال<input name="men" type="number" min="0" max="99" value="1" inputmode="numeric"></label><label>عدد النساء<input name="women" type="number" min="0" max="99" value="0" inputmode="numeric"></label></div><label>ما هو يوم الحجز؟<input name="date" type="date" required min="'+todayString()+'"></label><button type="submit" class="dlz-ent-submit">حجز الآن</button><div class="dlz-ent-form-message" aria-live="polite"></div></form>');
      const form=modalContent.querySelector('form');
      const first=form.querySelector(name&&phone?'[name=date]':'[name=name]');if(first)setTimeout(()=>first.focus(),30);
      form.addEventListener('submit',function(e){e.preventDefault();const fd=new FormData(form);fd.append('action',DLZ_ENT_DATA.action);fd.append('nonce',DLZ_ENT_DATA.nonce);fd.append('entertainment_id',it.id);const submit=form.querySelector('.dlz-ent-submit'),msg=form.querySelector('.dlz-ent-form-message');submit.disabled=true;submit.textContent='جارٍ إرسال الحجز...';msg.textContent='';fetch(DLZ_ENT_DATA.ajax_url,{method:'POST',body:fd,credentials:'same-origin'}).then(r=>r.json()).then(d=>{if(d.success){form.innerHTML='<div class="dlz-ent-success"><div class="dlz-ent-success-icon">✓</div><h4>تم إرسال طلب الحجز</h4><p>'+esc(d.data.message||'تم استلام طلبكم بنجاح.')+'</p><button type="button" class="dlz-ent-close-after">إغلاق</button></div>';form.querySelector('.dlz-ent-close-after').addEventListener('click',closeModal);}else{if(d.data&&d.data.redirect&&(d.data.code==='login_required'||d.data.code==='profile_required')){location.href=d.data.redirect;return;}msg.textContent=(d.data&&d.data.message)||'حدث خطأ، حاول مرة أخرى.';submit.disabled=false;submit.textContent='حجز الآن';}}).catch(()=>{msg.textContent='تعذر الاتصال بالخادم، حاول مرة أخرى.';submit.disabled=false;submit.textContent='حجز الآن';});});
    }
    cards.forEach(card=>{
      card.addEventListener('click',e=>{
        if(e.target.closest('.dlz-unified-favorite,a'))return;
        const it=data(card);
        if(e.target.closest('.dlz-ent-book')&&it.type==='paid'){paidForm(it);return;}
        details(it);
      });
      card.addEventListener('keydown',e=>{if((e.key==='Enter'||e.key===' ')&&e.target===card){e.preventDefault();details(data(card));}});
    });
    tabs.forEach(btn=>btn.addEventListener('click',function(){filter=this.dataset.filter||'paid';tabs.forEach(b=>{const active=b===this;b.classList.toggle('is-active',active);b.setAttribute('aria-selected',active?'true':'false');});render();}));
    closeBtn.addEventListener('click',closeModal);modal.querySelector('.dlz-ent-modal-backdrop').addEventListener('click',closeModal);document.addEventListener('keydown',e=>{if(e.key==='Escape'&&modal.classList.contains('is-open'))closeModal();});
    document.addEventListener('dase:cityChanged',function(e){const c=e&&e.detail?e.detail.city:'';if(c&&cities.includes(c)){root.dataset.currentCity=c;render();}});
    const hm=location.hash.match(/^#ent-(\d+)$/);
    if(hm){const c=root.querySelector('#ent-'+hm[1]);if(c){const it=data(c);if(it.type&&it.type!==filter){const t=root.querySelector('.dlz-ent-switch [data-filter="'+it.type+'"]');if(t){filter=it.type;tabs.forEach(b=>{b.classList.toggle('is-active',b===t);b.setAttribute('aria-selected',b===t?'true':'false');});}}render();setTimeout(()=>{c.scrollIntoView({block:'center'});details(it);},150);return;}}
    render();
  }
  function todayString(){const d=new Date();const p=n=>String(n).padStart(2,'0');return d.getFullYear()+'-'+p(d.getMonth()+1)+'-'+p(d.getDate());}
  function esc(v){return String(v==null?'':v).replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#039;','"':'&quot;'}[c]));}
  function boot(){document.querySelectorAll('.dlz-ent-widget').forEach(init);}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot);else boot();
  if(window.elementorFrontend&&window.elementorFrontend.hooks)window.elementorFrontend.hooks.addAction('frontend/element_ready/dlz_entertainment_cards.default',function($scope){init($scope[0]);});
})();
