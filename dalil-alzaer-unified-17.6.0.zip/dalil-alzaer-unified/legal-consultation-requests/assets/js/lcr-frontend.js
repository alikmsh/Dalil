(function ($) {
	'use strict';

	function closeAllPanels() {
		$('.lcr-cat-dropdown.open').removeClass('open').find('.lcr-cat-toggle').attr('aria-expanded', 'false');
	}

	$(document).on('click', '.lcr-cat-toggle', function (e) {
		e.stopPropagation();
		var $dropdown = $(this).closest('.lcr-cat-dropdown');
		var isOpen = $dropdown.hasClass('open');
		closeAllPanels();
		if (!isOpen) {
			$dropdown.addClass('open');
			$(this).attr('aria-expanded', 'true');
		}
	});

	$(document).on('click', '.lcr-cat-option', function () {
		var $dropdown = $(this).closest('.lcr-cat-dropdown');
		var value = $(this).data('value');
		var text = $(this).find('.lcr-cat-text').text();

		$dropdown.find('.lcr-cat-value').val(value);
		$dropdown.find('.lcr-cat-toggle-text').text(text);
		$dropdown.find('.lcr-cat-toggle').addClass('lcr-has-value');
		$dropdown.find('.lcr-cat-option').removeClass('active');
		$(this).addClass('active');
		closeAllPanels();
	});

	$(document).on('click', function () {
		closeAllPanels();
	});

	// upload label preview
	$(document).on('change', '.lcr-upload input[type=file]', function () {
		var name = this.files && this.files[0] ? this.files[0].name : '';
		if (name) {
			$(this).closest('.lcr-upload').find('.lcr-upload-text').text(name);
		}
	});

	$(document).on('submit', '.lcr-form', function (e) {
		e.preventDefault();
		var $form = $(this);
		var $widget = $form.closest('.lcr-widget');
		var $box = $form.find('.lcr-message-box');
		var $btn = $form.find('.lcr-submit');

		var catValue = $form.find('.lcr-cat-value').val();
		if (!catValue) {
			$box.attr('class', 'lcr-message-box error').text('يرجى اختيار نوع المشكلة.').show();
			$widget.get(0).scrollIntoView({ behavior: 'smooth', block: 'center' });
			return;
		}

		var formData = new FormData(this);
		formData.append('action', 'lcr_submit');
		formData.append('nonce', LCR_AJAX.nonce);

		$btn.prop('disabled', true);
		var originalText = $btn.find('.lcr-submit-text').text();
		$btn.find('.lcr-submit-text').text('...جارٍ الإرسال');

		$.ajax({
			url: LCR_AJAX.url,
			type: 'POST',
			data: formData,
			processData: false,
			contentType: false,
			success: function (res) {
				if (res.success) {
					$box.attr('class', 'lcr-message-box success').text(res.data.message).show();
					$form[0].reset();
					$form.find('.lcr-cat-value').val('');
					$form.find('.lcr-cat-toggle-text').text('اختر نوع المشكلة');
					$form.find('.lcr-cat-toggle').removeClass('lcr-has-value');
					$form.find('.lcr-cat-option').removeClass('active');
					$form.find('.lcr-upload-text').text('إرفاق صورة الجواز أو الوثيقة (اختياري)');
				} else {
					$box.attr('class', 'lcr-message-box error').text((res.data && res.data.message) || 'حدث خطأ، يرجى المحاولة مرة أخرى.').show();
				}
			},
			error: function () {
				$box.attr('class', 'lcr-message-box error').text('تعذر إرسال الطلب، يرجى المحاولة مرة أخرى.').show();
			},
			complete: function () {
				$btn.prop('disabled', false);
				$btn.find('.lcr-submit-text').text(originalText);
			}
		});
	});

}(jQuery));
