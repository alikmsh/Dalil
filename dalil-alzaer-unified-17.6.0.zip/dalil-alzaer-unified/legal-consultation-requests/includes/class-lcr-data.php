<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class LCR_Data {

	/**
	 * The 9 problem categories.
	 * Shown to the visitor in Arabic, shown to the admin in Persian.
	 */
	public static function categories() {
		return array(
			'visa'      => array( 'emoji' => '1️⃣', 'ar' => 'مشاكل الإقامة والتأشيرة', 'fa' => 'ویزا و اقامت' ),
			'passport'  => array( 'emoji' => '2️⃣', 'ar' => 'فقدان الجواز أو الوثائق',   'fa' => 'گم شدن پاسپورت' ),
			'accident'  => array( 'emoji' => '3️⃣', 'ar' => 'حادث سير أو إصابة',         'fa' => 'تصادف یا حادثه' ),
			'hospital'  => array( 'emoji' => '4️⃣', 'ar' => 'مشكلة مع المستشفى',         'fa' => 'مشکل بیمارستان' ),
			'hotel'     => array( 'emoji' => '5️⃣', 'ar' => 'مشكلة مع الفندق',           'fa' => 'مشکل هتل' ),
			'fraud'     => array( 'emoji' => '6️⃣', 'ar' => 'احتيال أو مشكلة مالية',     'fa' => 'کلاهبرداری یا مشکل مالی' ),
			'police'    => array( 'emoji' => '7️⃣', 'ar' => 'مشكلة مع الشرطة',           'fa' => 'مشکل با پلیس' ),
			'legal_doc' => array( 'emoji' => '8️⃣', 'ar' => 'ترجمة ووثائق قانونية',      'fa' => 'ترجمه و مدارک' ),
			'family'    => array( 'emoji' => '9️⃣', 'ar' => 'الزواج والأسرة',            'fa' => 'ازدواج و خانواده' ),
			'other'     => array( 'emoji' => '➕', 'ar' => 'مشاكل متفرقة',              'fa' => 'مشکلات متفرقه' ),
		);
	}

	public static function category_label( $key, $lang = 'ar' ) {
		$cats = self::categories();
		if ( isset( $cats[ $key ] ) ) {
			return $cats[ $key ][ $lang ];
		}
		return '';
	}

	/** Nationality list shown to the visitor — limited to these countries only. */
	public static function countries() {
		return array(
			'السعودية', 'الإمارات العربية المتحدة', 'الكويت', 'قطر', 'البحرين', 'عمان',
			'العراق', 'سوريا', 'لبنان', 'الأردن', 'فلسطين', 'اليمن', 'مصر',
		);
	}

	/** Destination cities in Iran, shown to the visitor. */
	public static function iran_cities() {
		return array(
			'مشهد المقدسة', 'قم المقدسة', 'طهران', 'شيراز',
		);
	}
}
