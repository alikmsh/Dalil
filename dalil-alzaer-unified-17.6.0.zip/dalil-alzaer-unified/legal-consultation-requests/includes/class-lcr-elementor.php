<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Shortcode fallback (works even without Elementor) — [lcr_form] */
add_shortcode( 'lcr_form', function( $atts ) {
	ob_start();
	lcr_render_form();
	return ob_get_clean();
} );

/**
 * Shared render function used by both the shortcode and the Elementor widget.
 */
function lcr_render_form( $gold_color = '', $navy_color = '', $show_header = true, $default_category = '' ) {
	wp_enqueue_style( 'lcr-frontend' );
	wp_enqueue_script( 'lcr-frontend' );

	$all_cats  = LCR_Data::categories();
	$countries = LCR_Data::countries();
	$cities    = LCR_Data::iran_cities();
	$uid       = 'lcr_' . wp_generate_uuid4();

	// Validate the default category key (comes from Elementor control).
	if ( $default_category && ! isset( $all_cats[ $default_category ] ) ) {
		$default_category = '';
	}
	$default_cat_text = $default_category ? $all_cats[ $default_category ]['ar'] : 'اختر نوع المشكلة';

	$style_parts = array();
	if ( $gold_color ) { $style_parts[] = '--lcr-gold:' . esc_attr( $gold_color ); }
	if ( $navy_color ) { $style_parts[] = '--lcr-navy:' . esc_attr( $navy_color ); }
	$style = $style_parts ? ' style="' . implode( ';', $style_parts ) . ';"' : '';
	?>
	<div class="lcr-widget" id="<?php echo esc_attr( $uid ); ?>"<?php echo $style; ?> dir="rtl">
		<form class="lcr-form" method="post" enctype="multipart/form-data" novalidate>

			<!-- Category bar: closed nav that opens a list of problem types -->
			<div class="lcr-field">
				<label class="lcr-label">نوع المشكلة <span class="lcr-req">*</span></label>
				<div class="lcr-cat-dropdown">
					<button type="button" class="lcr-cat-toggle<?php echo $default_category ? ' lcr-has-value' : ''; ?>" aria-expanded="false">
						<span class="lcr-cat-toggle-text"><?php echo esc_html( $default_cat_text ); ?></span>
						<span class="lcr-cat-arrow">⌄</span>
					</button>
					<div class="lcr-cat-panel">
						<?php foreach ( $all_cats as $key => $cat ) :
							$is_default = ( $default_category && $key === $default_category );
						?>
							<button type="button" class="lcr-cat-option<?php echo $is_default ? ' active' : ''; ?>" data-value="<?php echo esc_attr( $key ); ?>">
								<span class="lcr-cat-text"><?php echo esc_html( $cat['ar'] ); ?></span>
							</button>
						<?php endforeach; ?>
					</div>
					<input type="hidden" class="lcr-cat-value" name="category_key" value="<?php echo esc_attr( $default_category ); ?>" required />
				</div>
			</div>

			<div class="lcr-field">
				<label class="lcr-label" for="<?php echo esc_attr($uid);?>_name">الاسم <span class="lcr-req">*</span></label>
				<div class="lcr-input-wrap">
					<input type="text" id="<?php echo esc_attr($uid);?>_name" name="name" required />
				</div>
			</div>

			<div class="lcr-field">
				<label class="lcr-label">رقم الهاتف / واتساب <span class="lcr-req">*</span></label>
				<div class="lcr-input-wrap">
					<input type="tel" name="phone" required dir="ltr" />
				</div>
			</div>

			<div class="lcr-field lcr-field-row">
				<div class="lcr-field-half">
					<label class="lcr-label">الجنس <span class="lcr-req">*</span></label>
					<div class="lcr-input-wrap">
						<select name="gender" required>
							<option value="male">ذكر</option>
							<option value="female">أنثى</option>
						</select>
					</div>
				</div>
				<div class="lcr-field-half">
					<label class="lcr-label">الجنسية <span class="lcr-req">*</span></label>
					<div class="lcr-input-wrap">
						<select name="nationality" required>
							<?php foreach ( $countries as $c ) : ?>
								<option value="<?php echo esc_attr( $c ); ?>"><?php echo esc_html( $c ); ?></option>
							<?php endforeach; ?>
						</select>
					</div>
				</div>
			</div>

			<div class="lcr-field">
				<label class="lcr-label">المدينة المطلوبة للخدمات القانونية <span class="lcr-req">*</span></label>
				<div class="lcr-input-wrap">
					<select name="city" required>
						<?php foreach ( $cities as $c ) : ?>
							<option value="<?php echo esc_attr( $c ); ?>"><?php echo esc_html( $c ); ?></option>
						<?php endforeach; ?>
					</select>
				</div>
			</div>

			<div class="lcr-field">
				<label class="lcr-label">شرح المشكلة <span class="lcr-req">*</span></label>
				<div class="lcr-input-wrap lcr-textarea-wrap">
					<textarea name="message" rows="4" required></textarea>
				</div>
			</div>

			<div class="lcr-field">
				<label class="lcr-upload">
					<input type="file" name="attachment" accept=".jpg,.jpeg,.png,.webp,.pdf" />
					<span class="lcr-upload-text">إرفاق صورة الجواز أو الوثيقة (اختياري)</span>
					<span class="lcr-upload-hint">بإمكانك إرفاق صورة أو ملف PDF</span>
				</label>
			</div>

			<button type="submit" class="lcr-submit">
				<span class="lcr-submit-icon">➤</span>
				<span class="lcr-submit-text">إرسال الطلب</span>
			</button>

			<div class="lcr-message-box" style="display:none;"></div>
		</form>
	</div>
	<?php
}

/** Register the Elementor widget once Elementor has loaded. */
add_action( 'elementor/widgets/register', function( $widgets_manager ) {
	if ( ! class_exists( '\Elementor\Widget_Base' ) ) { return; }
	require_once LCR_PATH . 'includes/class-lcr-elementor-widget.php';
	$widgets_manager->register( new \LCR_Elementor_Widget() );
} );

add_action( 'elementor/elements/categories_registered', function( $elements_manager ) {
	$elements_manager->add_category( 'lcr-category', array(
		'title' => 'مشاوره قانونی',
		'icon'  => 'eicon-form-horizontal',
	) );
} );
