<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class LCR_Admin_Menu {

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'register_menu' ) );
	}

	public static function register_menu() {
		$new_count = LCR_DB::count_new();
		$badge     = $new_count > 0 ? ' <span class="lcr-badge">' . $new_count . '</span>' : '';

		add_menu_page(
			'مشاوره قانونی',
			'مشاوره قانونی' . $badge,
			'manage_options',
			'lcr-submissions',
			array( 'LCR_Admin_Submissions', 'render_list_page' ),
			'dashicons-clipboard',
			26
		);

		add_submenu_page( 'lcr-submissions', 'درخواست‌ها', 'درخواست‌ها' . $badge, 'manage_options', 'lcr-submissions', array( 'LCR_Admin_Submissions', 'render_list_page' ) );

		add_submenu_page( 'lcr-submissions', 'تنظیمات', 'تنظیمات', 'manage_options', 'lcr-settings', array( 'LCR_Settings', 'render_page' ) );
	}
}
LCR_Admin_Menu::init();
