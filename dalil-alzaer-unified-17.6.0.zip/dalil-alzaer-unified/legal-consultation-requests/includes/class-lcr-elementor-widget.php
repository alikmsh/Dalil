<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Core\Kits\Documents\Tabs\Global_Colors;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;

class LCR_Elementor_Widget extends Widget_Base {

	public function get_name() { return 'lcr_consultation_form'; }
	public function get_title() { return 'درخواست مشاوره قانونی'; }
	public function get_icon() { return 'eicon-form-horizontal'; }
	public function get_categories() { return array( 'dalil-alzaer' ); }
	public function get_keywords() { return array( 'مشاوره', 'فرم', 'consultation', 'legal', 'form' ); }

	protected function register_controls() {

		// ===== CONTENT TAB =====
		$this->start_controls_section( 'content_section', array(
			'label' => 'محتوا',
			'tab'   => Controls_Manager::TAB_CONTENT,
		) );

		$default_cat_options = array( '' => '— بدون پیش‌فرض —' );
		foreach ( LCR_Data::categories() as $key => $cat ) {
			$default_cat_options[ $key ] = $cat['fa'];
		}

		$this->add_control( 'default_category', array(
			'label'       => 'مشکل پیش‌فرض',
			'type'        => Controls_Manager::SELECT,
			'label_block' => true,
			'default'     => '',
			'options'     => $default_cat_options,
			'description' => 'اگر یک مورد رو انتخاب کنی، فرم با همون نوع مشکل از قبل انتخاب‌شده به کاربر نمایش داده می‌شه (کاربر همچنان می‌تونه تغییرش بده).',
		) );

		$this->end_controls_section();

		// ===== STYLE TAB =====
		$this->start_controls_section( 'style_section', array(
			'label' => 'ظاهر (سرمه‌ای و طلایی)',
			'tab'   => Controls_Manager::TAB_STYLE,
		) );

		$this->add_control( 'gold_color', array(
			'label'       => 'رنگ طلایی (اصلی)',
			'type'        => Controls_Manager::COLOR,
			'default'     => '#D4AF37',
			'global'      => array(
				'default' => Global_Colors::COLOR_PRIMARY,
			),
			'description' => 'رنگ دکمه‌ها، آیکون‌ها و برجسته‌ها. اگر به رنگ گلوبال قالب وصل بمونه، با تغییر رنگ اصلی تم خودکار آپدیت می‌شود.',
			'selectors'   => array(
				'{{WRAPPER}} .lcr-widget' => '--lcr-gold: {{VALUE}};',
			),
		) );

		$this->add_control( 'navy_color', array(
			'label'       => 'رنگ سرمه‌ای (پس‌زمینه)',
			'type'        => Controls_Manager::COLOR,
			'default'     => '#0B1B33',
			'global'      => array(
				'default' => Global_Colors::COLOR_SECONDARY,
			),
			'description' => 'رنگ پس‌زمینه‌ی کارت فرم. اگر به رنگ گلوبال قالب وصل بمونه، با تغییر رنگ ثانویه‌ی تم خودکار آپدیت می‌شود.',
			'selectors'   => array(
				'{{WRAPPER}} .lcr-widget' => '--lcr-navy: {{VALUE}};',
			),
		) );

		$this->add_control( 'radius', array(
			'label'     => 'گردی گوشه‌ها (px)',
			'type'      => Controls_Manager::SLIDER,
			'range'     => array( 'px' => array( 'min' => 0, 'max' => 40 ) ),
			'default'   => array( 'size' => 16, 'unit' => 'px' ),
			'selectors' => array(
				'{{WRAPPER}} .lcr-widget' => '--lcr-radius: {{SIZE}}{{UNIT}};',
			),
		) );

		$this->add_group_control( Group_Control_Typography::get_type(), array(
			'name'     => 'body_typography',
			'label'    => 'فونت',
			'global'   => array( 'default' => Global_Typography::TYPOGRAPHY_TEXT ),
			'selector' => '{{WRAPPER}} .lcr-widget',
		) );

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		lcr_render_form(
			$settings['gold_color'],
			$settings['navy_color'],
			true,
			$settings['default_category']
		);
	}
}
