<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

define( 'LCR_VERSION', '2.0.0' );
define( 'LCR_PATH', plugin_dir_path( __FILE__ ) );
define( 'LCR_URL', plugin_dir_url( __FILE__ ) );
define( 'LCR_TABLE', 'lcr_submissions' );

require_once LCR_PATH . 'includes/class-lcr-data.php';
require_once LCR_PATH . 'includes/class-lcr-db.php';
require_once LCR_PATH . 'includes/class-lcr-admin-menu.php';
require_once LCR_PATH . 'includes/class-lcr-admin-submissions.php';
require_once LCR_PATH . 'includes/class-lcr-settings.php';
require_once LCR_PATH . 'includes/class-lcr-ajax.php';
require_once LCR_PATH . 'includes/class-lcr-elementor.php';

register_activation_hook( __FILE__, array( 'LCR_DB', 'install' ) );
add_action( 'admin_init', array( 'LCR_DB', 'maybe_upgrade' ) );
add_action( 'wp_ajax_lcr_submit', array( 'LCR_DB', 'maybe_upgrade' ), 1 );
add_action( 'wp_ajax_nopriv_lcr_submit', array( 'LCR_DB', 'maybe_upgrade' ), 1 );

/**
 * Front-end assets — only loaded when the widget is actually on the page,
 * so it never conflicts with the active theme's own styles/scripts.
 */
function lcr_register_frontend_assets() {
	wp_register_style( 'lcr-frontend', LCR_URL . 'assets/css/lcr-frontend.css', array(), LCR_VERSION );
	wp_register_script( 'lcr-frontend', LCR_URL . 'assets/js/lcr-frontend.js', array( 'jquery' ), LCR_VERSION, true );
	wp_localize_script( 'lcr-frontend', 'LCR_AJAX', array(
		'url'   => admin_url( 'admin-ajax.php' ),
		'nonce' => wp_create_nonce( 'lcr_submit_nonce' ),
	) );
}
add_action( 'wp_enqueue_scripts', 'lcr_register_frontend_assets' );

/**
 * Admin assets — only on our own admin pages.
 */
function lcr_admin_assets( $hook ) {
	if ( strpos( $hook, 'lcr' ) === false ) {
		return;
	}
	wp_enqueue_style( 'lcr-admin', LCR_URL . 'assets/css/lcr-admin.css', array(), LCR_VERSION );
}
add_action( 'admin_enqueue_scripts', 'lcr_admin_assets' );
