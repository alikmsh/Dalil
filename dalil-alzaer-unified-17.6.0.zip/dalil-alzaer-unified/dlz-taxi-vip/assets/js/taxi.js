/* Dalil Al Zaer — «تاكسي VIP»: cards → bottom sheet (التفاصيل · القوانين · التأكيد). No jQuery. */
(function () {
	'use strict';
	var d = document, cfg = window.DLZTaxi || {};
	var LATIN = { '۰': 0, '۱': 1, '۲': 2, '۳': 3, '۴': 4, '۵': 5, '۶': 6, '۷': 7, '۸': 8, '۹': 9, '٠': 0, '١': 1, '٢': 2, '٣': 3, '٤': 4, '٥': 5, '٦': 6, '٧': 7, '٨': 8, '٩': 9 };
	function latin(s) { return String(s || '').replace(/[۰-۹٠-٩]/g, function (c) { return LATIN[c]; }); }

	function init(root) {
		if (root.__dtx) return;
		root.__dtx = 1;
		var ov = root.querySelector('.dtx-ov');
		if (!ov) return;
		d.body.appendChild(ov); // fixed overlay must not live inside a transformed Elementor container
		var sheet = ov.querySelector('.dtx-sheet'), body = ov.querySelector('.dtx-sh-body');
		var steps = ov.querySelectorAll('.dtx-step'), dots = ov.querySelectorAll('.dtx-steps li');
		var go = ov.querySelector('.dtx-go'), goT = go.querySelector('span'), back = ov.querySelector('.dtx-back');
		var msg = ov.querySelector('.dtx-msg'), agree = ov.querySelector('.dtx-agree-in');
		var track = ov.querySelector('.dtx-gal-track'), gdots = ov.querySelector('.dtx-dots');
		var nameIn = ov.querySelector('.dtx-name-in'), phoneIn = ov.querySelector('.dtx-phone-in');
		var cur = null, step = 1, service = '8', pushed = false, busy = false, lastFocus = null;

		function setStep(n) {
			step = n;
			steps.forEach(function (s) { s.hidden = +s.getAttribute('data-step') !== n; });
			dots.forEach(function (li, i) { li.classList.toggle('is-on', i < n); li.classList.toggle('is-cur', i === n - 1); });
			ov.querySelector('.dtx-steps').hidden = n === 4;
			back.hidden = n < 2 || n > 3;
			msg.textContent = '';
			msg.classList.remove('is-err');
			sheet.setAttribute('data-step', n);
			if (n === 1) goT.textContent = 'احجز الآن';
			else if (n === 2) goT.textContent = 'متابعة الحجز';
			else if (n === 3) goT.textContent = 'إرسال طلب الحجز';
			else goT.textContent = cfg.orders ? 'عرض «طلباتي»' : 'تم';
			go.disabled = n === 2 && !agree.checked;
			go.classList.toggle('is-done', n === 4);
			body.scrollTop = 0;
			if (n === 3 && cur) {
				var im = ov.querySelector('.dtx-sum img');
				if (cur.imgs && cur.imgs[0]) im.src = cur.imgs[0]; else im.removeAttribute('src');
				ov.querySelector('.dtx-sum-t').textContent = cur.model || cur.title;
				ov.querySelector('.dtx-sum-s').textContent = service === '8' ? 'خدمة 8 ساعات' : 'خدمة 24 ساعة';
				ov.querySelector('.dtx-sum-p').textContent = price() || '';
				if (!nameIn.value && cfg.name) nameIn.value = cfg.name;
				if (!phoneIn.value && cfg.phone) phoneIn.value = latin(cfg.phone);
			}
		}
		function pick(code) {
			service = String(code);
			ov.querySelectorAll('.dtx-opt').forEach(function (o) {
				var on = o.getAttribute('data-service') === service;
				o.classList.toggle('is-on', on);
				o.setAttribute('aria-checked', on ? 'true' : 'false');
			});
		}
		function price() { return cur ? (service === '8' ? cur.p8 : cur.p24) : ''; }

		function gallery(imgs) {
			track.innerHTML = '';
			gdots.innerHTML = '';
			(imgs.length ? imgs : ['']).forEach(function (u, i) {
				var f = d.createElement('figure');
				if (u) {
					var im = d.createElement('img');
					im.src = u; im.alt = ''; im.decoding = 'async';
					if (i) im.loading = 'lazy';
					f.appendChild(im);
				} else f.className = 'is-empty';
				track.appendChild(f);
				if (imgs.length > 1) {
					var b = d.createElement('button');
					b.type = 'button'; b.setAttribute('aria-label', 'الصورة ' + (i + 1));
					if (!i) b.className = 'is-on';
					b.addEventListener('click', function () { track.scrollTo({ left: track.children[i].offsetLeft - track.offsetLeft, behavior: 'smooth' }); });
					gdots.appendChild(b);
				}
			});
			track.scrollLeft = 0;
		}
		track.addEventListener('scroll', function () {
			var w = track.clientWidth || 1, i = Math.round(Math.abs(track.scrollLeft) / w);
			gdots.querySelectorAll('button').forEach(function (b, k) { b.classList.toggle('is-on', k === i); });
		}, { passive: true });

		function open(data, trigger) {
			cur = data;
			lastFocus = trigger || null;
			gallery(data.imgs || []);
			ov.querySelector('.dtx-sh-title').textContent = data.model || data.title || 'تاكسي VIP';
			ov.querySelector('.dtx-name b').textContent = data.model || data.title;
			ov.querySelector('.dtx-name small').textContent = data.model ? 'السائق: ' + data.title : 'سيارة خاصة مع سائق';
			var o8 = ov.querySelector('.dtx-opt[data-service="8"]'), o24 = ov.querySelector('.dtx-opt[data-service="24"]');
			o8.querySelector('.dtx-opt-p').textContent = data.p8 || '';
			o24.querySelector('.dtx-opt-p').textContent = data.p24 || '';
			o8.hidden = !data.p8 && !!data.p24;
			o24.hidden = !data.p24 && !!data.p8;
			pick(!data.p8 && data.p24 ? '24' : '8');
			var info = ov.querySelector('.dtx-info');
			info.hidden = !data.info;
			if (data.info) info.querySelector('img').src = data.info;
			agree.checked = false;
			ov.classList.remove('is-closing');
			setStep(1);
			ov.hidden = false;
			d.documentElement.classList.add('dtx-lock');
			requestAnimationFrame(function () { ov.classList.add('is-open'); });
			try { var st = {}, hs = history.state; if (hs && typeof hs === 'object') for (var k in hs) st[k] = hs[k]; st.dtx = 1; history.pushState(st, ''); pushed = true; } catch (e) { pushed = false; }
			setTimeout(function () { try { sheet.focus({ preventScroll: true }); } catch (e) {} }, 60);
		}
		function close(fromHistory) {
			if (ov.hidden) return;
			ov.classList.remove('is-open');
			ov.classList.add('is-closing');
			d.documentElement.classList.remove('dtx-lock');
			setTimeout(function () { ov.hidden = true; ov.classList.remove('is-closing'); }, 260);
			if (!fromHistory && pushed && history.state && history.state.dtx) { try { history.back(); } catch (e) {} }
			pushed = false;
			if (lastFocus) try { lastFocus.focus({ preventScroll: true }); } catch (e) {}
		}
		function error(t) { msg.textContent = t; msg.classList.add('is-err'); }

		function submit() {
			if (busy) return;
			var name = nameIn.value.trim(), phone = latin(phoneIn.value).trim();
			phoneIn.value = phone;
			if (name.length < 2) { error('يرجى كتابة اسمك.'); nameIn.focus(); return; }
			if (!/^[0-9+\-()\s]{7,30}$/.test(phone)) { error('يرجى كتابة رقم هاتف صحيح.'); phoneIn.focus(); return; }
			if (!cfg.logged) { location.href = cfg.login || '/'; return; }
			busy = true;
			go.disabled = true;
			go.classList.add('is-busy');
			goT.textContent = 'جارٍ الإرسال…';
			var f = new FormData();
			f.append('action', 'dlz_taxi_submit_booking');
			f.append('nonce', cfg.nonce || '');
			f.append('taxi_id', cur.id);
			f.append('service', service);
			f.append('customer_name', name);
			f.append('customer_phone', phone);
			fetch(cfg.ajax_url, { method: 'POST', body: f, credentials: 'same-origin' })
				.then(function (r) { return r.json().catch(function () { return {}; }); })
				.then(function (r) {
					busy = false;
					go.classList.remove('is-busy');
					if (r && r.success) {
						ov.querySelector('.dtx-done-m').textContent = (r.data && r.data.message) || 'تم إرسال طلب الحجز بنجاح.';
						setStep(4);
						go.disabled = false;
						return;
					}
					var dt = (r && r.data) || {};
					if (dt.code === 'login_required') { location.href = cfg.login || '/'; return; }
					if (dt.code === 'profile_required' && dt.redirect) { location.href = dt.redirect; return; }
					setStep(3);
					error(dt.message || 'حدث خطأ، حاول مرة أخرى.');
				})
				.catch(function () { busy = false; go.classList.remove('is-busy'); setStep(3); error('تعذّر الاتصال بالخادم، حاول مرة أخرى.'); });
		}

		root.addEventListener('click', function (e) {
			var c = e.target.closest('.dtx-open');
			if (c && root.contains(c)) {
				var data;
				try { data = JSON.parse(c.getAttribute('data-taxi') || '{}'); } catch (x) { data = {}; }
				if (data.id) open(data, c);
			}
		});
		ov.addEventListener('click', function (e) {
			var o = e.target.closest('.dtx-opt');
			if (o) { pick(o.getAttribute('data-service')); return; }
			if (e.target.closest('.dtx-x')) { close(false); return; }
			if (e.target === ov) { close(false); return; }
			if (e.target.closest('.dtx-back')) { if (step > 1 && step < 4) setStep(step - 1); return; }
			if (e.target.closest('.dtx-go')) {
				if (step === 1) setStep(2);
				else if (step === 2) { if (agree.checked) setStep(3); else error('يرجى الموافقة على قوانين السفر للمتابعة.'); }
				else if (step === 3) submit();
				else if (cfg.orders) location.href = cfg.orders;
				else close(false);
			}
		});
		agree.addEventListener('change', function () { go.disabled = !agree.checked; msg.textContent = ''; });
		ov.querySelector('.dtx-form').addEventListener('submit', function (e) { e.preventDefault(); submit(); });
		window.addEventListener('popstate', function () {
			if (ov.hidden) return;
			if (step === 2 || step === 3) {
				setStep(step - 1);
				try { var st = {}, hs = history.state; if (hs && typeof hs === 'object') for (var k in hs) st[k] = hs[k]; st.dtx = 1; history.pushState(st, ''); } catch (e) {}
				return;
			}
			close(true);
		});
		d.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !ov.hidden) close(false); });

		/* drag the grab bar down to close */
		var y0 = null, dy = 0;
		sheet.querySelector('.dtx-grab').addEventListener('touchstart', function (e) { y0 = e.touches[0].clientY; dy = 0; sheet.style.transition = 'none'; }, { passive: true });
		sheet.addEventListener('touchmove', function (e) {
			if (y0 === null) return;
			dy = Math.max(0, e.touches[0].clientY - y0);
			sheet.style.transform = 'translateY(' + dy + 'px)';
		}, { passive: true });
		sheet.addEventListener('touchend', function () {
			if (y0 === null) return;
			sheet.style.transition = '';
			sheet.style.transform = '';
			if (dy > 90) close(false);
			y0 = null;
		});
	}
	function boot() { d.querySelectorAll('.dtx').forEach(init); }
	if (d.readyState === 'loading') d.addEventListener('DOMContentLoaded', boot); else boot();
	window.addEventListener('elementor/frontend/init', function () { setTimeout(boot, 0); });
})();
