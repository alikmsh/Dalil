<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
if ( ! class_exists( '\Elementor\Widget_Base' ) ) { return; }

class DLZ_Taxi_Elementor_Widget extends \Elementor\Widget_Base {
    public function get_name() { return 'dlz_taxi_vip_cards'; }
    public function get_title() { return 'دلیل الزائر — تاكسي VIP'; }
    public function get_icon() { return 'eicon-car'; }
    public function get_categories() { return array( 'dalil-alzaer' ); }
    public function get_keywords() { return array( 'taxi', 'vip', 'dalil', 'دلیل الزائر', 'تاكسي', 'حجز' ); }

    protected function register_controls() {
        $this->start_controls_section( 'dlz_info', array( 'label' => 'دلیل الزائر' ) );
        $this->add_control( 'dlz_notice', array(
            'type' => \Elementor\Controls_Manager::RAW_HTML,
            'raw' => '<div style="line-height:1.8">تاکسی‌ها، تصاویر، مدل خودرو، امکانات و قیمت‌های ۸ و ۲۴ ساعته از «تاكسي VIP» در پیشخوان مدیریت می‌شوند. در این ویجت تنظیمی لازم نیست. (شورت‌کد: [dlz_taxi_vip])</div>',
            'content_classes' => 'elementor-panel-alert elementor-panel-alert-info'
        ) );
        $this->end_controls_section();
    }

    protected function render() {
        if ( class_exists( 'DLZ_Taxi_Frontend' ) ) {
            echo DLZ_Taxi_Frontend::render(); // phpcs:ignore
        }
    }
}
