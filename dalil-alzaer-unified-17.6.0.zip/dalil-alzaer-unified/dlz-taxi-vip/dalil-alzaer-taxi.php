<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
if ( ! defined( 'DLZ_TAXI_VERSION' ) ) define( 'DLZ_TAXI_VERSION', '9.0.0' );
if ( ! defined( 'DLZ_TAXI_PATH' ) ) define( 'DLZ_TAXI_PATH', DASE_PATH . 'dlz-taxi-vip/' );
if ( ! defined( 'DLZ_TAXI_URL' ) ) define( 'DLZ_TAXI_URL', DASE_URL . 'dlz-taxi-vip/' );
require_once DLZ_TAXI_PATH . 'includes/class-dlz-taxi-post-types.php';
require_once DLZ_TAXI_PATH . 'includes/class-dlz-taxi-admin.php';
require_once DLZ_TAXI_PATH . 'includes/class-dlz-taxi-frontend.php';
require_once DLZ_TAXI_PATH . 'includes/class-dlz-taxi-ajax.php';
if ( ! class_exists( 'DLZ_Taxi_Plugin', false ) ) {
    final class DLZ_Taxi_Plugin {
        private static $instance = null;
        public static function instance() { if ( null === self::$instance ) self::$instance = new self(); return self::$instance; }
        private function __construct() {
            DLZ_Taxi_Post_Types::instance();
            DLZ_Taxi_Admin::instance();
            DLZ_Taxi_Frontend::instance();
            DLZ_Taxi_Ajax::instance();
            add_action( 'elementor/widgets/register', array( $this, 'register_widget' ) );
            add_action( 'elementor/elements/categories_registered', array( $this, 'register_category' ) );
        }
        public function register_category( $manager ) { if ( is_object( $manager ) && method_exists( $manager, 'add_category' ) ) $manager->add_category( 'dlz-taxi-cat', array( 'title' => 'دلیل الزائر', 'icon' => 'eicon-car' ) ); }
        public function register_widget( $widgets_manager ) {
            if ( ! class_exists( '\Elementor\Widget_Base' ) ) return;
            require_once DLZ_TAXI_PATH . 'elementor/class-dlz-taxi-widget.php';
            if ( class_exists( 'DLZ_Taxi_Elementor_Widget' ) ) $widgets_manager->register( new DLZ_Taxi_Elementor_Widget() );
        }
    }
    DLZ_Taxi_Plugin::instance();
}
