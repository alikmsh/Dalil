<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
class DLZ_Taxi_Ajax {
    private static $instance = null;
    public static function instance() { if ( null === self::$instance ) { self::$instance = new self(); } return self::$instance; }
    private function __construct() { add_action( 'wp_ajax_dlz_taxi_submit_booking', array( $this, 'submit' ) ); add_action( 'wp_ajax_nopriv_dlz_taxi_submit_booking', array( $this, 'submit' ) ); }
    private function fail( $message, $status = 400 ) { wp_send_json_error( array( 'message' => $message ), $status ); }
    public function submit() {
        $nonce = isset( $_POST['nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['nonce'] ) ) : '';
        if ( ! wp_verify_nonce( $nonce, 'dlz_taxi_booking' ) ) { $this->fail( 'خطأ أمني، يرجى تحديث الصفحة.', 403 ); }
        if ( function_exists( 'dlz_require_profile_for_ajax' ) ) { dlz_require_profile_for_ajax(); } elseif ( ! is_user_logged_in() ) { $this->fail( 'يرجى تسجيل الدخول أولاً.', 401 ); }
        $rk = 'dlz_taxi_rl_' . md5( ( is_user_logged_in() ? 'u' . get_current_user_id() : '' ) . '|' . ( isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '' ) );
        $hits = (int) get_transient( $rk );
        if ( $hits >= 5 ) { $this->fail( 'لقد أرسلت عدة طلبات خلال وقت قصير، حاول بعد قليل.', 429 ); }
        set_transient( $rk, $hits + 1, 10 * MINUTE_IN_SECONDS );
        $taxi_id = isset( $_POST['taxi_id'] ) ? absint( $_POST['taxi_id'] ) : 0;
        $service_code = isset( $_POST['service'] ) ? sanitize_key( wp_unslash( $_POST['service'] ) ) : '';
        $name = isset( $_POST['customer_name'] ) ? sanitize_text_field( wp_unslash( $_POST['customer_name'] ) ) : '';
        $phone = isset( $_POST['customer_phone'] ) ? sanitize_text_field( wp_unslash( $_POST['customer_phone'] ) ) : '';
        $phone = strtr( $phone, array( '۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9','٠'=>'0','١'=>'1','٢'=>'2','٣'=>'3','٤'=>'4','٥'=>'5','٦'=>'6','٧'=>'7','٨'=>'8','٩'=>'9' ) );
        $name  = mb_substr( $name, 0, 80 );
        if ( ! $taxi_id || 'dlz_taxi_driver' !== get_post_type( $taxi_id ) || 'publish' !== get_post_status( $taxi_id ) ) { $this->fail( 'التاكسي غير متاح حالياً.' ); }
        if ( ! $name || ! $phone ) { $this->fail( 'يرجى إدخال الاسم ورقم الهاتف.' ); }
        if ( ! in_array( $service_code, array( '8', '24' ), true ) ) { $this->fail( 'نوع الخدمة غير صحيح.' ); }
        if ( ! preg_match( '/^[0-9+\-()\s]{7,30}$/u', $phone ) ) { $this->fail( 'رقم الهاتف غير صحيح.' ); }
        $title = get_the_title( $taxi_id );
        $price = get_post_meta( $taxi_id, '_dlz_price_' . $service_code, true );
        $service = '8' === $service_code ? 'خدمة 8 ساعات' : 'خدمة 24 ساعة';
        $booking_id = wp_insert_post( array( 'post_type' => 'dlz_taxi_booking', 'post_status' => 'publish', 'post_title' => 'حجز — ' . $title . ' — ' . $name ), true );
        if ( is_wp_error( $booking_id ) || ! $booking_id ) { $this->fail( 'تعذر تسجيل الحجز، حاول مرة أخرى.' ); }
        if ( is_user_logged_in() ) update_post_meta( $booking_id, '_dlz_user_id', get_current_user_id() );
        update_post_meta( $booking_id, '_dlz_taxi_id', $taxi_id ); update_post_meta( $booking_id, '_dlz_taxi_title', $title ); update_post_meta( $booking_id, '_dlz_service', $service ); update_post_meta( $booking_id, '_dlz_price', $price ); update_post_meta( $booking_id, '_dlz_customer_name', $name ); update_post_meta( $booking_id, '_dlz_customer_phone', $phone ); update_post_meta( $booking_id, '_dlz_created', current_time( 'mysql' ) );
        $email = get_option( 'admin_email' );
        if ( $email ) { $subject = 'حجز تاكسي VIP جديد — ' . $title; $message = "تم تسجيل حجز جديد في دليل الزائر\n\nالتاكسي: {$title}\nالخدمة: {$service}\nالسعر: {$price}\nاسم العميل: {$name}\nرقم الهاتف: {$phone}\n\n" . admin_url( 'edit.php?post_type=dlz_taxi_booking' ); wp_mail( $email, $subject, $message ); }
        wp_send_json_success( array( 'message' => 'تم إرسال طلب الحجز بنجاح. سيتواصل معك المسؤول قريباً.', 'code' => (int) $booking_id ) );
    }
}
