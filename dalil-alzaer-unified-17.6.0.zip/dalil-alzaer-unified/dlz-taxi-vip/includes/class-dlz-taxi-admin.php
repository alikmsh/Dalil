<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
class DLZ_Taxi_Admin {
    private static $instance = null;
    public static function instance() {
        if ( null === self::$instance ) { self::$instance = new self(); }
        return self::$instance;
    }
    private function __construct() {
        add_action( 'admin_menu', array( $this, 'menu' ) );
        add_action( 'add_meta_boxes', array( $this, 'boxes' ) );
        add_action( 'save_post_dlz_taxi_driver', array( $this, 'save_taxi' ) );
        add_action( 'admin_enqueue_scripts', array( $this, 'assets' ) );
        add_filter( 'manage_dlz_taxi_booking_posts_columns', array( $this, 'columns' ) );
        add_action( 'manage_dlz_taxi_booking_posts_custom_column', array( $this, 'column_content' ), 10, 2 );
    }
    public function menu() {
        add_menu_page( 'تاكسی VIP - دلیل الزائر', 'تاكسی VIP', 'manage_options', 'dlz-taxi-panel', array( $this, 'dashboard' ), 'dashicons-car', 26 );
        add_submenu_page( 'dlz-taxi-panel', 'تاکسی‌ها', 'تاکسی‌ها', 'manage_options', 'edit.php?post_type=dlz_taxi_driver' );
        add_submenu_page( 'dlz-taxi-panel', 'افزودن تاکسی', 'افزودن تاکسی', 'manage_options', 'post-new.php?post_type=dlz_taxi_driver' );
        add_submenu_page( 'dlz-taxi-panel', 'رزروها', 'رزروها', 'manage_options', 'edit.php?post_type=dlz_taxi_booking' );
    }
    public function dashboard() {
        $taxi_count = wp_count_posts( 'dlz_taxi_driver' );
        $booking_count = wp_count_posts( 'dlz_taxi_booking' );
        $taxi_total = isset( $taxi_count->publish ) ? (int) $taxi_count->publish : 0;
        $booking_total = isset( $booking_count->publish ) ? (int) $booking_count->publish : 0;
        ?>
        <div class="wrap" dir="rtl">
            <h1>دلیل الزائر — تاكسي VIP</h1>
            <p>تمام محتوای تاکسی‌ها از این بخش مدیریت می‌شود و ویجت Elementor فقط آن‌ها را نمایش می‌دهد.</p>
            <div style="display:flex;gap:16px;flex-wrap:wrap;margin:25px 0;">
                <div style="background:#06372a;color:#fff;padding:20px 28px;border-radius:14px;min-width:180px;"><strong style="font-size:28px;color:#e7bd4e;display:block;"><?php echo esc_html( $taxi_total ); ?></strong>تاکسی فعال</div>
                <div style="background:#06372a;color:#fff;padding:20px 28px;border-radius:14px;min-width:180px;"><strong style="font-size:28px;color:#e7bd4e;display:block;"><?php echo esc_html( $booking_total ); ?></strong>رزرو ثبت‌شده</div>
            </div>
            <p><a class="button button-primary" href="<?php echo esc_url( admin_url( 'edit.php?post_type=dlz_taxi_driver' ) ); ?>">مدیریت تاکسی‌ها</a> <a class="button" href="<?php echo esc_url( admin_url( 'edit.php?post_type=dlz_taxi_booking' ) ); ?>">مشاهده رزروها</a></p>
        </div>
        <?php
    }
    public function assets( $hook ) {
        if ( ! in_array( $hook, array( 'post.php', 'post-new.php' ), true ) ) { return; }
        if ( isset( $_GET['post_type'] ) && 'dlz_taxi_driver' === sanitize_key( wp_unslash( $_GET['post_type'] ) ) ) { wp_enqueue_media(); }
        if ( 'post.php' === $hook && isset( $_GET['post'] ) && 'dlz_taxi_driver' === get_post_type( absint( $_GET['post'] ) ) ) { wp_enqueue_media(); }
    }
    public function boxes() {
        add_meta_box( 'dlz_taxi_details', 'اطلاعات تاکسی VIP', array( $this, 'taxi_box' ), 'dlz_taxi_driver', 'normal', 'high' );
        add_meta_box( 'dlz_taxi_booking_details', 'جزئیات رزرو', array( $this, 'booking_box' ), 'dlz_taxi_booking', 'normal', 'high' );
    }
    private function field( $post_id, $key, $default = '' ) { $v = get_post_meta( $post_id, '_dlz_' . $key, true ); return '' !== $v ? $v : $default; }
    public function taxi_box( $post ) {
        wp_nonce_field( 'dlz_save_taxi', 'dlz_taxi_nonce' );
        $card = $this->field( $post->ID, 'card_image' ); $car = $this->field( $post->ID, 'car_image' ); $car_images = get_post_meta( $post->ID, '_dlz_car_images', true ); $car_images = is_array( $car_images ) ? $car_images : array(); $info = $this->field( $post->ID, 'info_image' );
        $p8 = $this->field( $post->ID, 'price_8' ); $p24 = $this->field( $post->ID, 'price_24' );
        ?>
        <div class="dlz-admin-fields" style="max-width:900px;">
            <p><strong>نام راننده / عنوان تاکسی</strong><br><input type="text" name="dlz_driver_name" value="<?php echo esc_attr( $post->post_title ); ?>" style="width:100%;max-width:620px;padding:8px;"></p>
            <p>تصویر اصلی کارت که در ویجت نمایش داده می‌شود:</p><?php $this->media_field( 'card_image', $card, 'انتخاب تصویر کارت' ); ?>
            <p>تصاویر خودرو که در پاپ‌آپ به‌صورت گالری نمایش داده می‌شوند (امکان انتخاب چند تصویر):</p><?php $this->media_gallery_field( 'car_images', $car_images, 'انتخاب تصاویر خودرو' ); ?>
            <p>تصویر اطلاعات راننده و محدوده فعالیت:</p><?php $this->media_field( 'info_image', $info, 'انتخاب تصویر اطلاعات راننده' ); ?>
            <hr>
            <h3>مشخصات خودرو (نمایش روی کارت)</h3>
            <p><label>مدل خودرو</label><br><input type="text" name="dlz_model" value="<?php echo esc_attr( get_post_meta( $post->ID, '_dlz_model', true ) ); ?>" placeholder="مثلاً تويوتا كامري" style="width:100%;max-width:420px;padding:8px;"></p>
            <p><label>تعداد صندلی مسافر</label><br><input type="number" min="0" max="60" name="dlz_seats" value="<?php echo esc_attr( get_post_meta( $post->ID, '_dlz_seats', true ) ); ?>" style="width:120px;padding:8px;"></p>
            <p><strong>امکانات</strong><br><?php
                $have = get_post_meta( $post->ID, '_dlz_features', true ); $have = is_array( $have ) ? $have : array();
                foreach ( DLZ_Taxi_Frontend::features() as $fk => $fv ) {
                    echo '<label style="display:inline-flex;gap:6px;align-items:center;margin:6px 0 0 18px"><input type="checkbox" name="dlz_features[]" value="' . esc_attr( $fk ) . '"' . checked( in_array( $fk, $have, true ), true, false ) . '> ' . esc_html( $fv[0] ) . '</label>';
                }
            ?></p>
            <p style="color:#666;">کارت جدید با عکس اول گالری خودرو ساخته می‌شود؛ «تصویر کارت» فقط وقتی استفاده می‌شود که گالری خالی باشد.</p>
            <hr>
            <h3>قیمت خدمات</h3>
            <p><label>قیمت خدمت ۸ ساعته</label><br><input type="text" name="dlz_price_8" value="<?php echo esc_attr( $p8 ); ?>" placeholder="مثلاً 75000 د.ع" style="width:240px;padding:8px;"></p>
            <p><label>قیمت خدمت ۲۴ ساعته</label><br><input type="text" name="dlz_price_24" value="<?php echo esc_attr( $p24 ); ?>" placeholder="مثلاً 120000 د.ع" style="width:240px;padding:8px;"></p>
            <p style="color:#666;">قیمت‌ها مستقیماً زیر گزینه‌های ۸ و ۲۴ ساعت در پاپ‌آپ نمایش داده می‌شوند.</p>
        </div>
        <?php
    }
    private function media_field( $key, $value, $button ) {
        $id = 'dlz_media_' . $key; $preview = $value ? '<img src="' . esc_url( $value ) . '" style="max-width:260px;max-height:150px;display:block;margin:8px 0;border-radius:10px;object-fit:cover;">' : '';
        echo '<input type="hidden" id="' . esc_attr( $id ) . '" name="dlz_' . esc_attr( $key ) . '" value="' . esc_attr( $value ) . '">';
        echo '<div id="' . esc_attr( $id ) . '_preview">' . $preview . '</div><button type="button" class="button dlz-media-btn" data-target="' . esc_attr( $id ) . '">' . esc_html( $button ) . '</button> <button type="button" class="button dlz-media-remove" data-target="' . esc_attr( $id ) . '">حذف</button>';
        static $printed = false;
        if ( ! $printed ) { $printed = true; add_action( 'admin_footer', array( $this, 'media_script' ) ); }
    }
    private function media_gallery_field( $key, $values, $button ) {
        $id = 'dlz_media_' . $key;
        $values = array_values( array_filter( array_map( 'esc_url_raw', (array) $values ) ) );
        echo '<input type="hidden" id="' . esc_attr( $id ) . '" name="dlz_' . esc_attr( $key ) . '" value="' . esc_attr( wp_json_encode( $values ) ) . '">';
        echo '<div id="' . esc_attr( $id ) . '_preview" style="display:flex;flex-wrap:wrap;gap:10px;margin:10px 0;">';
        foreach ( $values as $url ) { echo '<div class="dlz-gallery-preview" style="position:relative;"><img src="' . esc_url( $url ) . '" style="width:150px;height:90px;display:block;border-radius:10px;object-fit:cover;"></div>'; }
        echo '</div><button type="button" class="button dlz-media-gallery-btn" data-target="' . esc_attr( $id ) . '">' . esc_html( $button ) . '</button> <button type="button" class="button dlz-media-gallery-remove" data-target="' . esc_attr( $id ) . '">حذف همه</button>';
        static $gallery_printed = false;
        if ( ! $gallery_printed ) { $gallery_printed = true; add_action( 'admin_footer', array( $this, 'media_script' ) ); }
    }
    public function media_script() { ?>
        <script>(function(){function esc(s){return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');}function openSingle(btn){var target=btn.getAttribute('data-target'),frame=wp.media({title:'انتخاب تصویر',button:{text:'استفاده از تصویر'},multiple:false,library:{type:'image'}});frame.on('select',function(){var a=frame.state().get('selection').first().toJSON(),i=document.getElementById(target),p=document.getElementById(target+'_preview');i.value=a.url;p.innerHTML='<img src="'+esc(a.url)+'" style="max-width:260px;max-height:150px;display:block;margin:8px 0;border-radius:10px;object-fit:cover;">';});frame.open();}function openGallery(btn){var target=btn.getAttribute('data-target'),input=document.getElementById(target),preview=document.getElementById(target+'_preview'),existing=[];try{existing=JSON.parse(input.value||'[]');}catch(e){existing=[];}if(!Array.isArray(existing)){existing=[];}var frame=wp.media({title:'انتخاب تصاویر خودرو',button:{text:'افزودن تصاویر انتخاب‌شده'},multiple:true,library:{type:'image'}});frame.on('select',function(){var urls=existing.slice();frame.state().get('selection').each(function(a){var d=a.toJSON();if(d.url && urls.indexOf(d.url)===-1){urls.push(d.url);}});input.value=JSON.stringify(urls);renderGalleryPreview(preview,urls);});frame.open();}function renderGalleryPreview(p,urls){p.innerHTML=urls.map(function(u,i){return '<div class="dlz-gallery-preview" style="position:relative;"><img src="'+esc(u)+'" style="width:150px;height:90px;display:block;border-radius:10px;object-fit:cover;"><button type="button" class="button-link dlz-gallery-remove-one" data-index="'+i+'" style="position:absolute;top:3px;right:3px;background:#b32d2e;color:#fff;padding:2px 6px;border-radius:4px;text-decoration:none;">حذف</button></div>';}).join('');}document.addEventListener('click',function(e){if(e.target.classList.contains('dlz-media-btn')){e.preventDefault();openSingle(e.target);}if(e.target.classList.contains('dlz-media-remove')){e.preventDefault();var t=e.target.getAttribute('data-target');document.getElementById(t).value='';document.getElementById(t+'_preview').innerHTML='';}if(e.target.classList.contains('dlz-media-gallery-btn')){e.preventDefault();openGallery(e.target);}if(e.target.classList.contains('dlz-gallery-remove-one')){e.preventDefault();var wrap=e.target.closest('.dlz-gallery-preview'),p=wrap.parentNode,t=p.getAttribute('id').replace('_preview',''),arr=[];try{arr=JSON.parse(document.getElementById(t).value||'[]');}catch(x){arr=[];}var idx=parseInt(e.target.getAttribute('data-index')||'-1',10);if(idx>=0&&idx<arr.length){arr.splice(idx,1);document.getElementById(t).value=JSON.stringify(arr);renderGalleryPreview(p,arr);}}if(e.target.classList.contains('dlz-media-gallery-remove')){e.preventDefault();var t=e.target.getAttribute('data-target');document.getElementById(t).value='[]';document.getElementById(t+'_preview').innerHTML='';}});})();</script>
        <?php }
    public function save_taxi( $post_id ) {
        if ( ! isset( $_POST['dlz_taxi_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['dlz_taxi_nonce'] ) ), 'dlz_save_taxi' ) ) { return; }
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) { return; }
        if ( ! current_user_can( 'edit_post', $post_id ) ) { return; }
        $name = isset( $_POST['dlz_driver_name'] ) ? sanitize_text_field( wp_unslash( $_POST['dlz_driver_name'] ) ) : '';
        if ( $name && get_the_title( $post_id ) !== $name ) { remove_action( 'save_post_dlz_taxi_driver', array( $this, 'save_taxi' ) ); wp_update_post( array( 'ID' => $post_id, 'post_title' => $name ) ); add_action( 'save_post_dlz_taxi_driver', array( $this, 'save_taxi' ) ); }
        foreach ( array( 'card_image','info_image' ) as $key ) { update_post_meta( $post_id, '_dlz_' . $key, isset( $_POST['dlz_' . $key] ) ? esc_url_raw( wp_unslash( $_POST['dlz_' . $key] ) ) : '' ); }
        $gallery_raw = isset( $_POST['dlz_car_images'] ) ? wp_unslash( $_POST['dlz_car_images'] ) : '[]';
        $gallery = json_decode( $gallery_raw, true );
        if ( ! is_array( $gallery ) ) { $gallery = array(); }
        $gallery = array_values( array_filter( array_map( 'esc_url_raw', $gallery ) ) );
        update_post_meta( $post_id, '_dlz_car_images', $gallery );
        update_post_meta( $post_id, '_dlz_car_image', ! empty( $gallery ) ? $gallery[0] : '' );
        update_post_meta( $post_id, '_dlz_model', isset( $_POST['dlz_model'] ) ? sanitize_text_field( wp_unslash( $_POST['dlz_model'] ) ) : '' );
        update_post_meta( $post_id, '_dlz_seats', isset( $_POST['dlz_seats'] ) ? min( 60, absint( $_POST['dlz_seats'] ) ) : 0 );
        $feats = isset( $_POST['dlz_features'] ) ? array_map( 'sanitize_key', (array) wp_unslash( $_POST['dlz_features'] ) ) : array();
        update_post_meta( $post_id, '_dlz_features', array_values( array_intersect( $feats, array_keys( DLZ_Taxi_Frontend::features() ) ) ) );
        foreach ( array( 'price_8','price_24' ) as $key ) { update_post_meta( $post_id, '_dlz_' . $key, isset( $_POST['dlz_' . $key] ) ? sanitize_text_field( wp_unslash( $_POST['dlz_' . $key] ) ) : '' ); }
    }
    public function booking_box( $post ) {
        $fields = array( 'taxi_title' => 'تاکسی', 'service' => 'نوع سرویس', 'price' => 'قیمت', 'customer_name' => 'نام مشتری', 'customer_phone' => 'شماره تلفن', 'created' => 'زمان ثبت' );
        echo '<table class="form-table"><tbody>'; foreach ( $fields as $key => $label ) { $value = get_post_meta( $post->ID, '_dlz_' . $key, true ); echo '<tr><th>' . esc_html( $label ) . '</th><td>' . esc_html( $value ? $value : '—' ) . '</td></tr>'; } echo '</tbody></table>';
    }
    public function columns( $columns ) { return array( 'cb' => isset( $columns['cb'] ) ? $columns['cb'] : '<input type="checkbox" />', 'title' => 'رزرو', 'taxi' => 'تاکسی', 'service' => 'سرویس', 'price' => 'قیمت', 'customer' => 'نام مشتری', 'phone' => 'شماره تلفن', 'date' => 'تاریخ ثبت' ); }
    public function column_content( $column, $post_id ) { $map = array( 'taxi'=>'taxi_title','service'=>'service','price'=>'price','customer'=>'customer_name','phone'=>'customer_phone' ); if ( isset( $map[$column] ) ) { echo esc_html( get_post_meta( $post_id, '_dlz_' . $map[$column], true ) ?: '—' ); } }
}
