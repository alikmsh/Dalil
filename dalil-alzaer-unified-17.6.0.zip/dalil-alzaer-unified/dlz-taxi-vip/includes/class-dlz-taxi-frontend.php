<?php
/**
 * «تاكسي VIP» — front end (green · gold · cream, app-like bottom sheet).
 *
 * Cards → one bottom sheet with three steps: التفاصيل · القوانين · التأكيد.
 * Used by the Elementor widget and by the [dlz_taxi_vip] shortcode.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

class DLZ_Taxi_Frontend {
	private static $instance = null;
	private static $assets   = false;

	public static function instance() {
		if ( null === self::$instance ) { self::$instance = new self(); }
		return self::$instance;
	}

	private function __construct() {
		add_action( 'init', function () { add_shortcode( 'dlz_taxi_vip', array( __CLASS__, 'render' ) ); } );
		add_action( 'wp_enqueue_scripts', array( $this, 'register' ) );
	}

	/** Registered everywhere, loaded only on pages that show taxis. */
	public function register() {
		wp_register_script( 'dlz-taxi-frontend', DLZ_TAXI_URL . 'assets/js/taxi.js', array(), DLZ_TAXI_VERSION, true );
	}

	private static function assets() {
		if ( self::$assets ) { return ''; }
		self::$assets = true;
		if ( ! wp_script_is( 'dlz-taxi-frontend', 'registered' ) ) {
			wp_register_script( 'dlz-taxi-frontend', DLZ_TAXI_URL . 'assets/js/taxi.js', array(), DLZ_TAXI_VERSION, true );
		}
		$p = array(
			'ajax_url' => admin_url( 'admin-ajax.php' ),
			'nonce'    => wp_create_nonce( 'dlz_taxi_booking' ),
			'orders'   => class_exists( 'DLZ_App_Shell' ) ? (string) DLZ_App_Shell::links()['orders'] : '',
			'login'    => function_exists( 'dlz_profile_url' ) ? dlz_profile_url() : wp_login_url(),
			'logged'   => is_user_logged_in() ? 1 : 0,
		);
		if ( is_user_logged_in() ) {
			$uid  = get_current_user_id();
			$name = trim( (string) get_user_meta( $uid, 'mp_full_name', true ) );
			if ( '' === $name ) {
				$name = trim( get_user_meta( $uid, 'first_name', true ) . ' ' . get_user_meta( $uid, 'last_name', true ) );
			}
			$phone = (string) get_user_meta( $uid, 'mp_sms_phone', true );
			if ( '' === $phone ) {
				$phone = (string) get_user_meta( $uid, 'mp_intl_phone', true );
			}
			$p['name']  = $name;
			$p['phone'] = $phone;
		}
		wp_localize_script( 'dlz-taxi-frontend', 'DLZTaxi', $p );
		wp_enqueue_script( 'dlz-taxi-frontend' );
		if ( function_exists( 'dlz_inline_css' ) ) {
			return dlz_inline_css( 'dlz-taxi', DLZ_TAXI_PATH . 'assets/css/taxi.css' );
		}
		wp_enqueue_style( 'dlz-taxi-frontend', DLZ_TAXI_URL . 'assets/css/taxi.css', array(), DLZ_TAXI_VERSION );
		return '';
	}

	public static function icon( $n ) {
		$p = array(
			'clock'  => '<circle cx="12" cy="12" r="8.2"/><path d="M12 7.6V12l3 1.9"/>',
			'day'    => '<circle cx="12" cy="12" r="8.2"/><path d="M12 3.8v2M12 18.2v2M3.8 12h2M18.2 12h2"/><path d="M12 8.4V12l2.4 2.4"/>',
			'cal'    => '<rect x="4" y="5.5" width="16" height="14.5" rx="2.5"/><path d="M4 10h16M8.5 3.5v4M15.5 3.5v4"/>',
			'pin'    => '<path d="M12 21.2s-6.6-6.1-6.6-11.2a6.6 6.6 0 0 1 13.2 0c0 5.1-6.6 11.2-6.6 11.2z"/><circle cx="12" cy="10" r="2.5"/>',
			'route'  => '<circle cx="6.5" cy="17.5" r="2.3"/><circle cx="17.5" cy="6.5" r="2.3"/><path d="M8.8 17.5h6.7a3 3 0 0 0 0-6h-7a3 3 0 0 1 0-6h6.7"/>',
			'bell'   => '<path d="M6.5 16.5V11a5.5 5.5 0 0 1 11 0v5.5l1.5 1.8H5z"/><path d="M10 20.5a2.2 2.2 0 0 0 4 0"/>',
			'user'   => '<circle cx="12" cy="8.2" r="3.9"/><path d="M4.6 20.2c.7-4 3.6-6.3 7.4-6.3s6.7 2.3 7.4 6.3"/>',
			'seat'   => '<path d="M7 4.5h5a2 2 0 0 1 2 2V13h3.5a2 2 0 0 1 2 2v4.5"/><path d="M7 4.5V15h7M7 19.5V15"/>',
			'snow'   => '<path d="M12 3v18M4.2 7.5l15.6 9M19.8 7.5l-15.6 9"/><path d="m9.5 4.5 2.5 2 2.5-2M9.5 19.5l2.5-2 2.5 2"/>',
			'wifi'   => '<path d="M3.5 9.5a12 12 0 0 1 17 0M6.5 12.6a7.6 7.6 0 0 1 11 0M9.4 15.6a3.4 3.4 0 0 1 5.2 0"/><circle cx="12" cy="18.6" r="1.1" fill="currentColor"/>',
			'lang'   => '<path d="M4.5 6.5h9M9 4.5v2c0 4-2 7.5-5 9M6.5 10.5c1.3 2.2 3.4 4 6 5"/><path d="m13 20 3.5-8.5L20 20M14.3 17h4.4"/>',
			'water'  => '<path d="M12 3.5s-6 6.6-6 10.7a6 6 0 0 0 12 0C18 10.1 12 3.5 12 3.5z"/>',
			'shield' => '<path d="M12 3.5 5 6.2v5.3c0 4.4 3 7.7 7 9 4-1.3 7-4.6 7-9V6.2z"/><path d="m9 12 2.2 2.2L15.2 10"/>',
			'phone'  => '<path d="M6.6 3.8h2.6l1.4 4-2 1.3a11 11 0 0 0 6.3 6.3l1.3-2 4 1.4v2.6a2 2 0 0 1-2.1 2A16.5 16.5 0 0 1 4.6 5.9a2 2 0 0 1 2-2.1z"/>',
			'check'  => '<path d="m5 12.5 4.5 4.5L19 7.5"/>',
			'close'  => '<path d="M6.5 6.5l11 11M17.5 6.5l-11 11"/>',
			'back'   => '<path d="m9.5 6 6 6-6 6"/>',
			'fwd'    => '<path d="m14.5 6-6 6 6 6"/>',
			'car'    => '<path d="M5 16V11l2-5h10l2 5v5M3.5 16h17M5 11h14"/><circle cx="7.5" cy="16.5" r="1.7"/><circle cx="16.5" cy="16.5" r="1.7"/>',
			'photo'  => '<rect x="3.5" y="5.5" width="17" height="13" rx="2.5"/><circle cx="9" cy="10.5" r="1.8"/><path d="m4 17 5-4.5 3.5 3 3-2.5L20 17"/>',
			'list'   => '<rect x="5" y="3.5" width="14" height="17" rx="2.5"/><path d="M9 3.5h6v2.5H9zM8.5 10.5h7M8.5 14h7M8.5 17.5h4"/>',
			'info'   => '<circle cx="12" cy="12" r="8.2"/><path d="M12 11v5.2M12 7.8v.4"/>',
		);
		return '<svg class="dtx-i" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . ( isset( $p[ $n ] ) ? $p[ $n ] : '' ) . '</svg>';
	}

	/** Feature catalogue (admin ticks them per taxi). */
	public static function features() {
		return array(
			'ac'     => array( 'تكييف', 'snow' ),
			'wifi'   => array( 'واي فاي', 'wifi' ),
			'arabic' => array( 'سائق يتحدث العربية', 'lang' ),
			'water'  => array( 'مياه مجانية', 'water' ),
			'safe'   => array( 'سائق موثوق', 'shield' ),
		);
	}

	public static function render( $atts = array() ) {
		$q = new WP_Query( array(
			'post_type'      => 'dlz_taxi_driver',
			'post_status'    => 'publish',
			'posts_per_page' => 50,
			'orderby'        => array( 'menu_order' => 'ASC', 'date' => 'DESC' ),
			'no_found_rows'  => true,
		) );
		static $n = 0;
		$n++;
		$feats = self::features();
		ob_start();
		echo self::assets(); // phpcs:ignore
		echo '<div class="dtx" id="dtx-' . (int) $n . '" dir="rtl">';
		if ( ! $q->have_posts() ) {
			echo '<div class="dtx-empty"><span>' . self::icon( 'car' ) . '</span><b>لا توجد سيارات متاحة حالياً</b><p>سيتم إضافة السيارات قريباً، تواصل مع الدعم لأي استفسار.</p></div></div>'; // phpcs:ignore
			return ob_get_clean();
		}
		echo '<div class="dtx-list">';
		$i = 0;
		while ( $q->have_posts() ) {
			$q->the_post();
			$id    = get_the_ID();
			$title = get_the_title();
			$imgs  = get_post_meta( $id, '_dlz_car_images', true );
			$imgs  = is_array( $imgs ) ? array_values( array_filter( array_map( 'esc_url_raw', $imgs ) ) ) : array();
			$car   = (string) get_post_meta( $id, '_dlz_car_image', true );
			$card  = (string) get_post_meta( $id, '_dlz_card_image', true );
			if ( ! $imgs && $car ) { $imgs = array( $car ); }
			$cover = $imgs ? $imgs[0] : $card;
			if ( ! $imgs && $card ) { $imgs = array( $card ); }
			$p8    = trim( (string) get_post_meta( $id, '_dlz_price_8', true ) );
			$p8    = class_exists( 'DLZ_Money' ) ? DLZ_Money::text( $p8 ) : $p8;
			$p24   = trim( (string) get_post_meta( $id, '_dlz_price_24', true ) );
			$p24   = class_exists( 'DLZ_Money' ) ? DLZ_Money::text( $p24 ) : $p24;
			$model = trim( (string) get_post_meta( $id, '_dlz_model', true ) );
			$seats = (int) get_post_meta( $id, '_dlz_seats', true );
			$fk    = get_post_meta( $id, '_dlz_features', true );
			$fk    = is_array( $fk ) ? array_values( array_intersect( $fk, array_keys( $feats ) ) ) : array();
			$info  = (string) get_post_meta( $id, '_dlz_info_image', true );
			$from  = $p8 ? $p8 : $p24;
			$data  = array(
				'id'    => $id,
				'title' => $title,
				'model' => $model,
				'imgs'  => $imgs,
				'info'  => $info,
				'p8'    => $p8,
				'p24'   => $p24,
			);
			echo '<article class="dtx-card" style="--d:' . (int) min( $i++, 6 ) * 60 . 'ms">';
			echo '<button type="button" class="dtx-open" data-taxi="' . esc_attr( wp_json_encode( $data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) ) . '" aria-label="' . esc_attr( 'تفاصيل ' . ( $model ? $model : $title ) ) . '">';
			echo '<span class="dtx-media">' . ( $cover ? '<img src="' . esc_url( $cover ) . '" alt="" loading="' . ( $i > 2 ? 'lazy' : 'eager' ) . '" decoding="async">' : self::icon( 'car' ) ) . '<em class="dtx-vip">VIP</em>' . ( count( $imgs ) > 1 ? '<em class="dtx-count">' . self::icon( 'photo' ) . count( $imgs ) . '</em>' : '' ) . '</span>'; // phpcs:ignore
			echo '<span class="dtx-body"><span class="dtx-row"><span class="dtx-t"><b>' . esc_html( $model ? $model : $title ) . '</b>';
			echo '<small>' . self::icon( 'user' ) . esc_html( $model ? 'السائق: ' . $title : 'سيارة خاصة مع سائق' ) . '</small></span>'; // phpcs:ignore
			if ( $from ) {
				echo '<span class="dtx-from"><small>ابتداءً من</small><b dir="auto">' . esc_html( $from ) . '</b></span>';
			}
			echo '</span><span class="dtx-tags">';
			if ( $p8 ) { echo '<i>' . self::icon( 'clock' ) . '8 ساعات</i>'; } // phpcs:ignore
			if ( $p24 ) { echo '<i>' . self::icon( 'day' ) . '24 ساعة</i>'; } // phpcs:ignore
			if ( $seats ) { echo '<i>' . self::icon( 'seat' ) . (int) $seats . ' مقاعد</i>'; } // phpcs:ignore
			foreach ( array_slice( $fk, 0, 3 ) as $k ) { echo '<i>' . self::icon( $feats[ $k ][1] ) . esc_html( $feats[ $k ][0] ) . '</i>'; } // phpcs:ignore
			echo '</span><span class="dtx-cta">احجز الآن' . self::icon( 'fwd' ) . '</span></span></button></article>'; // phpcs:ignore
		}
		wp_reset_postdata();
		echo '</div>';

		// the sheet (filled by JS)
		$rules = array(
			array( 'cal', 'مدة الحجز', 'يجب أن تكون مدة الحجز يومين على الأقل.' ),
			array( 'pin', 'نطاق الخدمة', 'الخدمة متاحة داخل حدود المدينة فقط.' ),
			array( 'route', 'عدد الرحلات', 'الحد الأقصى أربع رحلات ذهاباً وإياباً في اليوم.' ),
			array( 'bell', 'التنسيق المسبق', 'يجب إبلاغنا باحتياج السفر قبل 30 دقيقة على الأقل.' ),
		);
		echo '<div class="dtx-ov" hidden><div class="dtx-sheet" role="dialog" aria-modal="true" aria-label="حجز تاكسي VIP" tabindex="-1">';
		echo '<div class="dtx-grab" aria-hidden="true"></div>';
		echo '<header class="dtx-sh-head"><button type="button" class="dtx-back" aria-label="رجوع" hidden>' . self::icon( 'back' ) . '</button><div class="dtx-sh-t"><b class="dtx-sh-title">تاكسي VIP</b><ol class="dtx-steps"><li class="is-on">التفاصيل</li><li>القوانين</li><li>التأكيد</li></ol></div><button type="button" class="dtx-x" aria-label="إغلاق">' . self::icon( 'close' ) . '</button></header>'; // phpcs:ignore
		echo '<div class="dtx-sh-body">';

		// step 1 — details
		echo '<section class="dtx-step" data-step="1">';
		echo '<div class="dtx-gal"><div class="dtx-gal-track"></div><div class="dtx-dots"></div></div>';
		echo '<div class="dtx-name"><b></b><small></small></div>';
		echo '<h4 class="dtx-h">اختر مدة الخدمة</h4><div class="dtx-svc" role="radiogroup">';
		echo '<button type="button" class="dtx-opt" data-service="8" role="radio"><span class="dtx-opt-ic">' . self::icon( 'clock' ) . '</span><span class="dtx-opt-t"><b>خدمة 8 ساعات</b><small>نصف يوم مع السائق</small></span><span class="dtx-opt-p" dir="auto"></span><span class="dtx-opt-ok">' . self::icon( 'check' ) . '</span></button>'; // phpcs:ignore
		echo '<button type="button" class="dtx-opt" data-service="24" role="radio"><span class="dtx-opt-ic">' . self::icon( 'day' ) . '</span><span class="dtx-opt-t"><b>خدمة 24 ساعة</b><small>يوم كامل مع السائق</small></span><span class="dtx-opt-p" dir="auto"></span><span class="dtx-opt-ok">' . self::icon( 'check' ) . '</span></button>'; // phpcs:ignore
		echo '</div><div class="dtx-info" hidden><h4 class="dtx-h">' . self::icon( 'info' ) . 'معلومات السائق ومجال الخدمة</h4><img alt="معلومات السائق ومجال الخدمة" loading="lazy" decoding="async"></div>'; // phpcs:ignore
		echo '<ul class="dtx-trust"><li>' . self::icon( 'shield' ) . 'حجز آمن</li><li>' . self::icon( 'phone' ) . 'دعم على مدار الساعة</li></ul>'; // phpcs:ignore
		echo '</section>';

		// step 2 — rules
		echo '<section class="dtx-step" data-step="2" hidden><p class="dtx-lead">يرجى قراءة قوانين السفر والموافقة عليها قبل إتمام الحجز</p><ol class="dtx-rules">';
		foreach ( $rules as $r ) {
			echo '<li><span>' . self::icon( $r[0] ) . '</span><div><b>' . esc_html( $r[1] ) . '</b><p>' . esc_html( $r[2] ) . '</p></div></li>'; // phpcs:ignore
		}
		echo '</ol><label class="dtx-agree"><input type="checkbox" class="dtx-agree-in"><span class="dtx-box">' . self::icon( 'check' ) . '</span><span>أوافق على قوانين السفر وأرغب في متابعة الحجز</span></label></section>'; // phpcs:ignore

		// step 3 — confirm
		echo '<section class="dtx-step" data-step="3" hidden><div class="dtx-sum"><img alt="" decoding="async"><div><small>ملخص الطلب</small><b class="dtx-sum-t"></b><span class="dtx-sum-s"></span></div><strong class="dtx-sum-p" dir="auto"></strong></div>';
		echo '<form class="dtx-form" novalidate><label class="dtx-f"><span>الاسم الكامل</span><span class="dtx-in">' . self::icon( 'user' ) . '<input class="dtx-name-in" name="customer_name" type="text" autocomplete="name" maxlength="80" required></span></label>'; // phpcs:ignore
		echo '<label class="dtx-f"><span>رقم الهاتف</span><span class="dtx-in">' . self::icon( 'phone' ) . '<input class="dtx-phone-in" name="customer_phone" type="tel" autocomplete="tel" inputmode="tel" dir="ltr" maxlength="30" required></span></label>'; // phpcs:ignore
		echo '<p class="dtx-note">' . self::icon( 'info' ) . 'سيتواصل معك فريق «دليل الزائر» لتأكيد الحجز وتفاصيل الاستقبال.</p></form></section>'; // phpcs:ignore

		// done
		echo '<section class="dtx-step dtx-done" data-step="4" hidden><span class="dtx-done-ic">' . self::icon( 'check' ) . '</span><b>تم إرسال طلب الحجز</b><p class="dtx-done-m">سيتواصل معك المسؤول قريباً لتأكيد الحجز.</p></section>'; // phpcs:ignore

		echo '</div><footer class="dtx-sh-foot"><p class="dtx-msg" role="alert" aria-live="polite"></p><button type="button" class="dtx-go"><span>متابعة</span>' . self::icon( 'fwd' ) . '</button></footer>'; // phpcs:ignore
		echo '</div></div></div>';
		return ob_get_clean();
	}
}
