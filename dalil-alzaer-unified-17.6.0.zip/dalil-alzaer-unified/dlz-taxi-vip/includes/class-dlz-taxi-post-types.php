<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
class DLZ_Taxi_Post_Types {
    private static $instance = null;
    public static function instance() {
        if ( null === self::$instance ) { self::$instance = new self(); }
        return self::$instance;
    }
    private function __construct() { add_action( 'init', array( $this, 'register' ) ); }
    public function register() { self::register_static(); }
    public static function register_static() {
        register_post_type( 'dlz_taxi_driver', array(
            'labels' => array(
                'name' => 'تاکسی‌ها', 'singular_name' => 'تاکسی', 'add_new' => 'افزودن تاکسی', 'add_new_item' => 'افزودن تاکسی جدید',
                'edit_item' => 'ویرایش تاکسی', 'new_item' => 'تاکسی جدید', 'view_item' => 'مشاهده تاکسی', 'search_items' => 'جستجوی تاکسی',
                'not_found' => 'تاکسی یافت نشد', 'menu_name' => 'تاکسی‌ها'
            ),
            'public' => false, 'show_ui' => true, 'show_in_menu' => false, 'supports' => array( 'title' ),
            'capability_type' => 'post', 'map_meta_cap' => true
        ) );
        register_post_type( 'dlz_taxi_booking', array(
            'labels' => array(
                'name' => 'رزروهای تاکسی', 'singular_name' => 'رزرو تاکسی', 'edit_item' => 'مشاهده رزرو', 'view_item' => 'مشاهده رزرو',
                'search_items' => 'جستجوی رزرو', 'not_found' => 'رزروی یافت نشد', 'menu_name' => 'رزروها'
            ),
            'public' => false, 'show_ui' => true, 'show_in_menu' => false, 'supports' => array( 'title' ),
            'capabilities' => array( 'create_posts' => 'do_not_allow' ), 'map_meta_cap' => true
        ) );
    }
    public static function activate() { self::register_static(); flush_rewrite_rules(); }
    public static function deactivate() { flush_rewrite_rules(); }
}
